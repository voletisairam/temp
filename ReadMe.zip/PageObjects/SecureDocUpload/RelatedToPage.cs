﻿using CSW.Common.Others;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CSW.PageObjects.SecureDocUpload
{
    class RelatedToPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public RelatedToPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////
        /////////    Upload Document Securely ///////////////////
        //////////////////////////////////////////////////////////


        //Upload my documents
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Upload my documents')]")]
        public IWebElement Uploadmydocuments { get; set; }

        //Upload documents securely
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Upload documents securely')]")]
        public IWebElement UploadDocumentSecurelyInfoPageTitle { get; set; }

        //Back to previous page link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to previous page')]")]
        public IWebElement BackToPreviousPage { get; set; }

        //Upload Document Related to
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'I need to upload a document related to a ...')]")]
        public IWebElement UploadDocumentRelatedtoHeader { get; set; }

        //Existing Contract/Certificate
        [FindsBy(How = How.XPath, Using = "//label[@for='DepartmentOther' and contains(@class, 'btn')]")]
        public IWebElement ExistingUserAccountsSheet_Certificate { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='DepartmentClaim' and contains(@class, 'btn')]")]
        public IWebElement Claim { get; set; }


        [FindsBy(How = How.XPath, Using = "(//*[contains(text(), 'Log in')])[1]")]
        public IWebElement LoginButton { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifySecureDocumentOptionPage                                                             ////////////
        ////// Description: Verify Upload Documents Securely details page fields availability and options       ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void VerifyUploadDocumentSecurelyInformation()
        {
            NYLDSelenium.AddHeader("Verify Upload Documents Relted to Existing Contract/Certificate (Or) Claim", "SubHeader");
            Thread.Sleep(3000);
            NYLDSelenium.PageLoad("Upload Documents Securely Related to", UploadDocumentSecurelyInfoPageTitle,"always","always",true);
            string UploadDocumentRelated = NYLDSelenium.GetAttribute("Upload Documents Securely", UploadDocumentRelatedtoHeader);
            NYLDSelenium.VerifyText("Secure Document Upload Related to a...", "I need to upload a document related to a ...".Trim(), UploadDocumentRelated.Trim());

            NYLDSelenium.VerifyText("Secure Document Upload Option 1", "Existing Contract/Certificate", NYLDSelenium.GetAttribute("Secure Document Upload Option 1", ExistingUserAccountsSheet_Certificate));
            NYLDSelenium.VerifyText("Secure Document Upload Option 2", "Claim", NYLDSelenium.GetAttribute("Secure Document Upload Option 2", Claim));

            NYLDSelenium.ElemExist("Secure Document Option1", ExistingUserAccountsSheet_Certificate);
            NYLDSelenium.ElemExist("Secure Document Option2", Claim);

            NYLDSelenium.AddHeader("Verify Upload Documents Relted to Existing Contract/Certificate (Or) Claim", "Success");
        }

        /// <summary>
        /// /Method helps to select the secure doc upload
        /// </summary>
        /// <param name="args"></param>
        public void PerformSecureDocUpload(string args)
        {
            NYLDSelenium.Click("Upload my documents", Uploadmydocuments, true);
        }

        /// <summary>
        /// Method helps to Select Secure Doc upload Option
        /// </summary>
        /// <param name="args"></param>
        public void SelectSecureDocumentUploadOption(string args)
        {
            QuickLinksPage SDUQL = new QuickLinksPage(driver, data);
            if (data[KeyRepository.UserAccountStatus] != "New" || data[KeyRepository.ContractType]== "SecureDocUpload")
            {
                if (NYLDSelenium.ElemExist("Upload my documents", Uploadmydocuments,true,"no","no","no"))
                {
                    //NYLDSelenium.ScrollToView(Uploadmydocuments, true);
                    NYLDSelenium.Click("Upload my documents", Uploadmydocuments,true);
                }
            }

            //Field Validations
            VerifyUploadDocumentSecurelyInformation();

            //validate the Quick links
            SDUQL.VerifyUploadDocumentSecurelyQuickLinks();
            SDUQL.ValidateSecureDocumentUploadQuickLinks();

            string[] option = args.Split(',');

           // NYLDSelenium.PageLoad("Upload documents securely Related to..", UploadDocumentSecurelyInfoPageTitle);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Select " + option[0].Trim() + " field for Upload Document Securely" + " </h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO", "no");
          

            //Select Document Related to
            switch (option[0].Trim())
            {
                case "Certificate":
                    NYLDSelenium.Click("Secure Document "+option[0].Trim(), ExistingUserAccountsSheet_Certificate,true,"always");
                    break;
                case "Claim":
                    NYLDSelenium.Click("Secure Document "+option[0].Trim(), Claim, true, "always");
                    break;
            }

        }

        /// <summary>
        /// Method helps to select the policy from the dropdown list
        /// </summary>
        /// <param name="args"></param>
        public void PerformSecureDocUploadSelectPolicy(string args)
        {
            CommonFunctions SecDocUploadMultContract = new CommonFunctions(data);
            //if User more than one contract then choose the existing contract (User login)
            SecDocUploadMultContract.SelectPolicy(args);
            NYLDSelenium.Click("Continue", ContinueBtn);
        }
    }
}
