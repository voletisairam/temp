﻿using CSW.Common.Others;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using PasswordEncryptDecrpt;
using SeleniumExtras.PageObjects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CSW.PageObjects.SecureDocUpload
{
    class QuickLinksPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public QuickLinksPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////
        /////////    Upload Document Securely - Quick Links ///////////////////
        //////////////////////////////////////////////////////////


        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Document upload FAQ')]")]
        public IWebElement DocumentuploadFAQ { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Manage beneficiaries')]")]
        public IWebElement Managebeneficiaries { get; set; }


        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Update my address')]")]
        public IWebElement Updatemyaddress { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Online easy pay')]")]
        public IWebElement Onlineeasypay { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Report a claim')]")]
        public IWebElement Reportaclaim { get; set; }

        public string QuickLinks = "//*[@class='pl-2']/li/a";

        //Upload documents securely
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Upload documents securely')]")]
        public IWebElement UploadDocumentSecurelyInfoPageTitle { get; set; }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifySecureDocumentOptionPage                                                             ////////////
        ////// Description: Verify Upload Documents Securely Quick Links     ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void VerifyUploadDocumentSecurelyQuickLinks()
        {

            NYLDSelenium.AddHeader("Verify Upload Documents Securely Quick Links..", "SubHeader");
            NYLDSelenium.PageLoad("Upload Documents Securely Quick Links", UploadDocumentSecurelyInfoPageTitle);

            NYLDSelenium.VerifyText("Document upload FAQ", "Document upload FAQ", NYLDSelenium.GetAttribute("Document upload FAQ", DocumentuploadFAQ));
            NYLDSelenium.VerifyText("Manage beneficiaries", "Manage beneficiaries", NYLDSelenium.GetAttribute("Manage beneficiaries", Managebeneficiaries));
            NYLDSelenium.VerifyText("Update my address", "Update my address", NYLDSelenium.GetAttribute("Update my address", Updatemyaddress));
            NYLDSelenium.VerifyText("Online easy pay", "Online easy pay", NYLDSelenium.GetAttribute("Online easy pay", Onlineeasypay));
            NYLDSelenium.VerifyText("Report a claim", "Report a claim", NYLDSelenium.GetAttribute("Report a claim", Reportaclaim));
            NYLDSelenium.ElemExist("Upload Documents Securely Quick Links", UploadDocumentSecurelyInfoPageTitle);

            NYLDSelenium.AddHeader("Verify Upload Documents Securely Quick Links..", "Success");
        }

        /// <summary>
        /// Method helps to validate the quicllinks passing a paramter like pagename,element
        /// </summary>
        public void ValidateSecureDocumentUploadQuickLinks()
        {
            CommonFunctions CF = new CommonFunctions(data);           
            CF.ValidateIWantToLinks("SecureDocUpload Page", QuickLinks);
        }


        public bool IsLinkWorking(string url, string Text)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                   | SecurityProtocolType.Tls11
                   | SecurityProtocolType.Tls12
                   | SecurityProtocolType.Ssl3;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            //You can set some parameters in the "request" object...
            request.UseDefaultCredentials = true;
            request.PreAuthenticate = true;
            request.Credentials = new NetworkCredential(Properties.Settings.Default.MuleServiceUserName, PasswordDecrypter.Decrypt(Properties.Settings.Default.MuleServicePassword));
            request.AllowAutoRedirect = true;

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {

                    // Releases the resources of the response.
                    response.Close();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                //TODO: Check for the right exception here
                NYLDSelenium.ReportStepResult("Secure Document Upload--Quick Link", "Secure Document Upload--Quick Link :" + Text + " is not working", "FAIL", "always");
                return false;
            }
        }

    }
}
