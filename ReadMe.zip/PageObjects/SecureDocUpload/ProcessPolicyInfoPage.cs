﻿using CSW.Common.Excel;
using CSW.Common.Others;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.PageObjects.SecureDocUpload
{
    class ProcessPolicyInfoPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ProcessPolicyInfoPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Light Authentication
        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'upload')]")]
        public IWebElement UploadPage1 { get; set; }



        //  Create an Account Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Create your account')]")]
        public IWebElement CreateAccountInstruction { get; set; }


        //Registration Page1
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),' Please provide the following policy holder information to continue')]")]
        public IWebElement PageHeading { get; set; }

        //Last Name LAbel
        [FindsBy(How = How.Id, Using = "lblLastName")]
        public IWebElement LastNameLabel { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement LastName { get; set; }

        //Last Name LAbel
        [FindsBy(How = How.Id, Using = "lblDateOfBirth")]
        public IWebElement DOBLabel { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "txtDateOfBirth")]
        public IWebElement DOB { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "lblSsn")]
        public IWebElement SSNLabel { get; set; }

        //SSN
        [FindsBy(How = How.Id, Using = "Ssn")]
        public IWebElement SSN { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//button[text()='Show']")]
        public IWebElement SSNShowBtn { get; set; }

        //Control Number
        [FindsBy(How = How.Id, Using = "txtRegistrationPolicyNumber")]
        public IWebElement ControlNumber { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "(//button[@type='submit'])[2]")]
        public IWebElement ContinueBtn { get; set; }

        public void Page1()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Navigate to process policy info page " + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            NYLDSelenium.Click("Navigate to process policy info Page", UploadPage1);
        }
            public void VerifyDetailsPage()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Your Details Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");


            //Verify if Verify Your Details PAge is loaded
            NYLDSelenium.PageLoad("Registration - Step1", PageHeading);

            //Verify the Labels

            //Last Name Label
            NYLDSelenium.VerifyText("Last name Label", "Last Name", NYLDSelenium.GetAttribute("Last name Label", LastNameLabel));

            //DOB Label
            NYLDSelenium.VerifyText("Date of birth Label", "Date of Birth", NYLDSelenium.GetAttribute("Date of birth Label", DOBLabel));

            //SSN Label
            NYLDSelenium.VerifyText("SSN Label", "Social Security Number", NYLDSelenium.GetAttribute("SSN Label", SSNLabel));

            //Last Name
            NYLDSelenium.ElemExist("Last Name", LastName);

            //DOB 
            NYLDSelenium.ElemExist("DOB", DOB);

            //SSN 
            NYLDSelenium.ElemExist("SSN", SSN);

            //SSN SHow
            NYLDSelenium.ElemExist("SSN Show", SSNShowBtn);

            //Control Number
            NYLDSelenium.ElemExist("Control Number", ControlNumber);


            //Verify SSN Entered

            //Get last 4 digits of SSN
            string SSN4 = data[KeyRepository.SSN];

            //Enter last 4 digits
            NYLDSelenium.SendKeys("SSN", SSN, data[KeyRepository.SSN]);

            //Verify if entered SSN displayed upon Clicking Show Buton
            NYLDSelenium.Click("SSN Show", SSNShowBtn);
            string enteredSSNValue = NYLDSelenium.GetAttribute("Get SSN input", SSN, "value");
            NYLDSelenium.VerifyText("Entered SSN Value", SSN4, enteredSSNValue);

            //Clear SSN
            NYLDSelenium.Clear("SSN", SSN);

        }

        public void FillYourOwnerDetailsPage(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Fill Verify Your Details Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");


            //Verify Registration Page 1 is laoded
            NYLDSelenium.PageLoad("Verify Your Details", PageHeading);


            //Enter Last Name
            NYLDSelenium.SendKeys("Last name", LastName, data[KeyRepository.LastName]);

            //Enter DOB
            NYLDSelenium.SendKeys("Date of birth", DOB, data[KeyRepository.DOB]);

            //Enter SSN

           //Enter SSN
            NYLDSelenium.SendKeys("SSN", SSN, data[KeyRepository.SSN]);

            //Enter Control number
            NYLDSelenium.SendKeys("Control Number", ControlNumber, data[KeyRepository.PolicyNumber]);

            //Click Continue Button
            //NYLDSelenium.ScrollToView(ContinueBtn, true);
            NYLDSelenium.Click("Next", ContinueBtn,true);
        }
    }
}
