﻿using CSW.Common.Others;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.PageObjects.SecureDocUpload
{
    class OptionalEmailPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public OptionalEmailPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////
        /////////    Upload Document Securely ///////////////////
        //////////////////////////////////////////////////////////
        ///


        //Upload documents securely
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Upload documents securely')]")]
        public IWebElement UploadDocumentSecurelyInfoPageTitle { get; set; }

        //Last Name LAbel
        [FindsBy(How = How.Id, Using = "lblEmail")]
        public IWebElement EMailLabel { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "txtEmail")]
        public IWebElement OptionalEmail { get; set; }


        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }


        public void VerifyUploadDocumentSecurelyOptionalEmail()
        {
            NYLDSelenium.AddHeader("Verify Upload Documents Securely - Optional Email page", "SubHeader");
            NYLDSelenium.PageLoad("Upload Documents Securely Related to Optional Email", UploadDocumentSecurelyInfoPageTitle);
            NYLDSelenium.ElemExist("Email label", EMailLabel);
            NYLDSelenium.ElemExist("Optional Email", OptionalEmail);
            NYLDSelenium.ElemExist("ContinueBtn", ContinueBtn);
            NYLDSelenium.AddHeader("Verify Upload Documents Securely - Optional Email page Success", "Success");
        }

        public void SubmitUploadDocumentSecurelyOptionalEmail()
        {
            VerifyUploadDocumentSecurelyOptionalEmail();
            DateTime now = DateTime.Now;
            NYLDSelenium.AddHeader("Submit Upload Documents Securely Optional Email..", "SubHeader");
            NYLDSelenium.SendKeys("Optional Email", OptionalEmail, data[KeyRepository.FirstName] + data[KeyRepository.SSN].Substring(5, 4) + now.Month + now.Day + now.Minute + "@automation.com");
            NYLDSelenium.Click("ContinueBtn", ContinueBtn);
            NYLDSelenium.AddHeader("Submit Upload Documents Securely Optional Email.. Success", "Success");
        }

    }
}
