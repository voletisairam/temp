﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using OpenDialogWindowHandler;
using NYLDWebAutomationFramework;
using System.Threading;
using CSW.Common.Others;
using System.IO;
using System.Globalization;

namespace CSW.PageObjects.SecureDocUpload
{
    class UploadFilePage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;
        private string[] FileTypes = { "doc", "docx", "png", "jpg", "jpeg", "bmp", "gif", "pdf", "tiff" };

        public UploadFilePage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

            /////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////           Page Objects    //////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////////////

            //////////////////////////////////////////////////////////
            /////////    Upload Document Securely - File Upload///////////////////
            //////////////////////////////////////////////////////////

            //Upload documents securely
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Upload documents securely')]")]
        public IWebElement UploadDocumentSecurelyInfoPageTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='lblPolicyNumber']")]
        public IWebElement PolicyHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='col-12 pb-3 text-steel fs-mask']//span")]
        public IWebElement ContractNumber { get; set; }

        //Back to previous page link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to previous page')]")]
        public IWebElement BackToPreviousPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'size is 25mb')]")]
        public IWebElement MaxTotalUploadSize { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Accepted file types:')]")]
        public IWebElement AcceptedFileTypes { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'browse your computer')]")]
        public IWebElement BrowseYourComputer { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='previews' and @class='dz-default dz-message dash-outline dropzone files-container dz-clickable']")]
        public IWebElement DragAndBrowseYourComputer { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='submit' and @id='Submit']")]
        public IWebElement Upload { get; set; }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifySecureDocumentFilesUploadPage                                                             ////////////
        ////// Description: Verify Upload Documents Securely -BrowseYourComputer -Files Upload       ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void VerifyUploadDocumentSecurely_FilesUploadPage()
        {
            try
            {
                NYLDSelenium.AddHeader("Verify Upload Documents Securely - Browse Your Computer..", "SubHeader");

                NYLDSelenium.PageLoad("Upload Documents Securely Related to", UploadDocumentSecurelyInfoPageTitle);

                string UploadDocumentRelated = NYLDSelenium.GetAttribute("Contract / Certificate", PolicyHeader);
                NYLDSelenium.VerifyText("Contract / Certificate", "Contract/Certificate Number:".Trim(), UploadDocumentRelated.Trim());

                NYLDSelenium.VerifyText("Maxium Total Upload size:25MB", "You can upload multiple documents at a time, as long as the total file size is 25mb or less".Trim(), NYLDSelenium.GetAttribute("Maxium Total Upload size:25MB", MaxTotalUploadSize).Trim());
                NYLDSelenium.VerifyText("Accepted file", "Accepted file types:", NYLDSelenium.GetAttribute("Accepted file", AcceptedFileTypes));

                NYLDSelenium.VerifyText("BrowseYourComputer", "browse your computer", NYLDSelenium.GetAttribute("BrowseYourComputer", BrowseYourComputer));
                NYLDSelenium.ElemExist("BrowseYourComputer", DragAndBrowseYourComputer);

                NYLDSelenium.AddHeader("Verify Upload Documents Securely - Browse Your Computer..", "Success");
            }
            catch
            {
                //nothing to do
            }
        }

        /// <summary>
        ///SecureDocumentUpload- Browser Your Computer upload the Files
        /// </summary>
        /// <param name="args"></param>
        public void SelectSecureDocumentUploadFiles(string args)
        {

            //Field Validation
            VerifyUploadDocumentSecurely_FilesUploadPage();

         
            int uploadfilecount = 0; int sleeptime = 0;
            NYLDSelenium.AddHeader("Select " + args.Trim(), "SubHeader");
            NYLDSelenium.VerifyText("Contract/Certificate Number", "Contract/Certificate Number: "+data[KeyRepository.PolicyNumber].Trim(), NYLDSelenium.GetAttribute("Contract/Certificate Number", ContractNumber).Trim());
            string FilesPath = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.SecureDocUploadFilesPath;
            var ext = new List<string> { ".jpg", ".pdf", ".docx" };
            string testFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.TestFileAppData;
            DirectoryInfo d = new DirectoryInfo(FilesPath); //Assuming Test is your Folder

            FileInfo[] Files =d.GetFiles("*.*",SearchOption.AllDirectories).Where(s=>ext.Contains(s.Extension)).OrderBy(p => p.FullName).ToArray();
            FileInfo files = Files[0];
            //Select Document Files Count  to Upload
            switch (args.Trim())
            {
                case "SingleDocument":
                    uploadfilecount = 1; sleeptime = 6000;
                    break;
                case "MultipleDocuments":
                    uploadfilecount = 4; sleeptime = 18000;
                    break;
            }

            if (Files.Count() != 0 && uploadfilecount > 0)
            {
                foreach (FileInfo file in Files)
                {
                    NYLDSelenium.AddHeader("Select " + file, "SubHeader");
                    Thread.Sleep(2000);
                    NYLDSelenium.Click("Browse Your Computer", DragAndBrowseYourComputer,true);
                    Thread.Sleep(100);
                    HandleOpenDialog hndOpen = new HandleOpenDialog();
                    Thread.Sleep(1000);
                    var svalue = FilesPath.Remove(FilesPath.Length - 1, 1);
                    Thread.Sleep(1000);
                    hndOpen.fileOpenDialog(svalue, file.Name);
                    Thread.Sleep(1000);
                    //NYLDSelenium.ScrollToView(Upload, true);
                    Thread.Sleep(1000);

                    fileupload(FilesPath, file);

                    NYLDSelenium.ReportStepResult("Secure Document Upload File", "Secure Document Upload file name--" + file.Name, "PASS");
                    if (args.Trim() == "SingleDocument")
                        break;
                }


                //upload to the application
                if (NYLDSelenium.ElemExist("upload", Upload,true,"no","no","no"))
                {
                    NYLDSelenium.Click("Upload the Files", Upload);
                }
                else
                {
                    fileupload(FilesPath, files);
                    NYLDSelenium.Click("Upload the Files", Upload);
                }

                Thread.Sleep(sleeptime);
                string dtConv = DateTime.Now.AddMinutes(-5).ToString(@"MM/dd/yyyy hh:mm tt");
                TestSetUp.date = DateTime.ParseExact(dtConv, @"MM/dd/yyyy hh:mm tt", new CultureInfo("en-US"));
            }
            else
                NYLDSelenium.ReportStepResult("Secure Document Upload--No Files", "Secure Document Upload--No Files", "FAIL", "always","yes");

        }

        public void fileupload(string FilesPath,FileInfo file)
        {
            for (int v = 0; v <= 4; v++)
            {
                if (driver.FindElement(By.XPath("//input[@type='submit' and @id='Submit']")).Displayed == false)
                {
                    Thread.Sleep(1000);
                    HandleOpenDialog hndOpens = new HandleOpenDialog(); Thread.Sleep(1000);
                    var svalue1 = FilesPath.Remove(FilesPath.Length - 1, 1); Thread.Sleep(1000);
                    hndOpens.fileOpenDialog(svalue1, file.Name);
                    Thread.Sleep(1000);
                    NYLDSelenium.ElemExist("upload",Upload, true);
                    Thread.Sleep(1000);
                }
            }
        }
    }
}
