﻿using CSW.Common.DataBase;
using CSW.Common.Others;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CSW.PageObjects.SecureDocUpload
{
    class MultiPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public MultiPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////
        /////////    Upload Document Securely - Choose the Contract number///////////////////
        //////////////////////////////////////////////////////////

        //Contract Number Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='policy-toggle']")]
        public IWebElement ContractNumberDropdown { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Upload documents securely')]")]
        public IWebElement UploadDocumentSecurelyInfoPageTitle { get; set; }

        //Back to previous page link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to previous page')]")]
        public IWebElement BackToPreviousPage { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[@class='col']//p)[1]")]
        public IWebElement UploadDocumentSecureHeader1 { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[@class='col']//p)[2]")]
        public IWebElement UploadDocumentSecureHeader2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Continue')]")]
        public IWebElement Continue { get; set; }



        public void SelectContract(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Multi Contract Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            string[] PolicyList = { }; string PolicyNumber = "";
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            DB.QueryAssociatedPolicies("Beneficiaries");

            if (CSWData.AssociatedPolicies != null && CSWData.AssociatedPolicies != "")
                PolicyList = CSWData.AssociatedPolicies.Split(';');

            NYLDSelenium.PageLoad("Upload Documents Securely", UploadDocumentSecurelyInfoPageTitle);

            if (data[KeyRepository.ContractCount] == "Multi" && PolicyList.Length <= 1)
                NYLDSelenium.ReportStepResult("Verify " + data[KeyRepository.PolicyNumber] + " is a Multi contract policy", "User does not have multiple policies, data sheet needs to be udpated with valid policy number", "FAIL", "no", "yes");
            if (data[KeyRepository.ContractCount] == "Multi")
                NYLDSelenium.ElemExist("Upload Documents Securely -Select One Contract", ContractNumberDropdown);

            //select the policy and upload the documents securely 
            for (int i = 0; i < PolicyList.Count(); i++)
            {
                //Get Policy Number from policy list queried
                string[] phrasePolicy = PolicyList[i].Split(' ');
                PolicyNumber = phrasePolicy.Last();
                Thread.Sleep(100);
                //get options in Drop down

                js.ExecuteScript("window.scrollBy(0,-1000);");
                Thread.Sleep(100);
                SelectElement select = new SelectElement(ContractNumberDropdown);
                IList<IWebElement> options = select.Options;
                Thread.Sleep(300);
                int ActPolCount = options.Count;
                string actPolicyName = "";

                //Policy list displayed in UI
                for (int j = 0; j < ActPolCount; j++)
                {
                    actPolicyName = options.ElementAt(j).GetAttribute("text").Trim();
                    Thread.Sleep(300);
                    if (actPolicyName == PolicyList[i])
                    {
                        string ContractSelected = "//*[contains(text(), '" + PolicyNumber + "')]";
                        js.ExecuteScript("window.scrollBy(0,-500);");
                        NYLDSelenium.SelectList("Select Policy", ContractNumberDropdown, actPolicyName, "bytext");
                        data[KeyRepository.PolicyNumber] = PolicyNumber;
                        NYLDSelenium.Click("Continue..", Continue);
                        break;
                    }
                    else if (j == ActPolCount - 1)
                    {
                        NYLDSelenium.ReportStepResult("Select policy: " + PolicyList[i], PolicyList[i] + " is not displayed in UI to select", "FAIL", "yes");
                    }
                }
            }
        }
    }
}
