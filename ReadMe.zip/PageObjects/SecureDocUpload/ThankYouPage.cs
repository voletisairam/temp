﻿using CSW.Common.Email;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.PageObjects.SecureDocUpload
{
    class ThankYouPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ThankYouPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////
        ///////////////    Upload Document Securely - Thank You Page ////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////


        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Upload successful!')]")]
        public IWebElement UploadSuccessful { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Thank you. A confirmation email has been sent to the email address')]")]
        public IWebElement ThankYouMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Upload more documents')]")]
        public IWebElement UploadmoreDocuments { get; set; }

        //Please visit our

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyManageBeneFAQ                                                                        ////////////
        ////// Description: Verify Secure Document Upload Thank You Page                                   ////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifySecureDocUploadThankYou()
        {
            //Verify Page Load
         
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Secure Document Upload Thank You Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            NYLDSelenium.PageLoad("Verify Secure Document Upload Thank You Page", UploadSuccessful);
            NYLDSelenium.ElemExist("Thank you.A Confirmation email has been sent", ThankYouMessage);
            NYLDSelenium.ElemExist("Upload more documents", UploadmoreDocuments);
        }


        public void ValidateSecureDocUploadThankYou(string args)
        {          
            VerifySecureDocUploadThankYou();

            //Verify Page Load
            string findstring = "Please";
            NYLDSelenium.AddHeader("Validate Secure Document Upload Thank you page  " + args.Trim(), "SubHeader");
            string Thankyouinfo = NYLDSelenium.GetAttribute("Thank you.A Confirmation email has been sent", ThankYouMessage);
            Thankyouinfo = Thankyouinfo.Substring(0, Thankyouinfo.IndexOf(findstring));

            NYLDSelenium.VerifyText("Thank you.A Confirmation email has been sent", "Thank you. A confirmation email has been sent to the email address on file and to any additional email address provided. If further information is required, we will contact you.".Trim(), Thankyouinfo.Trim());

            NYLDSelenium.AddHeader("Validate Secure Document Upload Thank you page  " + args.Trim(), "Success");
        }


        public void VerifySuccessEmailInfo()
        {
            Common.Email.EmailVerification outlookEmail = new EmailVerification(driver, data);
            //Verify Page Load
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + " Email Validation for Secure Document Upload successful" + " </h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO", "no");
            outlookEmail.VerifyEmailInbox("Secure Document Upload successful");
        }
    }
}
