﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;
using System.Globalization;

//TODO: Shall we ranme Page as Step?

namespace CSW.PageObjects.NewRegistration
{
    class ConfirmContractNumberPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ConfirmContractNumberPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        //Confirm Email
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Choose the best way to confirm')]")]  //Only way to differentiate between Page 1 and 2 is Label.
        public IWebElement VerifyEmailPageHeading { get; set; }

        //Label to confirm text

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[1]/div/label")]
        public IWebElement UseExistingRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[1]/div/label/p")]
        public IWebElement UseExistingText { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[2]/div/label")]
        public IWebElement UseNewRadioButtonLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[3]/div")]
        public IWebElement UseNewDescription { get; set; }




        //Registration Page2
        [FindsBy(How = How.Id, Using = "lblRegistrationPolicyNumber")]  //Only way to differentiate between Page 1 and 2 is Label.
        public IWebElement PageHeading { get; set; }



        //contract Number Label  
        [FindsBy(How = How.Id, Using = "lblRegistrationPolicyNumber")]
        public IWebElement ContractNumberLabel { get; set; }

        //Contract Number
        [FindsBy(How = How.Id, Using = "txtRegistrationPolicyNumber")]
        public IWebElement ContractNumber { get; set; }


        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        public void VerifyEnterContractPage()
        {
            NYLDSelenium.AddHeader("Verify Contract/certificate number Page", "SubHeader");
            //Verify Step2 Heading
            NYLDSelenium.PageLoad("Enter Contract Number", PageHeading);

            //Verify the Labels

            //Contract Number
            NYLDSelenium.VerifyText("Contract Number Label", "Contract/certificate number", NYLDSelenium.GetAttribute("Contract Number Label", ContractNumberLabel));

            //Verify the fields

            //Enter Contract Number
            NYLDSelenium.ElemExist("Contract Number", ContractNumber);


            //Click Continue
            NYLDSelenium.ElemExist("Next", ContinueBtn);

            NYLDSelenium.AddHeader("Verify Contract/certificate number Page", "Success");

        }
        public void FillEnterContractForm(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Registration Page2- Fill Enter Contract/certificate number Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Step2 Heading
            NYLDSelenium.PageLoad("Enter Contract Number", PageHeading);

            //For dispose 
            data[KeyRepository.Regerror] = "2";

            //Fill the form
            //Enter Contract Number
            NYLDSelenium.SendKeys("Contract Number", ContractNumber, data[KeyRepository.PolicyNumber]);

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn, true);

            //Chekc Click Here Link
            string dtConv = DateTime.Now.AddMinutes(-5).ToString(@"MM/dd/yyyy hh:mm tt");
            TestSetUp.date = DateTime.ParseExact(dtConv, @"MM/dd/yyyy hh:mm tt", new CultureInfo("en-US"));
        }
    }
}
