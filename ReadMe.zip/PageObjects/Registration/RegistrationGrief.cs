﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using System.Threading;
using CSW.Common.DataBase;
using CSW.PageObjects.Login;
using CSW.Drivers;
using CSW.Common.Excel;
using CSW.Common.Others;

namespace CSW.PageObjects.Registration
{
    class RegistrationGrief
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public RegistrationGrief(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        ////////////////////////////////////////// Error Messages /////////////////////////////

        //Please Call NYL Heading
        //[FindsBy(How = How.XPath, Using = "//div[@class='loginHeaderFont' and contains(., 'Please Call')] | //h2[contains(., 'Please Call')]")]
        //public IWebElement PleaseCallNYL { get; set; }

        //Error Message Button
        [FindsBy(How = How.XPath, Using = "//h2/..")]
        public IWebElement ErrorMessage { get; set; }

        //Error Message for dacetivated user
        [FindsBy(How = How.XPath, Using = "//*[@id='LoginErrorDisplay']//div[@class='signUpForm']/div | //div[@id='FormDisplay' and contains(., 'Please Call')]")]
        public IWebElement ErrorMessageDeactivatedUser { get; set; }

        //Token Exp Message and Exceeded Attempts Message
        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/div")]
        public IWebElement TokenDisableMessage { get; set; }

        //Error Message - Login with your username password 
        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'Forgotusername') and contains(text(), 'username')]")]
        public IWebElement ErrMsgLoginLink { get; set; }

        //Error Message -Reset Password
        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'Reset') and contains(text(), 'password?')]")]
        public IWebElement ErrMsgResetPwdLink { get; set; }

        //Reset Password
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'reset')]")]
        public IWebElement ResetPasswordHeader { get; set; }

        /// <summary>
        /// Method to verify Grief message at registartion phas
        /// </summary>
        /// <param name="args"></param>
        public void VerifyRegGriefMsg(string args)
        {
            Thread.Sleep(5000);
            Console.WriteLine("arguments are :" + args);

            string[] argslist;
            string action = "";
            string body;
            argslist = args.Split(',');

            LSPDatabase DB = new LSPDatabase(driver, data);
            TestData testData = new TestData();

            //Define the action when the grief message is displayed

            switch (argslist[0])
            {
                case "CyberFraudRegistration":
                    action = "Registration";
                    break;

                case "CyberFraudResetPassword":
                    action = "Reset Password";
                    break;

                case "CyberFraudLogin":
                case "CyberFraud":
                    action = "CyberFraudLogin";
                    argslist[0] = "CyberFraudLogin";
                    break;
                case "DeactivatedUserResettPassword":
                    action = "Login_Resetpassword_Registration-Deactivated User";
                    break;
                case "CyberFraudDeactivatedUser":
                    action = "Login_Resetpassword_Registration-Deactivated User";
                    break;

                case "CyberFraudSuspendedUser":
                    action = "Login_Resetpassword_Registration-Suspended User";
                    break;

                case "CyberFraudLoginNotReg":
                    action = "Login - Not Registered User";
                    break;
                case "Snowbird":
                    action = "Snow Bird contracts";
                    argslist[0] = "SnowbirdGrief";
                    break;
                case "ViperMorethan1Year":
                    action = "ViperMorethan1Year";
                    argslist[0] = "ViperMorethan1Year";
                    break;
                case "DeathClaimGriefMsg":
                    action = "DeathClaimGriefMsg";
                    argslist[0] = "DeathClaimGriefMsg";
                    break;
                default:
                    action = "Registration";
                    break;
            }

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Grief Message for: " + action + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            Thread.Sleep(1000);
            UserRegistrationDriver registerUser = new UserRegistrationDriver(driver, data);
            IWebElement errorElement = null;
            switch (argslist[0])
            {
                case "CheckLoginLink":
                    registerUser.RegisterUser("OwnerDetails");
                    break;
                case "CyberFraudLogin":
                    if (data[KeyRepository.UserAccountStatus] != "Active")
                        registerUser.RegisterUser("OwnerDetails");
                    body = testData.GetContent(argslist[0]);
                    errorElement = ErrorMessage;
                        NYLDSelenium.VerifyText("Grief Message for " + action, body, errorElement.Text.Replace("Please Call New York Life", "").Replace("\r", "").Replace("\n", ""), "always", "always");
                    break;
                case "CheckResetPasswordLink":
                    //Click Reset Password Link
                    NYLDSelenium.Click("Error Message -Reset Password", ErrMsgResetPwdLink);

                    //Verify if Reset Password Page is displayed
                    NYLDSelenium.PageLoad("Reset Password", ResetPasswordHeader);

                    //Verify the Header Name
                    NYLDSelenium.VerifyText("Reset Password", "To retrieve your username or reset your password, a few more details are needed.", NYLDSelenium.GetAttribute("Reset Password", ResetPasswordHeader, "text"), "always", "always");
                    break;
                case "DeactivatedUserResettPassword":
                    ResetPasswordPage rPP = new ResetPasswordPage(driver, data);
                    NYLDSelenium.VerifyText("EmailValidation error", "The information provided does not match our records.", NYLDSelenium.GetAttribute("", rPP.EmailFieldValidationError), "always", "always");
                    break;

                default:
                    body = testData.GetContent(argslist[0]);
                    if (argslist[0] == "")
                        errorElement = ErrorMessageDeactivatedUser;
                    else if (argslist[0] == "")
                    {
                        Login.LoginPage LP = new Login.LoginPage(driver, data);
                        errorElement = LP.CorrectFieldMessage;
                    }
                    else
                        errorElement = ErrorMessage;
                    if (argslist[0] != "SnowbirdGrief")
                        NYLDSelenium.VerifyText("Grief Message for " + action, body, errorElement.Text.Replace("Please Call New York Life", "").Replace("\r", "").Replace("\n", ""), "always", "always");
                    break;
            }
        }
    }
}
