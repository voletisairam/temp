﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;
using System.Globalization;


//TODO: Shall we ranme Page as Step?

namespace CSW.PageObjects.NewRegistration
{
    class AccountAlreadyExistsPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public AccountAlreadyExistsPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[text()='Account already exists']")]
        public IWebElement PageHeading { get; set; }

        //Heading Details
        [FindsBy(How = How.XPath, Using = "//h2[text()='Account already exists']//following::p[1]")]
        public IWebElement PageHeading_Details { get; set; }

        //Login Link
        [FindsBy(How = How.XPath, Using = "//h2[text()='Account already exists']//following::p[1]/a[text()='click here']")]
        public IWebElement LoginLink { get; set; }


        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[text()='This account has already been verified.']")]
        public IWebElement PageHeadingInUse { get; set; }

        //Heading Details
        [FindsBy(How = How.XPath, Using = "//h2[text()='This account has already been verified.']//following::p[1]")]
        public IWebElement PageHeading_InUseDetails { get; set; }

        //Login Link
        [FindsBy(How = How.XPath, Using = "//h2[text()='This account has already been verified.']//following::p[1]/a[text()='Click here']")]
        public IWebElement LoginLink_InUse { get; set; }

        public void VerifyAccountAlreadyExistsPage()
        {
            NYLDSelenium.AddHeader("Verify Account already exists Page", "SubHeader");
            //Verify Page Load
            NYLDSelenium.PageLoad("Registration Account already exists", PageHeading);

            //Verify PAge Heading Details Text
            NYLDSelenium.VerifyText("Registration Account already exists", "There is already an account associated with this policy. Please click here to log in.", NYLDSelenium.GetAttribute("Registration Account already exists - Details", PageHeading_Details));
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Account already exists Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "Pass");
            ////Verify Section Heading text
            //NYLDSelenium.VerifyText("Enter Your User Name, Password Text", "Enter a username and password to continue.", NYLDSelenium.GetAttribute("Create Your Login Page - Details", PageHeading_Details));
            NYLDSelenium.ElemExist("log in link", LoginLink);

            NYLDSelenium.AddHeader("Verify Account already exists Page", "Success");
        }


        public void ClickLogin()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Click Login in Account already exists Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Page Load
            NYLDSelenium.PageLoad("Account already exists", PageHeading);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Click Login in Account already exists Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "Pass");
            //Fill Form   
                if (NYLDSelenium.ElemExist("Login", LoginLink, false, "no", "no", "no"))
            NYLDSelenium.Click("Login",LoginLink);

        }


        public void VerifyAccountAlreadyInUsePage()
        {
            VerifyAccountAlreadyInUsePageLogin();
        }


        public void VerifyAccountAlreadyInUsePageLogin()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify this account has already been verified Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Page Load
            NYLDSelenium.PageLoad("Registration Account already In Use", PageHeadingInUse);
            NYLDSelenium.VerifyText("Registration Account already In Use", "This account has already been verified.", NYLDSelenium.GetAttribute("This account has already been verified.", PageHeadingInUse));
            NYLDSelenium.ElemExist("log in link", LoginLink_InUse);
            //Fill Form   
            if (NYLDSelenium.ElemExist("Login", LoginLink_InUse, false, "no", "no", "no"))
                NYLDSelenium.Click("Login", LoginLink_InUse);

        }


    }
}
