﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;


//TODO: Shall we ranme Page as Step?

namespace CSW.PageObjects.NewRegistration
{
    class CreateYourLoginPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public CreateYourLoginPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; ////
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Create your profile')]")]
        public IWebElement PageHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Create your profile')]//following::p[1]")]
        public IWebElement PageHeading_Details { get; set; }



        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'provide your profile details')]")]
        public IWebElement SectionHeading { get; set; }


        //Email Address Label
        [FindsBy(How = How.Id, Using = "lblEmail")]
        public IWebElement EmailAddressLabel { get; set; }

        //Email Address Label
        [FindsBy(How = How.Id, Using = "txtEmail")]
        public IWebElement EmailAddress { get; set; }

        //Email Already Exists Label
        [FindsBy(How = How.XPath, Using = "//span[@data-valmsg-for='Email']")]
        public IWebElement EmailAlreadyExistsLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Please enter a valid email address.')]")]
        public IWebElement ValidEmailLabel { get; set; }



        //Username Already Exists Label
        [FindsBy(How = How.XPath, Using = "//span[@data-valmsg-for='Username']")]
        public IWebElement UsernameAlreadyExistsLabel { get; set; }


        //Username Already Exists Label
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Username already exists, please use different username')]")]
        public IWebElement ValidUsernameLabel { get; set; }

        //UserName Label
        [FindsBy(How = How.Id, Using = "lblUsername")]
        public IWebElement UserNameLbl { get; set; }


        //UserName
        [FindsBy(How = How.Id, Using = "txtUsername")]
        public IWebElement UserName { get; set; }

        //Password Label
        [FindsBy(How = How.Id, Using = "lblPassword")]
        public IWebElement PasswordLbl { get; set; }

        //Password
        [FindsBy(How = How.Id, Using = "Password")]
        public IWebElement Password { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']/following-sibling::div/button[text()='Show']")]
        public IWebElement PwdShowBtn { get; set; }


        //Confirm Password Label
        [FindsBy(How = How.Id, Using = "lblConfirmPassword")]
        public IWebElement ConfirmPasswordLbl { get; set; }

        //Confirm Password
        [FindsBy(How = How.Id, Using = "ConfirmPassword")]
        public IWebElement ConfirmPassword { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//input[@id='ConfirmPassword']/following-sibling::div/button[text()='Show']")]
        public IWebElement ConfirmPwdShowBtn { get; set; }


        //Show Button
        [FindsBy(How = How.XPath, Using = "//button[text()='Continue']")]
        public IWebElement ContinueBtn { get; set; }


        //UserName
        [FindsBy(How = How.XPath, Using = "//*[@id='txtUsername']/following-sibling::span")]
        public IWebElement UserNamePopUp { get; set; }



        public void FillUserProfileDetails(string args)
        {
            //Fill Create login form
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Registration Page3-Fill Enter Email and Username & Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            
            //Verify Step2 Heading
            //Verify Page Load 
            NYLDSelenium.PageLoad("Create Your Log in", PageHeading);

            //For dispose 
            data[KeyRepository.Regerror] = "3";

            //Fill Form
            if (data[KeyRepository.EmailId].Contains("fuitest"))

            {
                Random random = new Random();
                string hp2 = random.Next(10, 100).ToString();
                int atIndex = data[KeyRepository.EmailId].ToString().IndexOf('@');
                string name = data[KeyRepository.EmailId].ToString().Substring(0, atIndex);
                string domain = data[KeyRepository.EmailId].ToString().Substring(atIndex);

                data[KeyRepository.EmailId] = name + hp2 + domain;
            }
            //Enter Email Address             
            NYLDSelenium.Click("Activate Email", EmailAddress);          
            NYLDSelenium.SendKeys("Email Address", EmailAddress, data[KeyRepository.EmailId]);
            data[KeyRepository.UserName] = ("AUT" + data[KeyRepository.LastName] + DateTime.Now.ToString("ddmmss")).ToString().Trim();
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            data[KeyRepository.Password] = "2W3e4r5t!";
            NYLDSelenium.SendKeys("Password", Password,data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Confirm password", ConfirmPassword,data[KeyRepository.Password]);

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn);

            if (data[KeyRepository.ContractSource] == "DataMine" && NYLDSelenium.ElemExist("Email Already exists message", EmailAlreadyExistsLabel, false, "no", "no", "no", 30))
            { EmailAlreadyInUsed(); NYLDSelenium.Click("Continue", ContinueBtn); }
        }

        /// <summary>
        /// This method helps to create a continue account creation 
        /// </summary>
        /// <param name="args"></param>
        public void FilltoCreateUserProfileDetails(string args)
        {
            //Fill Create login form
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Registration Page3-Fill Enter Email and Username & Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            Random random = new Random();
            string hp2 = random.Next(10, 200).ToString();
            //Verify Step2 Heading
            //Verify Page Load 
            NYLDSelenium.PageLoad("Create Your Log in", PageHeading);

            //For dispose 
            data[KeyRepository.Regerror] = "3";

            //Fill Form
            //Enter Email Address             
            NYLDSelenium.Click("Activate Email", EmailAddress);
            data[KeyRepository.EmailId] = ("AUTtest" + DateTime.Now.ToString("ddmmss") +random.Next(1,9).ToString() + "@" + "automation.com").Trim();
            NYLDSelenium.SendKeys("Email Address", EmailAddress, data[KeyRepository.EmailId]);
            data[KeyRepository.UserName] = ("AUT" + data[KeyRepository.LastName] + DateTime.Now.ToString("ddmmss")).ToString().Trim();
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            if(data[KeyRepository.LastName].Length > 7)
                data[KeyRepository.LastName].Substring(0, 7);
                data[KeyRepository.Password] = "2W3e4r5t!";
            NYLDSelenium.SendKeys("Password", Password,data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Confirm Password", ConfirmPassword,data[KeyRepository.Password]);

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn);


            //Email already Inuse to enter  the new email id
            if (NYLDSelenium.ElemExist("Email Already exists message", EmailAlreadyExistsLabel, false, "no", "no", "no", 10))
            {
                EmailAlreadyInUsed();
                NYLDSelenium.Click("Continue", ContinueBtn);
            }
        }

        /// <summary>
        /// Method helps to verify already an email exisit
        /// </summary>
        public void EmailAlreadyInUsed()
        {
            Random random = new Random(); 
            string hp1 = random.Next(10, 300).ToString();
            string hp2 = random.Next(100, 300).ToString();
            NYLDSelenium.ElemExist("Email Already exists message", EmailAlreadyExistsLabel, false, "no", "always");
            NYLDSelenium.VerifyText("Email already exist", "Email already exists, please use different email", NYLDSelenium.GetAttribute("Email already exist Grif message", EmailAlreadyExistsLabel),"always","always");

            //To refill the details -when grif message popup occurs
            NYLDSelenium.Clear("Email Address", EmailAddress);
            NYLDSelenium.Clear("User Name", UserName);
            NYLDSelenium.Clear("Password", Password);
            NYLDSelenium.Clear("Confirm password", ConfirmPassword);

            data[KeyRepository.UserName] = data[KeyRepository.UserName] + DateTime.Now.Second;
            data[KeyRepository.EmailId] = "AUTtest" + DateTime.Now.ToString("ddMMhhmmss")+ hp2 + "@" + "automation.com";
            NYLDSelenium.SendKeys("Email Address", EmailAddress, data[KeyRepository.EmailId]);
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            data[KeyRepository.Password]= data[KeyRepository.Password]+hp2+"*";
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Confirm password", ConfirmPassword, data[KeyRepository.Password]);
        }


        /// <summary>
        /// Method helps to verify already an email username
        /// </summary>
        public void UsernameAlreadyInUsed()
        {
            CommonFunctions cf = new CommonFunctions(data);
            Random random = new Random();
            string hp1 = random.Next(10, 999).ToString();
            string hp2 = random.Next(100, 300).ToString();
            NYLDSelenium.Clear("Username", UserName);
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            NYLDSelenium.Click("Continue", ContinueBtn);
            NYLDSelenium.ElemExist("Username Already exists message", UsernameAlreadyExistsLabel, false, "no", "always", "always");
            NYLDSelenium.VerifyText("Username already exist", "Username already exists, please use different username", NYLDSelenium.GetAttribute("Username already exist Grif message", ValidUsernameLabel),"always","always");
           
            //Fill to complete  to registration 
            NYLDSelenium.Clear("Email Address", EmailAddress);
            NYLDSelenium.Clear("User Name", UserName);
            NYLDSelenium.Clear("Password", Password);
            NYLDSelenium.Clear("Confirm password", ConfirmPassword);
            cf.getUserName();            
            data[KeyRepository.EmailId] = "AUTtest" + DateTime.Now.ToString("ddhhmmss") + hp2 + "@" + "automation.com";
            NYLDSelenium.SendKeys("Email Address", EmailAddress, data[KeyRepository.EmailId]);
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            data[KeyRepository.Password] = data[KeyRepository.Password] + hp2 + "*";
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Confirm password", ConfirmPassword, data[KeyRepository.Password]);
            NYLDSelenium.Click("Continue", ContinueBtn);
        }

        public void VerifyCreateYourProfilePage()
        {
            CommonFunctions commonFunctions = new CommonFunctions(data);
            NYLDSelenium.AddHeader("Create Your Profile", "SubHeader");

            //Verify Page Load
            NYLDSelenium.PageLoad("Create Your Profile", PageHeading);

            //Verify Section Heading text
            NYLDSelenium.VerifyText("Provide your profile details", "Please provide your profile details.", NYLDSelenium.GetAttribute("Provide your profile details Page", SectionHeading, "text"));

            //Email Adresss
            NYLDSelenium.VerifyText("Email Address Label", "Email address", NYLDSelenium.GetAttribute("Email Address Label", EmailAddressLabel));

            //Enter Email Address
            NYLDSelenium.ElemExist("Email Address", EmailAddress);

            //Verify Form

            //Verify UserName Label, Field and Show Link
            NYLDSelenium.VerifyText("Username Label", "Username", NYLDSelenium.GetAttribute("Username Label", UserNameLbl));

            NYLDSelenium.ElemExist("Username", UserName);

            //Verify Password Label, Field and Show Link
            NYLDSelenium.VerifyText("Password Label", "Password", NYLDSelenium.GetAttribute("Password Label", PasswordLbl));

            NYLDSelenium.ElemExist("Password", Password);

            NYLDSelenium.ElemExist("Password - Show", PwdShowBtn);

            //Verify Password Label, Field and Show Link
            NYLDSelenium.VerifyText("Confirm password Label", "Confirm password", NYLDSelenium.GetAttribute("Confirm password Label", ConfirmPasswordLbl));

            NYLDSelenium.ElemExist("Confirm password", ConfirmPassword);

            NYLDSelenium.ElemExist("Confirm password - Show", ConfirmPwdShowBtn);

            //Verify if Submit Button exist
            NYLDSelenium.ElemExist("Continue", ContinueBtn);
            NYLDSelenium.AddHeader("Create Your Profile", "Success");
        }
    }
}
