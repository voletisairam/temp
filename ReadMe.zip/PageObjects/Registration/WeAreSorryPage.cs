﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;
using System.Globalization;


//TODO: Shall we ranme Page as Step?

namespace CSW.PageObjects.NewRegistration
{
    class WeAreSorryPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public WeAreSorryPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[text()='We're sorry']")]
        public IWebElement PageHeading { get; set; }

        //Heading Details
        [FindsBy(How = How.XPath, Using = "//h2[text()='We're sorry']//following::p[1]")]
        public IWebElement PageHeading_Details { get; set; }

        //Login Link
        [FindsBy(How = How.XPath, Using = "//h2[text()='We're sorry']//following::p[1]/a[text()=' 1-800-850-2658 ']")]
        public IWebElement LoginLink { get; set; }

        public void VerifyWeAreSorryPage()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify We're Sorry Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Page Load
            NYLDSelenium.PageLoad("Registration - We're Sorry", PageHeading);

            //Verify PAge Heading Details Text
            NYLDSelenium.VerifyText("Registration - We're Sorry", "Something went wrong and we're unable to display your contract. Please call ", NYLDSelenium.GetAttribute("Registration We're sorry - Details", PageHeading_Details));

            ////Verify Section Heading text
            //NYLDSelenium.VerifyText("Enter Your User Name, Password Text", "Enter a username and password to continue.", NYLDSelenium.GetAttribute("Create Your Login Page - Details", PageHeading_Details));

            NYLDSelenium.ElemExist("log in link", LoginLink);
        }


    }
}
