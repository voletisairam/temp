﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.Login;
using System.Text.RegularExpressions;
using System.Threading;
using System.Reflection;
using CSW.Common.Excel;
using Microsoft.Office.Interop.Excel;


namespace CSW.PageObjects.NewRegistration
{
    class VerifyYourDetailsPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public VerifyYourDetailsPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        [FindsBy(How = How.XPath, Using = "//span[@class='field-validation-error' and @data-valmsg-for='LastName']")]
        public IWebElement ErrormessagepopupForLastName { get; set; }
        [FindsBy(How = How.XPath, Using = "//span[@class='field-validation-error' and @data-valmsg-for='DateOfBirth']")]
        public IWebElement ErrormessagepopupForDateOfBirth { get; set; }
        [FindsBy(How = How.XPath, Using = "//span[@class='field-validation-error' and @data-valmsg-for='LastFourSsn']")]
        public IWebElement ErrormessagepopupForLastFourSsn { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='field-validation-error' and @data-valmsg-for='Otp']")]
        public IWebElement ErrormessagepopupForOTP { get; set; }

        public string Errormessagecontent = "The information provided does not match our records.";

        public string ErrormessageOTPcontent = "You've entered an invalid code. Please enter the code from your email or click the link below to resend a new 6-digit code.";

        //  Create an Account Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Create your account')]")]
        public IWebElement CreateAccountInstruction { get; set; }


        //Registration Page1
        [FindsBy(How = How.XPath, Using = "//*[@role='heading']/descendant::h4")]
        public IWebElement PageHeading { get; set; }

        //Registration Page1
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Access your profile')]")]
        public IWebElement PageResetHeading { get; set; }

        //Registration Page1
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'To retrieve your username or reset your password, a few more details are needed.')]")]
        public IWebElement PageSubheadingHeading { get; set; }

        //Last Name LAbel
        [FindsBy(How = How.Id, Using = "lblLastName")]
        public IWebElement LastNameLabel { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement LastName { get; set; }

        //Last Name LAbel
        [FindsBy(How = How.Id, Using = "lblDateOfBirth")]
        public IWebElement DOBLabel { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "txtDateOfBirth")]
        public IWebElement DOB { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "lblLastFourSsn")]
        public IWebElement SSNLabel { get; set; }

        //SSN
        [FindsBy(How = How.Id, Using = "LastFourSsn")]
        public IWebElement SSN { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//button[text()='Show']")]
        public IWebElement SSNShowBtn { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }


        /// <summary>
        /// Method helps to verify the owner derails page
        /// </summary>
        public void VerifyDetailsPage()
        {
            
            NYLDSelenium.AddHeader("Verify Your Details Page ", "SubHeader");
           
            //Verify if Verify Your Details PAge is loaded
            NYLDSelenium.PageLoad("Verify Owner Details", PageHeading);

            //Verify the Labels

            //Last Name Label
            NYLDSelenium.VerifyText("Last name Label", "Last name", NYLDSelenium.GetAttribute("Last name Label", LastNameLabel));

            //DOB Label
            NYLDSelenium.VerifyText("Date of birth Label", "Date of birth", NYLDSelenium.GetAttribute("Date of birth Label", DOBLabel));

            //SSN Label
            NYLDSelenium.VerifyText("SSN Label", "Last four digits of your Social Security number (SSN)", NYLDSelenium.GetAttribute("SSN Label", SSNLabel));

            //Last Name
            NYLDSelenium.ElemExist("Last Name", LastName);

            //DOB 
            NYLDSelenium.ElemExist("DOB", DOB);

            //SSN 
            NYLDSelenium.ElemExist("SSN", SSN);

            //SSN SHow
            NYLDSelenium.ElemExist("SSN Show", SSNShowBtn);


            //Verify SSN Entered

            //Get last 4 digits of SSN
            string SSN4 = data[KeyRepository.SSN].Substring(data[KeyRepository.SSN].Length - 4);

            //Enter last 4 digits
            NYLDSelenium.SendKeys("SSN", SSN, SSN4);

            //Verify if entered SSN displayed upon Clicking Show Buton
            NYLDSelenium.Click("SSN Show", SSNShowBtn);
            string enteredSSNValue = NYLDSelenium.GetAttribute("Get SSN input", SSN, "value");
            NYLDSelenium.VerifyText("Entered SSN Value", SSN4, enteredSSNValue);

            //Clear SSN
            NYLDSelenium.Clear("SSN", SSN, 5);

            NYLDSelenium.AddHeader("Verify Your Personal Information : Verify Your Personal Information ", "Success");

        }


        /// <summary>
        /// Method helps to register the owner details
        /// </summary>
        /// <param name="args"></param>
        public void FillOwnerDetailsPage(string args,string reportstopfor)
        {
           // Turrinig Off logging the steps of if the user account is already created
            if (reportstopfor == "useraccounts")

            GetSettor.ReportEvent = "no";

            if (reportstopfor != "useraccounts")
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Registration Page1- Fill your personal information" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Registration Owner details page  is laoded
            NYLDSelenium.PageLoad("Your Details", PageHeading);

            FillOwnerdetails(args);

            //Turrinig On logging the steps of if the user account is already created
            if (reportstopfor == "useraccounts")
                GetSettor.ReportEvent = "yes";
        }


        /// <summary>
        /// Method helps to forgot the username / password to rest the owner details (PING)
        /// </summary>
        /// <param name="args"></param>
        public void ForgotOwnerDetailsPage(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Fill your personal information-Forgot Usrname / Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Forgot Owner details page is loaded
            NYLDSelenium.PageLoad("Access your profile", PageHeading);

            NYLDSelenium.ElemExist("To retrieve your username or reset your password", PageSubheadingHeading);

            FillOwnerdetails(args);
        }


        /// <summary>
        /// Method helps to Fill the owner details
        /// </summary>
        /// <param name="args"></param>
        public void FillOwnerdetails(string args)
        {
            //For dispose 
            data[KeyRepository.Regerror] = "1";

            NYLDSelenium.Clear("Clear LastName", LastName, 5);
            NYLDSelenium.Clear("Clear DOB", DOB, 5);
            NYLDSelenium.Clear("Clear SSN", SSN, 5);

            //Enter Last Name
            NYLDSelenium.SendKeys("Last name", LastName, data[KeyRepository.LastName]);

            //Enter DOB
            NYLDSelenium.SendKeys("Date of birth", DOB, data[KeyRepository.DOB]);

            //Enter SSN

            //Get last 4 digits of SSN
            string SSN4 = data[KeyRepository.SSN].Substring(data[KeyRepository.SSN].Length - 4);

            //Enter last 4 digits
            NYLDSelenium.SendKeys("SSN", SSN, SSN4);

            //Click Continue Button
            NYLDSelenium.Click("Next", ContinueBtn, true,"always","always");
        }
       
        /// <summary>
        /// Method helps to verify Grief message- Owner Details page via Reset password
        /// </summary>
        /// <param name="args"></param>
        public void VerifyGriefMessage(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify Owner Details Grief Message PopUp for:"+args + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO", "no");
            NYLDSelenium.ElemExist("Verify Message PopUp for " + args, ErrormessagepopupForOTP, false, "no", "always", "always");
            NYLDSelenium.VerifyText("Verify OTP Grief Message ", ErrormessageOTPcontent.Replace("\r", "").Replace("\n", "").Trim(), NYLDSelenium.GetAttribute("Verify OTP Grief Message ", ErrormessagepopupForOTP, "text").Replace("\r", "").Replace("\n", "").Trim());

        }

    }
}
