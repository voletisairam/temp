﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;
using System.Globalization;
using OpenQA.Selenium.DevTools.V119.DOM;


//TODO: Shall we ranme Page as Step?

namespace CSW.PageObjects.NewRegistration
{
    class ThankYouPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ThankYouPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; ////
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'all set!')]")]
        public IWebElement PageHeading { get; set; }

        //[FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Protect your profile')]")]
        //public IWebElement ProfilePageHeading { get; set; }


        //[FindsBy(How = How.XPath, Using = "//*[@id='showForm']")]
        //public IWebElement ProfileSetup { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[@id='txtMobileNumber']")]
        //public IWebElement ProfileMobileNumber { get; set; }


        //Login Link
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'With your online access, you can now:')]//following::a[text()='Log in']")]
        public IWebElement LoginLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'With your identity verified, you can now log in with your username and password.')]//following::a[text()='Log in']")]
        public IWebElement LoginfullyfunctionalLink { get; set; }

        //Heading Details
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'With your online access')]")]
        public IWebElement PageHeading_Details { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'fully functional')]")]
        public IWebElement PageSubHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'identity verified')]")]
        public IWebElement PageContent { get; set; }
        
        public void VerifyThankYouPage(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Registration Page4- Verify Thank You Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Page Load
            NYLDSelenium.PageLoad("Registration Thank you", PageHeading);

            //For dispose 
            data[KeyRepository.Regerror] = "5";

            //Verify PAge Heading Details Text
            NYLDSelenium.VerifyText("Registration Thank you - Details", "With your online access, you can now:", NYLDSelenium.GetAttribute("Registration Thank You - Details", PageHeading_Details));

            //Verify the login button
            NYLDSelenium.ElemExist("log in link", LoginLink);
            if(args != "ProtectProfile")
            NYLDSelenium.Click("Login", LoginLink);
        }

        public bool VerifyRegistrationThankYouPage()
        {
            bool status = false;
            //Verify Page Load
            NYLDSelenium.PageLoad("Registration Thank you", PageHeading, "onerror", "onerror");

            //For dispose 
            data[KeyRepository.Regerror] = "5";

            //Verify Page Heading Details Text
            NYLDSelenium.VerifyText("Registration all set page ", "Great, your account is now fully functional!", NYLDSelenium.GetAttribute("Registration fully functional", PageSubHeader), "onerror", "onerror");
            NYLDSelenium.VerifyText("Registration all set page content", "With your identity verified, you can now log in with your username and password.", NYLDSelenium.GetAttribute("Registration identity verified", PageContent), "onerror", "onerror");
            //Verify the login button
            status = NYLDSelenium.ElemExist("log in link", LoginfullyfunctionalLink, false, "no", "no");
            if(status)
                NYLDSelenium.Click("log in link", LoginfullyfunctionalLink, false, "onerror", "onerror");
            return status;
        }
    }
}
