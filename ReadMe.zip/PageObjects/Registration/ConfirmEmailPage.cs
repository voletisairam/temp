﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;
using System.Globalization;

//TODO: Shall we ranme Page as Step?

namespace CSW.PageObjects.NewRegistration
{
    class ConfirmEmailPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ConfirmEmailPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        //Confirm Email
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Choose the best way to confirm')]")]  //Only way to differentiate between Page 1 and 2 is Label.
        public IWebElement VerifyEmailPageHeading { get; set; }

        //Label to confirm text

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[1]/div/label")]
        public IWebElement UseExistingRadioButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[1]/div/label/p")]
        public IWebElement UseExistingText { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[1]/div/label/p/span")]
        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[1]/div/label")]
        public IWebElement UseExistingEmail { get; set; }

        [FindsBy(How = How.Id, Using = "lblConfirmEmail")]
        public IWebElement ConfirmEmailAddressLabel { get; set; }


        [FindsBy(How = How.Id, Using = "txtConfirmEmail")]
        public IWebElement ConfirmEmailAddress { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@data-valmsg-for='Email']")]
        public IWebElement ConfirmEmailAddressGriefmsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[2]/div/label")]
        public IWebElement UseNewRadioButtonLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyAccount-form']/div[1]/div[3]/div")]
        public IWebElement UseNewDescription { get; set; }




        //Registration Page2
        [FindsBy(How = How.Id, Using = "lblRegistrationPolicyNumber")]  //Only way to differentiate between Page 1 and 2 is Label.
        public IWebElement PageHeading { get; set; }



        //contract Number Label  
        [FindsBy(How = How.Id, Using = "lblRegistrationPolicyNumber")]
        public IWebElement ContractNumberLabel { get; set; }

        //Contract Number
        [FindsBy(How = How.Id, Using = "txtRegistrationPolicyNumber")]
        public IWebElement ContractNumber { get; set; }

        //Email Address Label
        [FindsBy(How = How.Id, Using = "lblEmail")]
        public IWebElement EmailAddressLabel { get; set; }

        //Email Address Label
        [FindsBy(How = How.Id, Using = "txtEmail")]
        public IWebElement EmailAddress { get; set; }

        //Email Already Exists Label
        [FindsBy(How = How.XPath, Using = "//span[@data-valmsg-for='Email']")]
        public IWebElement EmailAlreadyExistsLabel { get; set; }       

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Please enter a valid email address.')]")]
        public IWebElement ValidEmailLabel { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        public void VerifyConfirmExistingEmailPage()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Confirm Existing Email Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Step2 Heading
            NYLDSelenium.PageLoad("Confirm Existing Email", VerifyEmailPageHeading, "no", "no", false, 25);

            Thread.Sleep(100);

            //Verify if radio button exist
            NYLDSelenium.ElemExist("Email Listed on your application radio button", UseExistingRadioButton, false, "no", "no");

            //Verify email listed on your application text
            NYLDSelenium.VerifyText("Email Listed on your application text", "Use the email address listed on your application:a*********@au********.com", NYLDSelenium.GetAttribute("Email listed in your application", UseExistingText).Replace("\r\n", ""));

            //Verify Entrypted Email ID
            NYLDSelenium.VerifyText("Encrypted Email ID", "a*********@au********.com", NYLDSelenium.GetAttribute("Email listed in your application", UseExistingEmail));

            //Verify ConfirmEmailAddress Label
            NYLDSelenium.VerifyText("Confirm Email Address Lable", "Please verify your email address to continue:", NYLDSelenium.GetAttribute("Confirm Email address label in application", ConfirmEmailAddressLabel));

            //Verify ConfirmEmailAddress textbox
            NYLDSelenium.ElemExist("Confirm Email Address textbox", ConfirmEmailAddress, false, "no", "no");

            //Verify text in ConfirmEmailAddress textbox
            NYLDSelenium.VerifyText("Confirm Email Address watermark text", "emailname@online.com", NYLDSelenium.GetAttribute("Confirm Email Address watermark text in application", ConfirmEmailAddress, "placeholder"));

            //Verify if radio button exist for different email option
            NYLDSelenium.ElemExist("Use different email address radio button", UseNewRadioButtonLabel, false, "no", "no");

            //Click on the Radio Button to verify text and labels
            NYLDSelenium.Click("Use different email", UseNewRadioButtonLabel);


            //Verify email listed on your application text
            NYLDSelenium.VerifyText("Use different email text", "Use a different email address and your contract/certificate number", NYLDSelenium.GetAttribute("Use different email", UseNewRadioButtonLabel));


            //Verify description after selecting the option
            NYLDSelenium.VerifyText("Use different email description", "You can find your contract/certificate number from the Welcome Kit you received by mail about 10 days after your coverage was approved.", NYLDSelenium.GetAttribute("Use New Email Description", UseNewDescription));

            //Verify Email and Contract Labels
            //Contract Number
            NYLDSelenium.VerifyText("Contract Number Label", "Contract/Certificate number", NYLDSelenium.GetAttribute("Contract Number Label", ContractNumberLabel));

            //Email Adresss
            NYLDSelenium.VerifyText("Email Address Label", "Email address", NYLDSelenium.GetAttribute("Email Address Label", EmailAddressLabel));

        }


        public void ConfirmEmail(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Cofirm Email" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Step2 Heading
            NYLDSelenium.PageLoad("Confirm Existing Email", VerifyEmailPageHeading,"no","no", true);

            if (args == "OptNewEmail")
            {

                //Click on the Radio Button to verify text and labels
                NYLDSelenium.Click("Use different email", UseNewRadioButtonLabel);

                //Enter Contract Number
                NYLDSelenium.SendKeys("Contract Number", ContractNumber, data[KeyRepository.PolicyNumber]);

                //Enter Email Address
                NYLDSelenium.SendKeys("Email Address", EmailAddress, "AUTtest" + DateTime.Now.Second + "@" + "email.com");

            }
            else
            {

                //Click on the Radio Button for Use Existing Email
                NYLDSelenium.Click("Use existing email", UseExistingEmail);

                //Enter Email Address
                if (NYLDSelenium.ElemExist("Confirm Email Address", ConfirmEmailAddress, false, "no","no"))
                {
                    NYLDSelenium.Clear("Confirm Email Address", ConfirmEmailAddress);
                    NYLDSelenium.SendKeys("Confirm Email Address", ConfirmEmailAddress, data[KeyRepository.EmailId]);
                }

            }

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn, true);

        }

        public void VerifyConfimrEmailGriefMsg()
        {
            TestData testData = new TestData();
            NYLDSelenium.VerifyText("Confirm Email Grief Message", "Please enter a valid email address.", NYLDSelenium.GetAttribute("Confirm Email Gief message", ConfirmEmailAddressGriefmsg));
            //NYLDSelenium.VerifyText("Confirm Email Grief Message", testData.GetContent("ConfirmEmailGriefMsg"), NYLDSelenium.GetAttribute("Confirm Email Gief message", ConfirmEmailAddressGriefmsg));
        }

        public void VerifyEnterEmailContractPage()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Email and Contract Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            Thread.Sleep(100);
            //Verify Step2 Heading
            NYLDSelenium.PageLoad("Enter Email Contract", PageHeading);

            //Verify the Labels

            //Contract Number
            NYLDSelenium.VerifyText("Contract Number Label", "Contract/certificate number", NYLDSelenium.GetAttribute("Contract Number Label", ContractNumberLabel));

            //Email Adresss
            NYLDSelenium.VerifyText("Email Address Label", "Email address", NYLDSelenium.GetAttribute("Email Address Label", EmailAddressLabel));

            //Verify the fields

            //Enter Contract Number
            NYLDSelenium.ElemExist("Contract Number", ContractNumber);

            //Enter Email Address
            NYLDSelenium.ElemExist("Email Address", EmailAddress);


            //Click Continue
            NYLDSelenium.ElemExist("Next", ContinueBtn);

        }
        public void FillEnterEmailContractForm(string args)
        {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Fill Enter Email and Contract Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                //Verify Step2 Heading
                NYLDSelenium.PageLoad("Enter Email Contract", PageHeading);


                //Fill the form

                //Enter Contract Number
                NYLDSelenium.SendKeys("Contract Number", ContractNumber, data[KeyRepository.PolicyNumber]);

                //Enter Email Address  
                NYLDSelenium.Clear("Email Address", EmailAddress);

                NYLDSelenium.SendKeys("Email Address", EmailAddress, data[KeyRepository.EmailId].Replace("'", ""));


                //Click Continue
                //NYLDSelenium.ScrollToView(ContinueBtn, true);
                NYLDSelenium.Click("Continue", ContinueBtn, true);

                if(!data[KeyRepository.EmailId].Contains("InvalidEmail"))
                ExisitingEmailReplace();

                //Chekc Click Here Link
                string dtConv = DateTime.Now.AddMinutes(-5).ToString(@"MM/dd/yyyy hh:mm tt");
                TestSetUp.date = DateTime.ParseExact(dtConv, @"MM/dd/yyyy hh:mm tt", new CultureInfo("en-US"));
        }

        public void ExisitingEmailReplace()
        {
            Thread.Sleep(500);
            if ( NYLDSelenium.ElemExist("Email Already exists message", ValidEmailLabel,false,"no","no","no") || NYLDSelenium.ElemExist("This email account already exists, please enter a different email.", EmailAlreadyExistsLabel, false, "no", "no", "no"))
            {
                Random rnd = new Random();
                int rval = rnd.Next(1, 10);
                //NYLDSelenium.VerifyText("Email Already exists message", "This email account already exists, please enter a different email.", NYLDSelenium.GetAttribute("Email Already exists message", EmailAlreadyExistsLabel));
                NYLDSelenium.Clear("Email Address", EmailAddress);
                NYLDSelenium.SendKeys("Email Address", EmailAddress, "NYLTest" + rval + DateTime.Now.ToString("MMddHHmmss") + "@" + "automation.com");
                //NYLDSelenium.ScrollToView(ContinueBtn, true);
                NYLDSelenium.Click("Continue", ContinueBtn,true);
            }
        }
    }
}
