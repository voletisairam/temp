﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Text.RegularExpressions;
using System.Globalization;
using CSW.Common.Email;
using System.Threading;

namespace CSW.PageObjects.NewRegistration
{
    class OneTimeVerificationPage 
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public OneTimeVerificationPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; ////
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Enter the code sent to your')]")]
        public IWebElement PageHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1//following::p[1]")]
        public IWebElement AccountVerificationBody1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='registration-form']/div/div[4]/p")]
        public IWebElement AccountVerificationBody2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'txtOtp']")]
        public IWebElement Otp { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "(//a[contains(text(), 'request a new code')])[1]")]
        public IWebElement ResendOTP { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@data-valmsg-for='Otp']")]
        public IWebElement InvalidPINMsg { get; set; }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Verify your identity')]")]
        public IWebElement IdentityPageHeading { get; set; }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Verify your identity')]//following::p")]
        public IWebElement IdentitySubTitleTxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='confirm-otp-form']//div//p[contains(text(),'This code expires')]")]
        public IWebElement resendOtpTxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyDevice-form']/div/div/p")]
        public IWebElement deviceDisclaimerTxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyDevice-form']/div/h4[contains(text(),'Choose where to send your code.')]")]
        public IWebElement chooseDevicetxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='verifyDevice-form']//div/div[2]//label[contains(@class,'custom-control-label')]")]
        public IWebElement mobileRadioOption { get; set; }

        public void VerifyOneTimeVerificationPage()
        {
            TestData testData = new TestData();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your identity" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Confirm Your Account Heading
            NYLDSelenium.PageLoad("OTP Confirmation", PageHeading);

           //Verify One Time Fields
            NYLDSelenium.ElemExist("OTP", Otp);
       
            //Verify Body 2 Section
            //NYLDSelenium.VerifyText("Account Verifiction = Body 2", "This code expires in 15 minutes. If you do not receive the code, you can request a new code.".Trim(), NYLDSelenium.GetAttribute("Account Confirmation - Body2", AccountVerificationBody2,"text").Trim());

          
        }

        public void VerifyOneTimeVerificationSMSPage()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your identity" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Confirm Your Account Heading
            NYLDSelenium.PageLoad("OTP Device option", IdentityPageHeading);
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            NYLDSelenium.VerifyText("Identity verification content : ", CF.FormatString(testData.GetContent("IdentityMsg").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Identity verification content: ", IdentitySubTitleTxt)), "always", "always");
            NYLDSelenium.VerifyText("your mobile otp disclaimer", CF.FormatString(testData.GetContent("MobileOTPDisclaimer").ToString().Trim()), NYLDSelenium.GetAttribute("your mobile otp disclaimer ", deviceDisclaimerTxt, "text").Trim());
            //Verify One Time Fields
            NYLDSelenium.ElemExist("Choose where to send your code.", chooseDevicetxt,true,"yes");

            NYLDSelenium.Click("mobile otp option", mobileRadioOption);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Clicked mobile OTP option" + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "Pass");

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn);
        }

        public void FillOneTimeCode(string oneTimeCode)
        { 

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your indentity page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Confirm Your Account Heading
            NYLDSelenium.PageLoad("Account-Details Confirmation", PageHeading);
            //For dispose 
            data[KeyRepository.Regerror] = "4";

            NYLDSelenium.SendKeys("OTP", Otp, oneTimeCode);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Entered Pin Code" + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "Pass");

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn);
        }

        public void FillOneTimeCodeForTestData(string oneTimeCode)
        {
            //Verify Confirm Your Account Heading
            NYLDSelenium.PageLoad("Account-Details Confirmation", PageHeading, "onerror", "onerror");
            //For dispose 
            data[KeyRepository.Regerror] = "4";

            NYLDSelenium.SendKeys("OTP", Otp, oneTimeCode, false, "onerror", "onerror");
            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn, false, "onerror", "onerror");
        }
    }
}
