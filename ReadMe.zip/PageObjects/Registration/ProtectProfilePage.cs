﻿using CSW.Common.Excel;
using CSW.Common.Others;
using iText.Kernel.XMP.Options;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using static CSW.PageObjects.Email.EmailInformation;
using static iText.IO.Util.IntHashtable;
using static System.Net.WebRequestMethods;

namespace CSW.PageObjects.NewRegistration
{
    class ProtectProfilePage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ProtectProfilePage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; ////
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading

        //Heading for Successful Registration
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'all set!')]")]
        public IWebElement RegistrationSuccess { get; set; }

        //Mobile container in you're all set registration successful page
        [FindsBy(How = How.XPath, Using = "//*[@id='mobile-container']")]
        public IWebElement PageContainer { get; set; }

        //Mobile container header in Protect your profile  
        [FindsBy(How = How.XPath, Using = "//h4[contains(@class, 'text-steel')]//following::img[@class='img-left']")]
        public IWebElement PageHeading { get; set; }

        //Mobile container Extra security msg in Protect your profile
        [FindsBy(How = How.XPath, Using = "//h4[contains(@class, 'text-steel')]//following::img[@class='img-left']//following::div[@id='copy-text']")]
        public IWebElement PageText { get; set; }

        //Mobile container Setup now button in Protect your profile
        [FindsBy(How = How.XPath, Using = "//h4[contains(@class, 'text-steel')]//following::img[@class='img-left']//following::a[contains(text(), 'Setup now')]")]
        public IWebElement SetupNowBtn { get; set; }

        //Mobile container form to enter new mobile number in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='lblMobileNumber']")]
        public IWebElement MobileNumberlbl { get; set; }

        //Mobile container form to enter new mobile number in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='txtMobileNumber']")]
        public IWebElement MobileNumbertxtInput { get; set; }

        //Mobile container form to enter confirm mobile number in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='lblConfirmMobileNumber']")]
        public IWebElement ConfirmMobileNumberlbl { get; set; }

        //Mobile container form to enter confirm mobile number in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmMobileNumber']")]
        public IWebElement ConfirmMobileNumberTxtInput { get; set; }

        //Mobile container form to enter confirm mobile number in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmMobileNumber']//following::p")]
        public IWebElement Disclaimer { get; set; }

        //Mobile container form to submit button in Protect your profile
        [FindsBy(How = How.XPath, Using = "//button[@type ='submit' and text() ='Continue']")]
        public IWebElement Continue { get; set; }

        //Mobile container form to Enter OTP Txt label in Protect your profile
        [FindsBy(How = How.XPath, Using = "//h4[contains(@class, 'text-steel')]//following::img[@class='img-left']//following::div/div/p[contains(text(),'Enter the code')]")]
        public IWebElement OTPTxtLbl { get; set; }

        //Mobile container form to Enter OTP Txt input in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='txtMobileOtp']")]
        public IWebElement OTPTxtInput { get; set; }

        //Mobile container form to resend code msg in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='add-mobile-form']/div[1]/p")]
        public IWebElement ResendOTPlbl { get; set; }

        //Mobile container form to resend code msg in Protect your profile
        [FindsBy(How = How.XPath, Using = "//*[@id='add-mobile-form']/div[1]/p/text()[2]")]
        public IWebElement ResendOTPHref { get; set; }

        //Mobile your mobile phone was added to your account.
        [FindsBy(How = How.XPath, Using = "//h4[contains(@class, 'text-steel')]//following::img[@class='img-left']//following::div/p[contains(text(),'Great your mobile')]")]
        public IWebElement Added { get; set; }

        //Grief
        [FindsBy(How = How.XPath, Using = "//h4[contains(@class, 'text-steel')]//img[@class='img-left']//following::div/p[contains(text(), 'Sorry an error occurred. Please try again later.')]")]
        public IWebElement GriefMsg { get; set; }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SetupProfile                                          ///////////
        ////// Description:This method to start with profile security management update       ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void SetupProfile(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Protect your profile Registration Page " + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            //Verify Page Load
            NYLDSelenium.PageLoad("Registration Success Page and Mobile Setup page ", RegistrationSuccess);

            if (NYLDSelenium.ElemExist("Protect your profile form", PageContainer, true, "yes"))
            {
                //Verify Protect your profile Heading
                NYLDSelenium.PageLoad("Protect your profile", PageHeading);
                //Verify text Fields
                NYLDSelenium.VerifyText("Disclaimer content of : ", CF.FormatString(testData.GetContent("SecurityMsg").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Disclaimer content of: ", PageText)), "always", "always");
                //verify Mobile container has Setup now button in Protect your profile
                NYLDSelenium.ElemExist("Protect your profile form", SetupNowBtn, true, "yes");
                NYLDSelenium.Click("Set up now button ", SetupNowBtn);
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: FillMobileNumber                                          ///////////
        ////// Description:This method updates the new mobile 
        ///                 number to for profile security management            ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void FillMobileNumber(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            NYLDSelenium.PageLoad("Protect your profile new mobile number", PageHeading);
            NYLDSelenium.VerifyText("New mobile number label : ", "New mobile phone number", NYLDSelenium.GetAttribute("New mobile number label: ", MobileNumberlbl), "always", "always");
            NYLDSelenium.VerifyText("Confirm New mobile number label : ", "Confirm new mobile phone number", NYLDSelenium.GetAttribute("Confirm New mobile number label: ", ConfirmMobileNumberlbl), "always", "always");
            NYLDSelenium.ElemExist("Disclaimer", Disclaimer, true, "yes");
            NYLDSelenium.VerifyText("Mobile number Disclaimer: ", CF.FormatString(testData.GetContent("MobileDisclaimer").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Mobile number Disclaimer: ", Disclaimer)), "always", "always");           
            data[KeyRepository.ProfilePhone] = testData.GetInputData("ProfileMobileNumber");
            Random random = new Random();
            int randomNumber = random.Next(103, 199);
            string basePart = data[KeyRepository.ProfilePhone].Substring(0, data[KeyRepository.ProfilePhone].Length - 3);
             string phoneNumber = $"{basePart}{randomNumber}";
            //Format phone number
            data[KeyRepository.ProfilePhone] = $"({phoneNumber.Substring(0, 3)}) {phoneNumber.Substring(3, 3)}-{phoneNumber.Substring(6)}";
            //Enter New mobile number
            NYLDSelenium.SendKeys("New mobile number", MobileNumbertxtInput, data[KeyRepository.ProfilePhone].ToString());
            //Enter Confirm mobile number
            NYLDSelenium.SendKeys("Confirm New mobile number", ConfirmMobileNumberTxtInput, data[KeyRepository.ProfilePhone].ToString());
            NYLDSelenium.Click("updated new mobile number continue ", Continue);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: EnterOTP                                          ///////////
        ////// Description:This method enterd the OTP sent to the new number
        ///                  for profile security management            ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void EnterProfileOTP(string args, string oneTimeCode = "999999")
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            IList<string> options = new List<string>();
            string[] getOptions = args.Split(',');
            options = getOptions.ToList();

            if (options.Count == 1)
                options.Add("");

            NYLDSelenium.PageLoad("Protect your profile for OTP", PageHeading);
            //verify OTP Txt label
            NYLDSelenium.VerifyText("New mobile number label : ", "Enter the code sent to your mobile phone " + data[KeyRepository.ProfilePhone], NYLDSelenium.GetAttribute("Enter the code label: ", OTPTxtLbl), "always", "always");
            NYLDSelenium.VerifyText("Resend OTP content : ", CF.FormatString(testData.GetContent("ResendOTP").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Resend OTP content: ", ResendOTPlbl)), "always", "always");
            //NYLDSelenium.ElemExist("Resend OTP href link", ResendOTPHref, true, "yes");
            if (options[0] == "WaitforOTPtoExpire")
            {
                Thread.Sleep(900000);
            }
            else
            {
                //Enter OTP
                NYLDSelenium.SendKeys("OTP txt", OTPTxtInput, oneTimeCode);
                NYLDSelenium.Click("OTP verifiction ", Continue);
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: MobileAddSuccess                                          ///////////
        ////// Description:This method verify the update sucess
        ///                  for profile security management            ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void MobileAddSuccess(string args, string oneTimeCode = "999999")
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Protect your profile Registration Page - Verify update " + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Page Load
            NYLDSelenium.PageLoad("Protect your profile Successful Registration", PageHeading);
            NYLDSelenium.VerifyText("Mobile Phone was added to your account content: ", CF.FormatString(testData.GetContent("AddedSuccess").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Mobile Phone was added to your account content: ", Added)), "always", "always");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verify profile Phone number                                          ///////////
        ////// Description:This method verify the update sucess
        ///                  for profile secutity management            ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyProfilePhonenumber(string profileph)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Mobile Phone was added to Protect your profile service" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");            
            NYLDSelenium.VerifyText("Mobile Phone was added to your profile : ", Regex.Replace(data[KeyRepository.ProfilePhone], @"[^0-9]", ""), profileph, "always", "always");            
        }


        public bool CreateProtectProfileAccount()
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            bool AccountCreated = false;
            try
            {
                if (NYLDSelenium.ElemExist("Protect your profile form", PageContainer, true, "yes"))
                {
                    NYLDSelenium.Click("Set up now button ", SetupNowBtn);

                    string mobileNumber = data[KeyRepository.ProfilePhone] = "(813) 555-0120";
                    NYLDSelenium.SendKeys("New mobile number", MobileNumbertxtInput, mobileNumber.ToString());
                    //Enter Confirm mobile number
                    NYLDSelenium.SendKeys("Confirm New mobile number", ConfirmMobileNumberTxtInput, data[KeyRepository.ProfilePhone].ToString());
                    NYLDSelenium.Click("updated new mobile number continue ", Continue);

                    string oneTimeCode = "999999";
                    //Enter New mobile number
                    NYLDSelenium.SendKeys("OTP txt", OTPTxtInput, oneTimeCode);
                    NYLDSelenium.Click("OTP verifiction ", Continue);
                    NYLDSelenium.VerifyText("Mobile Phone was added to your account content: ", CF.FormatString(testData.GetContent("AddedSuccess").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Mobile Phone was added to your account content: ", Added)), "always", "always");
                    AccountCreated = true;
                }
            }
            catch
            {
                AccountCreated = false;
            }
            return AccountCreated;
        }
    }
}
