﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Text.RegularExpressions;
using System.Globalization;
using CSW.Common.Email;
using System.Threading;

namespace CSW.PageObjects.NewRegistration
{
    class EmailVerificationPage 
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public EmailVerificationPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; ////
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Account verification')]")]
        public IWebElement PageHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1//following::p[1]")]
        public IWebElement AccountVerificationBody1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1//following::p[2]")]
        public IWebElement AccountVerificationBody2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'Otp1']")]
        public IWebElement Otp1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'Otp2']")]
        public IWebElement Otp2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'Otp3']")]
        public IWebElement Otp3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'Otp4']")]
        public IWebElement Otp4 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'Otp5']")]
        public IWebElement Otp5 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'Otp6']")]
        public IWebElement Otp6 { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(), 'entered is not valid')]")]
        public IWebElement EnterValidOTP { get; set; }

        [FindsBy(How = How.XPath, Using = "(//a[contains(text(), 'click here')])[1]")]
        public IWebElement ResendOTP { get; set; }

        public void VerifyEmailVerificationPage()
        {
            TestData testData = new TestData();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Email Confirmation Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Confirm Your Account Heading
            NYLDSelenium.PageLoad("Email Verification", PageHeading);

            //Verify Account Verification Body
            NYLDSelenium.VerifyText("Email Verification - Body", "We've sent a one-time code to <>. Please enter your code on the right to ensure that your account stays safe and secure.", NYLDSelenium.GetAttribute("Account Verification Body", AccountVerificationBody1,"text"));

            //Verify One Time Fields
            NYLDSelenium.ElemExist("OTP1", Otp1);
            NYLDSelenium.ElemExist("OTP2", Otp2);
            NYLDSelenium.ElemExist("OTP3", Otp3);
            NYLDSelenium.ElemExist("OTP4", Otp4);
            NYLDSelenium.ElemExist("OTP5", Otp5);
            NYLDSelenium.ElemExist("OTP6", Otp6);
       
            //Verify Body 2 Section
            NYLDSelenium.VerifyText("Account Verifiction = Body 2", "This code will expire in 10 minutes. If you do not receive the code, Click here and we will resend it.", NYLDSelenium.GetAttribute("Account Confirmation - Body2", AccountVerificationBody2,"text"));

          
        }

        public void BtnClick(string display, IWebElement elemetdata, string element, Dictionary<string, string> data)
        {
                //NYLDSelenium.ScrollToView(elemetdata, true);
                NYLDSelenium.Click(display, elemetdata,true);
        }
    }
}
