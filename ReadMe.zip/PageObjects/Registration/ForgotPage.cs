﻿using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Drivers;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CSW.PageObjects.NewRegistration
{
    class ForgotPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ForgotPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; ////
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }
        [FindsBy(How = How.XPath, Using = "//input[@id = 'txtOtp']")]
        public IWebElement Otp { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[text()='request a new code']")]
        public IWebElement ReSendCode { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Your username was recovered!')]")]
        public IWebElement PageSubHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'all set!')]")]
        public IWebElement PageHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Great, your password has reset.')]")]
        public IWebElement PageSubHeadingPwd { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'With your identity verified')]")]
        public IWebElement PageSubHeadingtxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'With your account update complete')]")]
        public IWebElement PageSubHeadingPwdtxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@id = 'lblUsername']")]
        public IWebElement lblUsername { get; set; }

        [FindsBy(How = How.XPath, Using = "(//label[@id = 'lblUsername']//following::div/label)[1]")]
        public IWebElement ForgotUsernames { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Log in')]")]
        public IWebElement LoginIn { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[@id='main']//label)[2]")]
        public IWebElement userid { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        public void VerifyForgotUsername(string args)
        {
           
            string[] getOptions = args.Split(',');
            List<string> options = getOptions.ToList();
            string action = options[0];
            string actionType = "";
            if (options.Count > 1)
            {
                actionType = options[1];
            }
            UserRegistrationDriver registration = new UserRegistrationDriver(driver, data);
            VerifyYourDetailsPage verifyDetails = new VerifyYourDetailsPage(driver, data);
            LoginPage loginPage = new LoginPage(driver, data);
            ForgotPage forgotusername = new ForgotPage(driver, data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Forgot Username " + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            loginPage.ClickForgotUserName();

            if (action == "FieldValidation")
                verifyDetails.VerifyDetailsPage();

            verifyDetails.ForgotOwnerDetailsPage("");

            if (!driver.Url.Contains("Invalid?Reason"))
            {
                if (actionType == "SMSOTP")
                { OneTimeVerificationPage otpPage = new OneTimeVerificationPage(driver, data);
                    otpPage.VerifyOneTimeVerificationSMSPage();
                }
                registration.OneTimeVerificationPage(false);

                forgotusername.VerifyForgotUsernameResultPage();
            }
            else
            {
                if (!driver.Url.Contains("Invalid?Reason"))
                    NYLDSelenium.ReportStepResult("Records not found-in PING DB Table", "Could not fetch Records -in PING DB Table " + data[KeyRepository.PolicyNumber], "INFO", "no", "no");
            }
        }

        /// <summary>
        /// Method helps to Update the Forgot Password with new password 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyForgotPassword(string args)
        {
            EmailVerification email = new EmailVerification(driver, data);
            IList<string> options = new List<string>();
            string[] getOptions = args.Split(',');
            options = getOptions.ToList();
            bool verify = false;
            string oneTimeCode = "";bool throughemailOTP = false;

            UserRegistrationDriver registration = new UserRegistrationDriver(driver, data);
            VerifyYourDetailsPage verifyDetails = new VerifyYourDetailsPage(driver, data);
            LoginPage loginPage = new LoginPage(driver, data);
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);
            ForgotPage forgotpassword = new ForgotPage(driver, data);
            OneTimeVerificationPage verificationPage = new OneTimeVerificationPage(driver, data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Forgot Password " + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            loginPage.ClickForgotPassword();
            Thread.Sleep(500);

            if (!string.IsNullOrEmpty(options[0]))
            {
                if (options[0] == "ValidPIN" || options[1] == "ValidPIN")
                {
                    throughemailOTP = true;
                    oneTimeCode = email.GetOneTimeCodeFromValidEMail();
                }
            }

            verifyDetails.ForgotOwnerDetailsPage("");

            if (throughemailOTP == true)
            {
                registration.OneTimeVerificationPage(verify, oneTimeCode);
                resetPassword.UpdateNewPassword();
                forgotpassword.VerifyForgotPasswordResultPage();
            }
            else
            {
                if (args.Contains("ResendCode") || args.Contains("InvalidPIN"))
                    forgotpassword.ResendOTP(args);
                registration.OneTimeVerificationPage(verify);
                resetPassword.UpdateNewPassword();
                forgotpassword.VerifyForgotPasswordResultPage();
             
            }
        }


        public void VerifyForgotUsernameResultPage()
        {
            TestData testData = new TestData();
            NYLDSelenium.AddHeader("Verify Forgot Username - Thank you Page", "SubHeader");
            //Verify Confirm  Forgot username result Heading
            NYLDSelenium.PageLoad("You're all set - Forgot Username Thank you", PageHeading);

            //Verify Forgot username result Verification Body
            NYLDSelenium.VerifyText("With your identity verified", "With your identity verified, you can now log in with your username and password.", NYLDSelenium.GetAttribute("Get Username Verification Body", PageSubHeadingtxt, "text"));

            //Verify  Fields
            NYLDSelenium.ElemExist("Forgot Username Verification", PageSubHeading);
            NYLDSelenium.ElemExist("Username label", lblUsername);
            NYLDSelenium.ElemExist("Login", LoginIn);
            data[KeyRepository.UserName] = NYLDSelenium.GetAttribute("Get Username Verification", userid, "text");
            NYLDSelenium.VerifyText("Verify Username", data[KeyRepository.UserName], NYLDSelenium.GetAttribute("Get Username Verification", userid, "text"));

            NYLDSelenium.Click("Login", LoginIn);

            NYLDSelenium.AddHeader("Verify Forgot Username - Thank you Page", "Success");
        }


        public void VerifyForgotPasswordResultPage()
        {
            TestData testData = new TestData();

            NYLDSelenium.AddHeader("Verify Forgot Password - Thank you Page", "SubHeader");

            //Verify Confirm  Forgot password result Heading
            NYLDSelenium.PageLoad("You're all set - Forgot Password Thank you", PageHeading);

            NYLDSelenium.ElemExist("Reset Password", PageSubHeadingPwd);

            //Verify Forgot Password result Verification Body
            NYLDSelenium.VerifyText("With your account update complete", "With your account update complete, you can now log in with your username and new password.", NYLDSelenium.GetAttribute("Update Password Verification Body", PageSubHeadingPwdtxt, "text"),"always","always");

            NYLDSelenium.Click("Login", LoginIn);
            NYLDSelenium.AddHeader("Verify Forgot Password - Thank you Page", "Success");
        }

        public void ResendOTP(string args)
        {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Request to Invalid / Resend a new Pin Code" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                NYLDSelenium.Clear("OTP", Otp);
                Thread.Sleep(1000);
                NYLDSelenium.SendKeys("OTP", Otp, "123456");

                Thread.Sleep(1000);
            if (args.Contains("Invalid"))
                NYLDSelenium.Click("Continue", ContinueBtn);
            else
            {
                NYLDSelenium.Click("Resend Code", ReSendCode);
            }
        }

        /// <summary>
        /// Method helps to get the username and password to reset and update the emailid to execute for registration and reset testcases
        /// </summary>
        /// <param name="args"></param>
        public void DeleteEmailIdInExistingUserAccount(string args)
        {
            try

            {
                LSPDatabase db = new LSPDatabase(driver, data);
                db.GetDataBaseValues("queryEmailcontract");
                if (db.queryResultList.Count != 0)
                {
                    getusernameandpassword(db.queryResultList[0]["CRCTL1"].ToString(), true);
                }
            }
            catch
            {
                NYLDSelenium.ReportStepResult("Error in getting the username and password", "Error in getting the username and password to remove the Email id in Exisiting User account", "FAIL", "no", "yes");
            }       
        }

        /// <summary>
        /// Method helps to get the username and password
        /// </summary>
        /// <param name="policynumber"></param>
        /// <param name="update"></param>
        /// <returns></returns>
        public bool getusernameandpassword(string policynumber, bool update)
        {
            bool sucess = false;
            LSPDatabase db = new LSPDatabase(driver, data);
            LoginDriver login = new LoginDriver(driver, data);
            HomePage home = new HomePage(driver, data);
            UserRegistrationDriver userRegistration = new UserRegistrationDriver(driver, data);
            AccountInformationDriver accountInformation = new AccountInformationDriver(driver, data);

            data[KeyRepository.PolicyNumber] = policynumber;
            db.QueryPolicyNumber();
            db.GetDataBaseValues("queryPolicyDetailsEffectiveDate");
            VerifyForgotUsername("");
            if (!driver.Url.Contains("Invalid?Reason"))
            {
                data[KeyRepository.Password] = "2W3e4r5t*";
                VerifyForgotPassword("");
                Thread.Sleep(500);
                if (update == true)
                {
                    login.Login("");
                    userRegistration.SetValue("NewEmail");
                    accountInformation.UpdateAccountInformationPage("Email");
                    NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);
                    home.NavigateToPage(KeyRepository.LogoutPage);
                }
                sucess = true;
            }
            data[KeyRepository.PolicyNumber] = policynumber;
            return sucess;
        }

        /// <summary>
        /// Method helps to Update the Email in Account Information
        /// </summary>
        /// <param name="policynumber"></param>
        /// <returns></returns>
        public bool UpdateAccountInfoEMail(string policynumber,string arg)
        {
            bool success = false;
            LSPDatabase db = new LSPDatabase(driver, data);
            LoginDriver login = new LoginDriver(driver, data);
            HomePage home = new HomePage(driver, data);
            AccountInformationDriver accountInformation = new AccountInformationDriver(driver, data);

            data[KeyRepository.PolicyNumber] = policynumber;
            db.QueryPolicyNumber();
            db.GetDataBaseValues("queryPolicyDetailsEffectiveDate");
            if (!driver.Url.Contains("Invalid?Reason"))
            {
                login.Login("");
                data[KeyRepository.EmailId] = data[KeyRepository.EmailIdSet];
                accountInformation.UpdateAccountInformationPage(arg);
                NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);
                Thread.Sleep(1000);
                home.NavigateToPage(KeyRepository.LogoutPage);
                success = true;
            }
            return success;
        }
    }
}
