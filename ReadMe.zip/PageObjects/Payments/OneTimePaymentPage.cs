﻿using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.PageObjects.Login;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System.Threading;

namespace CSW.PageObjects.Payments
{
    class OneTimePaymentPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public OneTimePaymentPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        //TODO: 2023 Raj Remove Page Objects that are not referenced

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////
        /////////    One Time Payments Page Section    /////////
        ////////////////////////////////////////////////////////

        //Login page headder
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Welcome to the Customer Service Center!')]")]
        public IWebElement LoginPageHeader { get; set; }

        //Make a one time payment link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Make a one-time payment')]")]
        public IWebElement OneTimePaymentLink { get; set; }

        //Make One Time Payment Title
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Make a one-time payment')]")]
        public IWebElement MakeOneTimePaymentTitle { get; set; }

        //One Time Payment Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'One-time payment')]")]
        public IWebElement OneTimePaymentTitle { get; set; }

        //Contract Number Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblPolicyNumber']")]
        public IWebElement ContractNumberHeader { get; set; }

        //Contract Number
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPolicyNumber']")]
        public IWebElement ContractNumber { get; set; }

        //Contract Number Error
        [FindsBy(How = How.XPath, Using = "//*[@id='one-time-payment-form']/div[1]/div/span")]
        public IWebElement ContractNumberError { get; set; }


        //Contract Zip Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblZipCode']")]
        public IWebElement ZipCodeHeader { get; set; }

        //Zip Code
        [FindsBy(How = How.XPath, Using = "//*[@id='txtZipCode']")]
        public IWebElement ZipCode { get; set; }

        //Zip Code Error
        [FindsBy(How = How.XPath, Using = "//*[@id='one-time-payment-form']/div[2]/div/span")]
        public IWebElement ZipCodeError { get; set; }

        //New Email Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblEmail']")]
        public IWebElement EmailHeader { get; set; }

        //New Email
        [FindsBy(How = How.XPath, Using = "//*[@id='txtEmail']")]
        public IWebElement Email { get; set; }

        //New Email Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='one-time-payment-form']/div[5]/div/span")]
        public IWebElement EmailError { get; set; }
        
        //Confirm Email Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblConfirmEmail']")]
        public IWebElement ConfirmEmailHeader { get; set; }

        //Confirm Email
        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmEmail']")]
        public IWebElement ConfirmEmail { get; set; }

        //Confirm Email Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='one-time-payment-form']/div[6]/div/span")]
        public IWebElement ConfirmEmailError { get; set; }

        //Email Option Check Box
        [FindsBy(How = How.XPath, Using = "//*[@for='EmailOptIn']")]
        public IWebElement EmailOptionCheckBox { get; set; }

        //Email Option Message
        [FindsBy(How = How.XPath, Using = "//*[@for='EmailOptIn']")]
        public IWebElement EmailOptionMessage { get; set; }

        //Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Continue')]")]
        public IWebElement ContinueButton { get; set; }

        ///////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods          ////////////////////////
        ///////////////////////////////////////////////////////////////////////////

        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyOneTimePayment                                                                       ////////////
        ////// Description: Verify One Time Payment - Fields, presentation and navigation links                 ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void VerifyOneTimePayment()
        {
            LoginPage LP = new LoginPage(driver, data);

            // Report the beginning of the verification process
            NYLDSelenium.AddHeader("Verify One Time Payment Page", "SubHeader");
            // Ensure the login page is fully loaded
            NYLDSelenium.PageLoad("Login", LoginPageHeader);
           
            // Navigate to the One Time Payment Page
            NYLDSelenium.Click("One Time Payment Link", OneTimePaymentLink);
            // Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);
            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", LP.CloseMockBanner, false, "no", "no", "no", 30))
                NYLDSelenium.Click("Mock banner", LP.CloseMockBanner);

            // Verify the One Time Payment Page is loaded
            NYLDSelenium.PageLoad("One Time Payment", OneTimePaymentTitle,"always","no",true);

            // Directly verify text elements on the page
            NYLDSelenium.VerifyText("Make a one-time payment header", "Make a one-time payment", NYLDSelenium.GetAttribute("Make a one-time payment header", MakeOneTimePaymentTitle),"always");
            NYLDSelenium.VerifyText("One-time payment header", "One-time payment", NYLDSelenium.GetAttribute("One-time payment header", OneTimePaymentTitle), "always");
            NYLDSelenium.VerifyText("Contract/certificate number header", "Contract / certificate number", NYLDSelenium.GetAttribute("Contract/certificate number header", ContractNumberHeader), "always");
            NYLDSelenium.VerifyText("Owner's zip code header", "Owner's zip code", NYLDSelenium.GetAttribute("Owner's zip code header", ZipCodeHeader), "always");
            NYLDSelenium.VerifyText("Email Address header", "Email address", NYLDSelenium.GetAttribute("Email Address header", EmailHeader), "always");
            NYLDSelenium.VerifyText("Confirm Email Address header", "Confirm email address", NYLDSelenium.GetAttribute("Confirm email Address header", ConfirmEmailHeader), "always");
            NYLDSelenium.VerifyText("Email Option message", "Yes, I would like to receive valuable product information " +
                "and offers from the AARP Life Insurance Program from New York Life.", NYLDSelenium.GetAttribute("Email Option message", EmailOptionMessage), "always");

            // Verify the existence of form elements
            NYLDSelenium.ElemExist("Contract/certificate number", ContractNumber);            
            NYLDSelenium.ElemExist("Owner's zip code", ZipCode);            
            NYLDSelenium.ElemExist("Email Address", Email);            
            NYLDSelenium.ElemExist("Confirm Email Address", ConfirmEmail);
            NYLDSelenium.ElemExist("Email Option checkbox", EmailOptionCheckBox);
            NYLDSelenium.ElemExist("Continue Button", ContinueButton);

            NYLDSelenium.AddHeader("Verify One Time Payment Page field verification Successfully", "Success");
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: MakeOneTimePayment                                                                       ////////////
        ////// Description: Make One Time Payment page fields                                                 ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void MakeOneTimePayment(string args)
        {
            bool shouldContinue = !args.ToLower().Equals("nocontinue");
            // Retrieve necessary data
            string contractNumber = data[KeyRepository.PolicyNumber];
            string zipcode = data[KeyRepository.ZipCode];
            string ownerEmail = data[KeyRepository.EmailId];

            // Verify Page Load
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Make OneTime payment page is loaded" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "Info", "no");

            NYLDSelenium.PageLoad("One Time Payment", OneTimePaymentTitle);

            // Fill Form - streamlined to directly use the retrieved data
            Thread.Sleep(500);
            FillForm(contractNumber, zipcode, ownerEmail);

            // Click Continue, conditional based on the shouldContinue flag
            if (shouldContinue)
                NYLDSelenium.Click("Continue", ContinueButton); 
        }

        private void FillForm(string contractNumber, string zipcode, string ownerEmail)
        {
            NYLDSelenium.SendKeys("Contract/certificate number", ContractNumber, contractNumber,true,"always"); 
            NYLDSelenium.SendKeys("Owner's zip code", ZipCode, zipcode, true, "always"); 
            NYLDSelenium.SendKeys("Email Address", Email, ownerEmail, true, "always");
            NYLDSelenium.SendKeys("Confirm Email Address", ConfirmEmail, ownerEmail, true, "always"); 
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyOneTimePaymentFields
        ////// Description: Validates fields on the One Time Payment page
        ////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void ClickOneTimePaymentLink()
        {
            LoginPage LP = new LoginPage(driver, data);
            // Ensure the login page is fully loaded
            NYLDSelenium.PageLoad("Login", LoginPageHeader);
            // Navigate to the One Time Payment Page
            NYLDSelenium.Click("One Time Payment Link", OneTimePaymentLink);
            Thread.Sleep(5000);
            // Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);
            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", LP.CloseMockBanner, false, "no", "no", "no", 30))
                NYLDSelenium.Click("Mock banner", LP.CloseMockBanner);

            // Verify the One Time Payment Page is loaded
            NYLDSelenium.PageLoad("One Time Payment", OneTimePaymentTitle, "always", "no", true);
        }

    }
}
