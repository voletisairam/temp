﻿using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Home;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace CSW.PageObjects.Payments
{
    class ManagePaymentsPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ManagePaymentsPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        #region Pageobjects

        //Manage payment option page
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Invoices')]")]
        public IWebElement ManagePayment_Page { get; set; }

        //Contract Owner
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Contract Owner')]/../..")]
        public IWebElement ContractOwner { get; set; }

        //Back to dashboard
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Back to dashboard')]")]
        public IWebElement Backtodashboard { get; set; }
        //contract insured
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(), 'Insured')]/../..")]
        public IWebElement ContractInsured { get; set; }

        //Choose a contract number Header 
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Choose a contract number')]")]
        public IWebElement ContractHeader { get; set; }

        //Contract not eligible for paymnets - call NYL header 
        [FindsBy(How = How.XPath, Using = "//*[@id='resultForm']/div[2]")]
        public IWebElement CallNYLHeader { get; set; }

        //Contract not eligible for paymnets - customer care content
        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedContentBox']")]
        public IWebElement PastDueSection { get; set; }

        //Contract not eligible for paymnets - Premium 52 days due text
        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedContentBox']/div/p[1]")]
        public IWebElement PastDueText1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedContentBox']/div/p[2]")]
        public IWebElement PastDueText2 { get; set; }

        //Contract not eligible for paymnets - ContactNumber
        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedContentBox']/div/div")]
        public IWebElement PastDueContactNumb { get; set; }

        //Contract not eligible for paymnets - Time of contact
        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedContentBox']/div/p[3]")]
        public IWebElement PastDueContactTime { get; set; }

        //Contract not eligible for paymnets - Return to Home
        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedReturnToHomeButton']/a/img")]
        public IWebElement PastDueReturntohome { get; set; }

        //No payment required at this time
        [FindsBy(How = How.XPath, Using = "//*[@id='onlinePaymentDeniedContentBox']/div")]
        public IWebElement NoPaymntReqdTxt { get; set; }

        //Payment details pages
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(), 'Manage payments')]")]
        public IWebElement PaymentPage { get; set; }

        //Payment details pages
        [FindsBy(How = How.XPath, Using = "//*[@id='policy']")]
        public IWebElement PaymentdetailsPage { get; set; }

        //Contract number
        [FindsBy(How = How.XPath, Using = "//*[@id='contractNumber']")]
        public IWebElement ContractNumber { get; set; }

        //Payments information table Header - Status Info icon
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Payment information')]/..//i")]
        public IWebElement payInfoIcon { get; set; }

        //Payment Information Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Payment information')]")]
        public IWebElement PaymentInformationHeader { get; set; }

        //Payments information table content
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Payment information')]/../div")]
        public IList<IWebElement> BillingInfoTableContent { get; set; }

        //Family bill banner text with group number
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(), 'Group Billing')]/..")]
        public IWebElement FamilyBillBannerText { get; set; }

        //Family bill banner contract numbers line 1
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Contracts included')]/following-sibling::div/span[@class='mr-2']")]
        public IList<IWebElement> FamilyBillPolNumUptoFive { get; set; }

        //Family bill banner text with group number
        [FindsBy(How = How.XPath, Using = "//a[@id='group-policies-show-more']")]
        public IWebElement FamilyBillBannerArrow { get; set; }

        //Family bill banner contract numbers line 1
        [FindsBy(How = How.XPath, Using = "//a[@id = 'group-policies-show-more']/..//span[@class='mr-2']")]
        public IList<IWebElement> FamilyBillPolNumGreaterThanFive { get; set; }

        //Payment frequency header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'frequency')]")]
        public IWebElement PaymntfreqHeader { get; set; }

        //Payment frequency month radio button
        [FindsBy(How = How.XPath, Using = "//label[@for='frequency-Monthly']/../input")]
        public IWebElement PaymntfreqMonthRadbtn_Checked { get; set; }

        //Payment frequency month header
        [FindsBy(How = How.XPath, Using = "//label[@for = 'frequency-Monthly']")]
        public IWebElement PaymntfreqMonthlabel { get; set; }

        //Payment frequency Quarterly radio button
        [FindsBy(How = How.XPath, Using = "//label[@for='frequency-Quarterly']/../input")]
        public IWebElement PaymntfreqQuatrRadbtn_Checked { get; set; }

        //Payment frequency Quarterly header
        [FindsBy(How = How.XPath, Using = "//label[@for = 'frequency-Quarterly']")]
        public IWebElement PaymntfreqQuatrlabel { get; set; }

        //Select Payment header
        [FindsBy(How = How.XPath, Using = "//p[contains(., 'Select payment')]")]
        public IWebElement SelectPaymntHeader { get; set; }

        //payments page Continue button
        [FindsBy(How = How.XPath, Using = "//form[@id='submitUpdateEFT']/button/img")]
        public IWebElement PaymentOptionContinueButton { get; set; }

        //Payment Frequency Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Payment frequency')]")]
        public IWebElement PaymentFrequencyHeader { get; set; }

        //Update Payment Option
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Update automatic')]")]
        public IWebElement UpdateAutoPaymentHeader { get; set; }

        //paycode NN
        [FindsBy(How = How.XPath, Using = "//*[@id='policyTop']/../div[@class='formTitle']")]
        public IWebElement PayCodeNNPaymentPageHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='policyTop']/../div[@class='onlinePayRestricted']/div[1]")]
        public IWebElement PayCodeNNPaymentPageMessage { get; set; }

        //Contract Number Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='policy-toggle']")]
        public IWebElement ContractNumberDropdown { get; set; }

        ///////////////// Manage Payments Header //////////////////////////////////////////

        //disclaimer for Automatic paymnent
        [FindsBy(How = How.XPath, Using = "//div[@class='disclaimer']/div[@data-for='AutomaticPaymentSignup']")]
        public IWebElement DisclaimerNoteAutopaymnt { get; set; }

        //Auto Pay Option
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentmethod-autopay']")]
        public IWebElement AutoPayOption { get; set; }

        //Manage My Payments Option
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentmethod-manage']")]
        public IWebElement ManageMyPaymentsOption { get; set; }

        //One Time Payment Option label
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentmethod-onetime']")]
        public IWebElement OneTimePaymentOption { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'paymentmethod') and contains(., 'AutoPay')  or contains(., 'autopay')]")]
        public IWebElement AutoPayOption_label { get; set; }

        //Manage My Payments Option
        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'paymentmethod') and contains(., 'Manage') or contains(., 'manage')]")]
        public IWebElement OnlineEasyPayOption_label { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'paymentmethod') and contains(., 'One-Time')]")]
        public IWebElement OneTimePaymentOption_label { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'paymentmethod-onetime')]")]
        public IWebElement OneTimePayment_label { get; set; }

        //Update Payment Option
        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'paymentmethod') and contains(., 'Update') or contains(., 'update')]")]
        public IWebElement UpdatePaymentOption_label { get; set; }

        //One Time Payment Option
        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'paymentmethod') and contains(., 'Cancel')or contains(., 'cancel')]")]
        public IWebElement CancelPaymentOption_label { get; set; }

        //Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Continue')]")]
        public IWebElement ContinueButton { get; set; }

        //Submit payment selection 
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Select')]/..//button[@type = 'submit']")]
        public IWebElement PaymentContinueButton { get; set; }

        //Update pay frequency
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Update')]/..//button[@type = 'submit']")]
        public IWebElement UpdatepayFreqency { get; set; }

        //Back To Manage Payments Link
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Back to Manage Payments')]")]
        public IWebElement BackToManagePaymentsLink { get; set; }

        //Thank you information for Pay frequency change
        [FindsBy(How = How.XPath, Using = "//h3[contains(.,'Thank you')]/../p")]
        public IWebElement ThankYouInfo_PayFrequency { get; set; }

        //EFT Details
        [FindsBy(How = How.XPath, Using = "//h3[contains(.,'Thank you')]/..//div[1]/div")]
        public IList<IWebElement> PayFrequencyChangeDetails { get; set; }

        //Update Payment Information Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Update payment information')]")]
        public IWebElement UpdatePaymentInformationHeader { get; set; }

        //Monthly Option label
        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'frequency') and contains(., 'Monthly')]")]
        public IWebElement MonthlyOption_label { get; set; }

        //Quaterly Option label
        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'frequency') and contains(., 'Quarterly')]")]
        public IWebElement QuarterlyOption_label { get; set; }

        public string[] PolicyList { get; private set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        #endregion

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////


        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaymentsPage                                          ///////////
        ////// Description:Verify Single Contract Payments Page                                ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyManagePaymentDetails()
        {
            //TODO: Move this to driver method-done

            if (data[KeyRepository.ContractCount] == "Single")
                VerifySinglePaymentsPage();
            else
                VerifyMultiPaymentsPage();
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifySinglePaymentsPage                                          ///////////
        ////// Description:Verify Single Contract Payments Page                                ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////       
        public void VerifySinglePaymentsPage()
        {
            CommonFunctions CF = new CommonFunctions(data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Manage Payments Page-Single Contract" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");
            NYLDSelenium.PageLoad("Manage Payments", PaymentPage);


            NYLDSelenium.ElemNotExist("Contract dropdown list", ContractNumberDropdown,true);

            if (data[KeyRepository.PolicyStatus] == "Cancelled")
                NYLDSelenium.ReportStepResult("Verify policy status of Policy Number: " + data[KeyRepository.PolicyNumber], "Policy is not in Inforce status", "FAIL", "always","yes");

            //TODO: This should be after we select a policy not before-done
            CF.DeterminePolicyStatus();

            //Verify Payment section
            VerifyPaymentSection();
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyMultiPaymentsPage                                          ///////////
        ////// Description:Verify Multi Contract Payments Page                                ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyMultiPaymentsPage()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            PolicyList = new string[] { };
            string PolicyNumber = "";

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Manage Payments Page for Mutliple Contracts" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");
            NYLDSelenium.PageLoad("Manage Payments", PaymentPage);
            NYLDSelenium.ElemExist("Manage Payments Page", ContractNumberDropdown, true);

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollBy(0,-1000);");

            //Capturing the payment eligible policies            
            if (!string.IsNullOrEmpty(CSWData.AssociatedPolicies))
                PolicyList = CSWData.AssociatedPolicies.Split(';');

            // Multi: Contracts listed in drop down -should only be inforce and lapse
            NYLDSelenium.VerifyText("Contract dropdown Header", "Choose a contract number", NYLDSelenium.GetAttribute("Contract dropdown header", ContractHeader));
            //NYLDSelenium.VerifyList("Contract dropdown list", ContractNumberDropdown, PolicyList, "bytext",true,"always","always");


            if (string.IsNullOrEmpty(CSWData.Exisitngpolicyfromsheet))
                CSWData.Exisitngpolicyfromsheet = data[KeyRepository.PolicyNumber];

            //select the policy and verify payment Section
            for (int i = 0; i < PolicyList.Count(); i++)
            {
                //Get Policy Number from policy list queried -Associate policy list 
                string[] phrasePolicy = PolicyList[i].Split(' ');
                PolicyNumber = phrasePolicy.Last();
                string ContractSelected = "//*[contains(text(), '" + PolicyNumber + "')]";

                js.ExecuteScript("window.scrollBy(0,-1000);");
                SelectElement select = new SelectElement(ContractNumberDropdown);
                IList<IWebElement> options = select.Options;
                int ActPolCount = options.Count;
                string actPolicyName = "";

                //Policy list displayed in UI
                for (int j = 0; j < ActPolCount; j++)
                {
                    actPolicyName = options.ElementAt(j).GetAttribute("text").Trim();
                    Thread.Sleep(100);

                    if (actPolicyName.Contains(PolicyNumber))
                    {
                        NYLDSelenium.SelectList("Choose Policy from dropdown", ContractNumberDropdown, actPolicyName, "bytext", true);
                        Thread.Sleep(300);
                        NYLDSelenium.SelectList("Select Policy from dropdown", ContractNumberDropdown, actPolicyName, "bytext", true);
                        data[KeyRepository.PolicyNumber] = PolicyNumber;
                        DB.QueryPaymentDetails();
                        Console.WriteLine("Found- " + PolicyNumber);
                        CF.GetContractCardcolor();
                        //To set the argpass value
                        VerifyPaymentSection(ContractSelected, PolicyNumber);
                        VerifyPaymentFrequencyOptions();
                        //get the family bill details for payment details
                        if (data[KeyRepository.PayCode] == "FB")
                        {
                            DB.QueryFamilyBill();
                            VerifyFamilyBillBanner();
                            FamilyBillAdditionalPaymentDetails();
                        }
                        else
                            VerifyPaymentBillingInformation();
                        goto breakloop;
                    }
                    else if (j == ActPolCount - 1)
                        NYLDSelenium.ReportStepResult("Select policy: " + PolicyList[i], PolicyList[i] + " is not displayed in UI to select", "FAIL", "always", "yes");
                }
            breakloop:
                Console.WriteLine("");
            }
        }

        /// <summary>
        /// Method helps to select the contracts from dropdown and it resuable method for Exisitng contract which we pass the required contract selection
        /// </summary>
        public void ContractdropdownListSelected(string PolicyNumber)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            string actPolicyName = "";
            bool policyfoundinlist = false;

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            PolicyList = new string[] { };

            if (CSWData.AssociatedPolicies != null && CSWData.AssociatedPolicies != "")
                PolicyList = CSWData.AssociatedPolicies.Split(';');

            string ContractSelected = "//*[contains(text(), '" + PolicyNumber + "')]";

            js.ExecuteScript("window.scrollBy(0,-1000);");

            //Getthe dropdown values into options array 
            SelectElement select = new SelectElement(ContractNumberDropdown);
            IList<IWebElement> options = select.Options;
            int ActPolCount = options.Count;

            //Policy list displayed in UI
            for (int j = 0; j < ActPolCount; j++)
            {
                actPolicyName = options.ElementAt(j).GetAttribute("text").Trim();
                Thread.Sleep(100);

                if (actPolicyName.Contains(PolicyNumber))
                {
                    NYLDSelenium.SelectList("Select Policy", ContractNumberDropdown, actPolicyName, "bytext", true);
                    Thread.Sleep(300);
                    NYLDSelenium.SelectList("Select Policy", ContractNumberDropdown, actPolicyName, "bytext", true);
                    data[KeyRepository.PolicyNumber] = PolicyNumber;
                    DB.QueryPaymentDetails();
                    Console.WriteLine("Found- " + PolicyNumber);
                    CF.GetContractCardcolor();
                    policyfoundinlist = true;
                    break;
                }
                if (policyfoundinlist == true)
                    break;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyOwnerandInsuredDetails                                                      ///////////
        ////// Description:Verify Ownerand InsuredDetails                                              ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyOwnerandInsuredDetails()
        {
            CommonFunctions CF = new CommonFunctions(data);

            NYLDSelenium.AddHeader("Verify ManagePayments page - Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "SubHeader");

            CF.GetOwnerandInsuredDetails(ContractOwner, ContractInsured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName);

            //Verify Owner details 
            NYLDSelenium.VerifyText("Contract Owner", ExpOwnerNameandAddr.Trim(), ActualOwnerNameandAddr,"always");

            //Verify Insured details
            NYLDSelenium.VerifyText("Insured", ExpectedInsuredName, ActualInsuredName,"always");
            NYLDSelenium.AddHeader("Verify ManagePayments page - Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "Success");

        }

        /// <summary>
        /// Method helps to Verify Payments Section
        /// </summary>
        /// <param name="ContractSelected"></param>
        /// <param name="PolicyNumber"></param>
        public void VerifyPaymentSection([Optional]string ContractSelected ,[Optional]string PolicyNumber)
        {
            HomePage home = new HomePage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();

            //TODO: Lets discuss the logic here
            string argvalue = "";

            //GoodValue && PastDue
            if (data[KeyRepository.PayCode] == "NN")
                argvalue = "PayCodeNN";
            else if (data[KeyRepository.PolicyStatus] == "Lapse" && data[KeyRepository.ContractCardColor] == "Grey")
                argvalue = "PastDue";

            //NN contract // PastDue
            if ((data[KeyRepository.PayCode] == "NN") || (data[KeyRepository.PolicyStatus] == "Lapse" && data[KeyRepository.ContractCardColor] == "Grey"))
            {
                //To verify the contract information - content display in UI

                if (argvalue.Trim() == "PastDue")
                {
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Payments Page when policy is: " + argvalue.Trim() + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //Verify No contracts page display
                    NYLDSelenium.PageLoad("Payment details page of contract" + data[KeyRepository.PolicyNumber], PastDueSection);
                    //verify past due page content
                    NYLDSelenium.VerifyText("Verify call NYL header", "Please Call New York Life", NYLDSelenium.GetAttribute("CAll NYL header", CallNYLHeader));
                    NYLDSelenium.VerifyText("Verify payment past due information Text 1", "Your premium is more than 52 days past due.", CF.FormatString(NYLDSelenium.GetAttribute("Past due information", PastDueText1)).Trim());
                    NYLDSelenium.VerifyText("Verify payment past due information Text 2", "To discuss payment options and reinstate your contract, please call:", CF.FormatString(NYLDSelenium.GetAttribute("Past due information", PastDueText2)).Trim());

                    NYLDSelenium.VerifyText("Verify contact number", testData.GetContent("ContactNumber"), NYLDSelenium.GetAttribute("Past due phone number", PastDueContactNumb));
                    NYLDSelenium.VerifyText("Verify contact Time", testData.GetContent("ContactTime"), CF.FormatString(NYLDSelenium.GetAttribute("Past due Time", PastDueContactTime)).Trim());
                }
                else if (argvalue.Trim() == "PayCodeNN")
                {                    
                    string NNcontractSelected = "//div[contains(text(), 'Regarding Contract " + data[KeyRepository.PolicyNumber] + "')]";
                    NYLDSelenium.PageLoad("Payment details page of contract" + data[KeyRepository.PolicyNumber], NYLDSelenium.GetWE(NNcontractSelected, true, 0));

                    NYLDSelenium.AddHeader("Verify Payments Page for contact " + data[KeyRepository.PolicyNumber], "SubHeader");

                    NYLDSelenium.VerifyText("Payment page header for Payment code NN", "Regarding Contract " + data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Payment Code NN payment page header", PayCodeNNPaymentPageHeader));
                    NYLDSelenium.VerifyText("Payment page message for Payment code NN", "Good news! As you were notified by mail, your current " + CF.GetCurrentFrequencyWithPremium("").Split(',')[0] + " premium has been reduced to $0 a month, due to a change to your premium rates. Please rest assured, there is no decrease in the benefits that you have in place. You can simply enjoy them with no premium due. Thank you for trusting New York Life with your life insurance needs.", CF.FormatString(NYLDSelenium.GetAttribute("Payment Code NN payment page header", PayCodeNNPaymentPageMessage)).Replace("  ", " "));

                    NYLDSelenium.AddHeader("Verify Payments Page for contact " + data[KeyRepository.PolicyNumber], "Success");
                }

                if (data[KeyRepository.ContractCount] == "Single")
                {
                    //Click on return to home
                    NYLDSelenium.Click("Return to home", PastDueReturntohome);

                    //verify life insurance page load
                    NYLDSelenium.PageLoad("Life Insurance Overview", home.SummaryPage);
                }
            }
            else
            {
                //Multi contract 
                if (data[KeyRepository.ContractCount] != "Single")
                    NYLDSelenium.PageLoad("Payment details of contract: " + PolicyNumber, NYLDSelenium.GetWE(ContractSelected, true, 0), "always", "always", true, 240);

                VerifyPaymentDetails();
            }
        }

        /// <summary>
        /// Method to verify Family bill banner 
        /// </summary>
        public void VerifyFamilyBillBanner()
        {           
            NYLDSelenium.AddHeader("Verify ManagePayments Page - Family Bill Banner " + data[KeyRepository.PolicyNumber], "SubHeader");
            
            NYLDSelenium.VerifyText("Family Bill banner", "This contract is currently enrolled in Group Billing under Group Number " + data[KeyRepository.FamilyBillGroupID] + ". Contracts included in the group:", NYLDSelenium.GetAttribute("Family Bill banner text", FamilyBillBannerText).Replace("\r\n", " ").Trim(),"always");
           
            SelectElement select = new SelectElement(ContractNumberDropdown);
            IList<IWebElement> options = select.Options;
            IList<IWebElement> contracts = null;
            int ActPolCount = options.Count;
            string actualContracts = "";

            //Expand the banner if dispayed 
            if (NYLDSelenium.GetWE("//a[@id='group-policies-show-more']") != null)
            {
                IWebElement ExpandLink = driver.FindElement(By.XPath("//a[@id='group-policies-show-more']"));
                ExpandLink.Click();
            }

            //Get Actual contract displayed
            Thread.Sleep(3000);

            //Verify which type of contracts are displayed
            if (NYLDSelenium.GetWE("//a[@id = 'group-policies-show-more']/..//span[@class='mr-2']") != null)
                contracts = FamilyBillPolNumGreaterThanFive;
            else
                contracts = FamilyBillPolNumUptoFive;

            //Build contracts string
            foreach (IWebElement we in contracts)
            {
                actualContracts = actualContracts + " " + we.Text;
            }

            //Compare expected vs actual contracts list        
            NYLDSelenium.VerifyText("Policies displayed in the Banner", CSWData.TempVal.Trim(), actualContracts.Replace("   ", "").Trim(),"always");

            NYLDSelenium.AddHeader("Verify Family Bill banner displayed for contract - " + data[KeyRepository.PolicyNumber], "Success");
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaymentDetails                                                       ///////////
        ////// Description:Verify Payment Details Page Section                                  ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyPaymentDetails()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            NYLDSelenium.AddHeader("Verify ManagePayments - Payment Section for - " + data[KeyRepository.PolicyNumber], "SubHeader");

            DB.QueryPolicyDetails();
            DB.QueryPaymentDetails();
            DB.QueryQuarterlyPaymntElig();

            //Verify the contract card color 
            CF.GetContractCardcolor();

            //Verify Payment info,frequency type,payment options
            VerifyOwnerandInsuredDetails();
            //Verify Payment Options();
            if (data[KeyRepository.PolicyStatus] == "Inforce")
            {
                if (data[KeyRepository.PayCode] != "ET")
                    VerifyPaymentOptionsForNonEFT();
                else if (data[KeyRepository.PayCode] == "ET")
                {
                    string[] policies = CSWData.AssociatedPolicies.Split(';');
                    if (policies[0] == data[KeyRepository.PolicyNumber])
                        VerifyPaymentOptionsForEFT();
                    else
                        VerifyPaymentOptionsForNonEFT();
                }
            }

            NYLDSelenium.AddHeader("Verify ManagePayments - Payment Section & Owner /Insured Details validation success for - " + data[KeyRepository.PolicyNumber], "Success");           
        }

        /// <summary>
        /// Method to verify payment frequency options for a contract
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentFrequencyOptions()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify ManagePayments - Payment Frequency Section for -"+data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

            if (data[KeyRepository.PayCode] == "FB")
            {
                NYLDSelenium.ElemNotExist("Payment frequency section is not appliciable for FamilyBill group", PaymntfreqHeader, true, "no", "always");
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify ManagePayments - Payment Frequency Section validation  is not displayed as expected" + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO");
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify ManagePayments - Payment Frequency Section validation  is not displayed as expected" + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO");
            }
            else
            {
                if (data[KeyRepository.PayCode] != "ET" && data[KeyRepository.ContractType] != "EPPContract" && data[KeyRepository.PolicyStatus] != "Cancelled")
                {
                    NYLDSelenium.AddHeader("Verify payment frequency section of contract " + data[KeyRepository.PolicyNumber] +" Pending payment / Waiver of Premium is active then Pay frequency section for the contract", "SubHeader");
                  
                    VerifyPaymentFrequencySection();
                    if (!DB.PendingPayment() && CSWData.QuarterlyEligibility)
                    {    
                        if (UpdatepayFreqency.Enabled)
                            NYLDSelenium.ElemExist("Change payment frequency submit button", UpdatepayFreqency);
                    }

                    //Pending payment verification should not display the Payment frequency
                    if (data[KeyRepository.PayCode] != "ET" && DB.PendingPayment())
                        NYLDSelenium.ElemNotExist("Payment freqeuncy header absence when there is a pending payment for contract", PaymntfreqHeader);
                    NYLDSelenium.AddHeader("Verify payment frequency section of contract " + data[KeyRepository.PolicyNumber] + " Pending payment / Waiver of Premium is active then Pay frequency section for the contract", "Success");
                    if (DB.PendingPayment() || CSWData.QuarterlyEligibility == false)
                        NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify payment frequency section of contract " + data[KeyRepository.PolicyNumber] + "</h3>", "Pending payment / Waiver of Premium is active then Pay frequency section for the contract " + data[KeyRepository.PolicyNumber] + " is not displayed as expected ", "PASS");
                    else
                        NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify payment frequency section of contract " + data[KeyRepository.PolicyNumber] + "</h3>", "Pay frequency section details for the contract " + data[KeyRepository.PolicyNumber] + " is displayed as expected ", "PASS");
                    
                }
                else
                {
                    if (data[KeyRepository.PayCode] == "ET" && NYLDSelenium.ElemNotExist("Cancel", CancelPaymentOption_label, false, "no", "no", "no"))
                        NYLDSelenium.ElemExist("Payment frequency header", PaymntfreqHeader, true, "no", "always");
                    else
                        NYLDSelenium.ElemNotExist("Payment frequency header", PaymntfreqHeader, true, "no", "always");
                }
            }
        }

    private void VerifyPaymentFrequencySection()
    {
        LSPDatabase DB = new LSPDatabase(driver, data);
        bool isPendingPayement = DB.PendingPayment();

        //Checl if Pending Payment Exists 
        switch (data[KeyRepository.CurrentPaymentFrequency])
        {
            case "M":
                //Check if Quarterly Option is available if this contract is eligible if Quarterly Eligible and no pending payment
                if (CSWData.QuarterlyEligibility && !isPendingPayement)
                {
                        //Check if PayFrequency Section existing
                        NYLDSelenium.ElemExist("Payment Frequency header/Section", PaymntfreqHeader);

                        //Check if Monthly Option is Selected
                        if (!PaymntfreqMonthRadbtn_Checked.Selected)

                        NYLDSelenium.ReportStepResult("Check if monthly Pay frequency is selected", "Payment Frequency option Monthly is selected", "INFO", "always", "no");

                    NYLDSelenium.ElemExist("Quarterly Frequency Option", PaymntfreqMonthlabel);
                }

                else
                    //Check if PayFrequency Section existing
                    NYLDSelenium.ElemNotExist("Payment Frequency header/Section ", PaymntfreqHeader);
                break;
            case "Q":
                //Check if Monthly Option is available if this contract is eligible if Quarterly Eligible and no pending payment

                if (CSWData.MonthlyEligibility && !isPendingPayement)
                {
                    //Check if PayFrequency Section existing
                    NYLDSelenium.ElemExist("Payment Frequency header/Section", PaymntfreqHeader);
                    //Check if Quarterly Option is Selected
                    if (!PaymntfreqQuatrRadbtn_Checked.Selected)
                    NYLDSelenium.ReportStepResult("Check if monthly Pay frequency is selected", "Payment Frequency option Monthly is selected", "INFO", "always", "no");

                    //Check if Monthly Option is available if this contract is eligible if Monthly Eligible and no pending payment
                    if (CSWData.MonthlyEligibility && !isPendingPayement)
                        NYLDSelenium.ElemExist("Monthly Frequency Option", PaymntfreqMonthlabel);
                }else
                    //Check if PayFrequency Section existing
                    NYLDSelenium.ElemNotExist("Payment Frequency header/Section ", PaymntfreqHeader);
                break;
            }
        }

        /// <summary>
        /// Method helps to Verify No Frequency Section in Manage payments page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyNoFrequencyOption(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify User Payment Frequency Option Not Eligible" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            LSPDatabase DB = new LSPDatabase(driver, data);
            driver.Navigate().Refresh();
            if (DB.PendingPayment())
                NYLDSelenium.ElemNotExist("Payment freqeuncy header absence when there is a pending payment for contract", PaymntfreqHeader);
        }

        /// <summary>
        /// Method to verify Payment details other than FamilyBill
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentBillingInformation()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            RestServices webServices = new RestServices(data);
            bool DueEntryFound = false;

            NYLDSelenium.AddHeader("Verify Manage Payments - Billing Section for - " + data[KeyRepository.PolicyNumber], "SubHeader");

            //verify Contract number header
            IWebElement header = driver.FindElement(By.XPath("//h3[contains(text(), 'Manage payments')]"));
            //Verify Header              
            NYLDSelenium.VerifyText("Contract Number header", "Manage payments for: " + data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract Number header", header),"always");
            //verify payment info header
            NYLDSelenium.VerifyText("Payment information header", "Payment information", NYLDSelenium.GetAttribute("Contract header", PaymentInformationHeader),"always");

            //verify Paymnet info table details 
            CSWData.PaymentInformation.Clear();
            webServices.SubmitRestCall("PaymentInformation");

            IList<IWebElement> NumberOfDues = BillingInfoTableContent.ToList();
            IList<string> BillingInfoFromApplication = new List<string>();

            foreach (IWebElement we in NumberOfDues)
            {
                BillingInfoFromApplication.Add(we.Text.Replace("\r\n", " "));
            }

            //Verify Payment frequency and Policy Status
            NYLDSelenium.VerifyText("Current payment frequency", "Current " + CF.GetCurrentFrequencyWithPremium("").Split(',')[0] + " Premium: $" + data[KeyRepository.Premium].PadLeft(2,'0') + " Status: " + data[KeyRepository.PolicyStatus], BillingInfoFromApplication[0],"always");

            //verify policy status bubble information
            NYLDSelenium.Click("Contract status information bubble", payInfoIcon, true);
            NYLDSelenium.VerifyText("text displayed in status bubble", CF.GetPolicyStatusMessage(), NYLDSelenium.GetAttribute("status Info text", payInfoIcon, "data-original-title"),"always");

            //verify the UI and Webservice list          
            for (int i = 0; i < CSWData.PaymentInformation.Count(); i++)
            {
                DueEntryFound = false;
                for (int j = 1; j < BillingInfoFromApplication.Count(); j++)
                {
                    if (CSWData.PaymentInformation[i].Trim() == BillingInfoFromApplication[j].Replace(",", "").Trim())
                    {
                        DueEntryFound = true;
                        NYLDSelenium.VerifyText("Billing Information Entry", CSWData.PaymentInformation[i].Trim(), BillingInfoFromApplication[j].Replace(",", "").Trim(), "always");
                        break;
                    }
                    else if (!DueEntryFound && j == BillingInfoFromApplication.Count() - 1)
                        NYLDSelenium.ReportStepResult("Verify " + CSWData.PaymentInformation[i].Trim() + " entry exists in Billing Information section", CSWData.PaymentInformation[i].Trim() + " entry is not found in Billing Information section and Actual Value is " + BillingInfoFromApplication[j].Replace(",", ""), "FAIL","always");
                }
            }

            NYLDSelenium.AddHeader("Verify ManagePayments - Billing Section for - " + data[KeyRepository.PolicyNumber], "Success");
        }

        /// <summary>
        /// Method to verify FamilyBill Additional PaymentDetails 
        /// </summary>
        /// <param name="args"></param>
        public void FamilyBillAdditionalPaymentDetails()
        {
            //TODO: Raj 2023 Shall we have seperate method for the same - like FamilyBill Additional PaymentDetails -done
            CommonFunctions CF = new CommonFunctions(data);
            bool DueEntryFound = false;
            IWebElement header = driver.FindElement(By.XPath("//h3[contains(text(), 'Manage payments')]"));

            //Verify Header
            NYLDSelenium.VerifyText("Contract Number header", "Manage payments for: " + data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract header", header));

            //verify payment info header
            NYLDSelenium.VerifyText("Payment information header", "Payment information", NYLDSelenium.GetAttribute("Contract header", PaymentInformationHeader));

            //verify policy status bubble information 
            NYLDSelenium.Click("Contract status information bubble", payInfoIcon, true);


            #region//################################------Contract Status ----------#######################//

            NYLDSelenium.AddHeader("Verify Contract Status - " + data[KeyRepository.PolicyNumber], "SubHeader");

            NYLDSelenium.VerifyText("text displayed in status bubble", CF.GetPolicyStatusMessage(), NYLDSelenium.GetAttribute("status Info text", payInfoIcon, "data-original-title"), "always");

            NYLDSelenium.AddHeader("Verify Contract Status - " + data[KeyRepository.PolicyNumber], "Success");
            #endregion//#######################################################################################//


            #region  //################################------Current Payment Frequency  /  Billing Information ----------#######################//
           
            NYLDSelenium.AddHeader("Billing Section for - " + data[KeyRepository.PolicyNumber], "SubHeader");
            IList<IWebElement> NumberOfDues = BillingInfoTableContent.ToList();
            IList<string> BillingInfoFromApplication = new List<string>();


            var Frequencytype = CF.GetCurrentFrequencyWithPremium("").Split(',')[0];
            foreach (IWebElement we in NumberOfDues)
            {
                BillingInfoFromApplication.Add(we.Text.Replace("\r\n", " "));
            }

            NYLDSelenium.VerifyText("Current payment frequency", "Current Group " + Frequencytype + " Premium: $" + data[KeyRepository.Premium].PadLeft(2,'0') + " Status: " + data[KeyRepository.PolicyStatus], BillingInfoFromApplication[0],"always");


            for (int i = 0; i < CSWData.PaymentInformation.Count(); i++)
            {
                DueEntryFound = false;
                for (int j = 1; j < BillingInfoFromApplication.Count(); j++)
                {
                    if (CSWData.PaymentInformation[i].Trim() == BillingInfoFromApplication[j].Replace(",", "").Trim())
                    {
                        DueEntryFound = true;
                        NYLDSelenium.VerifyText("Verify Billing Information Entry" , CSWData.PaymentInformation[i].Trim() , BillingInfoFromApplication[j].Replace(",", "").Trim(),"always");
                        break;
                    }
                    else if (!DueEntryFound && j == BillingInfoFromApplication.Count() - 1)
                        NYLDSelenium.ReportStepResult("Verify " + CSWData.PaymentInformation[i].Trim() + " entry exists in Billing Information section", CSWData.PaymentInformation[i].Trim() + " entry is not found in Billing Information section and actual value :"+ BillingInfoFromApplication[j].Replace(",", ""), "FAIL", "always","no");
                }
            }
            NYLDSelenium.AddHeader("Billing Information section displayed the premium details as expected for - " + data[KeyRepository.PolicyNumber], "Success");

            #endregion //#######################################################################################//

        }

        /// <summary>
        /// Method to Verify PaymentOptions For EFT 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentOptionsForEFT()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            RestServices webServices = new RestServices(data);
            Coverage.MyBeneficiariesPage beneficiary = new Coverage.MyBeneficiariesPage(driver, data);
            TestData testData = new TestData();

            NYLDSelenium.AddHeader("Premium Payment Labels - Automatic, Autopay, Cancel ", "SubHeader");

            if (NYLDSelenium.ElemExist("Update EFT section", UpdateAutoPaymentHeader,true, "no", "no","no"))
            {
                string UpdataAutoPayment = NYLDSelenium.GetAttribute("Auto Premium Payment definition", AutoPayOption_label).Replace(Environment.NewLine, " ");
                string ExpUpdateAutoPaymentA = "Update Automatic Premium Payment Information " + testData.GetContent("UpdatePaymentOption");
                string ExpUpdateAutoPaymentB = "Update AutoPay Information " + testData.GetContent("UpdatePaymentOption");

                if (!((UpdataAutoPayment == ExpUpdateAutoPaymentA) || (UpdataAutoPayment == ExpUpdateAutoPaymentB)))
                    NYLDSelenium.ReportStepResult("Verify Automatic Premium Payment Label", "Automatic Premium Payment Label displayed is not expected", "Fail", "always","no");


                string CancelAutoPayment = NYLDSelenium.GetAttribute("Cancel Automatic Payment definition", CancelPaymentOption_label).Replace(Environment.NewLine, " ");
                string CancelAutoPamyentA = "Cancel Automatic Premium Payment " + testData.GetContent("CancelPaymentOption");
                string CancelAutoPaymentB = "Cancel AutoPay " + testData.GetContent("CancelPaymentOption");

                if (!((CancelAutoPayment == CancelAutoPamyentA) || (CancelAutoPayment == CancelAutoPaymentB)))
                    NYLDSelenium.ReportStepResult("Verify Cancel Premium Payment Label", "Automatic Premium Payment Label displayed is not expected", "Fail", "always", "no");
            }
            else
                NYLDSelenium.ReportStepResult("Update EFT section not displayed", "Update EFT section is not dispalyed for the contract with paycode ET, Contract Number: " + data[KeyRepository.PolicyNumber], "Fail", "always", "yes");
                
            NYLDSelenium.AddHeader("Premium Payment Labels ", "Success");
            CSWData.PaymentInformation.Clear();
        }

        /// <summary>
        /// Method to Verify PaymentOptions For NonEFT
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentOptionsForNonEFT()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            RestServices webServices = new RestServices(data);
            TestData testData = new TestData();

            string policystatus = "Lapse";
            NYLDSelenium.AddHeader("Verify select payment method section of contract " + data[KeyRepository.PolicyNumber], "SubHeader");

            IList<IWebElement> paymentOptions = driver.FindElements(By.XPath("//label[contains(@for, 'paymentmethod')]"));

            //Verify Payment options displayed --calling the service 
            bool EFTeligible;
            string EFTStatus = webServices.SubmitRestCall("CheckEFTElig");


            if (EFTStatus == "Not Eligible" || EFTStatus == "Existing EFT")
                EFTeligible = false;
            else
                EFTeligible = true;

            if (data[KeyRepository.ContractType] != "PastDue"  && data[KeyRepository.PolicyStatus] != policystatus)
            {
                NYLDSelenium.VerifyText("Payment method header", "Select payment method", NYLDSelenium.GetAttribute("Payment method header", SelectPaymntHeader),"always");

                if (EFTeligible && data[KeyRepository.PayCode] != "FB")
                {                    
                    NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

                    string SignUpAutoPayLabel = NYLDSelenium.GetAttribute("Auto Premium Payment definition", AutoPayOption_label).Replace(Environment.NewLine, "");
                    string ExpSignUpAutoPayLabelA = "Sign up for AutoPay";

                    if (!SignUpAutoPayLabel.Contains(ExpSignUpAutoPayLabelA))
                        NYLDSelenium.ReportStepResult("Verify Sign Up for Auto Pay Label", "Sign Up for Auto Pay Label displayed is not expected", "INFO");


                    if (AutoPayOption.Selected)
                        NYLDSelenium.ReportStepResult("Verify if Automatic Premium payment option is selected by default", "Automatic Premium payment option was selected by default", "Fail", "always", "yes");
                    else
                        NYLDSelenium.ReportStepResult("Verify if Automatic Premium payment option is selected by default", "Automatic Premium payment option was not selected by default as expected", "Pass", "always", "no");
                }
                else
                    NYLDSelenium.ElemNotExist("Automatic Premium payment option", AutoPayOption_label);

                //Managepayments change to Online Easy Pay
                if ( NYLDSelenium.ElemExist("Verify Online Pay", OnlineEasyPayOption_label, true, "no", "no", "no"))
                    NYLDSelenium.ReportStepResult("Verify if Online Easy Pay is displayed", "Online Easy Pay option is available as expected", "Pass", "always", "no");
                else
                    NYLDSelenium.ReportStepResult("Verify if Online Easy Pay is not displayed", "Online Easy Pay option is not available as expected", "Fail", "always", "yes");

                //OneTime Payment
                if (NYLDSelenium.ElemExist("Verify Manage Payment", OneTimePaymentOption_label, true, "no", "no", "no") || NYLDSelenium.ElemExist("Verify Online Pay", OneTimePayment_label, true, "no", "no", "no"))
                    NYLDSelenium.ReportStepResult("Verify if OneTime Payment is displayed", "OneTime payment option is available as expected", "Pass", "always");
                else
                    NYLDSelenium.ReportStepResult("Verify if OneTime Payment is not displayed", "OneTime payment option is not available as expected", "Fail", "always");

                NYLDSelenium.AddHeader("Verify select payment method section of contract " + data[KeyRepository.PolicyNumber], "Success");  
            }

            //check if option selected by default
            if (ManageMyPaymentsOption.Selected || OneTimePaymentOption.Selected)
            {
                string PaymentMethod;
                if (ManageMyPaymentsOption.Selected)
                    PaymentMethod = "Manage My payment";
                else
                    PaymentMethod = "One Time payment";

                NYLDSelenium.ReportStepResult("Verify if " + PaymentMethod + " option is selected by default", PaymentMethod + " option was selected by default", "Fail", "always","yes");
            }
            else
                NYLDSelenium.ReportStepResult("Verify if Manage Payment and One Time Payment options are not selected by default", "Manage Payment and One Time Payment options were not selected by default as expected", "PASS", "always", "no");

            //continue button not present
            if (PaymentContinueButton.Enabled)
                NYLDSelenium.ElemNotExist("My Payments page continue button", PaymentOptionContinueButton);


            CSWData.PaymentInformation.Clear();
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SelectPaymentOption                                                        ///////////
        ////// Description: Selecting the payment option from parameter                         ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void SelectPaymentOption(string option) //TODO:Rajk 2023 Lets review the method
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Select Payment Channel" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            switch (option)
            {
                case "NewAutoPay":
                case "SignUpAutoPay":
                    NYLDSelenium.Click("Sign Up for AutoPay", AutoPayOption_label);
                    break;
                case "UpdateAutoPay":
                    NYLDSelenium.Click("Update AutoPay", UpdatePaymentOption_label);
                    break;
                case "CancelAutoPay":
                    NYLDSelenium.Click("Cancel Autopay", CancelPaymentOption_label);
                    break;
                case "Manage":
                    NYLDSelenium.Click("OnlineEasy Pay", OnlineEasyPayOption_label);
                    break;
                case "FIS":
                case "one-timePayment":
                    NYLDSelenium.Click("One Time Payement", OneTimePaymentOption_label);
                    break;
            }

            CSWData.EventTriggerTime = DateTime.Now;
            NYLDSelenium.Click("Continue", ContinueButton, true, "always", "always");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaymentOption                                                        ///////////
        ////// Description: Verify the payment option from parameter                         ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyPaymentOption(string option)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Payment Channel & Payment Frequency" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            NYLDSelenium.ElemNotExist("Verify Manage Payment", OneTimePaymentOption_label, true, "no", "always", "always");
            NYLDSelenium.ElemNotExist("Payment frequency section is not display for Lapse Contract", PaymntfreqHeader, true, "no", "always", "always");
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify ManagePayments - OneTimePaymentOption & Payment Frequency Section is not displayed as expected" + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO");
        }
    }
}
