﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using iText.StyledXmlParser.Jsoup.Select;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Web.UI.WebControls;
using static CSW.PageObjects.Email.EmailInformation;
using static Spire.Pdf.General.Render.Font.OpenTypeFile.Table_cmap.Format2;

namespace CSW.PageObjects.Payments
{
    class AutoPayPage : ManagePaymentsPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;
        public IWebElement selectedpickadate;

        public AutoPayPage(IWebDriver webDriver, Dictionary<string, string> testdata) : base(webDriver, testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        //Update EFT Page
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(), 'Update payment information')]")]
        public IWebElement UpdateAutoPayPage { get; set; }

        //Routing Number Header
        [FindsBy(How = How.XPath, Using = "//label[contains(text(),'Routing Number')]")]
        public IWebElement RoutingNumberLabel { get; set; }

        //Routing Number
        [FindsBy(How = How.XPath, Using = "//*[@id='RoutingNumber']")]
        public IWebElement RoutingNumberInputField { get; set; }

        //Routing Number Error
        [FindsBy(How = How.XPath, Using = "//*[@id='RoutingNumber-error']")]
        public IWebElement RoutingNumberError { get; set; }

        //Routing Number Show
        [FindsBy(How = How.XPath, Using = "//input[@id='RoutingNumber']/following-sibling::div/button[text()='Show']")]
        public IWebElement RoutingNumberShowLink { get; set; }

        //Account Number Header
        [FindsBy(How = How.XPath, Using = "//label[contains(text(),'Account Number')]")]
        public IWebElement AccountNumberLabel { get; set; }

        //Account Number
        [FindsBy(How = How.XPath, Using = "//*[@id='AccountNumber']")]
        public IWebElement AccountNumberInputField { get; set; }

        //Account Number Error
        [FindsBy(How = How.XPath, Using = "//*[@id='AccountNumber-error']")]
        public IWebElement AccountNumberError { get; set; }

        //Account Number Show
        [FindsBy(How = How.XPath, Using = "//input[@id='AccountNumber']/following-sibling::div/button[text()='Show']")]
        public IWebElement AccountNumberShowLink { get; set; }

        //Review And Confirm
        [FindsBy(How = How.XPath, Using = "//label[@for='ReviewAndConfirm']")]
        public IWebElement ReviewAndConfirm { get; set; }

        //Review And Confirm label
        [FindsBy(How = How.XPath, Using = "//label[contains(text(),'I am an authorized signer on this bank account.')]")]
        public IWebElement ReviewAndConfirm_label { get; set; }

        //Cancel Review And Confirm label
        [FindsBy(How = How.XPath, Using = "//label[contains(text(),'I agree with the terms and conditions above.')]")]
        public IWebElement CancelReviewAndConfirm_label { get; set; }

        //Thank You Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(.,'Thank you')]")]
        public IWebElement ThankYouHeader { get; set; }

        //Enrolled Success Message
        [FindsBy(How = How.XPath, Using = "(//*[@id='main']//following-sibling::p)[1]")]
        public IWebElement EnrolledSuccessMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='preferredPayDateSelected']")]
        public IWebElement PreferredPayDateSelected { get; set; }

        //EFT Details
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Current bank account')]/../div[1]/div")]
        public IList<IWebElement> EFTDetails_Current { get; set; }

        //EFT Details
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'You have successfully')]/../div[1]/div")]
        public IList<IWebElement> EFTDetails_Update { get; set; }

        //Bank Account Information Header
        [FindsBy(How = How.XPath, Using = "(//p[contains(text(),'Bank account information')])")]
        public IWebElement BankAccountInfomrmationSectionTitle { get; set; }

        //Bank Account Information Header - NEW EFT
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Bank account information')]")]
        public IWebElement BankAccountInfomrmationHeader_NewEFT { get; set; }

        //Current Bank Account Information Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Current bank account information')]")]
        public IWebElement CurrentBankAccountInfomrmationHeader { get; set; }

        //Terms And Conditions Header
        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Terms and Conditions')]")]
        public IWebElement TermsAndConditionsHeader { get; set; }

        //Terms And Conditions Text
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Terms and Conditions')]")]
        public IWebElement TermsAndConditionsText { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='col-12 mb-3 py-3 px-4 alert-warning custom-terms-text']")]
         public IWebElement TermsAndConditionsBodyText { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='col-12 py-3 px-4 alert-warning']")]
         public IWebElement TermsAndConditionsThankyouBodyText { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='autopay - form']//following-sibling::p[2][contains(text(),'Choose any date')]")]
        public IWebElement Ongoingdebitdate { get; set; }

        //Terms And Conditions Header
        [FindsBy(How = How.XPath, Using = "//*[@id='autopay-form']/div/div[5]/div")]
        public IWebElement TermsAndConditionsBody { get; set; }

        //Terms And Conditions Header
        [FindsBy(How = How.XPath, Using = "//*[@id='autopay-form']/div/div[4]/div")]
        public IWebElement TermsAndConditionsBodyNewEFT { get; set; }

        //Terms And Conditions Header
        [FindsBy(How = How.XPath, Using = "//*[@id='main']/section/div/div/div[1]/div[2]/div[2]/div")]
        public IWebElement TermsAndConditionsBodyTY { get; set; }

        //Print Confirmation Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Print confirmation')]")]
        public IWebElement PrintConfirmationButton { get; set; }

        //Cancel Auto Pay Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Cancel AutoPay')]")]
        public IWebElement CancelAutoPayHeader { get; set; }

        //Cancelled Succes Message
        [FindsBy(How = How.XPath, Using = "(//*[@id='main']//following-sibling::p)[1]")]
        public IWebElement CancelledSuccesMessagehdr { get; set; }

        //Cancelled Succes Sub message
        [FindsBy(How = How.XPath, Using = "(//*[@id='main']//following-sibling::p)[2]")]
        public IWebElement CancelledSuccesSubmessage { get; set; }

        //Verify Address Message
        [FindsBy(How = How.XPath, Using = "(//*[@id='main']//following-sibling::p)[3]")]
        public IWebElement VerifyAddressMessage { get; set; }

        //Update My Address Link
        [FindsBy(How = How.XPath, Using = "(//a[contains(text(),'Update my address')])[1]")]
        public IWebElement UpdateMyAddressLink { get; set; }

        //Update Payment Frequency Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Update payment frequency')]")]
        public IWebElement UpdatePaymentFrequencyHeader { get; set; }

        //Cancelled Succes Sub message
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'payment in process')]")]
        public IWebElement CancelledPendingSubmessage { get; set; }

        //Enroll in AutoPay Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Enroll in AutoPay and')]")]
        public IWebElement NewAutoPayPage { get; set; }


        //Debit day list dropdown and content change based on day - calculate the Efective date calculated
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(), 'Choose your ongoing debit day (optional)')]")]
        public IWebElement Debitday { get; set; }

        //Contract Number Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='PreferredPaymentDate']")]
        public IWebElement DebitdayDropdown { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        public string[] DebitDayList = { "Select", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28" };

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////
        

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: Verify New Auto Pay Page                                                   ///////////
        ////// Description: Verify new Auto Pay                                                 ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyNewAutoPayPage()
        {
            
            TestData testData = new TestData();
            CommonFunctions CF = new CommonFunctions(data);
            Random randomClass = new Random();

           
            NYLDSelenium.AddHeader("Verify New Automatic Premium Payment Page", "SubHeader");
            // Ensure "New Auto Pay" page is loaded
            NYLDSelenium.PageLoad("New AutoPay", NewAutoPayPage,"always","always",true);
            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink);

            // Verify header texts
            NYLDSelenium.VerifyText("Enroll in AutoPay header", testData.GetContent("NewEFTHeaderText"),
                NYLDSelenium.GetAttribute("Enroll in AutoPay header", NewAutoPayPage));
            NYLDSelenium.VerifyText("Payment frequency header", "Payment frequency",
                NYLDSelenium.GetAttribute("Payment frequency header", PaymentFrequencyHeader));
            NYLDSelenium.VerifyText("Bank account information header", "Bank account information",
                NYLDSelenium.GetAttribute("Bank account information header", BankAccountInfomrmationHeader_NewEFT));
            NYLDSelenium.VerifyText("Terms and Conditions header", "*Terms and Conditions",
                NYLDSelenium.GetAttribute("Terms and Conditions header", TermsAndConditionsHeader));

            // Payment frequency option visibility
            VerifyPaymentFrequencyOption();

            // Routing and Account Number fields verification
            VerifyRoutingAndAccountNumberFields();

            // Review and Confirm section
            NYLDSelenium.ElemExist("Review and Confirm", ReviewAndConfirm);
            NYLDSelenium.VerifyText("Review and Confirm Text", testData.GetContent("ReviewAndConfirm"),
                NYLDSelenium.GetAttribute("Review and Confirm Text", ReviewAndConfirm_label, "text", true, "always", "always"), "always");

            // Preferred Payment Date selection and verification
            SelectAndVerifyPreferredPaymentDate(CF, randomClass);

            // Terms And Conditions Text verification
            VerifyTermsAndConditionsText(testData, CF);

            // Continue Button presence check
            NYLDSelenium.ElemExist("Continue Button", ContinueButton);
            NYLDSelenium.AddHeader("Verify New Automatic Premium Payment Page", "Success");
        }

        /// <summary>
        /// Method helps to verify payment Frequency option
        /// </summary>
        /// <param name="DB"></param>
        private void VerifyPaymentFrequencyOption()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
           bool isPendingPayement = DB.PendingPayment();

            switch (data[KeyRepository.CurrentPaymentFrequency])
            {
                case "M":
                    //Check if Monthly Option is Selected
                    if (!PaymntfreqMonthRadbtn_Checked.Selected)
                        NYLDSelenium.ReportStepResult("Check if monthly Pay frequency is selected", "Payment Frequency option Monthly is selected", "INFO", "always", "no");
                    //Check if Quarterly Option is available if this contract is eligible if Quarterly Eligible and no pending payment
                    if (CSWData.QuarterlyEligibility && !isPendingPayement)
                        NYLDSelenium.ElemExist("Quarterly Frequency Option", PaymntfreqQuatrlabel);
                    break;

                case "Q":
                    //Check if Quarterly Option is Selected
                    if (!PaymntfreqQuatrRadbtn_Checked.Selected)
                        NYLDSelenium.ReportStepResult("Check if monthly Pay frequency is selected", "Payment Frequency option Monthly is selected", "INFO", "always", "no");
                    //Check if Monthly Option is available if this contract is eligible if Monthly Eligible and no pending payment
                    if (CSWData.MonthlyEligibility && !isPendingPayement)
                        NYLDSelenium.ElemExist("Monthly Frequency Option", PaymntfreqMonthlabel);
                    break;

            }
        }


        /// <summary>
        /// Method helps to VerifyRoutingAndAccountNumberFields 
        /// </summary>
        private void VerifyRoutingAndAccountNumberFields()
        {
            // Routing Number Label and Input Field verification
            NYLDSelenium.VerifyText("Routing Number Label", "Routing Number",
                NYLDSelenium.GetAttribute("Routing Number Label", RoutingNumberLabel,"text",true,"always","always"),"always");
            NYLDSelenium.ElemExist("Routing Number", RoutingNumberInputField);
            NYLDSelenium.ElemExist("Routing Number Show Link", RoutingNumberShowLink);

            // Account Number Label and Input Field verification
            NYLDSelenium.VerifyText("Accout Number Label", "Account Number",
                NYLDSelenium.GetAttribute("Account Number Label", AccountNumberLabel, "text", true, "always", "always"), "always");
            NYLDSelenium.ElemExist("Account Number Input Field", AccountNumberInputField);
            NYLDSelenium.ElemExist("Account Number Show Link", AccountNumberShowLink);
        }

        private void SelectAndVerifyPreferredPaymentDate(CommonFunctions CF, Random randomClass)
        {
            // Select a random preferred payment date from 1 to 28
          
            NYLDSelenium.SelectList("Select Preferred Payment Date: ", DebitdayDropdown,
                randomClass.Next(1, 28).ToString(), "bytext", true, "always");
            SelectElement selectPaidToDate = new SelectElement(DebitdayDropdown);
            selectedpickadate = selectPaidToDate.SelectedOption;

            data[KeyRepository.selectedpickadate] = selectedpickadate.Text;
            NYLDSelenium.VerifyText("Preferred Payment Selected Date", selectedpickadate.Text +
                CF.GetDaySuffix(Convert.ToInt32(selectedpickadate.Text)),
                NYLDSelenium.GetAttribute("Preferred Payment Selected Date", PreferredPayDateSelected));
        }

        public void VerifyTermsAndConditionsText(TestData testData, CommonFunctions CF)
        {
            NYLDSelenium.Click("Terms And Conditions Text -Verify AutoPay", TermsAndConditionsText,true, "no", "no");
            string termsAndConditionsText = testData.GetContent("Terms And Conditions New AutoPay")
                .Replace("{selectedDate}", data[KeyRepository.selectedpickadate] + CF.GetDaySuffix(Convert.ToInt32(data[KeyRepository.selectedpickadate])));

            var termscondtionsbodytextvalue = GetFormattedAttributeText("Terms And Conditions Text -Verify AutoPay", TermsAndConditionsBodyText);
            NYLDSelenium.VerifyText("Terms And Conditions Text -Verify AutoPay", ("*Terms and Conditions "+termsAndConditionsText).Trim(),termscondtionsbodytextvalue,"always");
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: Fill New Auto Pay form                                                    //////////
        ////// Description: Submitting new  Auto Pay form                                      //////////
        ////////////////////////////////////////////////////////////////////////////////////////////////
        public void SubmitNewAutoPayForm(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            Random randomClass = new Random();
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Set up new Automatic premium Payment Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            string BankRoutingNumber = testData.GetInputData("BankRoutingNumber");
            string BankAccountNumber = testData.GetInputData("BankAccountNumber");

            // Load the New Auto Pay Page
            NYLDSelenium.PageLoad("New AutoPay", NewAutoPayPage);

            // Verify and select from Contract Number dropdown if multiple policies are associated - not required 
            //VerifyAndSelectFromContractDropdown();
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Purple\">" + "Using Policy Number:" + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Purple\">" + "###########" + "</h3>", "INFO", "no");


            // Set Payment Frequency based on args
            SetPaymentFrequency(args.Trim());

            // Fill in Routing and Account Number
            FillInBankDetails(BankRoutingNumber, BankAccountNumber);

            // Select a random preferred payment date and verify selected date
            SelectAndVerifyPreferredPaymentDate(CF, randomClass);

            // Finalize the form submission
            FinalizeFormSubmission("Save");
        }

        private void VerifyAndSelectFromContractDropdown()
        {
            if (CSWData.AssociatedPolicies != null)
            {
                string[] PolicyList = CSWData.AssociatedPolicies.Split(';');
                if (PolicyList.Length > 1)
                {
                    NYLDSelenium.VerifyList("Contract Number", ContractNumberDropdown, PolicyList, "bytext");
                    SelectPolicyFromDropdown(PolicyList);
                }
            }
        }

        private void SelectPolicyFromDropdown(string[] PolicyList)
        {
            SelectElement select = new SelectElement(ContractNumberDropdown);
            foreach (var policy in PolicyList)
            {
                if (select.Options.Any(o => o.Text.Trim() == policy.Trim()))
                {
                    NYLDSelenium.SelectList("Select Policy: " + policy, ContractNumberDropdown, policy, "bytext", true);
                    // Break after selecting to avoid unnecessary iterations
                    break;
                }
            }
        }

        private void SetPaymentFrequency(string frequency)
        {
            if (frequency == "QuarterlyEFT")
            {
                NYLDSelenium.Click("Quarterly", QuarterlyOption_label);
            }
            else if (frequency == "MonthlyEFT")
            {
                NYLDSelenium.Click("Monthly", MonthlyOption_label);
            }
        }

        private void FillInBankDetails(string BankRoutingNumber, string BankAccountNumber)
        {
            NYLDSelenium.SendKeys("Routing Number", RoutingNumberInputField, BankRoutingNumber);
            NYLDSelenium.SendKeys("Account Number", AccountNumberInputField, BankAccountNumber);
            NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);
        }

        private void SelectAndVerifyPreferredPaymentsDate(CommonFunctions CF, Random randomClass)
        {
            NYLDSelenium.SelectList("Select Preferred Payment Date: ", DebitdayDropdown, randomClass.Next(1, 28).ToString(), "bytext", true, "always");
            SelectElement selectPaidToDate = new SelectElement(DebitdayDropdown);
            selectedpickadate = selectPaidToDate.SelectedOption;
            NYLDSelenium.VerifyText("Preferred Payment Selected Date", selectedpickadate.Text + CF.GetDaySuffix(Convert.ToInt32(selectedpickadate.Text)), NYLDSelenium.GetAttribute("Preferred Payment Selected Date", PreferredPayDateSelected));
        }

        private void FinalizeFormSubmission(string msg)
        {
            TestData testData = new TestData();
            string BankRoutingNumber = testData.GetInputData("BankRoutingNumber");
            string BankAccountNumber = testData.GetInputData("BankAccountNumber");

            NYLDSelenium.Click(msg, ContinueButton,true,"always","always");
            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-60);
            // Optionally, store the updated value for future reference
            data[KeyRepository.TempValue] = BankAccountNumber + ":" + BankRoutingNumber;
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyUpdateAutoPayInfoPage                                                ///////////
        ////// Description: Verify update Auto Pay info Page                                    ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyUpdateAutoPayInfoPage()
        {
            TestData testData = new TestData();
            CommonFunctions CF = new CommonFunctions(data);
            Random randomClass = new Random();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Existing Automatic Premium Payment Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            // Load the Update Auto Pay Page
            NYLDSelenium.PageLoad("Update AutoPay Page", UpdateAutoPayPage);

            // Verify page elements and text content
            VerifyPageElementsAndText(testData, CF, randomClass);

            // Finalize form review
            FinalizeFormReview();
        }

        private void VerifyPageElementsAndText(TestData testData, CommonFunctions CF, Random randomClass)
        {
            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink,true,"no","no","no");

            VerifyHeaderText(testData);

            // EFT Details Verification
            VerifyEFTDetails(CF);

            // Routing and Account Number Verification
            VerifyRoutingAndAccountNumber();

            // Preferred Payment Date Selection
            SelectPreferredPaymentDate(randomClass);

            // Terms And Conditions Verification
            VerifyTermsAndConditions(testData, CF);
        }

        /// <summary>
        /// Method helps to VerifyHeaderText 
        /// </summary>
        /// <param name="testData"></param>
        private void VerifyHeaderText(TestData testData)
        {
            NYLDSelenium.AddHeader("Verify Header Text Failed", "SubHeader");
            NYLDSelenium.VerifyText("Update payment information header", "Update payment information",
                NYLDSelenium.GetAttribute("Update payment information header", UpdatePaymentInformationHeader, "text", true, "always"), "always");
            NYLDSelenium.VerifyText("Current Bank account information header", "Current bank account information",
                NYLDSelenium.GetAttribute("Current Bank account information header", CurrentBankAccountInfomrmationHeader, "text", true, "always"), "always");
            NYLDSelenium.VerifyText("Review and Confirm Text", testData.GetContent("ReviewAndConfirm"),
                NYLDSelenium.GetAttribute("Review and Confirm Text", ReviewAndConfirm_label, "text", true, "always"), "always");

            NYLDSelenium.AddHeader("Verify Header Text Failed", "Success");
        }


        /// <summary>
        /// Method helps to verify VerifyEFTDetails
        /// </summary>
        /// <param name="CF"></param>
        private void VerifyEFTDetails(CommonFunctions CF)
        {
            string BankAccountNumber = data[KeyRepository.AccountNumber].Substring(data[KeyRepository.AccountNumber].Length - 4).PadLeft(12, '*');
            VerifyBankAccountNumber(BankAccountNumber);
            VerifyPremiumAmount();
        }

        /// <summary>
        /// Method helps to Verify Bank Account Number
        /// </summary>
        /// <param name="BankAccountNumber"></param>
        private void VerifyBankAccountNumber(string BankAccountNumber)
        {
            NYLDSelenium.AddHeader("Verify Bank AccountNumber", "SubHeader");
            string actualValue = NYLDSelenium.GetAttribute("Automatic premium payment - Bank account number", EFTDetails_Current[0]).Trim().Replace("\r\n", " ");
            NYLDSelenium.VerifyText("Automatic premium payment - Bank account number", "TD BANK NA: " + BankAccountNumber, actualValue,"always");
            NYLDSelenium.AddHeader("Verify Bank AccountNumber", "Success");
        }

        /// <summary>
        /// Method helps to Verify Premium amount
        /// </summary>
        private void VerifyPremiumAmount()
        {
            NYLDSelenium.AddHeader("Verify Premium Amount", "SubHeader");
            string premiumpaymentamount = NYLDSelenium.GetAttribute("Automatic premium payment - Payment amount", EFTDetails_Current[2], "text", true, "always").Trim().Replace("\r\n", " ");
            NYLDSelenium.VerifyText("Automatic premium payment - Payment amount", "Payment Amount: $" + data[KeyRepository.Premium], premiumpaymentamount, "always");
            NYLDSelenium.AddHeader("Verify Premium Amount", "Success");
        }

        /// <summary>
        /// Method helps to VerifyRoutingAndAccountNumber 
        /// </summary>
        private void VerifyRoutingAndAccountNumber()
        {
            NYLDSelenium.AddHeader("Verify Routing And AccountNumber", "SubHeader");
            // Rounting Number fields and labels verification
            NYLDSelenium.VerifyText("Routing Number Header", "Routing Number", NYLDSelenium.GetAttribute("Routing Number header", RoutingNumberLabel));
            NYLDSelenium.VerifyText("Routing Number Input Field", "", NYLDSelenium.GetAttribute("Routing Number Input Field", RoutingNumberInputField));
            NYLDSelenium.ElemExist("Routing Number", RoutingNumberInputField);
            NYLDSelenium.ElemExist("Routing Number Show", RoutingNumberShowLink);

            // Account Number fields and labels verification
            NYLDSelenium.VerifyText("Accout Number Header", "Account Number", NYLDSelenium.GetAttribute("Account Number header", AccountNumberLabel));
            NYLDSelenium.VerifyText("Account Number Input Field", "", NYLDSelenium.GetAttribute("Account Number Input Field", AccountNumberInputField));
            NYLDSelenium.ElemExist("Account Number", AccountNumberLabel);
            NYLDSelenium.ElemExist("Routing Number Show", AccountNumberShowLink);
            NYLDSelenium.AddHeader("Verify Routing And AccountNumber", "Success");
        }

        /// <summary>
        /// Method helps to SelectPreferredPaymentDate
        /// </summary>
        /// <param name="randomClass"></param>
        private void SelectPreferredPaymentDate(Random randomClass)
        {
            NYLDSelenium.AddHeader("Preferred Payment Selected Date", "SubHeader");

            CommonFunctions CF = new CommonFunctions(data);

            NYLDSelenium.SelectList("Select Preferred Payment Date ", DebitdayDropdown, randomClass.Next(1, 28).ToString(), "bytext", true, "always");

            //NYLDSelenium.VerifyList("Select Preferred Payment Date list from dropdown", DebitdayDropdown, DebitDayList, "bytext", true, "always");
            
            SelectElement selectPaidToDate = new SelectElement(DebitdayDropdown);
            selectedpickadate = selectPaidToDate.SelectedOption;

            data[KeyRepository.selectedpickadate] = selectedpickadate.Text;

            NYLDSelenium.VerifyText("Preferred Payment Selected Date", selectedpickadate.Text + CF.GetDaySuffix(Convert.ToInt32(selectedpickadate.Text)),
            NYLDSelenium.GetAttribute("Preferred Payment Selected Date", PreferredPayDateSelected));
            NYLDSelenium.AddHeader("Preferred Payment Selected Date", "Success");

        }

        /// <summary>
        /// Method helps to VerifyTermsAndConditions
        /// </summary>
        /// <param name="testData"></param>
        /// <param name="CF"></param>
        private void VerifyTermsAndConditions(TestData testData, CommonFunctions CF)
        {
            NYLDSelenium.AddHeader("Verify Terms And Conditions", "SubHeader");
            NYLDSelenium.VerifyText("Terms and Conditions header", "*Terms and Conditions",
                NYLDSelenium.GetAttribute("Terms and Conditions header", TermsAndConditionsHeader));
            NYLDSelenium.VerifyText("Terms And Conditions Text", ("*Terms and Conditions " + testData.GetContent("Terms And Conditions New AutoPay").Replace("{selectedDate}", data[KeyRepository.selectedpickadate] + CF.GetDaySuffix(Convert.ToInt32(data[KeyRepository.selectedpickadate])))).Trim(),
               GetFormattedAttributeText("Terms And Conditions Text", TermsAndConditionsBodyText));

            NYLDSelenium.AddHeader("Verify Terms And Conditions", "Success");
        }

        private void FinalizeFormReview()
        {
            NYLDSelenium.ElemExist("Continue Button", ContinueButton);
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: UpdateAutoPaySettings                                                     ///////////
        ////// Description: Update Bank Account Information and Payment Frequency              ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////

        public void UpdateAutoPaySettings(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Update Automatic Premium Payment Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            Random randomClass = new Random();
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();

            // Retrieve bank account information from the data sheet
            string BankRoutingNumber = testData.GetInputData("BankRoutingNumber");
            string BankAccountNumber = testData.GetInputData("BankAccountNumber");

            // Ensure the AutoPay page is loaded
            NYLDSelenium.PageLoad("Update Autopay", UpdateAutoPayPage,"always","always",true);

            // Splitting the arguments to identify the action and its value
            string[] options = args.Split('-');
            string action = options[0].Trim();
            string actionValue = options.Length > 1 ? options[1].Trim() : "";

            // Enter Bank Account Information if specified
            if (action == "BankAccountNumber" || action == "PayFrequency")
            {
                // Enter Account information
                NYLDSelenium.SendKeys("Routing Number", RoutingNumberInputField, BankRoutingNumber,true);
                NYLDSelenium.SendKeys("Account Number", AccountNumberInputField, BankAccountNumber, true);

                // Select a random preferred payment date
                NYLDSelenium.SelectList("Select Preferred Payment Date: ", DebitdayDropdown, randomClass.Next(1, 28).ToString(), "bytext", true, "always");

                
                // Display the selected payment date
                SelectElement selectpaidtodate = new SelectElement(DebitdayDropdown);
                selectedpickadate = selectpaidtodate.SelectedOption;

                data[KeyRepository.selectedpickadate] = selectedpickadate.Text;
                NYLDSelenium.VerifyText("Preferred Payment Selected Date", selectedpickadate.Text + CF.GetDaySuffix(Convert.ToInt32(selectedpickadate.Text)), NYLDSelenium.GetAttribute("Preferred Payment Selected Date", PreferredPayDateSelected));

                // Review and confirm the changes
                CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-60);
                NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);

            }

            // Update Payment Frequency if specified
            if (action == "PayFrequency")
            {
                NYLDSelenium.ElemExist("Routing Number", RoutingNumberInputField, true,"no","no","no");
                switch (actionValue.ToLower())
                {
                    case "quarterly":
                        NYLDSelenium.Click("Quarterly", QuarterlyOption_label);
                        break;
                    case "monthly":
                        NYLDSelenium.Click("Monthly", MonthlyOption_label);
                        break;
                    default:
                        // Handle error or invalid input
                        break;
                }
            }
            // Finalize the form submission
            FinalizeFormSubmission("Update");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyCancelAutoPayPage                                                    ///////////
        ////// Description: Veryfing Cancel AutoPay Page                                        ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyCancelAutoPayPage(string args)
        {
            TestData testData = new TestData();
            CommonFunctions CF = new CommonFunctions(data);
            NYLDSelenium.AddHeader("Verify Cancel AutoPay Page Validation", "SubHeader");
            // Refresh the page to ensure up-to-date content
            RefreshPage();

            // Ensure the "Cancel AutoPay" page is loaded
            NYLDSelenium.PageLoad("Cancel AutoPay", CancelAutoPayHeader);

            // Verify page elements
            VerifyPageElements(testData);

            // Finalize the page review
            FinalizePageReview();

            NYLDSelenium.AddHeader("Verify Cancel AutoPay Page Validation", "Success");
        }

        private void RefreshPage()
        {
            driver.Navigate().Refresh();
            Thread.Sleep(150);
        }

        private void VerifyPageElements(TestData testData)
        {
          
            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink);
            NYLDSelenium.VerifyText("Cancel AutoPay header", "Cancel AutoPay",
                NYLDSelenium.GetAttribute("Cancel AutoPay header", CancelAutoPayHeader),"always");
            NYLDSelenium.VerifyText("Terms And Conditions header", "Terms and Conditions",
                NYLDSelenium.GetAttribute("*Terms And Conditions header", TermsAndConditionsHeader));
            NYLDSelenium.VerifyText("Terms And Conditions Text-Cancel AutoPay", ("Terms and Conditions" + testData.GetContent("Terms And Conditions Cancel AutoPay")).Trim(),
                NYLDSelenium.GetAttribute("Terms And Conditions Text -Cancel AutoPay", TermsAndConditionsText).Trim(),"always");
            NYLDSelenium.VerifyText("Cancel Review and Confirm Text", "I agree with the terms and conditions above.",
                NYLDSelenium.GetAttribute("Cancel Review and Confirm Text", CancelReviewAndConfirm_label),"always");
        }

        private void FinalizePageReview()
        {
            NYLDSelenium.ElemExist("Continue Button", ContinueButton);
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: CancelAutoPay                                                              ///////////
        ////// Description: Submint the Cancelation of AutoPay                                  ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void SubmitCancelAutoPay(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Submit Cancel Automatic premium Payment Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Page load to confirm cancelation of AutoPay 
            NYLDSelenium.PageLoad("Cancel AutoPay", CancelAutoPayHeader);

            NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);
            NYLDSelenium.Click("Continue", ContinueButton);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: Verify set up New AutoPay Thank you Page                                                                    ///////////
        ////// Description: Verifying Thank You AutoPay Page for setting up a new AutoPay or in case there is a pending payment   //////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifySetupNewAutoPayThankYouPage(string args)
        {
            TestData testData = new TestData();
            CommonFunctions CF = new CommonFunctions(data);
            NYLDSelenium.AddHeader("Verify Thank You Page - " + args, "SubHeader");

            // Load the Thank You page and verify essential elements
            LoadAndVerifyEssentialPageElements();

            // Determine and verify the success message based on the scenario
            VerifySuccessMessage(args, testData);

            // Verify bank account and withdrawal date details
            VerifyBankAccountAndWithdrawalDateDetails();

            // Verify payment frequency and amount
            VerifyPaymentFrequencyAndAmount(CF);

            // Verify terms and conditions
            VerifyTermsAndConditionsNewAutoPay(testData, CF);

            // Verify the existence of the Print Confirmation button
            NYLDSelenium.ElemExist("Print confirmation", PrintConfirmationButton);
            NYLDSelenium.AddHeader("Verify Setup New AutoPay ThankYouPage Validation", "Success");

        }

        private void LoadAndVerifyEssentialPageElements()
        {
            NYLDSelenium.PageLoad("Thank You", ThankYouHeader);
            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink);
        }

        private void VerifySuccessMessage(string args, TestData testData)
        {
            string successMessageKey = args == "PendingPayment" ? "SuccessfulEnrollmentWithPendingPayment" : "SuccessfulEnrollmentWithNoPendingPayment";
            string expectedSuccessMessage = testData.GetContent(successMessageKey);
            string actualSuccessMessage = NYLDSelenium.GetAttribute("Enrolled Success Message", EnrolledSuccessMessage).Trim().Replace("\r\n", " ");
            NYLDSelenium.VerifyText("Enrolled Success Message", (expectedSuccessMessage + " " + data[KeyRepository.PolicyNumber] + ".").Trim(), actualSuccessMessage.Trim(), "always", "always");
        }

        private void VerifyBankAccountAndWithdrawalDateDetails()
        {
            CommonFunctions CF = new CommonFunctions(data);
            if (NYLDSelenium.GetAttribute("Automatic premium payment - Bank account number", EFTDetails_Update[0], "text", true, "always", "no").Contains("TD BANK NA"))
            {
                string updatedAccount = data[KeyRepository.TempValue].Split(':')[0];
                string BankAccountNumber = updatedAccount.Substring(updatedAccount.Length - 4).PadLeft(12, '*');
                NYLDSelenium.VerifyText("Automatic premium payment - Bank account number", "TD BANK NA: " + BankAccountNumber, GetFormattedAttribute("Automatic premium payment - Bank account number", EFTDetails_Update[0]), "always");
                
            }
            Thread.Sleep(2000);
            if (NYLDSelenium.GetAttribute("Automatic premium payment - Withdrawal date", EFTDetails_Update[1], "text", true, "no", "no").Contains("Next Withdrawal Date*:"))
            {
                NYLDSelenium.VerifyText("Automatic premium payment - Withdrawal date", "Next Withdrawal Date*: " + CF.PaidToDate(data[KeyRepository.selectedpickadate]), GetFormattedAttribute("Automatic premium payment - Withdrawal date", EFTDetails_Update[1]), "always"); ;
                Console.WriteLine("Automatic premium payment - Withdrawal date -PASS");
            }
        }

        private void VerifyPaymentFrequencyAndAmount(CommonFunctions CF)
        {
            string paymentAmount = "Payment Amount: $" + CF.GetCurrentFrequencyWithPremium("").Split(',')[2];
            string payFrequency = "Payment frequency " + CF.GetCurrentFrequencyWithPremium("").Split(',')[0];
            NYLDSelenium.VerifyText("Automatic premium payment - Payment amount", paymentAmount, GetFormattedAttribute("Automatic premium payment - Payment amount", EFTDetails_Update[2]), "always");
            NYLDSelenium.VerifyText("Pay Frequency", payFrequency, GetFormattedAttribute("Pay Frequency", EFTDetails_Update[3]));
        }

        private void VerifyTermsAndConditionsNewAutoPay(TestData testData, CommonFunctions CF)
        {
            NYLDSelenium.Click("Terms And Conditions New AutoPay", TermsAndConditionsText, true, "no", "no");

            string termscondtionsbodytextvalue = GetFormattedAttributeText("Terms And Conditions New AutoPay", TermsAndConditionsThankyouBodyText);
            string termsAndConditionsTextdata = testData.GetContent("Terms And Conditions New AutoPay")
               .Replace("{selectedDate}", data[KeyRepository.selectedpickadate] + CF.GetDaySuffix(Convert.ToInt32(data[KeyRepository.selectedpickadate]))) ;

            NYLDSelenium.VerifyText("Terms And Conditions New AutoPay", "*Terms and Conditions " + termsAndConditionsTextdata, termscondtionsbodytextvalue, "always");
        }

        private string GetFormattedAttribute(string elementName, IWebElement element)
        {
            return NYLDSelenium.GetAttribute(elementName, element).Trim().Replace("\r\n", " ");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyUpdateAutoPayThankYouPage                                                                ///////////
        ////// Description: Verify Thank You Page for Update AutoPay whether there is a Payment Pending or NOT      ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public void VerifyUpdateAutoPayThankYouPage(string args)
        {
            TestData testData = new TestData();
            CommonFunctions CF = new CommonFunctions(data);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Thank you Page - Updated Automatic premium payment" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            // Ensure "Thank You" page is loaded
            NYLDSelenium.PageLoad("Thank You", ThankYouHeader);
            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink);

            // Determine and verify the appropriate success message
            string successMessageKey = args == "PendingPayment" ? "SuccessfullyUpdateEnrollmentWithPendingPayment" : "SuccessfulUpdateEnrollmentWithNoPendingPayment";
            string expectedSuccessMessage = testData.GetContent(successMessageKey);
            NYLDSelenium.VerifyText("Enrolled for Update Success Message", (expectedSuccessMessage + " " + data[KeyRepository.PolicyNumber] + ".").Trim(), GetFormattedAttributeText("Enrolled Update Success Message", EnrolledSuccessMessage).Trim(), "always");


            // Verifying bank account details
            VerifyUpdateExistingAutopayBankAccountDetails();

            // Verifying withdrawal date
            VerifyUpdateExistingAutoPayWithdrawalDateDetails();

            // Verifying payment amount and frequency
            VerifyUpdateExistingAutoPayPaymentsDetails();

            // Verifying terms and conditions
            VerifyUpdateExistingAutoPayTermsAndConditions();

            // Check for the existence of the Print Confirmation button
            NYLDSelenium.ElemExist("Print confirmation", PrintConfirmationButton);
        }

        private string GetFormattedAttributeText(string attributeName, IWebElement element)
        {
            return NYLDSelenium.GetAttribute(attributeName, element).Trim().Replace("\r\n", " ");
        }


        /// <summary>
        /// Method helps to VerifyUpdateExistingAutopayBankAccountDetails
        /// </summary>
        private void VerifyUpdateExistingAutopayBankAccountDetails()
        {
            CommonFunctions CF = new CommonFunctions(data);
            var premiumpayment = GetFormattedAttributeText("Automatic premium payment - - Bank account number", EFTDetails_Update[0]);
            string updatedAccount = data[KeyRepository.TempValue].Split(':')[0];
            string BankAccountNumber = updatedAccount.Substring(updatedAccount.Length - 4).PadLeft(12, '*');
            NYLDSelenium.VerifyText("Automatic premium payment - Bank account number", "TD BANK NA: " + BankAccountNumber, premiumpayment, "always");
        }

        /// <summary>
        /// Method helps to VerifyUpdateExistingAutoPayWithdrawalDateDetails
        /// </summary>
        private void VerifyUpdateExistingAutoPayWithdrawalDateDetails()
        {
            CommonFunctions CF = new CommonFunctions(data);
            string textvalue = GetFormattedAttributeText("Automatic premium payment - Withdrawal date", EFTDetails_Update[1]);
            NYLDSelenium.VerifyText("Automatic premium payment - Withdrawal date", "Next Withdrawal Date*: " + CF.PaidToDate(data[KeyRepository.selectedpickadate]), textvalue, "always", "always");
        }

        /// <summary>
        /// Method helps to VerifyUpdateExistingAutoPayPaymentsDetails
        /// </summary>
        private void VerifyUpdateExistingAutoPayPaymentsDetails()
        {
            CommonFunctions CF = new CommonFunctions(data);

            string paymentFrequency = CF.GetCurrentFrequencyWithPremium("").Split(',')[0];
            string paymentAmount = "Payment Amount: $" + CF.GetCurrentFrequencyWithPremium("").Split(',')[2];
            NYLDSelenium.VerifyText("Automatic premium payment - Payment amount", paymentAmount, GetFormattedAttributeText("Automatic premium payment - Payment amount", EFTDetails_Update[2]));
            NYLDSelenium.VerifyText("Pay Frequency", "Payment frequency " + paymentFrequency, GetFormattedAttributeText("Pay Frequency", EFTDetails_Update[3]));
        }

        /// <summary>
        /// Method helps to 
        /// </summary>
        private void VerifyUpdateExistingAutoPayTermsAndConditions()
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();

            NYLDSelenium.VerifyText("Terms and Conditions header", "*Terms and Conditions", GetFormattedAttributeText("Terms and Conditions header", TermsAndConditionsHeader));
            string dateset = data[KeyRepository.selectedpickadate] + CF.GetDaySuffix(Convert.ToInt32(data[KeyRepository.selectedpickadate]));

            string termsAndConditionsExpectedText = testData.GetContent("Terms And Conditions New AutoPay").Replace("{selectedDate}", dateset);
            NYLDSelenium.VerifyText("Terms And Conditions text for Update AutoPay", "*Terms and Conditions " + termsAndConditionsExpectedText, GetFormattedAttributeText("Terms And Conditions Text", TermsAndConditionsThankyouBodyText), "always");
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyCancelAutoPayThankYouPage                                              ///////////
        ////// Description: Verifying Thank You Page after Canceling AutoPay                       ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyCancelAutoPayThankYouPage(string args)
        {
            CommonFunctions cf = new CommonFunctions(data);
            TestData testData = new TestData();
            NYLDSelenium.AddHeader("Verify Cancel AutoPay ThankYou Pagefor - " + args, "SubHeader");

            // Initialize necessary data
            cf.GetAddressInfo();

            // Reporting step result
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Cancel AutoPay ThankYou Page for-" + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            // Load the "Thank You" page and verify essential elements
            LoadAndVerifyEssentialElements();

            // Determine and verify the appropriate message based on the scenario
            VerifyCancellationMessage(args, testData);

            // Verify additional elements on the page
            VerifyAdditionalPageElements();

            NYLDSelenium.AddHeader("Verify Cancel AutoPay ThankYou Pagefor - " + args, "Success");
        }

        private void LoadAndVerifyEssentialElements()
        {
            NYLDSelenium.PageLoad("Thank You", ThankYouHeader);
            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink, true);
            NYLDSelenium.VerifyText("Thank you header", "Thank you", NYLDSelenium.GetAttribute("Thank you header", ThankYouHeader),"always");
        }

        private void VerifyCancellationMessage(string args, TestData testData)
        {
            if (args=="PendingPayment")
            {
                VerifyPendingPaymentScenario(testData);
            }
            else if (args=="NoPendingPayment")
            {
                VerifyNoPendingPaymentScenario(testData);
            }
        }

        private void VerifyPendingPaymentScenario(TestData testData)
        {
            NYLDSelenium.VerifyText("Cancelled Pending Payment Message", testData.GetContent("Successfully canceled enrollment with Pending Payment"),
                NYLDSelenium.GetAttribute("Cancelled Pending Payment Message", CancelledPendingSubmessage),"always");
            VerifyTheAddressMessage();
        }

        private void VerifyNoPendingPaymentScenario(TestData testData)
        {
            NYLDSelenium.VerifyText("Cancelled Success Message", testData.GetContent("Successfully canceled enrollment with no Pending Payment") +" "+data[KeyRepository.PolicyNumber]+".",
                NYLDSelenium.GetAttribute("Cancelled Success Message", CancelledSuccesMessagehdr, "Text"),"always");
            NYLDSelenium.VerifyText("Cancelled Success Sub Message", testData.GetContent("Successfully cancelled enrollment with no Pending Payment Sub Message") +" "+ data[KeyRepository.PaidToDate] + ".",
                NYLDSelenium.GetAttribute("Cancelled Success Sub Message", CancelledSuccesSubmessage, "Text"),"always");
            VerifyTheAddressMessage();
        }

        private void VerifyTheAddressMessage()
        {
            string expectedAddressMessage = "Please verify that we have your correct mailing address: " + data[KeyRepository.Address].Split(',')[0].Trim();
            string actualAddressMessage = NYLDSelenium.GetAttribute("Verify Address Message", VerifyAddressMessage).Replace("\r\n", " ").Split(',')[0].Trim();
            NYLDSelenium.VerifyText("Verify Address Message", expectedAddressMessage, actualAddressMessage,"always");
        }

        private void VerifyAdditionalPageElements()
        {
            NYLDSelenium.ElemExist("Update My Address", UpdateMyAddressLink,true,"no","always");
            NYLDSelenium.ElemExist("Print confirmation", PrintConfirmationButton,true,"no", "always","always");
        }


        /// <summary>
        /// Method to change the payment frequency of the Contract
        /// </summary>
        /// <param name="args"></param>
        public void ChangePaymentFrequency(string args)
        {
            try
            {
              
                Coverage.MyBeneficiariesPage beneficiary = new Coverage.MyBeneficiariesPage(driver, data);
                LoginPage LP = new LoginPage(driver, data);
                ManagePaymentsPage managePaymentsPage = new ManagePaymentsPage(driver, data);
                string currentfreq = "";
                IWebElement changefeqelement = null; 
                NYLDSelenium.AddHeader("Pay frequency change - " + args, "SubHeader");
                //waiting time to get the payment frequency selected information
                Thread.Sleep(1000);
                bool Qsel = driver.FindElement(By.Id("frequency-Quarterly")).Selected;
                bool Msel = driver.FindElement(By.Id("frequency-Monthly")).Selected;
                bool reset = false;

                if (args.Trim().Contains("Quarterly"))
                {
                    currentfreq = "M";
                    reset = Msel;
                    changefeqelement = PaymntfreqQuatrlabel;
                }
                else if (args.Trim().Contains("Monthly"))
                {
                    currentfreq = "Q";
                    reset = Qsel;
                    changefeqelement = PaymntfreqMonthlabel;
                }

                //id default not select then no need to reset 
                if (Qsel == false && Msel == false)
                {
                    //no need to reset
                }
                else
                    ResetPaymentFrequency(args, reset);

                NYLDSelenium.Click(args.Trim() + " payment frequency option", changefeqelement, true);
                data[KeyRepository.CurrentPaymentFrequency] = currentfreq;
                NYLDSelenium.Click("Pay frequency change Submit button", UpdatepayFreqency, false, "always", "always");
                Thread.Sleep(3000);
                NYLDDigital.SkipSurveyPopUp(StartSurvey, 30, false);
                CSWData.EventTriggerTime = DateTime.Now;
              
                NYLDSelenium.AddHeader("Pay frequency change - " + args, "Success");
            }
            catch
            {
                NYLDSelenium.ReportStepResult("Pay frequency change Failed", "Pay frequency change request Fail " + args, "FAIL", "always", "yes");
            }
        }

        /// <summary>
        /// Method helps to reset the logic required to click the payment frequency change
        /// </summary>
        /// <param name="args"></param>
        /// <param name=""></param>
        public void ResetPaymentFrequency(string args,bool reset)
        {
            LoginPage LP = new LoginPage(driver, data);
            ManagePaymentsPage managePaymentsPage = new ManagePaymentsPage(driver, data);
            try
            {

                if (args.Trim().Contains("Quarterly"))
                {
                    if (reset == false)
                    {
                       
                        NYLDSelenium.Click("Monthly payment frequency option", PaymntfreqMonthlabel, true, "no", "no");
                        NYLDSelenium.Click("Pay frequency change Submit button", UpdatepayFreqency, true, "no", "no");
                        Thread.Sleep(3000);
                        NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

                        if (NYLDSelenium.ElemExist("Back to Payment", BackToManagePaymentsLink, true, "no", "no", "no", 10))
                        {
                            Thread.Sleep(400);
                            NYLDSelenium.Click("Back to payments", BackToManagePaymentsLink, true, "no", "no");
                        }
                    }
                }
                else if (args.Trim().Contains("Monthly"))
                {
                    if (reset == false)
                    {
                       
                        NYLDSelenium.Click("Quarterly payment frequency option", PaymntfreqQuatrlabel, true, "no", "no");
                        NYLDSelenium.Click("Pay frequency change Submit button", UpdatepayFreqency, true, "no", "no");
                        Thread.Sleep(3000);
                        NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);
                        Thread.Sleep(400);
                        if (NYLDSelenium.ElemExist("Back to Payment", BackToManagePaymentsLink, true, "no", "no", "no", 10)) //TODO Raj 2023, We dont need this elemexist as we are clickin the same in next step
                        { Thread.Sleep(400); NYLDSelenium.Click("Back to payments", BackToManagePaymentsLink, true, "no", "no"); }
                    }
                }
            }
            catch
            {
                NYLDSelenium.ReportStepResult("Verify Payment Frequency -Reset can't posbile to change", "Payment Frequency not as expected", "FAIL", "always", "yes");
            }
        }

        /// <summary>
        /// Method to verify the result screen of payment frequency update
        /// </summary>
        /// <param name="args"></param>
        public void VerifyUpdatePaymentFrequencyResult(string args)
        {
            HomePage home = new HomePage(driver, data);
            CommonFunctions commonFunctions = new CommonFunctions(data);
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            Coverage.MyBeneficiariesPage beneficiary = new Coverage.MyBeneficiariesPage(driver, data);

            //TODO Raj 2023 Remove Survey -done           
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Payment Frequency -Thank you page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            //Page load
            NYLDSelenium.PageLoad("Thank You", ThankYouHeader);
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 30, false);
            //Derive frequency
            var freq = commonFunctions.GetCurrentFrequencyWithPremium("");

            NYLDSelenium.ElemExist("Back to Manage Payments Link", BackToManagePaymentsLink);

            //Verify Thank you header
            NYLDSelenium.VerifyText("Thank you header", "Thank you, " + data[KeyRepository.FirstName], NYLDSelenium.GetAttribute("Thank you header", ThankYouHeader));

            //verify Thank you sub header                    
            NYLDSelenium.VerifyText("Payment frequency Change - Thank you sub header", "You have successfully updated your payment frequency from " + freq.Split(',')[0].ToLower() + " to " + freq.Split(',')[3].ToLower() + " for account " + data[KeyRepository.PolicyNumber]+".", NYLDSelenium.GetAttribute("Pay Frequency Change - Thank you sub header", ThankYouInfo_PayFrequency));

            //verify Payment date 

            //TODO Raj 2023 lets create a method in common formunctions-done
            NYLDSelenium.VerifyText("Updated payment frequency - Next payment date", "Next Withdrawal Date: " + commonFunctions.PaidToDate(""), NYLDSelenium.GetAttribute("Pay Frequency Change - Next payment date header", PayFrequencyChangeDetails[0]).Replace("\r\n", " "));

            //Payment Amount          
            NYLDSelenium.VerifyText("Updated payment frequency - Pay amount", "Payment Amount: $" + freq.Split(',')[4], NYLDSelenium.GetAttribute("Pay Frequency Change - Pay amount header", PayFrequencyChangeDetails[1]).Replace("\r\n", " "));

            //Payment frequency
            NYLDSelenium.VerifyText("Updated payment frequency", "Payment Frequency: " + freq.Split(',')[3], NYLDSelenium.GetAttribute("Pay Frequency Change - Updated frequency", PayFrequencyChangeDetails[2]).Replace("\r\n", " "));

            //verify Print option exists            
            NYLDSelenium.ElemExist("Print confirmation", PrintConfirmationButton);

            //After completion need to navigate the payments page due to EFT
            home.NavigateToPage(KeyRepository.PaymentPage);

        }
    }
}
