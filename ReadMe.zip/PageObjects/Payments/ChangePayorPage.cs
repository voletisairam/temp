﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using iText.StyledXmlParser.Jsoup.Select;
using System.Drawing;

namespace CSW.PageObjects.Payments
{
    class ChangePayorPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ChangePayorPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ////////////////////////////////////////////////////////////////////////////
        ////////////////////////        Page Objects        ////////////////////////
        ////////////////////////////////////////////////////////////////////////////

        //Choose a contract number Header 
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Choose a contract number')]")]
        public IWebElement ContractHeader { get; set; }

        //Choose a contract number dropdown 
        [FindsBy(How = How.XPath, Using = "//*[@id='policy-toggle']")]
        public IWebElement ContractNumberDropdown { get; set; }

        //Payor Information Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Payor information')]")]
        public IWebElement PayorInfoHeader { get; set; }

        //Update pay details Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Update payor details')]")]
        public IWebElement UpdatePayorDetails { get; set; }

        //First Name Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblFirstName']")]
        public IWebElement FirstNameHeader { get; set; }

        //First Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtFirstName']")]
        public IWebElement FirstName { get; set; }

        //First Name Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtFirstName']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement FirstNamePopUp { get; set; }

        //Last Name Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblLastName']")]
        public IWebElement LastNameHeader { get; set; }

        //Last Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtLastName']")]
        public IWebElement LastName { get; set; }

        //Last Name Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtLastName']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement LastNamePopUp { get; set; }

        //Phone Number Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblPhoneNumber']")]
        public IWebElement PhoneNumberHeader { get; set; }

        //Phone Number Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPhoneNumber']")]
        public IWebElement PhoneNumber { get; set; }

        //Phone Number Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtPhoneNumber']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement PhoneNumberPopUp { get; set; }

        //Addresss Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblAddress1']")]
        public IWebElement AddressHeader { get; set; }

        //Address Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress1']")]
        public IWebElement AddresLine1 { get; set; }

        //Payor Addresss Line Validation message Pop Up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtAddress1']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement AddressPopUp { get; set; }

        //Addresss Line 2 Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblAddress2']")]
        public IWebElement AddressLine2Header { get; set; }

        //Addresss Line 2 Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress2']")]
        public IWebElement AddressLine2 { get; set; }

        //Address Line 2 Pop up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtAddress2']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement AddressLine2PopUp { get; set; }

        //City Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblCity']")]
        public IWebElement CityHeader { get; set; }

        //City Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCity']")]
        public IWebElement City { get; set; }

        //City validation message pop up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtCity']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement CityPopUp { get; set; }

        //State Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblState']")]
        public IWebElement StateHeader { get; set; }

        //State Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='State']")]
        public IWebElement State { get; set; }

        //Payor State Pop Up
        [FindsBy(How = How.XPath, Using = "//input[@id='State']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement StatePopUp { get; set; }

        //Zip Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblZip']")]
        public IWebElement ZipHeader { get; set; }

        //Zip Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtZip']")]
        public IWebElement Zip { get; set; }

        //Zip validation message pop up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtZip']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement ZipPopUp { get; set; }

        //Province Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblProvince']")]
        public IWebElement ProvinceHeader { get; set; }

        //Province Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='Province']")]
        public IWebElement Province { get; set; }

        //Province Pop up
        [FindsBy(How = How.XPath, Using = "//input[@id='Province']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement ProvincePopUp { get; set; }

        //Postal code Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblPostalCode']")]
        public IWebElement PostalCodeHeader { get; set; }

        //Postal code Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPostalCode']")]
        public IWebElement PostalCode { get; set; }

        //Postal Code validation message pop up
        [FindsBy(How = How.XPath, Using = "//input[@id='txtPostalCode']/following-sibling::span[@class='field-validation-error']/span")]
        public IWebElement PostalCodePopUp { get; set; }

        //Country Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblCountry']")]
        public IWebElement CountryHeader { get; set; }

        //Country Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='Country']")]
        public IWebElement Country { get; set; }

        //Country validation message pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='Country-error']")]
        public IWebElement CountryPopup { get; set; }

        //Save Button
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and text() = 'Save']")]
        public IWebElement SaveButton { get; set; }

        //Thank You Message
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Thank you')]")]
        public IWebElement ThankYouMessage { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to dashboard')]")]
        public IWebElement BackToDasboardLink { get; set; }

        //Confirm Address Header
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Please confirm')]")]
        public IWebElement ConfirmAddressHeader { get; set; }

        //Suggested Address Header
        [FindsBy(How = How.XPath, Using = "//*[@id='suggested-address']/../../p")]
        public IWebElement SuggestedAddressHeader { get; set; }

        //Entered Address Header
        [FindsBy(How = How.XPath, Using = "//*[@id='entered-address']/../../p")]
        public IWebElement EnteredAddressHeader { get; set; }

        //Suggested Address
        [FindsBy(How = How.XPath, Using = "//*[@id='suggested-address']/../label")]
        public IWebElement SuggestedAdrress { get; set; }

        //Entered Address
        [FindsBy(How = How.XPath, Using = "//*[@id='entered-address']/../label")]
        public IWebElement EnteredAdrress { get; set; }

        //Confirm Button
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and text() = 'Confirm']")]
        public IWebElement ConfirmButton { get; set; }

        //Unable to chagne policy
        [FindsBy(How = How.XPath, Using = "//*[@id='change-payor-form']/div[contains(text(),'Unable to change payor for this policy')]")]
        public IWebElement ChangePayor_DisableMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='edit-insured-form']/div[contains(text(),'Unable to edit insured for this policy')]")]
        public IWebElement EditInsured_DisableMessage { get; set; }

        //*[@id="change-payor-form"]/div

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Methods      //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyChangePayorEditInsured                                                                ///////////
        ////// Description:  Select a contract to verify Change payor or insured details                         ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyChangePayorInfo()
        {     

            string[] policyList = { };

            NYLDSelenium.AddHeader("Verify Change Payor Form", "SubHeader");
            //Verify Change Payor screen is loaded
            NYLDSelenium.PageLoad("Change Payor", PayorInfoHeader);

            //Query of Associated contracts and viper policy list           
            if (CSWData.AssociatedPolicies != null)
                policyList = CSWData.AssociatedPolicies.Split(';');

            if (policyList.Length == 1)
                VerifyChangePayor_ForSingle();
            else
                VerifyChangePayor_ForMulti();

            NYLDSelenium.AddHeader("Verify Change Payor Form", "Success");

        }

        public void ChangePayorChangeCountry(string args)
        {
            TestData testData = new TestData();
            NYLDSelenium.AddHeader("Verify Change Payor Form", "SubHeader");
            //Verify Change Payor screen is loaded
            NYLDSelenium.PageLoad("Change Payor", PayorInfoHeader);

            NYLDSelenium.ReportStepResult("Select Country: " + args, "Select Country", "INFO", "no");
            CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", args.Trim()));

            NYLDSelenium.AddHeader("Verify Change Payor Form", "Success");

        }

        public void VerifyChangePayor_ForSingle()
        {
            //Verify drop down and choose contract header is not present
            NYLDSelenium.ElemNotExist("choose contract header", ContractHeader);
            NYLDSelenium.ElemNotExist("Drop down list", ContractNumberDropdown);

            //verify Owner,Insured Name and Payor fields
            VerifyDetails();
        }

        public void VerifyChangePayor_ForMulti()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);

            string[] policyList = { };
            policyList = CSWData.AssociatedPolicies.Split(';');
             
            //Verify the Contract drop down list has only viper policies
            NYLDSelenium.VerifyList("VIPER Policy", ContractNumberDropdown, policyList,"bytext",true);

            //TODO: Lets review the logic and haev a cleaner way
            //Derive indivdual policy information                    
            for (int j = 0; j <= (policyList.Count() - 1); j++)
            {
                IJavaScriptExecutor js1 = (IJavaScriptExecutor)driver;
                js1.ExecuteScript("window.scrollBy(0,-5000);");
                //Get Policy Number
                string[] phrasePolicy = policyList[j].Split(' ');
                string PolicyNumber = phrasePolicy.Last();

                //get options in Drop down
                NYLDSelenium.ElemExist("Contract Number dropdown", ContractNumberDropdown, true);
                SelectElement select = new SelectElement(ContractNumberDropdown);
                IList<IWebElement> options = select.Options;
                int ActOptCount = options.Count;

                for (int i = 0; i < ActOptCount; i++)
                {
                    string actPolName = options.ElementAt(i).GetAttribute("text").Trim();

                    //select Policy
                    if (actPolName == policyList[j].Trim())
                    {

                        string ContractSelected = "//*[contains(text(), '" + PolicyNumber + "')]";
                        NYLDSelenium.SelectList("Select Policy", ContractNumberDropdown, actPolName, "bytext", true,"no");
                        Thread.Sleep(300);
                        NYLDSelenium.SelectList("Select Policy", ContractNumberDropdown, actPolName, "bytext", true);
                        data[KeyRepository.PolicyNumber] = PolicyNumber;
                        NYLDSelenium.PageLoad("Payor", PayorInfoHeader);
                        DB.QueryPolicyDetails();  //TODO: Not right place to do these

                        //Verify the Owner and Insured field
                        VerifyDetails();
                        goto breakLoop;
                    }
                }
            breakLoop:
                Console.WriteLine("");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyDetails                                                                               ///////////
        ////// Description:  Verify the details of the Change payor or insured details page                      ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyDetails()
        {
            CommonFunctions CF = new CommonFunctions(data);
            ManagePaymentsPage MP = new ManagePaymentsPage(driver, data);
            TestData testData = new TestData();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify details page for policy - " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Contract Owner details         
            NYLDSelenium.AddHeader("Owner and Insured Name", "SubHeader");
            CF.GetOwnerandInsuredDetails(MP.ContractOwner, MP.ContractInsured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName);

            //Verify Owner details 
            NYLDSelenium.VerifyText("Contract Owner", ExpOwnerNameandAddr.Trim(), ActualOwnerNameandAddr); //TODO: Why we commented these?

            //Verify Insured details
            NYLDSelenium.VerifyText("Insured", ExpectedInsuredName, ActualInsuredName);
            NYLDSelenium.AddHeader("Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "Success");
            //Verify Payor fields
            NYLDSelenium.VerifyText("Payor first name", data[KeyRepository.PayorFirstName], NYLDSelenium.GetAttribute("Payor FirstName", FirstName, "value"));
            NYLDSelenium.VerifyText("Payor Last name", data[KeyRepository.PayorLastName], NYLDSelenium.GetAttribute("Payor LastName", LastName, "value"));
            NYLDSelenium.VerifyText("Payor Phone number", data[KeyRepository.PayorPhone], NYLDSelenium.GetAttribute("Payor Phone Numb", PhoneNumber, "value").Replace("-", "").Replace("(", "").Replace(")", "").Replace(" ", "").Trim());

            NYLDSelenium.VerifyText("Payor Address Line 1", data[KeyRepository.PayorAddressLine1], NYLDSelenium.GetAttribute("Payor Address Line1", AddresLine1, "value"));
            NYLDSelenium.VerifyText("Payor Address Line 2", data[KeyRepository.PayorAddressLine2], NYLDSelenium.GetAttribute("Payor Address Line2", AddressLine2, "value"));
            NYLDSelenium.VerifyText("Payor city", data[KeyRepository.PayorCity], NYLDSelenium.GetAttribute("Payor City", City, "value"));

            //Verify Country specific fields in Payor page
            if (data[KeyRepository.PayorCountry] == "US")
            {
                //fetch country name in full
                NYLDSelenium.VerifyText("Payor Country", testData.GetMappedValue("Country", data[KeyRepository.PayorCountry]), CF.GetDropDownValue(Country).Trim());

                //Verify content of State and Zipcode field                    
                NYLDSelenium.VerifyText("Payor State selected", testData.GetMappedValue("State", data[KeyRepository.PayorState]), CF.GetDropDownValue(State).Trim());
                NYLDSelenium.VerifyText("Payor Zipcode  ", data[KeyRepository.PayorZip], NYLDSelenium.GetAttribute("Payor Province List", Zip, "value"));
            }
            else if (data[KeyRepository.PayorCountry] == "CN" | data[KeyRepository.PayorCountry] == "CA")
            {
                //fetch country name in full
                NYLDSelenium.VerifyText("Payor Country", testData.GetMappedValue("Country", "CN"), CF.GetDropDownValue(Country).Trim());

                //Verify content of Province and PostalCode field --(added the logic for Mapping to the state is missing previously)
                NYLDSelenium.VerifyText("Payor Province selected", testData.GetMappedValue("State", data[KeyRepository.PayorState]), CF.GetDropDownValue(Province).Trim());
                NYLDSelenium.VerifyText("Payor PostalCode", data[KeyRepository.PayorZip], NYLDSelenium.GetAttribute("Payor Postal Code", PostalCode, "value"));
            }
            else
            {
                //Verify the absence of Country specifc fields
                NYLDSelenium.ElemNotExist("No state field exist", State);
                NYLDSelenium.ElemNotExist("No Zipcode field exist", Zip);
                NYLDSelenium.ElemNotExist("No state field exist", Province);
                NYLDSelenium.ElemNotExist("No Zipcode field exist", PostalCode);
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyChangePayorEditInsuredGriefMsg                                                        ///////////
        ////// Description:  No policy grief message displayed for change payor or edit insured page             ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyChangePayorEditInsuredGriefMsg(string args)  //TODO: Lets move into common class and remove unwanted code. KEep this method as last but one
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Update: " + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            if (args == "Change Payor")
                NYLDSelenium.PageLoad("Unable to Change Payor", ChangePayor_DisableMessage);
            else
                NYLDSelenium.PageLoad("Unable to Edit Insured", EditInsured_DisableMessage);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: UpdateChangePayor                                                                           ///////////
        ////// Description:  Update change payor fields based on parameters passed                               ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateChangePayor(string args)
        {
           
            LoginPage login = new LoginPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            //Verify the availability of Change Payor page
            NYLDSelenium.PageLoad("Payor", PayorInfoHeader);
            NYLDSelenium.AddHeader("Update Change Payor: " + args, "SubHeader");
            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", login.CloseMockBanner, true,"no","no"))
                NYLDSelenium.Click("Mock banner", login.CloseMockBanner);            

            //verify if the policy selected is retained in drop down
            if (data[KeyRepository.ContractCount] == "Multi") //TODO: We should not be verifying these here
            {
                //Verify the Policy Name displayed
                string polSelected = CF.GetDropDownValue(ContractNumberDropdown);
                if (polSelected.Contains(data[KeyRepository.PolicyNumber].Trim()))
                    NYLDSelenium.ReportStepResult("Display selected Policy", "Policy selected for payor udpate is displayed","Pass", "always", "no");
                else
                    NYLDSelenium.ReportStepResult("Display selected Policy", "Policy selected for payor udpate is Not displayed", "Fail", "always", "yes");
            }

            CF.ChangePayorByTestDataConfigState(args,FirstName,LastName,PhoneNumber,AddresLine1,AddressLine2,City,Country,State,Zip,Province,PostalCode,
                out string pFN,out string pLN,out string pPN,out string pAL1,out string pCY,out string StatenZip,out string pCN,out string pAL2);

            //Click on Submit button
            NYLDSelenium.Click("Submit", SaveButton, true, "always", "yes");

            //Get the updated details of payor
            if (pAL2 == "")
                CSWData.TempVal = pFN + " " + pLN + ":" + pPN + ":" + pAL1 + " " + pCY + "," + " " + StatenZip + ":" + pCN;
            else
                CSWData.TempVal = pFN + " " + pLN + ":" + pPN + ":" + pAL1 + " " + pAL2 + " " + pCY + "," + " " + StatenZip + ":" + pCN;

            //Set Trigger Time
            CSWData.EventTriggerTime = DateTime.Now;
            CSWData.EventTriggerTime.AddSeconds(-100);

            NYLDSelenium.ReportStepResult("Event Trigger time", "Time captured in Update change payor method " + CSWData.EventTriggerTime, "info");
            NYLDSelenium.AddHeader("Update Change Payor Success ", "Success");
        }



        /// <summary>
        /// Method helps to Verify ChangePayor USPSAddress Validation Page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyChangePayorUSPSAddressValidationPage(string args)
        {
            string[] getOption = args.Split(',');

            NYLDSelenium.AddHeader("Verify Change Payor USPS Address Validation Page: " + args, "SubHeader");

            //Verify Header is displayed
            NYLDSelenium.VerifyText("Confirm Address Header", "Please confirm address", NYLDSelenium.GetAttribute("Confirm address header", ConfirmAddressHeader));

            //Verify Suggested address Header
            NYLDSelenium.VerifyText("Suggested Address Header", "Suggested U.S. Postal Service address", NYLDSelenium.GetAttribute("Confirm address header", SuggestedAddressHeader));

            //Verify Entered address Header
            NYLDSelenium.VerifyText("Entered Address Header", "Use address entered", NYLDSelenium.GetAttribute("Confirm address header", EnteredAddressHeader));

            NYLDSelenium.AddHeader("Verify Change Payor USPS Address Validation Page ", "Success");
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyConfirmAddress                                                                        ///////////
        ////// Description:  Verify Select address page displayed after change payor update                     ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateSelectAddress(string args)
        {
            string selectedAddress;
            string[] updatedInfo;
            string[] getOption = args.Split(',');

            NYLDSelenium.AddHeader("Verify Select Address Page as: " + args, "SubHeader");

            //Select Suggested or entered address as mentioned in args
            if (getOption[1] == "Suggested")
            {
                NYLDSelenium.Click("Select Suggested radio Button", SuggestedAdrress);
                selectedAddress = NYLDSelenium.GetAttribute("Suggested Address", SuggestedAdrress);
                selectedAddress = selectedAddress.Replace(System.Environment.NewLine, " ");
            }
            else
            {
                NYLDSelenium.Click("Select Entered radio Button/", EnteredAdrress);
                selectedAddress = NYLDSelenium.GetAttribute("Entered Address", EnteredAdrress);
                selectedAddress = selectedAddress.Replace(System.Environment.NewLine, " ");
            }

            //Click on submit or back based on args
            updatedInfo = CSWData.TempVal.Split(':');
           
            //Click on Submit 
            NYLDSelenium.Click("Confirm Address Submit", ConfirmButton);
            //update temp val
            if (CSWData.TempVal != "")
                CSWData.TempVal = updatedInfo[0] + ":" + updatedInfo[1] + ":" + selectedAddress + ":" + updatedInfo[3];

            NYLDSelenium.AddHeader("Confirm Selected address page verification", "Success");
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyChangePayorThankYou                                                                   ///////////
        ////// Description:  Verify Thank you page of Change payor                                               ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyChangePayorThankYouPage(string args)
        {
           
            HomePage home = new HomePage(driver, data);
            TestData testData = new TestData();
            string pAddress;
            string[] payorDetails = { };
            LSPDatabase DB = new LSPDatabase(driver, data);
            MIDatabase MIDB = new MIDatabase(data);
            LoginPage LP = new LoginPage(driver, data);

            // Verify Change Payor Thank you screen
            NYLDSelenium.PageLoad("Change Payor Thank You", ThankYouMessage);

            NYLDSelenium.AddHeader("Verify Change Payor Thank you page", "SubHeader");

            //Verify the succes Message displayed in the Thanks you screen
            NYLDSelenium.VerifyText("Submit succesful message", "Thank you " + data[KeyRepository.FirstName] + ". Your payor information has been updated.", ThankYouMessage.Text);

            //Return to Home from Change Payor screen
            NYLDSelenium.Click("Return to Home", BackToDasboardLink,true);

            //Verify if My Coverage- Life insurance tab is displayed
            Thread.Sleep(30000);
            NYLDSelenium.ElemExist("Life insurance overview tab", home.SummaryPage);

            if ((CSWData.TempVal != null) && (CSWData.TempVal != "") && args != "Fields") //DB method should be move to DB class and call from Driver Class
            {
                //Verify Payor information updated is reflected in data base
                DB.QueryPolicyDetails();

                payorDetails = CSWData.TempVal.Split(':');

                string pCountry;
                string payorDetailsUI;

                //Get country full name
                if (data[KeyRepository.PayorCountry] != "CN")
                    pCountry = data[KeyRepository.PayorCountry] + " " + "-" + " " + testData.GetMappedValue("Country", data[KeyRepository.PayorCountry]);
                else
                    pCountry = "CA" + " " + "-" + " " + testData.GetMappedValue("Country", "CA");

                //Build address of DB to suit updated values in payor page
                if (data[KeyRepository.PayorAddressLine2] != "")
                    pAddress = data[KeyRepository.PayorAddressLine1] + " " + data[KeyRepository.PayorAddressLine2] + " " + data[KeyRepository.PayorCity] + "," + " " + data[KeyRepository.PayorState] + " " + data[KeyRepository.PayorZip] + " " + pCountry;
                else
                {
                    if (data[KeyRepository.PayorState] != "" && data[KeyRepository.PayorZip] != "")
                        pAddress = data[KeyRepository.PayorAddressLine1] + " " + data[KeyRepository.PayorCity] + "," + " " + data[KeyRepository.PayorState] + " " + data[KeyRepository.PayorZip] + " " + pCountry;
                    else
                        pAddress = data[KeyRepository.PayorAddressLine1] + " " + data[KeyRepository.PayorCity] + "," + " " + pCountry;
                }

                if (data[KeyRepository.PayorState] != "" && data[KeyRepository.PayorZip] != "")
                    payorDetailsUI = payorDetails[2] + " " + pCountry;
                else
                    payorDetailsUI = payorDetails[2] + payorDetails[3];

                //Verify Payor fields
                NYLDSelenium.VerifyText("Payor Name", payorDetails[0], data[KeyRepository.PayorFirstName] + " " + data[KeyRepository.PayorLastName]);
                NYLDSelenium.VerifyText("Payor Phone", payorDetails[1].Replace("-", "").Replace("(", "").Replace(")", "").Replace(" ", "").Trim(), data[KeyRepository.PayorPhone]);
                NYLDSelenium.VerifyText("PayorDetails Adress", payorDetailsUI.Replace("  ", " "), pAddress);

            }
            else
                NYLDSelenium.ReportStepResult("Thank you Page verification", "Thank you page verification failed", "Fail", "always", "no");

            NYLDSelenium.AddHeader("Change payor process sucessful: Payor details update, Email Verification, LSP Notes and Activity Table entry verification is as expected", "Success");
            
        }
    }
}
