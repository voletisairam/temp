﻿using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.External_Applications;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace CSW.PageObjects.Payments
{
    class EditInsuredPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public EditInsuredPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ////////////////////////////////////////////////////////////////////////////
        ////////////////////////        Page Objects        ////////////////////////
        ////////////////////////////////////////////////////////////////////////////

        //Choose a contract number Header 
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Choose a contract number')]")]
        public IWebElement ContractHeader { get; set; }

        //Choose a contract number dropdown 
        [FindsBy(How = How.XPath, Using = "//*[@id='policy-toggle']")]
        public IWebElement ContractNumberDropdown { get; set; }

        //Payor Information Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Insured information')]")]
        public IWebElement InsuredInfoHeader { get; set; }

        //Update pay details Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Update payor details')]")]
        public IWebElement UpdatePayorDetails { get; set; }

        //First Name Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblFirstName']")]
        public IWebElement FirstNameHeader { get; set; }

        //First Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtFirstName']")]
        public IWebElement FirstName { get; set; }

        //First Name Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtFirstName-error']")]
        public IWebElement FirstNamePopUp { get; set; }

        //Last Name Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblLastName']")]
        public IWebElement LastNameHeader { get; set; }

        //Last Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtLastName']")]
        public IWebElement LastName { get; set; }

        //Last Name Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtLastName-error']")]
        public IWebElement LastNamePopUp { get; set; }

        //Name change drop down
        [FindsBy(How = How.XPath, Using = "//*[@id='NameChangeReason']")]
        public IWebElement NameChangeReason { get; set; }        

        //Name change drop down
        [FindsBy(How = How.XPath, Using = "//*[@id='NameChangeReasonOther']")]
        public IWebElement NameChangeReasonOther { get; set; }

        //Name change drop down error pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='NameChangeReason-error']")]
        public IWebElement NameChangeReasonPopUp { get; set; }        

        //DOB
        [FindsBy(How = How.XPath, Using = "//*[@id='txtDateOfBirth']")]
        public IWebElement DateOfBirth { get; set; }

        //DOB PoP UP
        [FindsBy(How = How.XPath, Using = "//*[@id='txtDateOfBirth-error']")]
        public IWebElement DateOfBirthPopUp { get; set; }

        //Gender Male
        [FindsBy(How = How.XPath, Using = "//*[@id='MaleGender']//parent::label[contains(@class, 'btn btn-outline-steel')]")]
        public IWebElement Male { get; set; }

        //Gender Male
        [FindsBy(How = How.XPath, Using = "//*[@id='MaleGender']/parent::label[contains(@class, 'active')]")]
        public IWebElement Male_Selected { get; set; }

        //Gender Female
        [FindsBy(How = How.XPath, Using = "//*[@id='FemaleGender']//parent::label[contains(@class, 'btn btn-outline-steel')]")]
        public IWebElement Female { get; set; }

        //Save Button
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and text() = 'Save']")]
        public IWebElement SaveButton { get; set; }

        //Thank You Message
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Thank you')]/../..")]
        public IWebElement ThankYouMessage { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to dashboard')]")]
        public IWebElement BackToDasboardLink { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Please confirm')]")]
        public IWebElement ConfirmAddressHeader { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//*[@id='suggested-address']/../../p")]
        public IWebElement SuggestedAddressHeader { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//*[@id='entered-address']/../../p")]
        public IWebElement EnteredAddressHeader { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//*[@id='suggested-address']/../label")]
        public IWebElement SuggestedAdrress { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//*[@id='entered-address']/../label")]
        public IWebElement EnteredAdrress { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and text() = 'Confirm']")]
        public IWebElement ConfirmButton { get; set; }


        //No Associated policy page
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Currently there are no policies')]")]
        public IWebElement NoAssociatedPolicyHeader { get; set; }


        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Currently there are no policies')]/../div")]
        public IWebElement NoAssociatedPolicyContent { get; set; }


        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Methods      //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////
        

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyChangePayorEditInsured                                                                ///////////
        ////// Description:  Select a contract to verify Change payor or insured details                         ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyEditInsuredPage(string args)
        {
            string[] policyList = { };

            NYLDSelenium.AddHeader("Verify " + args, "SubHeader");

            // Verify Edit Insured Page based on the args            
             NYLDSelenium.PageLoad("Edit Insured", InsuredInfoHeader);

            if (CSWData.AssociatedPolicies != null)
                policyList = CSWData.AssociatedPolicies.Split(';');

            if (policyList.Length == 1)
                VerifyEditInsured_ForSingle(args);
            else
                VerifyEditInsured_ForMulti(args);

            NYLDSelenium.AddHeader("Verify " + args, "Success");
        }

        /// <summary>
        /// Description:  Verify the Contract is single and verify the details page  
        /// </summary>
        /// <param name="args"></param>
        public void VerifyEditInsured_ForSingle(string args)
        {
            //Verify drop down and choose contract header is not present
            NYLDSelenium.ElemNotExist("choose contract header", ContractHeader);
            NYLDSelenium.ElemNotExist("Drop down list", ContractNumberDropdown);

            //verify Owner,Insured Name and Payor fields
            VerifyDetails(args);
        }

        /// <summary>
        /// Description:  Verify the Contract is multi and verify the details page  
        /// </summary>
        /// <param name="args"></param>
        public void VerifyEditInsured_ForMulti(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);

            string[] policyList = { };
            if (CSWData.AssociatedPolicies != null)
                policyList = CSWData.AssociatedPolicies.Split(';');

            //Verify the Contract drop down list has policies               
            NYLDSelenium.VerifyList("Verify Policy", ContractNumberDropdown, policyList);

            //Derive indivdual policy information                    
            for (int j = 0; j <= (policyList.Count() - 1); j++)
            {
                //Get Policy Number
                string[] phrasePolicy = policyList[j].Split(' ');
                string polnum = phrasePolicy.Last();

                //get options in Drop down
                //IList<IWebElement> options = NYLDSelenium.GetDropdownValues("Get Dropdown Values",ContractNumberDropdown,true);
                SelectElement select = new SelectElement(ContractNumberDropdown);
                IList<IWebElement> options = select.Options;
                int ActOptCount = options.Count;

                for (int i = 0; i < ActOptCount; i++)
                {
                    string actPolName = options.ElementAt(i).GetAttribute("text").Trim();

                    //select Policy
                    if (actPolName == policyList[j].Trim())
                    {
                        IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);");
                        string ContractSelected = "//*[contains(text(), '" + polnum + "')]";
                        NYLDSelenium.SelectList("Select Policy: " + actPolName, ContractNumberDropdown, policyList[j], "bytext", true);
                        Thread.Sleep(300);
                        NYLDSelenium.SelectList("Select Policy: " + actPolName, ContractNumberDropdown, policyList[j], "bytext", true);
                        NYLDSelenium.PageLoad("Insured", InsuredInfoHeader);


                        //Query the policy related information
                        data[KeyRepository.PolicyNumber] = polnum;
                        DB.QueryPolicyDetails();

                        //Verify the Owner and Insured field
                        VerifyDetails(args);
                        goto breakLoop;
                    }
                }
            breakLoop:
                Console.WriteLine("");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyDetails                                                                               ///////////
        ////// Description:  Verify the details of the Change payor or insured details page                      ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyDetails(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            ManagePaymentsPage MP = new ManagePaymentsPage(driver, data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify details page for policy - " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");


            //Verify Contract Owner details 
            NYLDSelenium.AddHeader("Owner and Insured Name", "SubHeader");
            CF.GetOwnerandInsuredDetails(MP.ContractOwner, MP.ContractInsured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName);

            //Verify Owner details
            NYLDSelenium.VerifyText("Contract Owner", ExpOwnerNameandAddr.Trim(), ActualOwnerNameandAddr);

            //Verify Insured details
            NYLDSelenium.VerifyText("Insured", ExpectedInsuredName, ActualInsuredName);


            //Verify Insured fields
            NYLDSelenium.VerifyText("Insured first name", data[KeyRepository.InsuredFirstName], NYLDSelenium.GetAttribute("Insured FirstName", FirstName, "value"));
            NYLDSelenium.VerifyText("Insured Last name", data[KeyRepository.InsuredLastName], NYLDSelenium.GetAttribute("Insured LastName", LastName, "value"));

            //Verify DOB
            string dob = Convert.ToInt16(data[KeyRepository.InsuredDOBMonth]).ToString("00") + "/" + Convert.ToInt16(data[KeyRepository.InsuredDOBDay]).ToString("00") + "/" + Convert.ToInt16(data[KeyRepository.InsuredDOBYear]).ToString("00");
            NYLDSelenium.VerifyText("Insured DOB", dob, NYLDSelenium.GetAttribute("DOB Month", DateOfBirth, "value"));

            //Get value of the option selected                
            if (NYLDSelenium.ElemExist("Male selected", Male_Selected, false, "no", "no", "no"))
                NYLDSelenium.VerifyText("Gender", data[KeyRepository.InsuredGender], "Male");
            else
                NYLDSelenium.VerifyText("Gender", data[KeyRepository.InsuredGender], "Female");

            NYLDSelenium.AddHeader("Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "Success");

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyConfirmAddress                                                                        ///////////
        ////// Description:  Verify confirm address page displayed after change payor update                     ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyConfirmAddress(string args)
        {
            string selectedAddress;
            string[] updatedInfo;
            string[] getOption = args.Split(',');

            if (NYLDSelenium.ElemExist("Confirm Address page", ConfirmAddressHeader, false, "no", "no", "no"))
            {
                NYLDSelenium.AddHeader("Verify Confirm Address Page: " + args, "SubHeader");

                //Verify Header is displayed
                NYLDSelenium.VerifyText("Confirm Address Header", "Please Confirm Address", NYLDSelenium.GetAttribute("Confirm address header", ConfirmAddressHeader));

                //Verify Suggested address Header
                NYLDSelenium.VerifyText("Suggested Address Header", "Suggested U.S. Postal Service Address", NYLDSelenium.GetAttribute("Confirm address header", SuggestedAddressHeader));

                //Verify Entered address Header
                NYLDSelenium.VerifyText("Entered Address Header", "Use Address Entered", NYLDSelenium.GetAttribute("Confirm address header", EnteredAddressHeader));

                //Select Suggested or entered address as mentioned in args
                if (getOption[0] == "Suggested")
                {
                    //NYLDSelenium.selectRadioBtn("Suggested option", CPsuggAddrRadioBtn, "SuggestedPostalAddress");
                    NYLDSelenium.Click("Select Suggested radio Button", SuggestedAdrress);

                    selectedAddress = NYLDSelenium.GetAttribute("Suggested Address", SuggestedAdrress);
                    selectedAddress = selectedAddress.Replace(System.Environment.NewLine, " ");
                }
                else
                {
                    //NYLDSelenium.selectRadioBtn("Entered option", CPenteredAddrRadioBtn, "EnteredAddress");
                    NYLDSelenium.Click("Select Entered radio Button/", EnteredAdrress);

                    selectedAddress = NYLDSelenium.GetAttribute("Entered Address", EnteredAdrress);
                    selectedAddress = selectedAddress.Replace(System.Environment.NewLine, " ");
                }

                //Click on submit or back based on args
                updatedInfo = CSWData.TempVal.Split(':');
                if (getOption[1] == "Submit")
                {
                    //Click on Submit 
                    NYLDSelenium.Click("Confirm Address Submit", ConfirmButton);

                    //update temp val
                    CSWData.TempVal = updatedInfo[0] + ":" + updatedInfo[1] + ":" + selectedAddress + ":" + updatedInfo[3];
                }

                NYLDSelenium.AddHeader("Confirm address page verification ", "Success");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: updateEditInsured                                                                           ///////////
        ////// Description:  Update edit insured page based on paramters passed                                  ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateEditInsured(string args)
        {
            //args split
            string[] getoption = args.Split(',');

            //Field values
            string iFN = "TestFirstName";
            string iLN = "TestLastName";
            string iothr = "This is a test to check if name change reason text box will accept 200 characters or not. This name change reason text will be sent to process flow as name change reason. xxxxxxxxxxxxxxxxxxxxxxxxxxxx.";
            string idob = "10/02/1957";            
            string iGN = "Male";

            LoginPage login = new LoginPage(driver, data);

            //Verify Page Load
            NYLDSelenium.PageLoad("Payor", InsuredInfoHeader);

            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", login.CloseMockBanner, false, "no", "no", "no"))
                NYLDSelenium.Click("Mock banner", login.CloseMockBanner);

            NYLDSelenium.AddHeader("Update Edit Insured  " + args, "SubHeader");

            //update field as mentioned in args
            switch (getoption[0])
            {
                case "FirstName":
                    NYLDSelenium.Clear("Clear FirstName", FirstName);
                    NYLDSelenium.SendKeys("Update Insured first name", FirstName, iFN);
                    if (getoption[1] != "Other")
                    {
                        NYLDSelenium.SelectList("Update Reason", NameChangeReason, getoption[1], "bytext",true,"always","always");
                        CSWData.TempVal = "Namechange" + ":" + iFN + " " + data[KeyRepository.InsuredLastName] + "," + getoption[1];
                    }
                    else
                    {
                        NYLDSelenium.SelectList("Update Reason", NameChangeReason, getoption[1], "bytext", true, "always", "always");
                        NYLDSelenium.Clear("Clear Other Reason text", NameChangeReasonOther);
                        NYLDSelenium.SendKeys("Update other field", NameChangeReasonOther, iothr);
                        CSWData.TempVal = "Namechange" + ":" + iFN + " " + data[KeyRepository.InsuredLastName] + "," + iothr;
                    }
                    break;

                case "LastName":
                    NYLDSelenium.Clear("Clear FirstName", LastName);
                    NYLDSelenium.SendKeys("Update Insured last name", LastName, iLN);
                    if (getoption[1] != "Other")
                    {
                        NYLDSelenium.SelectList("Update Reason", NameChangeReason, getoption[1], "bytext", true, "always", "always");
                        CSWData.TempVal = "Namechange" + ":" + data[KeyRepository.InsuredFirstName] + " " + iLN + "," + getoption[1];
                    }
                    else
                    {
                        NYLDSelenium.SelectList("Update Reason", NameChangeReason, getoption[1], "bytext", true, "always", "always");
                        NYLDSelenium.Clear("Clear Other Reason text", NameChangeReasonOther);
                        NYLDSelenium.SendKeys("Update other field", NameChangeReasonOther, iothr);
                        CSWData.TempVal = "Namechange" + ":" + data[KeyRepository.InsuredFirstName] + " " + iLN + "," + iothr;
                    }
                    break;

                case "DOB":
                    
                    NYLDSelenium.Clear("DOB", DateOfBirth);
                    NYLDSelenium.SendKeys("DOB", DateOfBirth, idob);

                    CSWData.TempVal = "DOBchange" + ":" + idob;
                    break;

                case "Gender":
                    if (NYLDSelenium.ElemExist("Male selected", Male_Selected, false, "no", "no", "no"))
                    {
                        //NYLDSelenium.selectRadioBtn("Select Female option", Female, "Male");
                        NYLDSelenium.Click("Female Option", Female);
                        iGN = "Female";
                    }
                    else
                    {
                        //NYLDSelenium.selectRadioBtn("Select Male option", Male, "Male");
                        NYLDSelenium.Click("Male Option", Male);
                        iGN = "Male";
                    }
                    CSWData.TempVal = "Genderchange" + ":" + iGN;
                    break;

                case "All":
                    NYLDSelenium.Clear("Clear FirstName", FirstName);
                    NYLDSelenium.SendKeys("Update Insured first name", FirstName, iFN);
                    NYLDSelenium.Clear("Clear FirstName", LastName);
                    NYLDSelenium.SendKeys("Update Insured last name", LastName, iLN);
                    if (getoption[1] != "Other")
                        NYLDSelenium.SelectList("Update Reason", NameChangeReason, getoption[1], "bytext", true, "always", "always");
                    else
                    {
                        NYLDSelenium.SelectList("Update Reason", NameChangeReason, getoption[1], "bytext", true, "always", "always");
                        NYLDSelenium.Clear("Clear Other Reason text", NameChangeReasonOther);
                        NYLDSelenium.SendKeys("Update other field", NameChangeReasonOther, iothr);
                    }

                    //NYLDSelenium.ScrollToView(FirstName);
                    NYLDSelenium.Clear("DOB", DateOfBirth);
                    NYLDSelenium.SendKeys("DOB", DateOfBirth, idob);

                    if (NYLDSelenium.ElemExist("Male selected", Male_Selected, false, "no", "no", "no"))
                    {
                        //NYLDSelenium.selectRadioBtn("Select Female option", Female, "Male");
                        NYLDSelenium.Click("Female Option", Female);
                        iGN = "Female";
                    }
                    else
                    {
                        //NYLDSelenium.selectRadioBtn("Select Male option", Male, "Male");
                        NYLDSelenium.Click("Male Option", Male);
                        iGN = "Male";
                    }
                    if (getoption[1] != "Other")
                        CSWData.TempVal = "Allchange" + ":" + iFN + " " + iLN + "," + getoption[1] + ":" + idob + ":" + iGN;
                    else
                        CSWData.TempVal = "Allchange" + ":" + iFN + " " + iLN + "," + iothr + ":" + idob + ":" + iGN;
                    break;

                default:
                    break;
            }

            //submit
            NYLDSelenium.Click("Submit insured", SaveButton,false,"always","always");
            NYLDSelenium.AddHeader("Update Edit insured fields " + args, "Success");        
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyEditInsuredThankYou                                                                   ///////////
        ////// Description:  Verify Thank you page of Edit Insured                                               ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyEditInsuredThankYouPage()
        {
            HomePage home = new HomePage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            // Verify Change Payor Thank you screen
            NYLDSelenium.PageLoad("Edit Insured Thank You", ThankYouMessage);

            NYLDSelenium.AddHeader("Verify Edit Insured Thank You Page", "SubHeader");

            //Verify the succes Message displayed in the Thanks you screen
            NYLDSelenium.VerifyText("Submit succesful message", "Thank you "+data[KeyRepository.FirstName]+ ". Your changes will be processed. Please allow up to 5 business days for updates to be visible on this site. New York Life may contact you for additional information if needed.", CF.FormatString(NYLDSelenium.GetAttribute("InsuredSuccess message 1", ThankYouMessage)));

            //set trigger time
            CSWData.EventTriggerTime = DateTime.Now;
            CSWData.EventTriggerTime.AddSeconds(-90);
            NYLDSelenium.ReportStepResult("Event Trigger time", "Time captured in Update  insured method" + CSWData.EventTriggerTime, "info");

            NYLDSelenium.AddHeader("Verify Edit Insured Thank You Page", "Success");
        }

        public void ProcessFlow(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            ProcessFlow PF = new ProcessFlow(driver, data);
            string[] getoption = args.Split(',');
            NYLDSelenium.AddHeader("Edit Insured process : Insured details update, Email Verification and Process flow entry verification", "SubHeader");
            //Verify Process Flow  
            DateTime eventTriggertimeConverted = Convert.ToDateTime(CSWData.EventTriggerTime.ToString("MM/dd/yyyy HH:mm"));
            PF.VerifyProcessFlowEntry("EditInsured", CSWData.TempVal);

            //Verify LSP Notes
            DB.QueryLSPNotes("Edit Insured", getoption[0].Trim());
            NYLDSelenium.AddHeader("Edit Insured process : Insured details update, Email Verification and Process flow entry verification", "Success");

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyEditInsuredfields                                                                     ///////////
        ////// Description:  Field validation for Edit insured page                                              ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyEditInsuredfields(string args)
        {
            //Edit insured page field validations
            CommonFunctions CF = new CommonFunctions(data);
            LoginPage login = new LoginPage(driver, data);

            //Field values
            string iFN = "Connie";
            string iLN = "Tuttle";
            string iCR = "Marriage";
            string idob = "10/31/2017";            
            string iGN = "Male";

            //Edit Insured page
            NYLDSelenium.PageLoad("Edit Insured", InsuredInfoHeader);
            NYLDSelenium.AddHeader("Edit Insured Field validation screen", "SubHeader");
            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", login.CloseMockBanner, false, "no", "no", "no"))
                NYLDSelenium.Click("Mock banner", login.CloseMockBanner);

            //Arrays of edint insured feilds to be validated
            string[] Insuredfields = new string[] { "First Name", "Last Name", "Date of Birth" };           

            //verify pop up messages and validations by passing the array of fields
            for (int i = 0; i < Insuredfields.Length; i++)
            {

                //Refill the data with valid parameters after valiadtion
                switch (Insuredfields[i])
                {
                    case "FirstName":
                        NYLDSelenium.Clear("Clear First Name", FirstName);
                        NYLDSelenium.SendKeys("Update Insured First Name", FirstName, iFN);
                        break;

                    case "LastName":
                        NYLDSelenium.Clear("Clear Last Name", LastName);
                        NYLDSelenium.SendKeys("Update Insured Last Name", LastName, iLN);
                        break;

                    case "NameChange":
                        NYLDSelenium.SelectList("Update Insured Name change reason", NameChangeReason, iCR, "bytext");
                        break;

                    case "DOB":                        
                        NYLDSelenium.Clear("Clear DOB", DateOfBirth);
                        NYLDSelenium.SendKeys("Update DOB", DateOfBirth, idob);
                        break;
                }
            }

            if (NYLDSelenium.ElemExist("Male selected", Male_Selected, false, "no", "no", "no"))
            {
                NYLDSelenium.Click("Female Option", Female);
                iGN = "Female";
            }
            else
            {
                NYLDSelenium.Click("Male Option", Male);
                iGN = "Male";
            }
            NYLDSelenium.Click("Insured Submit", SaveButton);
            CSWData.EventTriggerTime = DateTime.Now;
            CSWData.EventTriggerTime.AddSeconds(-100);
            CSWData.TempVal = "Allchange" + ":" + iFN + " " + iLN + "," + iCR + ":" + idob + ":" + iGN;
            NYLDSelenium.AddHeader("Edit Insured Field validation", "Success");
        }        
    }
}

