﻿using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Home;
using Microsoft.Office.Interop.Excel;
using NUnit.Framework;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Web.UI;
using static CSW.Common.DataBase.LSPDatabase;

namespace CSW.PageObjects.Payments
{
    class PaymentHistoryPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public PaymentHistoryPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        #region Pageobjects
        ///////////////// Payments History Header //////////////////////////////////////////
        //Payment History  pages
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(), 'Payment history')]")]
        public IWebElement PaymentHistoryHeader { get; set; }

        //Contracts List Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='policy-toggle']")]
        public IWebElement ContractDropdown { get; set; }

        //Choose a contract number Header 
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Choose a contract number')]")]
        public IWebElement ContractHeader { get; set; }

        //Choose a Payment History Sub-header 
        [FindsBy(How = How.XPath, Using = "//h3[@class='text-steel']/following-sibling::p[1]")]
        public IWebElement PaymentHistorySubHeader { get; set; }

        //Choose a Payment History Policy txt 
        [FindsBy(How = How.XPath, Using = "//h4[@class='pb-4 text-steel']")]
        public IWebElement PaymentHistoryPolicyTxt { get; set; }

        //Choose a Payment History Policy Number
        [FindsBy(How = How.XPath, Using = "//h4[@class='pb-4 text-steel']//span/span")]
        public IWebElement PaymentHistoryPolicyNumber { get; set; }

        //Choose a Payment History Current Date
        [FindsBy(How = How.XPath, Using = "//*[@id='main']/section/div//p/strong")]
        public IWebElement PaymentHistoryCurrentDateTxt { get; set; }

        //Choose a Payment History Current Date
        [FindsBy(How = How.XPath, Using = "//*[@id='main']/section/div//p/strong/following-sibling::span")]
        public IWebElement PaymentHistoryCurrentDate { get; set; }

        //Choose a Payment History Table
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable']")]
        public IWebElement paymentHistoryTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable_paginate']/ul")]
        public IWebElement paymentHistorypagination { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable_paginate']/ul/li")]
        public IWebElement paymentHistorypaginationNumber { get; set; }

        //Request a mail copy lable
        [FindsBy(How = How.XPath, Using = "//a[contains(@href, '/Payments/Payment-History-By-Mail')]/parent::label")]
        public IWebElement paymentHistoryReqMailTxt { get; set; }

        //Request a mail Href
        [FindsBy(How = How.XPath, Using = "//a[contains(@href, '/Payments/Payment-History-By-Mail')]")]
        public IWebElement paymentHistoryReqMailHref { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(@class,'responsive-table')][2]")]
        public IWebElement paymentHistoryResponsiveTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(@class,'no-payment-history')]")]
        public IWebElement noPaymantHistorytxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable']/thead/tr")]
        public IWebElement historyTableHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable']/thead/tr/th[@aria-sort='descending']")]
        public IWebElement DateAppliedHeaderOrder { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable']/thead/tr/th[contains(text(),'Date applied')]")]
        public IWebElement DateAppliedlabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='paymentHistoryTable']/thead/tr/th[contains(text(),'Paid To date')]")]
        public IWebElement PaidtoDatelabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(@class, 'text-steel')]/../h5")]
        public IWebElement letterPageHeader { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//h1[contains(@class, 'text-steel')]/../p")]
        public IWebElement letterPageContent { get; set; }

        //Pament History mail page owner address
        [FindsBy(How = How.XPath, Using = "//*[@id='payment-history-by-mail-form']/div/div/p")]
        public IWebElement ownerAddress { get; set; }

        //Confirm Button
        [FindsBy(How = How.XPath, Using = "//button[@type ='submit' and text() ='Confirm']")]
        public IWebElement ConfirmButton { get; set; }

        //Thank you page
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(), 'Thank you')]")]
        public IWebElement ThankYouPage { get; set; }

        // Confirm Dialog
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(), 'Thank you')]/../..")]
        public IWebElement ThankYouPageMsg { get; set; }


        #endregion

        public string[] PolicyList { get; private set; }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyMultiPaymentHistoryPage                                          ///////////
        ////// Description:Verify Multi Contract Payment history Page                                ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyPaymentHistoryPage(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);            

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify payment history page for mutliple contracts" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");
            NYLDSelenium.PageLoad("Payment History", PaymentHistoryHeader);
            IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);");

            //Verify Drop down Menu
            if (!string.IsNullOrEmpty(CSWData.AssociatedPolicies))
                PolicyList = CSWData.AssociatedPolicies.Split(';');
            if (data[KeyRepository.ContractCount] == "Single")
            {

                NYLDSelenium.ElemNotExist("Contract dropdown list", ContractDropdown);
            }
            else
            {
                NYLDSelenium.ElemExist("Contract dropdown list", ContractDropdown);
                // Multi:verifying Contract drop down header label 
                NYLDSelenium.VerifyText("Contract dropdown Header", "Choose a contract number", NYLDSelenium.GetAttribute("Contract dropdown header", ContractHeader), "always");
            }

            if (string.IsNullOrEmpty(CSWData.Exisitngpolicyfromsheet))
                CSWData.Exisitngpolicyfromsheet = data[KeyRepository.PolicyNumber];

            //Verify the Contract List
           // NYLDSelenium.VerifyList("contract", ContractDropdown, PolicyList, "bytext", true);
            int count = 0; string ActualPolicyName = "";
            //select the policy and verify payment History Section
            foreach (string policy in PolicyList)
            {
                Console.WriteLine("policy: " + policy);
                if (PolicyList.Count() > 1)
                {
                    SelectElement select = new SelectElement(ContractDropdown);
                    IList<IWebElement> options = select.Options;

                    ActualPolicyName = options[count].GetAttribute("text").Trim();
                    data[KeyRepository.PolicyNumber] = ActualPolicyName.Split('-')[1].Trim();

                    //Select the contract from dropdown
                    js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);"); Thread.Sleep(6000);
                    NYLDSelenium.SelectList("Policy drop down", ContractDropdown, ActualPolicyName, "bytext", true);
                }
                else
                    data[KeyRepository.PolicyNumber] = policy;

                VerifyPaymentHistorySection(args);
                count = count + 1;
                if (count == PolicyList.Length)
                    NYLDSelenium.AddHeader("Verify Payment history details steps completed successfully", "SubHeader");
            }
        }

        /// <summary>
        /// Method helps to Verify Payment history Section
        /// </summary>
        /// <param name="ContractSelected"></param>
        /// <param name="PolicyNumber"></param>
        public void VerifyPaymentHistorySection(string args)
        {
            HomePage home = new HomePage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            LSPDatabase LSP = new LSPDatabase(driver, data);

            //verify Premium payments paid
            NYLDSelenium.VerifyText("premium payments months ", "Premium payments paid up to the past 24 months.", NYLDSelenium.GetAttribute("Premium payments paid up", PaymentHistorySubHeader), "always", "always");

            //verify the Payment history for which policy
            NYLDSelenium.VerifyText("Payment history for " + data[KeyRepository.PolicyNumber], "Payment history for: " + data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Current as of: ", PaymentHistoryPolicyTxt), "always", "always");

            //Verify the Current date txt
            DateTime now = DateTime.Now;
            NYLDSelenium.VerifyText("Current as of: " + now.ToString("MM/dd/yyyy"), "Current as of: " + now.ToString("MM/dd/yyyy"), NYLDSelenium.GetAttribute("Current as of: ", PaymentHistoryCurrentDateTxt)+ " " + NYLDSelenium.GetAttribute("Current As of Date", PaymentHistoryCurrentDate), "always", "always");

            // ToDo: ******************Need to add the DB method to verify the payment history*********************
            LSP.QueryPaymentDetails();
            PaymentHistoryResult paymentHistoryResult = LSP.QueryPaymentHistory(args);
            List<string> PaymentHistory = paymentHistoryResult.PaymentHistory;
            List<string> PaymentReversalHistory = paymentHistoryResult.PaymentReversalHistory;
            string paymentHistoryTable = "//*[@id='paymentHistoryTable']//tbody//tr";
            IList<IWebElement> tableCount = NYLDSelenium.GetWES(paymentHistoryTable);

            if (args == "PaymentReversal")
            {
                if (PaymentHistory.Count != tableCount.Count)
                {
                    NYLDSelenium.ReportStepResult(
                        "Payment reversal record count does not match with UI records: " + tableCount.Count,
                        PaymentHistory.Count.ToString(),
                        "Fail",
                        "no",
                        "no"
                    );
                }else
                    NYLDSelenium.ReportStepResult(
                        "Payment reversal record found in LSP table  ",
                        PaymentReversalHistory.Count.ToString(),
                        "Info",
                        "no",
                        "no"
                    );

            }
            // *********************Compare the numberofRows vs expected count from DB/Service*******************            

            NYLDSelenium.ReportStepResult("payment history DB number of record found: ", PaymentHistory.Count.ToString(),"Info","no","no");
            if (PaymentHistory.Count == 0)
            {
                if (NYLDSelenium.ElemExist("no Payment history content", noPaymantHistorytxt))
                    NYLDSelenium.VerifyText("no Payment history content", CF.FormatString(testData.GetContent("NoPaymentHistory").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("no payament history content ", noPaymantHistorytxt)), "always", "always");
            }
            else
            {
                int expPageCount = (int)Math.Ceiling((double)PaymentHistory.Count / 12);
                if(expPageCount > 1)
                    NYLDSelenium.ElemExist("Pagination", paymentHistorypagination, false, "Yes");

                string headertxt = NYLDSelenium.GetAttribute("History Table Header: ", historyTableHeader);
                Console.WriteLine("headertxt: " + headertxt);
                string[] headerexpect = {"Date applied", "Amount applied", "Paid to date" };
                NYLDSelenium.VerifyText("payment history table header Info ", CF.FormatString(headerexpect[0] + " " + headerexpect[1] + " " + headerexpect[2]), CF.FormatString(headertxt), "always", "always");
                Thread.Sleep(1000);
                string pageelement = "//*[@id='paymentHistoryTable_paginate']/ul/li";
                if (expPageCount != 1)
                {
                    IList<IWebElement> pageCount = NYLDSelenium.GetWES(pageelement, true);
                    if (expPageCount != pageCount.Count || (expPageCount > 0 && pageCount == null))
                    {
                        NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of pagination", "Actual page count displayed page count not matching", "Fail");
                    }
                }
                else
                {
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number ", "pagination not available for single page", "Pass");
                }

                NYLDSelenium.AddHeader("Verify payment history: Date applied, Amount applied and Paid to Date all entries are displayed as expected for the Contract " + data[KeyRepository.PolicyNumber], "SubHeader");
                
                IList<IWebElement> historyTableRows = NYLDSelenium.GetWES(paymentHistoryTable);
                int row = 0;
                int page = 1;
                foreach(string historydata in PaymentHistory)
                {
                    WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                    IList<IWebElement> items = wait.Until(d => d.FindElements(By.XPath(paymentHistoryTable+"["+(row+1)+"]//td")));
                    string td = paymentHistoryTable+"["+(row+1)+"]//td";
                    IList<IWebElement> historyInfo = NYLDSelenium.GetWES(td);
                    NYLDSelenium.VerifyText("Date applied index " + row, DateTime.Parse(historydata.Split(' ')[0].ToString()).ToString("MM/dd/yyyy"), historyInfo[0].Text.Trim());
                    NYLDSelenium.VerifyText("Amount applied index " + row, "$" + historydata.Split(' ')[1], historyInfo[1].Text.Trim());
                    NYLDSelenium.VerifyText("Paid to Date index " + row, DateTime.Parse(historydata.Split(' ')[2].ToString()).ToString("MM/dd/yyyy"), historyInfo[2].Text.Trim());                   
                        row++;
                    Console.WriteLine(" Row" + row);
                     if (row == 12)
                    {
                        row = 0;
                        string getpageElement = pageelement + "[" + (page + 1) + "]";
                        IWebElement paginationindexnumber = NYLDSelenium.GetWE(getpageElement);
                        if (paginationindexnumber == null)
                            break;
                        NYLDSelenium.Click("on page number: " + (page + 1), paginationindexnumber);
                        Thread.Sleep(10000);
                        string pageindex = "//*[@id='paymentHistoryTable_paginate']/ul/li/a[contains(@aria-current, 'page')]";
                        IWebElement paginationIndex = NYLDSelenium.GetWE(pageindex);                        
                        NYLDSelenium.ElemExist("Pagination paginate", paginationIndex, false, "Yes");
                        page++;
                    }
                }

                NYLDSelenium.AddHeader("Verification for the payment history Successful " + data[KeyRepository.PolicyNumber], "Success");
               
                NYLDSelenium.VerifyText("Request a copy: mail", "Request a copy: mail", NYLDSelenium.GetAttribute("Request a copy: ", paymentHistoryReqMailTxt), "always", "always");
              
                IList<IWebElement> footertableRows = NYLDSelenium.GetWES("//*[contains(@class,'responsive-table')][2]/div[@class='responsive-row']");

                //Array heading names
                string[] footerHeadingexpect = { "Current", "Date", "AmountApplied" };
                for (int i = 0; i < footertableRows.Count - 1; i++)
                {
                    NYLDSelenium.VerifyText("Payment history footer content", CF.FormatString(testData.GetContent(footerHeadingexpect[i]).ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Payment history footer content : ", footertableRows[i])), "always", "always");
                }                
            }
        }

        public void ClickMailLink()
        {
            NYLDSelenium.Click("on mail link", paymentHistoryReqMailHref);
        }

        public void VerifyMailPage()
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            string ExpContractOwner;
            if (data[KeyRepository.AddressLine2] == " ")
                ExpContractOwner = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + data[KeyRepository.AddressLine1] + data[KeyRepository.City] + ", " + data[KeyRepository.State] + " " + data[KeyRepository.Zip];
            else
                ExpContractOwner = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + data[KeyRepository.AddressLine1] + data[KeyRepository.AddressLine2] + data[KeyRepository.City] + ", " + data[KeyRepository.State] + " " + data[KeyRepository.Zip];

            NYLDSelenium.PageLoad("Get a payment history letter by mail", letterPageHeader);
            NYLDSelenium.VerifyText("Payment history letter page header", "Get a payment history letter by mail", CF.FormatString(NYLDSelenium.GetAttribute("Payment history letter page header : ", letterPageHeader)), "always", "always");
            NYLDSelenium.VerifyText("Payment history letter page content", CF.FormatString(testData.GetContent("PaymentHistoryLetterPage").ToString().Trim())+ " " +data[KeyRepository.PolicyNumber] + ". We'll mail the letter to the address below:", CF.FormatString(NYLDSelenium.GetAttribute("Payment history letter page content :", letterPageContent)), "always", "always");

            NYLDSelenium.VerifyText("Payment history Owner Address for mail", ExpContractOwner.Replace(" ", "").Replace(",", ""), NYLDSelenium.GetAttribute("Policy owner name", ownerAddress).Replace(" ", "").Replace("\r\n", "").Replace(",", ""), "always");
            NYLDSelenium.Click("on confirm", ConfirmButton,false,"always","onerror",90);
            
        }
        public void VerifyMailThankyouPage()
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            string ExpThankMsg = "Thank you, " + data[KeyRepository.FirstName] +". " + CF.FormatString(testData.GetContent("PaymentHistoryMailThankyouMessage").ToString().Trim());

            //ThankYou page and message
            NYLDSelenium.PageLoad("Payment history letter ThankYou", ThankYouPageMsg);
            NYLDSelenium.VerifyText("Thank you message", ExpThankMsg, CF.FormatString(NYLDSelenium.GetAttribute("get message text", ThankYouPageMsg)));

        }

    }

}