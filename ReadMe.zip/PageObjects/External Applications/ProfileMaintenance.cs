﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using System.Threading;
using CSW.Common.Services;
using CSW.Common.Email;
using CSW.Common.DataBase;
using System.IO;
using CSW.Common.Others;
using CSW.Common.Excel;
using System.Drawing;

namespace CSW.PageObjects.External_Applications
{
    class ProfileMaintenance
    {

        private IWebDriver driver;
        private Dictionary<string, string> data;
        
        public ProfileMaintenance(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

       
        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //Page Header
        [FindsBy(How = How.XPath, Using = "//a[@class='navbar-brand' and contains(., 'Profile Maintenance')]")]
        public IWebElement PMHeader { get; set; }

        //Contract Number Field
        [FindsBy(How = How.Name, Using = "PolicyNumber")]
        public IWebElement ContractNo { get; set; }

        //Contract Search button
        [FindsBy(How = How.XPath, Using = "//*[@id='navbar-search']/div[2]/input")]
        public IWebElement ContractSearch { get; set; }

        //Customer Name
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[2]/div/div/div/div/div/h4")]
        public IWebElement Name { get; set; }

        //Contract Number
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[1]/span")]
        public IWebElement ActContractNo { get; set; }

        //User Status
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/div/div[1]/span")]
        public IWebElement UserStatus { get; set; }

        //User ID
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[2]/div/p")]
        public IWebElement ProfileInfo_Row1 { get; set; }

        //Registered Email Address
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[3]/div/p")]
        public IWebElement ProfileInfo_Row2 { get; set; }

        //Address
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[4]/div")]
        public IWebElement ProfileInfo_Row3 { get; set; }

        //City], State]
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[5]/div/p")]
        public IWebElement ProfileInfo_Row4 { get; set; }

        // Zip Code
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[6]/div/p")]
        public IWebElement ProfileInfo_Row5 { get; set; }

        //SSN
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/form/div[7]/div/p")]
        public IWebElement ProfileInfo_Row6 { get; set; }

        //Cyber Fraud Prevention Flag Header - Flagged
        [FindsBy(How = How.XPath, Using = "//*[@class='alert alert-danger fade in block-inner' and contains(., 'Cyber Fraud Prevention Flag : Flagged')]")]
        public IWebElement CyberFraudPreventionFlagFlaggedHeader { get; set; }

        //Cyber Fraud Prevention Flag Header - Not Flagged
        [FindsBy(How = How.XPath, Using = "//*[@class='alert alert-danger fade in block-inner' and contains(., 'Cyber Fraud Prevention Flag : Not Flagged')]")]
        public IWebElement CyberFraudPreventionFlagNotFlaggedHeader { get; set; }

        //Apply Cyber Fraud Prevention Button
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary' and contains(., 'Apply Cyber Fraud Protection')]")]
        public IWebElement ApplyCyberFraudPreventionButton { get; set; }

        //Apply Cyber Fraud Prevention Button
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary' and contains(., 'Remove Cyber Fraud Protection')]")]
        public IWebElement RemoveCyberFraudPreventionButton { get; set; }

        //Send Reset Password Button
        [FindsBy(How = How.XPath, Using = "//*[@class='btn btn-primary' and contains(., 'Send Reset Password')]")]
        public IWebElement SendResetPassword { get; set; }

        //Send Profile Verification Email
        [FindsBy(How = How.XPath, Using = "//*[@class='btn btn-primary' and contains(., 'Send Profile Verification Email')]")]
        public IWebElement SendProfileVerificationEmail { get; set; }

        //Reset Password Confirmation Header
        [FindsBy(How = How.XPath, Using = "//*[@class='alert alert-block alert-info fade in block-inner' and contains(., 'Reset Confirmation')]")]
        public IWebElement ResetPasswordConfHeader { get; set; }

        //Profile Verification Confirmaiton Header
        [FindsBy(How = How.XPath, Using = "//*[@class='alert alert-block alert-info fade in block-inner' and contains(., 'Profile Confirmation')]")]
        public IWebElement ProfileConfeader { get; set; }

        //Reset Password Confirmation Body
        [FindsBy(How = How.XPath, Using = "//html/body/div[2]/div/div[2]/div[2]/div/p")]
        public IWebElement SuccessMsgConfBody { get; set; }

        //Deactivate Button
        [FindsBy(How = How.XPath, Using = "//a[@class='btn btn-primary' and contains(., 'Deactivate Customer')]")]
        public IWebElement DeactivateCustomer { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='deactivateform']/div[1]/div/h6[contains(., 'Deactivation of Account')]")]
        public IWebElement DeactivateAccountHeader { get; set; }

        //Deactivate UserNameConf
        [FindsBy(How = How.XPath, Using = "//*[@id='deactivateform']/div[1]/div/h5")]
        public IWebElement DeactUserNameConf { get; set; }

        //Deactivate Reason
        [FindsBy(How = How.Name, Using = "DeactivateReason")]
        public IWebElement DeactivateReason { get; set; }

        //Return to Client Info
        [FindsBy(How = How.XPath, Using = "//*[@id='deactivateform']/div[1]/div/div/a[2]")]
        public IWebElement ReturntoClientInfo { get; set; }

        //Continue Deactivation
        [FindsBy(How = How.XPath, Using = "//*[@id='deactivateform']/div[1]/div/div/input")]
        public IWebElement ContinueDeactivation { get; set; }

        //ConfirmationMessage
        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/div/div[2]/div[1]/div/div[2]/div[1]/div/div")]////div[contains(@class, 'success') and contains(., 'success')]
        public IWebElement ConfirmationMessage { get; set; }

        //Cyber Fraud Flag - Window
        [FindsBy(How = How.XPath, Using = "//*[@class='alert alert-block alert-danger fade in block-inner' and contains(., 'Add/Remove Cyber fraud flag on Account')]")]
        public IWebElement CyberFraudWindow { get; set; }

        //Client ID
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[2]/form/div/div/div[1]/div[2]")]
        public IWebElement CyberFraudClientID { get; set; }

        //Name
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[2]/form/div/div/div[2]/div[2]")]
        public IWebElement CyberFraudName { get; set; }

        //Name
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[2]/form/div/div//ul/li")]
        public IWebElement CyberFraudNotesError { get; set; }

        //Notes Window
        [FindsBy(How = How.Id, Using = "Notes")]
        public IWebElement CyberFraudNotes { get; set; }

        //Apply Cyber Fraud Prevention Button
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[2]/form/div/div/div[6]/input")]
        public IWebElement SetCyberFraudFlagButton { get; set; }

        //Return to Search
        [FindsBy(How = How.XPath, Using = "//*[@class='btn btn-info' and contains(., 'Return To Search')]")]
        public IWebElement ReturnToSearchButton { get; set; }

        //Not Registered - Header Message
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/div/div[3]/div/div/h6")]
        public IWebElement NotRegisteredHeader { get; set; }

        //Not Registered - Body Message
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/div/div[3]//div/div/p")]
        public IWebElement NotRegisteredBody { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/div/div[3]/div/div[1]/h6")]
        public IWebElement PolicyAlertBanner1 { get; set; }

        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[3]/div/div/div[3]/div/div[2]/h6")]
        public IWebElement PolicyAlertBanner2 { get; set; }

        //Search Page
        [FindsBy(How = How.XPath, Using = "//h6[@class='heading-hr' and contains(., 'Primary Contract Search')]")]
        public IWebElement SearchHeading { get; set; }

        //Search Body
        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/div/div[2]/div[1]/div/div[2]/div[1]/div/div")]
        public IWebElement SearchBody { get; set; }


        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////
        

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: LaunchPF                                                                                    ///////////
        ////// Description:  Launch Profile maintenance                                                          ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void LaunchPF(string type="")
        {
            CommonFunctions.WindowsTabFocus("OpenNewTab", "newTabInstance");
            string URL;

            if (type == "NoPolicy")
                URL = "http://model-profilemaintenance/Client/Index/";
            else
                URL = "http://model-profilemaintenance/Client/Index/" + data[KeyRepository.PolicyNumber];

            if (type != "Payments")
            {
                driver.Navigate().GoToUrl(URL);
            }
            else
                driver.Navigate().GoToUrl("http://model-profilemaintenance/Client/Index/" + data[KeyRepository.PolicyNumber]);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: ClosePF                                                                                     ///////////
        ////// Description:  Close Profile maintenance and open CSW application url                             ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void ClosePF()
        {
            //Close();
            //OpenBrowser(CSWData.browser);
            Thread.Sleep(3000);
            CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
            CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");

          //  NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Navigate to CSW application" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
           new CommonFunctions(data).ErrorCertByPass();

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getUserStatus                                                                              ////////////
        ////// Description: Get status of user as displayed in porfile maintenance page                         ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public string GetUserStatus(string args)
        {
            //Verify Profile Maintenance Page
          //  NYLDSelenium.PageLoad("Profile Maintenance", PMHeader);
            return UserStatus.Text;
        }

        public string GetUserStatusRiderAndExchanges(string args)
        {
            //Verify Profile Maintenance Page
            //  NYLDSelenium.PageLoad("Profile Maintenance", PMHeader);
            string username = "";
            if (UserStatus.Text == "Active")
                username = ProfileInfo_Row1.Text.ToLower();
            return UserStatus.Text + "|" + username;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyProfileMt                                                                            ////////////
        ////// Description: Verify profile maintenance page for the contract                                    ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void VerifyProfileMt(string args)
        {
            string[] argslist;
            argslist = args.Split(',');
            bool CyberFraudFlag;
            LSPDatabase DB = new LSPDatabase(driver, data);
            TestData testData = new TestData();
            EmailVerification OE = new EmailVerification(driver, data);
            RestServices webService = new RestServices(data);

            if (argslist[0] != "JustSearchContract")
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Profile Maintenance ContactInfoPage Title" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                string pfuserstatus;
                string userStatus = "Unknown";
                string CustName;


                //Get User Status from ADLDS 
                if(data[KeyRepository.UserAccountStatus] != "Not Registered")
                    userStatus = webService.SubmitWSCall("ProfileStatus");

                if (userStatus == "Unknown")
                    pfuserstatus = "NotRegistered";
                else
                    pfuserstatus = userStatus;

                //Verify Profile Maintenance Page
               NYLDSelenium.PageLoad("Profile Maintenance", PMHeader);


                //Verify First Name and Last Name Header                
                if (data[KeyRepository.MiddleName] != "")
                    CustName = data[KeyRepository.Title].ToLower() + " " + data[KeyRepository.FirstName].ToLower() + " " + data[KeyRepository.MiddleName].ToLower() + " " + data[KeyRepository.LastName].Substring(0, 1).ToLower() + data[KeyRepository.LastName].Substring(1).ToLower();
                else
                    CustName = data[KeyRepository.Title].ToLower() + " " + data[KeyRepository.FirstName].ToLower() + " " + data[KeyRepository.LastName].Substring(0, 1).ToLower() + data[KeyRepository.LastName].Substring(1).ToLower();

                if (data[KeyRepository.Suffix] != null && data[KeyRepository.Suffix] != "")
                    CustName = CustName.Trim() + " " + data[KeyRepository.Suffix];

              //  NYLDSelenium.VerifyText("Name", CustName.ToLower().Trim(), Name.Text.ToLower(), "yes");                   

                //Verify Contract Number
                NYLDSelenium.VerifyText("Contract No.", data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Acutal Contract", ActContractNo,"text"));

                //Verify Profile Status
                NYLDSelenium.VerifyText("User Status", pfuserstatus, UserStatus.Text);
                
                
                if (pfuserstatus == "NotRegistered")
                {
                    //Verify Address
                    NYLDSelenium.VerifyText("Address", (data[KeyRepository.AddressLine1]).Trim(), ProfileInfo_Row1.Text, "yes");

                    //Verify City], State]
                    NYLDSelenium.VerifyText("City], State]", data[KeyRepository.City].Trim() + ", " + data[KeyRepository.State], ProfileInfo_Row2.Text, "yes");//**changed from row2 to row 5 as row 2 does not display City] and stae

                    //Verify Zip]
                    NYLDSelenium.VerifyText("Zip Code", data[KeyRepository.Zip].Trim(), ProfileInfo_Row3.Text, "yes");

                    //Verify SSN
                    NYLDSelenium.VerifyText("SSN", data[KeyRepository.SSN].Substring(5), ProfileInfo_Row4.Text, "yes");
                }
                else
                {
                    //Verify User ID
                    NYLDSelenium.VerifyText("User Name", data[KeyRepository.UserName].ToLower(), ProfileInfo_Row1.Text.ToLower(), "yes");

                    //Verify Registered Email ID                   
                    //NYLDSelenium.containsText("Email ID", ProfileInfo_Row2.Text.Trim().ToLower(), data[KeyRepository.EmailId].ToLower());
                    string email = NYLDSelenium.GetAttribute("Email ID", ProfileInfo_Row2);
                 //   if( email.ToLower().Trim().Contains(data[KeyRepository.EmailId].ToLower().Trim()))
                  //      NYLDSelenium.ReportStepResult("Email id mismatch, Exp : " + data[KeyRepository.EmailId].ToLower() +" Actual : " + email.ToLower(), "INFO", "no");
                    //NYLDSelenium.VerifyText("Email ID", data[KeyRepository.EmailId].ToLower().Trim() + "_" + DateTime.Now.ToString("yyyyMMddHHmmss"), ProfileInfo_Row2.Text.Trim().ToLower(), "yes");

                    //Verify Address
                    NYLDSelenium.VerifyText("Address", (data[KeyRepository.AddressLine1]).Trim(), ProfileInfo_Row3.Text, "yes");

                    //Verify City], State]
                    NYLDSelenium.VerifyText("City], State]", data[KeyRepository.City].Trim() + ", " + data[KeyRepository.State], ProfileInfo_Row4.Text, "yes");

                    //Verify Zip]
                    NYLDSelenium.VerifyText("Zip Code", data[KeyRepository.Zip].Trim(), ProfileInfo_Row5.Text, "yes");

                    //Verify SSN
                    NYLDSelenium.VerifyText("SSN", data[KeyRepository.SSN].Substring(5), ProfileInfo_Row6.Text, "yes");
                }

                //Check if Cyber Fraud Alert exists
                CyberFraudFlag = DB.QueryCyberFraudAlerts();

                //Depending on Profile Status = Verify Resent Online Password and Deactivate Customer Online Profile
                if (!CyberFraudFlag)
                {
                    switch (pfuserstatus)
                    {
                        case "NotRegistered":

                            //Verify Not Registered Heading
                            NYLDSelenium.VerifyText("No Active Online Profile - Heading", "Client does not have an active Online Profile", NYLDSelenium.GetAttribute("Not Registered - Header", NotRegisteredHeader), "yes");

                            //Verify Not Registered Body
                            NYLDSelenium.VerifyText("No Active Online Profile - Body", testData.GetContent("NoActiveOnlineProfile"), NYLDSelenium.GetAttribute("Not Registered - Body", NotRegisteredBody), "yes");

                            break;

                        case "Deactivated":
                            //Verify Not Registered Heading
                            NYLDSelenium.VerifyText("Client Online Profile Deactivated - Heading", "Client Online Profile Deactivated", NYLDSelenium.GetAttribute("Not Registered - Header", NotRegisteredHeader), "yes");

                            //Verify Not Registered Body
                            NYLDSelenium.VerifyText("Client Online Profile Deactivated - Body", testData.GetContent("ClientOnlineProfileDeactivated"), NYLDSelenium.GetAttribute("Not Registered - Body", NotRegisteredBody), "yes");
                            break;

                        default:
                            if (pfuserstatus == "Registered")
                            {
                                //Verify Not Registered Heading
                                NYLDSelenium.VerifyText("Client Online Profile Not Yet Verified - Policy Alert", "Client Online Profile Not Yet Verified", PolicyAlertBanner1.Text.Trim(), "yes");

                                //Verify if Send Reset Password button exists
                                //NYLDSelenium.ElemExist("Send Reset Password Button", SendProfileVerificationEmail, 60, "yes", "yes");
                            }
                            else
                            {
                                //Verify Not Registered Heading
                             //   NYLDSelenium.VerifyText("Reset Online Profile Password - Policy Alert", "Reset Online Profile Password", PolicyAlertBanner1.Text.Trim(), "yes");

                                //TODO: Insert the code for to verify Reset password text
                                //Verify if Send Reset Password button exists
                              //  NYLDSelenium.ElemExist("Send Reset Password Button", SendResetPassword, 60, "yes", "yes");
                            }

                            //Verify Deactivation Body
                            NYLDSelenium.VerifyText("Deactivate Customer Online Profile - Policy Alert", "Deactivate Customer Online Profile", PolicyAlertBanner2.Text.Trim(), "yes");

                            //Verify if Deactivate button exists
                            NYLDSelenium.ElemExist("Deactivate Customer Button", DeactivateCustomer,true);

                            break;
                    }
                }

                if (!CyberFraudFlag)
                {
                    //Check the Cyber Alert Banner
                    NYLDSelenium.ElemExist("Cyber Fraud Prevention Flag : Not Flagged Header", CyberFraudPreventionFlagNotFlaggedHeader);

                    //Check Cyber Alert Button
                    if (data[KeyRepository.Environment] == "QA" || data[KeyRepository.Environment].ToUpper() == "MODEL")
                        NYLDSelenium.ElemExist("Apply Cyber Fraud Prevention Button", ApplyCyberFraudPreventionButton);

                }
                else
                {
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Cyber Fraud section" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //Check if Other Banners doesnt exist
                    NYLDSelenium.ElemNotExist("Not Registered - Header", NotRegisteredHeader);
                    NYLDSelenium.ElemNotExist("Not Registered - Body", NotRegisteredBody);

                    //Check the Cyber Alert Banner
                    NYLDSelenium.ElemExist("Cyber Fraud Prevention Flag : Flagged Header", CyberFraudPreventionFlagFlaggedHeader);

                    //Check Cyber Alert Button
                    NYLDSelenium.ElemExist("Remove Cyber Fraud Prevention Button", RemoveCyberFraudPreventionButton);

                    //Check if Reset Online Password window doesnt exist
                    NYLDSelenium.ElemNotExist("Reset Online Profile Password Section", ResetPasswordConfHeader, false,"no", "yes","always");

                    //Check if Deactivite Customer Online Profile doesnt exist
                    NYLDSelenium.ElemNotExist("Deactive Customer Online Profile Section", DeactivateAccountHeader,false, "no", "yes","always");
                }
            }

            //Capture submit time
            CSWData.EventTriggerTime = DateTime.Now;

            //Perform actions
            switch (argslist[0])
            {
                case "SearchContract":
                case "JustSearchContract":

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Search Contract" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

                    if (argslist[1] == "Multi")
                    {
                        string[] policies;
                        //Get the associated policies
                        DB.QueryAssociatedPolicies("Benes");

                        policies = CSWData.AssociatedPolicies.Split(';');

                        foreach (string pl in policies)
                        {
                            data[KeyRepository.PolicyNumber] = pl;
                            DB.QueryPolicyDetails();

                            NYLDSelenium.Click("Contract Number", ContractNo);

                            //Enter Contract Number
                            NYLDSelenium.SendKeys("Contract Number", ContractNo, pl);

                            //Click Search Contract
                            NYLDSelenium.Click("Contract Search", ContractSearch);
                            //Verify Profile MaintenancePage
                            VerifyProfileMt("");
                        }
                    }
                    else
                    {
                        //Click Contract Number
                        NYLDSelenium.Click("Contract Number", ContractNo);


                        //Enter Contract Number
                        NYLDSelenium.SendKeys("Contract Number", ContractNo, data[KeyRepository.PolicyNumber]);

                        //Click Search Contract
                        NYLDSelenium.Click("Contract Search", ContractSearch);

                        if ((argslist[1] == "invalid") || (argslist[1] == "nonexist"))
                            VerifyNoResults("", argslist[1]);
                        else
                        {
                            //Verify Profile MaintenancePage
                            VerifyProfileMt("");
                        }
                    }
                    break;

                case "DeactivateUser":

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Deactivate User" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

                    //Click Deactivate User button
                    NYLDSelenium.Click("Deactivate Customer Button", DeactivateCustomer);

                    //Verify Deactivate Account Page Load
                    NYLDSelenium.PageLoad("Deactivation of Account", DeactivateAccountHeader);

                    //Return to Client Info
                    NYLDSelenium.Click("Return to Client Info", ReturntoClientInfo);

                    //Click Deactivate User button
                    NYLDSelenium.Click("Deactivate Customer Button", DeactivateCustomer);

                    //Verify Deactivate Account Page Load
                    NYLDSelenium.PageLoad("Deactivation of Account", DeactivateAccountHeader);

                    //Verify Decactivation User Name
                    NYLDSelenium.VerifyText("Profile Name in Deactivation of Account", data[KeyRepository.UserName].ToLower(), DeactUserNameConf.Text.ToLower(), "yes");

                    //Verify Deactivation List
                    string[] reasons = new string[] { "IncorrectProfileInformation", "SecurityConcerns", "Other" };
                    NYLDSelenium.VerifyList("Deactivation Reason", DeactivateReason, reasons);

                    //Verify default listed value
                    //Need to work on it

                    //Select Deactivation Reason
                    NYLDSelenium.SelectList("Deactivation Reason", DeactivateReason, argslist[1], "bytext");

                    //Click Continue Deactivation
                    NYLDSelenium.Click("Continue Deactivation", ContinueDeactivation);

                    //Verify Deactivation Confirmation Message
                    if ((NYLDSelenium.ElemExist("Confirmation Message", ConfirmationMessage) && (ConfirmationMessage.Text.Trim().Contains("not successful"))))
                    {
                        NYLDSelenium.ReportStepResult("Confirm Deactivation.", "Deactivation was not successful", "FAIL","always","yes");
                    }
                    else
                    {
                        for (int k = 1; k < 5; k++)
                        {
                            Thread.Sleep(4000);

                            if (webService.SubmitWSCall("DeactivatedUser") == "yes")
                            {
                                break;
                            }
                        }

                        //Call WebService and cofirm User Status
                        //TODO-Need to review -Profile Maintenance not working so commented the below 
                        //if (deact == "yes")
                        //{
                        //    NYLDSelenium.ReportStepResult("Confirm Deactivation.", "Deactivation message displayed and ADLDS Status confirms the same.", "PASS");
                        //    CreateDeactivateCustEmailContent(argslist[1]);
                        //}
                        //else
                        //    NYLDSelenium.ReportStepResult("Confirm Deactivation.", "Deactivation message displayed and ADLDS Status not changed to Deactivated.", "FAIL","always");

                        // CreateDeactivateCustEmailContent(argslist[1]);
                    }
                

                    //Verify ADLSD
                    //Verify LSP Notes
                   // DB.QueryLSPNotes("Deactivate User", argslist[1]);

                    //Emails verification
                    //OE.GetEmailsList("Deactivated Customer Notification");
                    break;

                case "SendResetPassword":

                    Thread.Sleep(3000);

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Send Reset Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

                    //Click Send Reset Password Button
                    try {
                        if (NYLDSelenium.ElemExist("Send Reset Password", SendResetPassword, false, "no", "no"))
                            NYLDSelenium.Click("Send Reset Password", SendResetPassword);
                    }
                    catch {
                        if (NYLDSelenium.ElemExist("Send Reset Password", SendResetPassword, false, "no", "no"))
                            BtnClick("//*[@class='btn btn-primary' and contains(., 'Send Reset Password')]", data);
                    }

                    //Verify Reset Password Confirmation
                    NYLDSelenium.PageLoad("Reset Password", ResetPasswordConfHeader);

                    //Verify Reset Password Confirmation Body
                    NYLDSelenium.VerifyText("Reset Password Confirmation Text", "An email link to reset the customer's profile has been sent to the owner's email address currently on file. The email link is valid for 24 hours.", SuccessMsgConfBody.Text.Trim(), "yes");

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Reset Password LSP Notes and Email" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //Verify LSP Notes
                    DB.QueryLSPNotes("Reset Password");

                    CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");

                    if (CSWData.EmailVerificationflag)
                    {
                        CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
                        LaunchBrowserwithToken("Reset Password");
                    }

                    //Verify Reset Password Email
                    OE.VerifyEmailInbox("PM Reset Password");

                    string newUrl = driver.Url.ToString();
                    if (data[KeyRepository.Environment] == "QA" || data[KeyRepository.Environment] == "Model" || data[KeyRepository.Environment] == "MODEL")
                    {
                        newUrl = newUrl.Replace("stage.service.nylaarp.com", "nylcsc-model-1.nylaarp.nt.newyorklife.com");
                        driver.Navigate().GoToUrl(newUrl);
                        Thread.Sleep(3000);
                    }

                    break;

                case "SendProfileVerificationEmail":

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Send Profile Verification Email" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //Click Send Reset Password Button
                    NYLDSelenium.Click("Send Profile Confirmation Email", SendProfileVerificationEmail);

                    //Verify Reset Password Confirmation
                    NYLDSelenium.PageLoad("Profile Confirmation", ProfileConfeader);

                    //Verify Reset Password Confirmation Body
                    NYLDSelenium.VerifyText("Profile Confirmation Text", "An email link to ReConfirm the customer's profile has been sent to the owner's email address currently on file. The email link is valid for 24 hours.", SuccessMsgConfBody.Text.Trim(), "yes");

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Email Verification LSP Notes and Email" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //Verify LSP Notes
                    DB.QueryLSPNotes("Email Verification");

                    //Verify Reset Password Email
                    //EmailVer.VerifyEmail("Email Verification", false);
                    //Emails verification
                    //OE.GetEmailsList("Email Verification");
                    //OE.GetEmailsList("Account Confirmation");
                    break;

                case "ApplyCyberFraudProtection":
                case "RemoveCyberFraudProtection":
                    IWebElement applyFlag;
                    string cyberAlertFlaggedMessage;
                    string param;
                    string action;
                    if (argslist[0].Trim() == "ApplyCyberFraudProtection")
                    {
                        applyFlag = ApplyCyberFraudPreventionButton;
                        param = " not ";
                        action = "Apply";
                    }
                    else
                    {
                        applyFlag = RemoveCyberFraudPreventionButton;
                        param = " ";
                        action = "Remove";
                    }

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify " + action + " Cyber Fraud Flag for Policy: " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //Success message 
                    cyberAlertFlaggedMessage = "An email alert has been sent to the Security Cyber Fraud Team.The customer will" + param + "be able to access their account online.";

                    //Click Apply Cyber Fraud Protection Button
                    NYLDSelenium.Click(action + " Cyber Fraud Protection Button", applyFlag);

                    //Verify if Add Cyber Flag Page Displays
                    NYLDSelenium.PageLoad(action + " Cyber Fraud Protection", CyberFraudWindow);

                    //Verify the content of the page
                    NYLDSelenium.VerifyText(action + " Cyber Fraud - ClientID", data[KeyRepository.ClientIdOfPolicy], NYLDSelenium.GetAttribute("Cyber Fraud ClientID", CyberFraudClientID));
                    NYLDSelenium.VerifyText(action + " Cyber Fraud - Full Name", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], NYLDSelenium.GetAttribute("Cyber Fraud Name", CyberFraudName));

                    // Click submit before entering notes & verify message
                    NYLDSelenium.Click(action + " Cyber Fraud - Set Cyber Fraud Flag", SetCyberFraudFlagButton);
                    NYLDSelenium.VerifyText("Error message for missing Notes entry", "The Notes field is required.", NYLDSelenium.GetAttribute("Error message for missing Notes entry", CyberFraudNotesError));

                    //Enter Notes
                    NYLDSelenium.Click(action + " Cyber Fraud - Notes", CyberFraudNotes);
                    NYLDSelenium.SendKeys(action + " Cyber Fraud - Notes", CyberFraudNotes, argslist[1].Trim());

                    //Click Apply or Remove Cyber Fraud Flag
                    NYLDSelenium.Click(action + " Cyber Fraud - Set Cyber Fraud Flag", SetCyberFraudFlagButton);

                    //verify Apply or Remove cyber flag confirmation message                    
                    NYLDSelenium.PageLoad("Confirmation message", ConfirmationMessage);
                    //data[KeyRepository.eventTriggertime = DateTime.Now.AddMinutes(-1);
                    CSWData.EventTriggerTime = DateTime.Now;          
                    
                   
                    //Verify CyberFraud Table and Cyber Fraud history table
                    if (argslist[0].Trim() == "ApplyCyberFraudProtection")
                    {
                        if (ConfirmationMessage.Text.Trim() == "An email alert was NOT sent to the Security Cyber Fraud Team.The customer will not be able to access their account online.")
                            NYLDSelenium.ReportStepResult("Cyber alert " + action + " flag confirmation", "Cyber alert " + action + " flag confirmation message is displayed", "PASS", "no");
                        else
                            NYLDSelenium.ReportStepResult("Cyber alert " + action + " flag confirmation", "Cyber alert " + action + " flag confirmation message is not displayed", "FAIL", "always","yes");


                        //verify policy entry in cyber fraud table
                        if (CyberFraudFlag = DB.QueryCyberFraudAlerts())
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in table after applying the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is found in the cyber fraud table", "PASS", "no");
                        else
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in table after applying the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is not found in the cyber fraud table", "FAIL", "no");

                        //verify policy entry in cyber fraud history table
                        if (!(CyberFraudFlag = DB.QueryCyberFraudHistory()))
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in history table after applying the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is not logged in the cyber fraud history table after applying cyber fraud flag", "PASS", "no");
                        else
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in history table after applying the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is logged in the cyber fraud history table for after applying cyber fraud flag", "FAIL", "no");
                    }
                    else
                    {
                        if (ConfirmationMessage.Text.Trim() == "An email alert was NOT sent to the Security Cyber Fraud Team.The customer will be able to access their account online.")
                            NYLDSelenium.ReportStepResult("Cyber alert " + action + " flag confirmation", "Cyber alert " + action + " flag confirmation message is displayed", "PASS", "no");
                        else
                            NYLDSelenium.ReportStepResult("Cyber alert " + action + " flag confirmation", "Cyber alert " + action + " flag confirmation message is not displayed", "FAIL", "no");


                        //verify policy entry in cyber fraud table
                        if (!(CyberFraudFlag = DB.QueryCyberFraudAlerts()))
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in table after removing the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is not found in the cyber entry fraud table", "PASS", "no");
                        else
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in table after removing the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is found in the cyber entry fraud table", "FAIL", "no");

                        //verify policy entry in cyber fraud history table
                        if (CyberFraudFlag = DB.QueryCyberFraudHistory())
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in history table after removing the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is logged in the cyber fraud history table after removing cyber fraud flag", "PASS", "no");
                        else
                            NYLDSelenium.ReportStepResult("Cyber fraud alert entry in history table after removing the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is not logged in the cyber fraud history table for after removing cyber fraud flag", "FAIL", "no");
                    }

                    //Verify LSP Notes
                    DB.QueryLSPNotes(argslist[0].Trim(), argslist[1].Trim());

                    //Verify Reset Password Email 
                    CSWData.TempVal = "";
                    if (argslist[0].Trim() == "ApplyCyberFraudProtection")
                        CSWData.TempVal = "SWO has Set Cyber Fraud Flag. " + argslist[1].Trim();
                    else
                        CSWData.TempVal = "SWO has Remove Cyber Fraud Flag. " + argslist[1].Trim();

                    //Emails verification
                    //CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
                    //OE.GetEmailsList("Cyber Fraud Alert");
                    CSWData.TempVal = "";
                    break;

                default:
                    break;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: createDeactivateCustEmailContent                                                           ////////////
        ////// Description: Create the expected content deactivation notficiation mail in the file path required ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void CreateDeactivateCustEmailContent(string reason)
        {
            string filespath = @"\\FS1\ProfilesRedirect\" + Environment.UserName.ToUpper() + @"\My Documents\AutomationSettings\CSWEmailVerification_" + Environment.MachineName + @"\";
            string deaccustemail = filespath + @"\DeactivatedCustomerNotification.txt";

            if (!Directory.Exists(filespath))
                Directory.CreateDirectory(filespath);

            if (File.Exists(deaccustemail))
                File.Delete(deaccustemail);
            File.Create(deaccustemail).Close();

            //Create Entry File
            using (StreamWriter sw = new StreamWriter(deaccustemail))
            {
                sw.WriteLine("Deactivate Message");
                sw.WriteLine("");
                sw.WriteLine("Email Address : " + data[KeyRepository.EmailId].ToLower());
                sw.WriteLine("Username : " + data[KeyRepository.UserName]);
                sw.WriteLine("Contract Number : " + data[KeyRepository.PolicyNumber]);
                sw.WriteLine("Deactivation Reason : " + reason);
                sw.WriteLine("Performed By : " + Environment.UserName);
                sw.WriteLine("");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyNoResults                                                                            ////////////
        ////// Description: verify PF screen when contract entered fetches no results                            ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void VerifyNoResults(string args, string datatype = "valid")
        {
            string polval;

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify No Results ContactInfoPageTitle" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

            Thread.Sleep(500);
            //Verify Page Load
            NYLDSelenium.PageLoad("No Results", SearchHeading);

            if (datatype == "invalid")
                polval = "";
            else
            {
                polval = data[KeyRepository.PolicyNumber];
                NYLDSelenium.VerifyText("No Results Message", "No results found for Contract Number : " + polval + ".", SearchBody.Text.Trim(), "yes");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: deactivateUser                                                                             ////////////
        ////// Description: Deactivate the registered user                                                       ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void DeactivateUser(string args)
        {
            //Launch Profile Maintenance URL
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Deactivate User" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            RestServices webServices = new RestServices(data);
            Thread.Sleep(8000);

            //Verify Page Load
            driver.Navigate().Refresh();
            //LaunchPF("");
            //NYLDSelenium.PageLoad("Profile Maintenance", PMHeader);

            ////Check the User Status
            //if (UserStatus.Text != "Deactivated")
            //{
            //    //Click Deactivate User button
            //    NYLDSelenium.Click("Deactivate Customer Button", DeactivateCustomer);

            //    //Select Deactivation Reason
            //    NYLDSelenium.SelectList("Deactivation Reason", DeactivateReason, "IncorrectProfileInformation");

            //    //Click Continue Deactivation
            //    NYLDSelenium.Click("Continue Deactivation", ContinueDeactivation);

            //    //Verify Deactivation Confirmation Message
            //    if ((NYLDSelenium.ElemExist("Confirmation Message", ConfirmationMessage) && (ConfirmationMessage.Text.Trim().Contains("not successful"))))
            //    {
            //        NYLDSelenium.ReportStepResult("Confirm Deactivation.", "Deactivation was not successful", "FAIL","always","yes");
            //        //Call WebService and cofirm User Status
            //        //if (webServices.SubmitRestCall("DeactivatedUser") == "yes")
         
            //        //else
            //        //    NYLDSelenium.ReportStepResult("Confirm Deactivation.", "Deactivation was not successful", "FAIL");
            //    }
            //    else
            //        NYLDSelenium.ReportStepResult("Confirm Deactivation.", "Deactivation was successful", "PASS");
            //}
            //else
            //    NYLDSelenium.ReportStepResult("Confirm Deactivation.", "User already deactivated", "FAIL");

            //ClosePF();
            //Close();
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getUserStatus                                                                              ////////////
        ////// Description: Get User status displayed in profile maintenance page by sending the contract number  //////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public string GetUserStatus()
        {
            NYLDSelenium.Clear("Contract Number", ContractNo);

            //Enter Contract Number
            NYLDSelenium.SendKeys("Contract Number", ContractNo, data[KeyRepository.PolicyNumber]);

            //Click Search Contract
            NYLDSelenium.Click("Contract Search", ContractSearch);

            if (NYLDSelenium.ElemExist("User Status", UserStatus, false,"no", "no"))
                return UserStatus.Text;
            else
                return "Not Found";
        }

        public void BtnClick(string element, Dictionary<string, string> data)
        {
            driver.FindElement(By.XPath(element)).Click();
        }
        /// <summary>
        /// Method to launch the browser with verify accound token
        /// </summary>
        /// <param name="eventtype"></param>
        public void LaunchBrowserwithToken(string eventtype)
        {
            RestServices restCall = new RestServices(data);
            string token;
            string stokenURL;
            string exptime;
            int waittime;

            Console.WriteLine("The wait time set to " + (data[KeyRepository.TokenWaitTime]));

            if (data[KeyRepository.TokenWaitTime] == "Expired")
            {
                exptime = "1";
                waittime = 90000;
            }
            else
            {
                exptime = "100";
                waittime = 0;
            }

            token = restCall.SubmitWSCall("GenerateToken", exptime);

            switch (eventtype)
            {

                case "Email Verification":
                    stokenURL = data[KeyRepository.URL] + "?action=newLogin&token=" + token;
                    break;

                case "Reset Password":
                    stokenURL = data[KeyRepository.URL] + "?action=reset3&token=" + token;
                    break;
                default:
                    stokenURL = data[KeyRepository.URL];
                    break; //
            }


            ////Launch Browser and navigate to token URL
            string currenthanlder = driver.CurrentWindowHandle;

            Thread.Sleep(waittime);

            //Set Trigger Time
            CSWData.EventTriggerTime = DateTime.Now;

            //Navigate to the New URL
            driver.Navigate().GoToUrl(stokenURL);
        }

    }
}

