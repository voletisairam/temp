﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using System.Threading;
using CSW.Common.Excel;

namespace CSW.PageObjects.External_Applications
{
    class FISPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public FISPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Home Page
        [FindsBy(How = How.Id, Using = "topBarNavLinkControl1")]
        public IWebElement InvoicesTab { get; set; }

        [FindsBy(How = How.Id, Using = "topBarNavLinkControl4")]
        public IWebElement ManageTab { get; set; }

        [FindsBy(How = How.Id, Using = "topBarNavLinkControl4")]
        public IWebElement PaymentsTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='top_bar_nav PayMyBills']//li[@id='topBarNavLink4']")]
        public IWebElement ProfileTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='ui-listview']//a[contains(text(),'User Information')]")]
        public IWebElement UserInformation { get; set; }
                
        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'.com')]")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2['Invoices']")]
        public IWebElement InvoicesPage { get; set; }



        //////////////////////////////////////////
        /////////    FIS Page Section    /////////
        //////////////////////////////////////////

        //FIS Enter Page Header
        [FindsBy(How = How.XPath, Using = "//*[@id='quickpay_workspace']/h2[contains(text(),'Authenticate Account')]")]
        public IWebElement FISEnterPageHeader { get; set; }

        //FIS Verfiy Page Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Verify Payment Information')]")]
        public IWebElement FISVerifyPageHeader { get; set; }

        //FIS Status Page Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Payment Request Submitted')]")]
        public IWebElement FISStatusPageHeader { get; set; }

        //FIS Failed Page Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Payment Failed')]")]
        public IWebElement FISFailedPageHeader { get; set; }

        //Account Information Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account Information')]")]
        public IWebElement AccountInformationHeader { get; set; }

        //Account Detail Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account detail')]")]
        public IWebElement AccountDetailHeader { get; set; }

        //Account Detail Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account detail')]/../../div[1]")]
        public IWebElement AccountDetailOutput { get; set; }

        //Account Detail Output 2
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account detail')]/../../div[2]")]
        public IWebElement AccountDetailOutput2 { get; set; }

        //Contract Group Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Contract/group')]")]
        public IWebElement ContractGroupHeader { get; set; }

        //Contract Group Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Contract/group')]/../../div[3]")]
        public IWebElement ContractGroupOutput { get; set; }

        //Contract Group Output 2
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Contract/group')]/../../div[2]")]
        public IWebElement ContractGroupOutput2 { get; set; }

        //Contract Information Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Contact Information')]")]
        public IWebElement ContactInformationHeader { get; set; }

        //First Name Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'First name')]")]
        public IWebElement FirstNameHeader { get; set; }

        //First Name Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'First name')]//..//input")]
        public IWebElement FirstNameInput { get; set; }

        //First Name Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'First name')]/../../div[2]")]
        public IWebElement FirstNameOutput { get; set; }

        //Middle Initial Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Middle initial')]")]
        public IWebElement MiddleInitialHeader { get; set; }

        //Middle Initial Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Middle initial')]//..//input")]
        public IWebElement MiddleInitialInput { get; set; }

        //Middle initial Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Middle initial')]/../../div[2]")]
        public IWebElement MiddleInitialOutput { get; set; }

        //Last Name Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Last name')]")]
        public IWebElement LastName2Header { get; set; }

        //Last Name Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Last name')]//..//input")]
        public IWebElement LastName2Input { get; set; }

        //Last Name Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Last name')]/../../div[2]")]
        public IWebElement LastName2Output { get; set; }

        //Email Address Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'E-mail address')]")]
        public IWebElement EmailAddressHeader { get; set; }

        //Email Address Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'E-mail address')]//..//input")]
        public IWebElement EmailAddressInput { get; set; }

        //Email Address Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'E-mail address')]/../../div[2]")]
        public IWebElement EmailAddressOutput { get; set; }

        //Retype Email Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Re-type e-mail address')]")]
        public IWebElement RetypeEmailHeader { get; set; }

        //Contract Information Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Re-type e-mail address')]//..//input")]
        public IWebElement RetypeEmailInput { get; set; }

        //Payment Information Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Payment Information')]")]
        public IWebElement PaymentInformationHeader { get; set; }

        //Payment Amount Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Payment amount')]")]
        public IWebElement PaymentAmountHeader { get; set; }

        //Payment Amount Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Payment amount')]//..//input")]
        public IWebElement PaymentAmountInput { get; set; }

        //Payment Amount Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Payment amount')]/../../div[2]")]
        public IWebElement PaymentAmountOutput { get; set; }

        //Method Of Payment Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Method of')]")]
        public IWebElement MethodOfPaymentHeader { get; set; }

        //Method Of Payment Input
        //[FindsBy(How = How.XPath, Using = "//*[contains(text(),'Method of')]//..//select")]
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentMethod-button']")]
        public IWebElement MethodOfPaymentInput { get; set; }

        //Method Of Payment Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Method of payment')]/../../div[2]")]
        public IWebElement MethodOfPaymentOutput { get; set; }

        //Pay On Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Pay on:')]")]
        public IWebElement PayOnHeader { get; set; }

        //Pay On Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Pay on:')]//..//input")]
        public IWebElement PayOnInput { get; set; }

        //Pay On Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Pay on:')]/../../div[2]")]
        public IWebElement PayOnOutput { get; set; }

        //Bank Account Type Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Bank account type')]")]
        public IWebElement BankAccountTypeHeader { get; set; }

        //Bank Account Type Input 
        //[FindsBy(How = How.XPath, Using = "//*[contains(text(),'Bank account type')]//..//select")]
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentMethodInfo.bankInfo.bankAccountType-button']")]
        public IWebElement BankAccountTypeInput { get; set; }

        //Bank Account Type Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Bank account type')]/../../div[2]")]
        public IWebElement BankAccountOutput { get; set; }

        //Personal Account Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Personal or business account')]")]
        public IWebElement PersonalAccountHeader { get; set; }

        //Personal Account Input
        //[FindsBy(How = How.XPath, Using = "//*[contains(text(),'Personal or business account')]//..//select")]
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentMethodInfo.bankInfo.achType-button']")]
        public IWebElement PersonalAccountInput { get; set; }

        //Personal Account Input
        //[FindsBy(How = How.XPath, Using = "//*[@id='paymentMethodInfo.bankInfo.achType']")]
        [FindsBy(How = How.XPath, Using = "//*[@id='paymentMethodInfo.bankInfo.achType']/option[2]")]
        public IWebElement PersonalAccountInput2 { get; set; }

        //Routing Number Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Routing number')]")]
        public IWebElement RoutingNumberHeader { get; set; }

        //Routing Number Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Routing number')]//..//input")]
        public IWebElement RoutingNumberInput { get; set; }

        //Routing Number Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Routing number')]/../../div[2]")]
        public IWebElement RoutingNumberOutput { get; set; }

        //Account Number Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account number')]")]
        public IWebElement AccountNumberHeader { get; set; }

        //Account Number Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account number')]//..//input")]
        public IWebElement AccountNumberInput { get; set; }

        //Account Number Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account number')]/../../div[2]")]
        public IWebElement AccountNumberOutput { get; set; }

        //Account Holder Name Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account holder name')]")]
        public IWebElement AccountHolderNameHeader { get; set; }

        //Account Holder Name Header 2
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account Holder Name')]")]
        public IWebElement AccountHolderNameHeader2 { get; set; }

        //Account Holder Name Input
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account holder name')]//..//input")]
        public IWebElement AccountHolderNameInput { get; set; }

        //Account Holder Name Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account holder name')]/../../div[2]")]
        public IWebElement AccountHolderNameOutput { get; set; }

        //Account Holder Name Output 2
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Account Holder Name')]/../../div[2]")]
        public IWebElement AccountHolderNameOutput2 { get; set; }

        //Bank Name Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Bank name')]")]
        public IWebElement BankNameHeader { get; set; }

        //Bank Name Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Bank name')]/../../div[2]")]
        public IWebElement BankNameOutput { get; set; }

        //Thank You Message
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Thank you!')]")]
        public IWebElement ThankYouMessage { get; set; }

        //Thank You Message
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Due to technical difficulties')]")]
        public IWebElement PaymentFailedMessage { get; set; }

        //Payment Details Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Payment Details')]")]
        public IWebElement PaymentDetailsHeader { get; set; }

        //Reference ID Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Reference ID')]")]
        public IWebElement ReferenceIDHeader { get; set; }

        //Reference ID Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Reference ID')]/../../div[2]")]
        public IWebElement ReferenceIDOutput { get; set; }

        //Date and Time Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Date and time')]")]
        public IWebElement DateAndTimeHeader { get; set; }

        //Date and Time Output
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Date and time')]/../../div[2]")]
        public IWebElement DateAndTimeOutput { get; set; }

        //FIS Terms and Conditions
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'I have read and agree')]")]
        public IWebElement FISTermsAndConditions { get; set; }

        //Submit Payment button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Submit Payment')]")]
        public IWebElement SubmitPaymentButton { get; set; }

        //Back Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Back')]")]
        public IWebElement BackButton { get; set; }

        //Exit Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Exit AARP Life Premium Pay')]")]
        public IWebElement ExitButton { get; set; }

        // Failure Message
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'We are sorry. We could not authenticate your information.')]")]
        public IWebElement failureMessage { get; set; }

        // Data Mismatch
        [FindsBy(How = How.XPath, Using = " //*[contains(text(),'There are no invoices per the selection criteria')]")]
        public IWebElement dataMismatch { get; set; }
       

        /// <summary>
        /// Method helps to Veify the FIS landing page
        /// </summary>
        public void NavigateToUserInformation()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Navigate to FIS application" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            try
            {
                CommonFunctions.WindowsTabFocus("NavigateNewTab", "Invoices");
                NYLDSelenium.Click("Profile Tab", ProfileTab,true,"always");
                NYLDSelenium.Click("User Information", UserInformation,true,"always");
                NYLDSelenium.ReportStepResult("Navigate to FIS-UserInformation", "", "PASS");
            }
            catch(Exception e)
            {
                NYLDSelenium.ReportStepResult("Navigate to FIS-UserInformation", "", "FAIL");
                Console.WriteLine(e.ToString());
            }
        }

        public void VerifyEmailAddress()
        {
          
            NYLDSelenium.VerifyText("Email address", data[KeyRepository.EmailId], NYLDSelenium.GetAttribute("Email address", EmailAddress),"always","always");                        
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: FISPages                                                                                   ////////////
        ////// Description: Verify all 3 FIS  pages                                                             ////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void FISPages()
        {
            VerifyFISEnterPage();  //TOD: Raj 2023 This was a workaround when FIS page was not filly displayed
                                   // VerifyFISVerifyPage();
                                   //  VerifyFISStatusPage();
        }

        //TODO: Raj 2023 Need to check if we still able to access FIS Page (Note : FIS Page will be displayed for specific set of Contracts which are already shared to FIS group)

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyFISEnterPage                                                                         ////////////
        ////// Description: Verify FIS Enter page                                                               ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void VerifyFISEnterPage()
        {
            //Verify Page Load - According to QA Verifying is this page is loaded is enough.
            NYLDSelenium.PageLoad("FIS Enter", FISEnterPageHeader);

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyFISEnterPage                                                                         ////////////
        ////// Description: Verify FIS Enter page                                                               ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void VerifyFISPage(string args)
        {
            //Verify Page Load - According to QA Verifying is this page is loaded is enough.
            NYLDSelenium.PageLoad("FIS Page", InvoicesPage);

            if (args == "FailureMessage")
            {
                NYLDSelenium.VerifyText("No Invoices failure Message", "We are sorry. We could not authenticate your information. Please provide the correct information and try again or contact us for help.", 
                    NYLDSelenium.GetAttribute("Failure Message", failureMessage));
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyLSPErrorMessage                                                                     ////////////
        ////// Description: Verify LSP Data Mismatch Error Message                                             ////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////       
        public void VerifyLSPErrorMessage(string args)
        {
            
            NYLDSelenium.PageLoad("LSP Data Mismatch", InvoicesPage);

            if (args == "VerifyFISPage")
            {
                NYLDSelenium.VerifyText("LSP Data Error Messag", "We are sorry. We could not authenticate your information. Please provide the correct information and try again or contact us for help.", 
                    NYLDSelenium.GetAttribute("LSP Data Error Message", failureMessage));
            }
        }


        //TODO: Raj 2023 Need to check if we still able to access FIS Page (Note : FIS Page will be displayed for specific set of Contracts which are already shared to FIS group)

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyFISVerifyPage                                                                        ////////////
        ////// Description: Verify FIS Verify Page                                                              ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////          
        public void VerifyFISPageFieldsVerification()
        {
            string date = (DateTime.Now).ToString("MM/dd/yyyy");
            NavigateToUserInformation();
            //Verify Page Load
            NYLDSelenium.PageLoad("FIS Verify", FISVerifyPageHeader);

            // Need to check with Raj
            //NYLDSelenium.PageLoad("FIS Page", InvoicesPage);

            //Account Information section
            NYLDSelenium.VerifyText("Account Information header", "Account Information", NYLDSelenium.GetAttribute("Account Information header", AccountInformationHeader));
            NYLDSelenium.VerifyText("Account detail header", "Account detail:", NYLDSelenium.GetAttribute("Account detail header", AccountDetailHeader));
            NYLDSelenium.VerifyText("Account detail output", "Welcome " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + "!", NYLDSelenium.GetAttribute("Account detail output", AccountDetailOutput2));
            NYLDSelenium.VerifyText("Contract/group header", "Contract/group:", NYLDSelenium.GetAttribute("Contract/group header", ContractGroupHeader));
            NYLDSelenium.VerifyText("Contract/group output", data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract/group output", ContractGroupOutput2));

            //Contact Information section
            NYLDSelenium.VerifyText("Contact Information header", "Contact Information", NYLDSelenium.GetAttribute("Contact Information header", ContactInformationHeader));
            NYLDSelenium.VerifyText("First name header", "First name:", NYLDSelenium.GetAttribute("First name header", FirstNameHeader));
            NYLDSelenium.VerifyText("First name output", data[KeyRepository.FirstName], NYLDSelenium.GetAttribute("First name output", FirstNameOutput));
            NYLDSelenium.VerifyText("Middle initial header", "Middle initial:", NYLDSelenium.GetAttribute("Middle initial header", MiddleInitialHeader));
            NYLDSelenium.VerifyText("Middle initial output", data[KeyRepository.MiddleName], NYLDSelenium.GetAttribute("Middle initial output", MiddleInitialOutput));
            NYLDSelenium.VerifyText("Last name header", "Last name:", NYLDSelenium.GetAttribute("Last name header", LastName2Header));
            NYLDSelenium.VerifyText("Last name output", data[KeyRepository.LastName], NYLDSelenium.GetAttribute("Last name output", LastName2Output));
            NYLDSelenium.VerifyText("Email address header", "E-mail address:", NYLDSelenium.GetAttribute("Email address header", EmailAddressHeader));
            NYLDSelenium.VerifyText("Email address output", data[KeyRepository.EmailId], NYLDSelenium.GetAttribute("Email address output", EmailAddressOutput));

            //Payment Information section
            NYLDSelenium.VerifyText("Payment Information header", "Payment Information", NYLDSelenium.GetAttribute("Payment Information header", PaymentInformationHeader));
            NYLDSelenium.VerifyText("Contract/group output", data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract/group output", ContractGroupOutput2).Replace("Contract/group:\r\n", ""));
            NYLDSelenium.VerifyText("Pay on header", "Pay on:", NYLDSelenium.GetAttribute("Pay on header", PayOnHeader));
            NYLDSelenium.VerifyText("Pay on output", date, NYLDSelenium.GetAttribute("Pay on output", PayOnOutput));
            NYLDSelenium.VerifyText("Payment amount header", "Payment amount:", NYLDSelenium.GetAttribute("Payment amount header", PaymentAmountHeader));
            NYLDSelenium.VerifyText("Payment amount output", "$" + data[KeyRepository.FISPremium], NYLDSelenium.GetAttribute("Payment amount output", PaymentAmountOutput));
            NYLDSelenium.VerifyText("Method of payment header", "Method of payment:", NYLDSelenium.GetAttribute("Method of payment header", MethodOfPaymentHeader));
            NYLDSelenium.VerifyText("Method of payment output", "Bank Account", NYLDSelenium.GetAttribute("Method of payment output", MethodOfPaymentOutput));
            NYLDSelenium.VerifyText("Bank account type header", "Bank account type:", NYLDSelenium.GetAttribute("Bank account type header", BankAccountTypeHeader));
            NYLDSelenium.VerifyText("Account holder name header", "Account holder name:", NYLDSelenium.GetAttribute("Account holder name header", AccountHolderNameHeader));
            NYLDSelenium.VerifyText("Account holder name output", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], NYLDSelenium.GetAttribute("Account holder name output", AccountHolderNameOutput));
            NYLDSelenium.VerifyText("Routing number header", "Routing number:", NYLDSelenium.GetAttribute("Routing number header", RoutingNumberHeader));
            NYLDSelenium.VerifyText("Account number header", "Account number:", NYLDSelenium.GetAttribute("Account number header", AccountNumberHeader));
            NYLDSelenium.VerifyText("Bank name header", "Bank name:", NYLDSelenium.GetAttribute("Bank name header", BankNameHeader));

            //Terms and Conditions
            NYLDSelenium.ElemExist("FIS Terms and Conditions", FISTermsAndConditions);
            NYLDSelenium.ElemExist("Submit Payment", SubmitPaymentButton);
            NYLDSelenium.ElemExist("Back", BackButton);
            NYLDSelenium.ElemExist("Exit AARP Life Premium Pay", ExitButton);

            NYLDSelenium.Click("FIS Terms and Conditions", FISTermsAndConditions);
            NYLDSelenium.Click("Submit Payment", SubmitPaymentButton);
        }




        //TODO: Raj 2023 Need to check if we still able to access FIS Page (Note : FIS Page will be displayed for specific set of Contracts which are already shared to FIS group)

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyFISStatusPage                                                                        ////////////
        ////// Description: Verify FIS Status Page                                                              ////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyFISStatusPage()
        {
            string date = (DateTime.Now).ToString("MM/dd/yyyy");

            if (NYLDSelenium.ElemExist("Payment failed", FISFailedPageHeader, false,"no","no","no"))
            {
                //Verify Page Load
                NYLDSelenium.PageLoad("FIS Payment Failed", FISFailedPageHeader);

                NYLDSelenium.VerifyText("Payment failed message", "Due to technical difficultiesm, the following payment cannot be confirmed at this time.PLEASE DO NOT RETRY THIS PAYMENT.", NYLDSelenium.GetAttribute("Thank you message", PaymentFailedMessage).Replace("\r\n", ""));
            }
            else
            {
                //Verify Page Load
                NYLDSelenium.PageLoad("FIS Status", FISStatusPageHeader);

                NYLDSelenium.VerifyText("Thank you message", "Thank you! The payment request below has been submitted. Please print this page or make a note of the Reference ID.", NYLDSelenium.GetAttribute("Thank you message", ThankYouMessage));
            }

            //Payment Details section
            NYLDSelenium.VerifyText("Payment Details header", "Payment Details", NYLDSelenium.GetAttribute("Payment Details header", PaymentDetailsHeader));
            NYLDSelenium.VerifyText("Reference ID header", "Reference ID:", NYLDSelenium.GetAttribute("Reference ID header", ReferenceIDHeader));
            NYLDSelenium.VerifyText("Date and time header", "Date and time:", NYLDSelenium.GetAttribute("Date and time header", DateAndTimeHeader));
            NYLDSelenium.VerifyText("Date and time output", date, NYLDSelenium.GetAttribute("Date and time output", DateAndTimeOutput).Split(' ').First());
            NYLDSelenium.VerifyText("Contract/group header", "Contract/group:", NYLDSelenium.GetAttribute("Contract/group header", ContractGroupHeader));
            NYLDSelenium.VerifyText("Contract/group output", data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract/group output", ContractGroupOutput2));
            NYLDSelenium.VerifyText("Pay on header", "Pay on:", NYLDSelenium.GetAttribute("Pay on header", PayOnHeader));
            NYLDSelenium.VerifyText("Pay on output", date, NYLDSelenium.GetAttribute("Pay on output", PayOnOutput));
            NYLDSelenium.VerifyText("Account holder name header", "Account Holder Name:", NYLDSelenium.GetAttribute("Account holder name header", AccountHolderNameHeader2));
            NYLDSelenium.VerifyText("Account holder name output", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], NYLDSelenium.GetAttribute("Account holder name output", AccountHolderNameOutput2));
            NYLDSelenium.VerifyText("Email address header", "E-mail address:", NYLDSelenium.GetAttribute("Email address header", EmailAddressHeader));
            NYLDSelenium.VerifyText("Email address output", data[KeyRepository.EmailId], NYLDSelenium.GetAttribute("Email address output", EmailAddressOutput));
            NYLDSelenium.VerifyText("Method of payment header", "Method of payment:", NYLDSelenium.GetAttribute("Method of payment header", MethodOfPaymentHeader));
            NYLDSelenium.VerifyText("Payment amount header", "Payment amount:", NYLDSelenium.GetAttribute("Payment amount header", PaymentAmountHeader));
            NYLDSelenium.VerifyText("Payment amount output", "$" + data[KeyRepository.FISPremium], NYLDSelenium.GetAttribute("Payment amount output", PaymentAmountOutput));

            NYLDSelenium.ElemExist("Exit AARP Life Premium Pay", ExitButton);

            NYLDSelenium.Click("Exit AARP Life Premium Pay", ExitButton);
        }









    }
}
