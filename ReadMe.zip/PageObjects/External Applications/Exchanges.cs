﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Functions;
using CSW.PageObjects.Login;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using Spire.Pdf.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace CSW.PageObjects.External_Applications
{
    //ToDO: This is not external app, please create a folder named Riders_Exchanges and move it there
    class Exchanges
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public Exchanges(IWebDriver webDriver, Dictionary<string, string> data)
        {
            this.driver = webDriver;
            this.data = data;
            PageFactory.InitElements(webDriver, this);
        }

        [FindsBy(How = How.XPath, Using = "//section[@class='exchanges-hero']//*[contains(text(), 'term to permanent')]")]
        public IWebElement ExchangeEligibilityPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@data-ea-zone, 'Exchange') and contains(text(), 'eligible')]")]
        public IWebElement EligibilityLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//form[contains(@action, Exchange/Result) and (@class='offer-form')]")]
        public IWebElement ExchangeForm { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name='SelectedOffer']/../div")]
        public IList<IWebElement> ExchangeOffers { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name='SelectedOffer']/..")]
        public IList<IWebElement> ExchangePremiums { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@type='submit' and contains(text(), 'Exchange now')]")]
        public IWebElement GetStarted { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Review and submit')]")]
        public IWebElement ReviewAndSubmitPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(), 'Current term')]/following-sibling::div/strong")]
        public IWebElement Coverage_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@name, 'SelectedCoverage')]/../label/strong")]
        public IList<IWebElement> Exchanges_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id, 'read-and-sign')]/..")]
        public IWebElement ReadAndSign_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Sign & confirm')]")]
        public IWebElement Submit_Certified { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Thank you')]")]
        public IWebElement ThankYouHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'Apply/Exchange') and contains(text(), 'Download')]")]
        public IWebElement ApplicationPDFLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Call New York')]/..")]
        public IWebElement CallNewYorkLife_Text { get; set; }

        /// <summary>
        /// Method to check if the contract of exchange is eligible
        /// </summary>
        /// <param name="args"></param>
        public void CheckEligibility_Exchange(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Launch Exchange Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            int startCounter = GetSettor.failCounter;
            TestData testData = new TestData();
            string[] urlDetails = null;
            string type = "";

            //Fetch Exchange Url
            if (args == "")
            {
                urlDetails = testData.GetEnvionmentDetails("Findability").Split(';');
                type = "Findability";
            }
            else
            {
                urlDetails = testData.GetEnvionmentDetails("Email URL").Split(';');
                type = "Email Link";
            }
            string url = urlDetails[1];

            //Print Header
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Launch Exchange Page - " + type + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Build URL
            BuildUrl(url, type);

            //Launch URL
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            //driver.Navigate().GoToUrl("https://qa4.nylaarp.com/Life-Insurance/Exchange");

            //Term Exchange page displayed
            NYLDSelenium.PageLoad("Term Exchange", ExchangeEligibilityPage);

            //Click on Eligibility Link

            NYLDSelenium.Click("Click on Eligibility", EligibilityLink);

            //Publish report
            int endcounter = GetSettor.failCounter;
            if (startCounter == endcounter)
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Exchange Page Launch Was successful" + "</h3>", "<h3 style=\"color:Green\">" + "Exchange Page Launch Was successful" + "</h3>", "Pass", "yes");
                LSPDatabase DB = new LSPDatabase(driver, data);
                DB.GetLSPDate();
                DB.QueryPolicyNumber();
                DB.QueryPolicyDetails();
                //    UserRegistration registration = new UserRegistration(driver, data);
                //   registration.RegisterUser("");
            }
        }

        /// <summary>
        /// Method to Build the URl for email link
        /// </summary>
        /// <param name="url"></param>
        /// <param name="type"></param>
        public void BuildUrl(string url, string type)
        {
            RestServices restService = new RestServices(data);
            LSPDatabase lspDatabase = new LSPDatabase(driver, data);

            List<string> offersList = new List<string>();
            string offers = "";

            //Get control Number
            lspDatabase.QueryControlNumber();

            //Build URL
            //data[KeyRepository.URL] = data[KeyRepository.URL].Replace("/Account/Login", "") + url.Replace("{channel}", data[KeyRepository.ContractType]);
            data[KeyRepository.URL] = data[KeyRepository.URL].Replace("/Account/Login", "").Replace("/login", "") + url.Replace("{channel}", data[KeyRepository.ContractType]);

            if (type == "Email Link")
            {
                //Get Offers listed
                restService.GetOffersAPI("Exchange");

                //Build url with Channel, State an First Name
                data[KeyRepository.URL] = data[KeyRepository.URL].Replace("{p1}", data[KeyRepository.State]).Replace("{p2}", data[KeyRepository.FirstName]);

                //Replace coverage and premium information
                string frequency = "", coverage = "";

                //Derive Frequency
                if (data[KeyRepository.CurrentPaymentFrequency] == "Q")
                    frequency = "quarter";
                else if (data[KeyRepository.CurrentPaymentFrequency] == "M")
                    frequency = "month";
                else if (data[KeyRepository.CurrentPaymentFrequency] == "S")
                    frequency = "semiannual";
                else if (data[KeyRepository.CurrentPaymentFrequency] == "A")
                    frequency = "annual";

                //Derive coverage
                coverage = (Convert.ToDouble(data[KeyRepository.CoverageAmount]) / 1000).ToString();

                data[KeyRepository.URL] = data[KeyRepository.URL].Replace("{p3}", coverage + "%2C000").Replace("{p4}", data[KeyRepository.Premium]).Replace("{p5}", "per%20" + frequency);

                //Derive coverage and Premium for offers
                foreach (List<string> ls in CSWData.RiderInfo)
                {
                    string placeValue = "000";
                    string formatCoverage = (Convert.ToDouble(ls[1]) / 1000).ToString();
                    if (formatCoverage.Contains("."))
                        placeValue = formatCoverage.Split('.')[1].PadRight(3, '0');
                    string offerCoverage = "%24" + formatCoverage.Split('.')[0] + "%2C" + placeValue;
                    string offerPremium = "%24" + ls[0];

                    offersList.Add(offerCoverage + ":" + offerPremium);
                }
                offers = String.Join("|", offersList);

                //Build Url with offers
                data[KeyRepository.URL] = data[KeyRepository.URL].Replace("{offers}", offers).Replace("{p6}", data[KeyRepository.ControlNumber]);
            }
        }

        /// <summary>
        /// Method to veriy offers displayed
        /// </summary>
        /// <param name="args"></param>
        public void VerifyOffers(String args = "")
        {
            CSW.Common.Services.RestServices restService = new CSW.Common.Services.RestServices(data);
            NYLDSelenium.AddHeader("Verify Offers displayed", "SubHeader");
            bool offerFound = false;
            List<string> exchangeCoverageAmount = new List<string>();
            List<string> exchangePremiums = new List<string>();

            restService.GetOffersAPI(args);

            int currentCoverageAmount = Convert.ToInt32(data[KeyRepository.CoverageAmount]);
            double currentPremium = Convert.ToDouble(data[KeyRepository.Premium]);

            //Verify current Coverage and Premium
            //NYLDSelenium.VerifyText("Current Coverage", data[KeyRepository.CoverageAmount], CurrentRiderCoverage.Text.Replace("$", "").Replace(",", "").Trim());
            // NYLDSelenium.VerifyText("Current Premium", data[KeyRepository.Premium] + " per month", CurrentRiderPremium.Text.Replace("$", "").Trim());

            //Report mismatgch in Exchange offer counts     
            if (ExchangeOffers.Count == 0)
                NYLDSelenium.ReportStepResult("Verify Exchange Offers", "No exchange offers displayed in the UI", "Fail");
            else if (ExchangeOffers.Count != CSWData.RiderInfo.Count() || ExchangeOffers.Count == 0)
                NYLDSelenium.ReportStepResult("Verify Exchange Offers", "There is mismatch in the expected and actual offers count. <br> Expected Offers: " + CSWData.RiderInfo.Count() + "<br> Actual Offers: " + ExchangeOffers.Count, "Fail");

            //Collect the Exchange offers
            foreach (List<string> offer in CSWData.RiderInfo)
            {
                exchangePremiums.Add(String.Format("{0:0.00}", offer[1]));
                exchangeCoverageAmount.Add(offer[0].Split('.')[0]);
            }

            //verify Offers
            for (int j = 0; j < ExchangeOffers.Count; j++)
            {
                string actualOffer = ExchangeOffers[j].Text.Replace("$", "").Replace(",", "").Trim();
                string actualPremium = "$" + ExchangePremiums[j].Text.Split('$')[2].Replace("per month", "").TrimEnd('1').Trim();

                offerFound = false;
                for (int i = 0; i < exchangeCoverageAmount.Count; i++)
                {
                    if (actualOffer == exchangeCoverageAmount[i])
                    {
                        if (!actualPremium.Contains(exchangePremiums[i]))
                            NYLDSelenium.ReportStepResult("Exchange offer Premium displayed for Coverage - " + exchangeCoverageAmount[i] + " is not as expected.", "Expected Premium - " + exchangePremiums[i], "Fail");
                        offerFound = true;
                        break;
                    }
                    else if (i == exchangeCoverageAmount.Count - 1 && !offerFound)
                        NYLDSelenium.ReportStepResult("Exchange offer could not be found", "Term Exchange offer - " + actualOffer + " could not be found", "Fail");
                }
            }
            NYLDSelenium.AddHeader("Verify Offers displayed", "Success");
        }

        /// <summary>
        /// Method to select the required offer
        /// </summary>
        /// <param name="args"></param>
        public void SelectOffer(string args = "")
        {
            NYLDSelenium.AddHeader("Select the Offer", "SubHeader");

            LoginPage Login = new LoginPage(driver, data);


            //Collect the Coverage Amount and Premium from Banner
            string coverage = ExchangeOffers[0].Text.Replace("$", "").Replace(",", "");

            //data[KeyRepository.DeltaCoverage] = (Convert.ToInt32(coverage) - Convert.ToInt32(data[KeyRepository.CoverageAmount])).ToString().Replace("-", "");
            data[KeyRepository.CoverageAmount] = coverage;
            string premium = ExchangePremiums[0].Text.Replace("for just", "").Replace("per month", "").Replace("$", "").Replace("1", "").Trim();
            premium = premium.Replace("Keep the same amount of coverage you currently have.\r\n0,000\r\n", "").Trim();
            data[KeyRepository.Premium] = premium;

            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", Login.CloseMockBanner, false, "no", "no"))
                NYLDSelenium.Click("Mock banner", Login.CloseMockBanner);

            //Select Offer
            //NYLDSelenium.ScrollToView( ExchangeOffers[0]);
            NYLDSelenium.Click("Select Offer", ExchangePremiums[0]);

            //Click on Get started
            NYLDSelenium.Click("Get Started", GetStarted);
            NYLDSelenium.AddHeader("Select the Offer", "Success");
        }


        /// <summary>
        /// Method to verify the entered details in review and confirm screen
        /// </summary>
        public void ReviewAndConfirmExchange()
        {
            TestData testData = new TestData();
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Review and confirmation screen" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            NYLDSelenium.AddHeader("Verify Review and confirmation screen", "SubHeader");

            CommonFunctions cmmonFunctions = new CommonFunctions(data);

            //Verify Call Newyork life text
            string expectedContactText = new TestData().GetContent("CallNYL_Exchange");
            string actualContactText = CallNewYorkLife_Text.Text.Replace("\r\n", " ");
            NYLDSelenium.VerifyText("Call New york Life Info", expectedContactText, actualContactText);

            //Verify Generic information
            //cmmonFunctions.GetAddress();
            string[] generalInformation = { "First name", "Last name", "Address", "City", "State", "Zip", "Certificate number" };
            string[] expected_GeneralInfo = { data[KeyRepository.FirstName], data[KeyRepository.LastName], data[KeyRepository.AddressLine1], data[KeyRepository.City], data[KeyRepository.State], data[KeyRepository.Zip], data[KeyRepository.PolicyNumber] };

            for (int i = 0; i < generalInformation.Count(); i++)
            {
                string xpath = "//div[contains(text(), '" + generalInformation[i] + "')]/following-sibling::div";
                string actualInformation = NYLDSelenium.GetWE(xpath).Text.Replace("\r\n", " ").Replace("(", "").Replace(")", "").Trim();

                if (generalInformation[i] == "Date of birth")
                    actualInformation = actualInformation.Replace("0", "");
                if (generalInformation[i] == "Phone number")
                    actualInformation = actualInformation.Replace(" ", "");

                if (expected_GeneralInfo[i] != actualInformation)
                    NYLDSelenium.ReportStepResult("Mismatch in General Information section - " + generalInformation[i], "Expected: " + expected_GeneralInfo[i] + " \n Actual: " + actualInformation, "Fail");
            }
            NYLDSelenium.AddHeader("Verify Review and confirmation screen", "Success");
            NYLDSelenium.AddHeader("Verify Coverage Section", "SubHeader");

            //Verify Coverage
            string actualCoverage = NYLDSelenium.GetAttribute("Coverage", Coverage_Review).Trim();
            NYLDSelenium.VerifyText("Delta Coverage", data[KeyRepository.CoverageAmount], actualCoverage.Replace("$", "").Replace(",", "").Trim());

            int j = 0;
            //Verify Exchanges
            foreach (IWebElement exchange in Exchanges_Review)
            {

                IList<IWebElement> inputElements = driver.FindElements(By.XPath("//input[@name='SelectedCoverage' and @type='radio']"));
                string actualExchange = exchange.Text.Replace(",", "").Replace(".00", ".0").Trim();
                string expectedExchange = "";
                for (int i = 0; i < CSWData.RiderInfo.Count; i++)
                {
                    expectedExchange = "$" + CSWData.RiderInfo[i][1].Split('.')[0].Trim() + " for " + "$" + CSWData.RiderInfo[i][0] + " per month";

                    if (expectedExchange != actualExchange && i == CSWData.RiderInfo.Count)
                        NYLDSelenium.ReportStepResult("Exchange not found in the list", "'" + expectedExchange + "' Exchange not found in the list", "yes", "Fail");
                    else if (expectedExchange == actualExchange)
                    {
                        try
                        {
                            bool check = inputElements[j].Selected;
                        }
                        catch
                        {

                        }
                        if (actualExchange.Contains(data[KeyRepository.CoverageAmount]))
                        {
                            if (!inputElements[j].Selected)
                                NYLDSelenium.ReportStepResult("Exchange option is not selected", "Exchange with coverage of " + data[KeyRepository.CoverageAmount] + "  is not selected", "Fail");
                        }
                        j++;
                        break;
                    }
                }
            }

            NYLDSelenium.AddHeader("Verify Coverage Section", "Success");

            NYLDSelenium.AddHeader("Verify Read and Sign Text", "SubHeader");

            //Reading PDF Boundaries 
            int row = 2;
            string PleaseRead = "";
            do
            {
                data[KeyRepository.TemplateType] = "3540-01";
                string ch = data[KeyRepository.TemplateType];
                string ch2 = testData.GetPDFContent(row, 5);

                if (ch2.Trim() == ch.Trim())
                {
                    PleaseRead = testData.GetPDFContent(row, 6);
                    break;
                }

                row = row + 1;

            } while (testData.GetPDFContent(row, 1) != "");

            //Verify Please read
            string expectedPleaseReadFrontP1 = NYLDSelenium.GetAttribute("Get first paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/p[1]"), "text");
            string expectedPleaseReadFrontP2 = NYLDSelenium.GetAttribute("Get second paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/p[2]"), "text");
            string expectedPleaseReadFrontP3 = NYLDSelenium.GetAttribute("Get third paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/p[3]"), "text");
            string expectedPleaseReadFrontP4 = NYLDSelenium.GetAttribute("Get fourth paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/p[4]"), "text");
            string expectedPleaseReadFrontP5 = NYLDSelenium.GetAttribute("Get fifth paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/p[5]"), "text");
            string expectedPleaseReadFrontP5L1 = NYLDSelenium.GetAttribute("Get fifth first paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/ol[1]/li[1]"), "text");
            string expectedPleaseReadFrontP5L2 = NYLDSelenium.GetAttribute("Get fifth second paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/ol[1]/li[2]"), "text");
            string expectedPleaseReadFrontP6 = NYLDSelenium.GetAttribute("Get sixth paragraph", NYLDSelenium.GetWE("//div[@class='text-steel']/p[6]"), "text");

            string expectedPleaseRead = expectedPleaseReadFrontP1 + expectedPleaseReadFrontP2 + expectedPleaseReadFrontP3 + expectedPleaseReadFrontP4 + expectedPleaseReadFrontP5 + expectedPleaseReadFrontP5L1 + expectedPleaseReadFrontP5L2 + expectedPleaseReadFrontP6;
            expectedPleaseRead = expectedPleaseRead.Replace(" ", "").Replace("\"", "");
            PleaseRead = PleaseRead.Replace(" ", "").Replace("\"", "").Replace("\n", "");
            NYLDSelenium.VerifyText("Read and Sign Text", PleaseRead, expectedPleaseRead);
            NYLDSelenium.AddHeader("Verify Read and Sign Text", "Success");
            //Agree Terms
            CSWData.EventTriggerTime = DateTime.Now;
            NYLDSelenium.Click("Read and Sign", ReadAndSign_Review);

            //Sign and Confirm
            NYLDSelenium.Click("Sign and Confirm", Submit_Certified);

            NYLDSelenium.AddHeader("Verify Exchange review Form", "Success");
        }

        /// <summary>
        /// Method to verify Thank you page of E sig
        /// </summary>
        /// <param name="args"></param>
        public void VerifyThankYouPage(string args)
        {
            MIDatabase midb = new MIDatabase(data);
            LSPDatabase lspdatabase = new LSPDatabase(driver, data);

            //Print Header            
            NYLDSelenium.AddHeader("Verify Thank You page for the Exchange submission", "SubHeader");
            //Precautionary wait for page components to load
            Thread.Sleep(10000);

            //Thank you page
            NYLDSelenium.PageLoad("Esig Thank you", ThankYouHeader);

            //Get expected results from datasheet based on result column in scenario sheet
            NYLDSelenium.VerifyText("E sig Thank you header", "Thank you! Your Exchange has been received.", ThankYouHeader.Text);

            //Publish report
            NYLDSelenium.AddHeader("Verify Thank you page for Exchange submission", "Success");

        }


        /// <summary>
        /// Method to verify PDF downloaded after submitting Exchange form
        /// </summary>
        public void VerifyEsigApplicationPDF(string type)
        {

            //PDF validation      
            CommonFunctions commonfunctions = new CommonFunctions(data);
            ValidatePDF validatePdf = new ValidatePDF(driver, data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Download PDF" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Delete Existing file
            string filePath = @"C:\Users\" + Environment.UserName + @"\Downloads";
            NYLDGeneric.DeleteFiles(filePath, "ExchangeApp*");
            //data[KeyRepository.TemplateType] = "3111-01-VT";

            //Click download pdf link
            //commonPageObjfunctions.ScrollToViewElement("//a[contains(text(),'What you need')]");
            //NYLDSelenium.ScrollToView(ApplicationPDFLink);

            NYLDSelenium.Click("Download PDF Link", ApplicationPDFLink);
            System.Threading.Thread.Sleep(10000);

            //Print the Template type
            NYLDSelenium.ReportStepResult("Esig PDF: Control Number Validation", "Template type of PDF is: " + data[KeyRepository.TemplateType], "INFO", "no");
        }
    }
}
