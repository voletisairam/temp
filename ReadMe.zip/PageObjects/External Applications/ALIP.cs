﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using System.Threading;
using CSW.Common.Excel;

namespace CSW.PageObjects.External_Applications
{
    class ALIP
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ALIP(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //Login Page
        [FindsBy(How = How.Name, Using = "login")]
        public IWebElement LoginPage { get; set; }

        [FindsBy(How = How.Name, Using = "username")]
        public IWebElement UserName { get; set; }

        [FindsBy(How = How.Name, Using = "password")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Name, Using = "login")]
        public IWebElement Submit { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Welcome']")]
        public IWebElement HomrPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Integration History Search']")]
        public IWebElement IntegrationHistorySearchPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text()='Welcome']")]
        public IWebElement HomePage { get; set; }

        [FindsBy(How = How.Name, Using = "integrationType")]
        public IWebElement IntegrationType { get; set; }

        [FindsBy(How = How.Id, Using = "externalId")]
        public IWebElement ExternalID { get; set; }

        [FindsBy(How = How.Id, Using = "referenceId")]
        public IWebElement ReferenceID { get; set; }

        [FindsBy(How = How.Id, Using = "searchBtn")]
        public IWebElement Search { get; set; }

        [FindsBy(How = How.XPath, Using = "//tbody[@class='ui-table-tbody']")]
        public IWebElement ResultsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//tbody[@class='ui-table-tbody']/tr/td")]
        public IWebElement NoResults { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[text() = 'Quick Search']")]
        public IWebElement QuickSearch { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@id='logOffButton']")]
        public IWebElement LogOffButton { get; set; }

        //Search

        [FindsBy(How = How.Id, Using = "searchType")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "searchMode")]
        public IWebElement SubSearchType { get; set; }

        [FindsBy(How = How.Name, Using = "searchText")]
        public IWebElement SearchTextBox { get; set; }

        [FindsBy(How = How.Id, Using = "search")]
        public IWebElement SearchButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Additional Criteria')]")]
        public IWebElement AdditionalCriteriaHeader { get; set; }


        [FindsBy(How = How.Id, Using = "submenu_308_application_summary")]
        public IWebElement ApplicationSummary { get; set; }
        
        //CaseWork Bench

        [FindsBy(How = How.XPath, Using = "//div[@role='tab' and @id='decisionSupport-header']")]
        public IWebElement DecisionFactor { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@role='tabpanel']//div[@role='tab' and @class='card-header' and contains(@id,'topic-')]//span[contains(text(),'Interview')]/parent::button")]
        public IWebElement DecisionFactor_InterviewRequired { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[text()='View Results']")]
        public IWebElement ViewResults { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='component-container']//div[@id='deuiApp']")]
        public IWebElement InsuredReqActionResultsPage { get; set; }

        [FindsBy(How = How.Id, Using = "saveAndExitBtn")]
        public IWebElement saveAndExitButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@role='tab' and @id='caseRequirements-header']")]
        public IWebElement CaseRequirementsSection { get; set; }

        //Add Requirements
        [FindsBy(How = How.Id, Using = "addCaseRequirements")]
        public IWebElement AddCaseRequirementButton { get; set; }

        [FindsBy(How = How.Id, Using = "//span[contains(@id,'label') and text() = 'Add Requirement']")]
        public IWebElement AddRequirementWindow { get; set; }
               

        [FindsBy(How = How.XPath, Using = "//select[contains(@name,'Requirement/Category')]")]
        public IWebElement Category { get; set; }

        [FindsBy(How = How.XPath, Using = "//select[contains(@name,'Requirement/Name')]")]
        public IWebElement RequirementName { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Next')]")]
        public IWebElement NextButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tblCaseRequirements']")]
        public IWebElement CaseRequirementsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'tblCaseRequirements_row')]")]
        public IList<IWebElement> CaseRequirementsTableRows { get; set; }
        string[] urlDetails;

        [FindsBy(How = How.Id, Using = "referenceType")]
        public IWebElement referenceType { get; set; }

        public void Login()
        {
            //Create test data variable
            TestData testData = new TestData();

            //Get the URL, UserID, Password
            urlDetails = testData.GetEnvionmentDetails("ALIP").Split(';');

            //Navigate to ALIP URL
            driver.Navigate().GoToUrl(urlDetails[1]);

            //Verify if ALIP Login Page is Loaded
            NYLDSelenium.PageLoad("ALIP Login", LoginPage);

            Thread.Sleep(500);
            //Enter UserName
            if (NYLDSelenium.ElemExist("Username textbox", UserName,false,"no", "no"))
            {
                NYLDSelenium.SendKeys("Username textbox", UserName, urlDetails[2].Trim());
            }

            //Enter Password
            NYLDSelenium.SendKeys("Password textbox", Password, urlDetails[3].Trim());

            //Click Enter
            NYLDSelenium.Click("Submit button", Submit);

            //PageLoad Home Page
            NYLDSelenium.PageLoad("Home", HomrPage);
        }

        /// <summary>
        /// Metghod to launch the ALIP application and login
        /// </summary>
        /// <param name="args"></param>
        public void VerifyEntryinALIP(string requestType)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Task Creation in ALIP" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            
              bool success = false;
              Login();

            //Navigate to ALIP URL
            driver.Navigate().GoToUrl(urlDetails[1] + "/administration/reporting_monitoring/IntegrationHistory?headerContext=welcome");

            //Verify Page Load
            NYLDSelenium.PageLoad("Integration Search Page", IntegrationHistorySearchPage);

            NYLDSelenium.SelectList("Reference Type", referenceType, "All","bytext"); //-2 ref for 'All'

            //Send control number to be verified          
            NYLDSelenium.SendKeys("Reference ID", ReferenceID, data[KeyRepository.ControlNumber]);

            //Click Seach
            NYLDSelenium.Click("Search", Search);

            Thread.Sleep(5000);

            //NYLDSelenium.PageLoad("Results Table", ResultsTable);

            //Verify and Save the results
               IList<IWebElement> readRows = driver.FindElements(By.XPath("//tbody[@class='p-element p-datatable-tbody']/tr"));

            if (!(readRows.Count == 1 && readRows[0].Text.Contains("No records were found")))
            {
                for (int i = 0; i < readRows.Count; i++)
                {

                    IWebElement StatusWe = NYLDSelenium.GetWE("//tbody[@class='p-element p-datatable-tbody']/tr[" + (i + 1) + "]/td[7]");
                    IWebElement IntTypeWe = NYLDSelenium.GetWE("//tbody[@class='p-element p-datatable-tbody']/tr[" + (i + 1) + "]/td[3]");

                    if((IntTypeWe.Text == "New Business Submit Integration") || (IntTypeWe.Text == "Create Task"))
                   {
                        success = true;
                        break;
                    }
                }
            }

            if (success)
                NYLDSelenium.ReportStepResult("<h4 style=\"color:Green\">" + "Verify "+ requestType + " Entry in ALIP" + "</h4>", "<h4 style=\"color:Green\">" + requestType + " entry is made through ALIP." + "</h4>", "PASS", "yes");
            else
                NYLDSelenium.ReportStepResult("Verify if "+ requestType + " Entry in ALIP", requestType + " entry is not found in ALIP. There might be other reasons: <br> 1. Check if ALIP Environment (URL) is correct <br> 2. Ensure 'Submit Application' flag in Sitecore is 'unchecked'", "Fail");

        }

        /// <summary>
        /// Method to select search category and type in search info to select the required application
        /// </summary>
        /// <param name="args"></param>
        public void TriggerInterview(string args)
        {
            
          
            //Navigate to Search Applications Screen
            driver.Navigate().GoToUrl(NavigateTo("SearchApplications", data[KeyRepository.Environment]));

           Thread.Sleep(5000);

            //Verify if Application page is loaded
            NYLDSelenium.PageLoad("Application Search", SearchTextBox);

            Thread.Sleep(100);    //100 seems to work very well (9/14/18)           

            //Enter the Application Number
            NYLDSelenium.SendKeys("Search Text Box", SearchTextBox, "0125447467");

            //Click Search Button
            NYLDSelenium.Click("Search Button", SearchButton);

            //Verify Application Information page is displayed
            NYLDSelenium.PageLoad("Application Summary", ApplicationSummary);

            //Set the header
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Decision Factor</h3> ", " <h3 style =\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Navigate to CaseWorkBench
            driver.Navigate().GoToUrl(NavigateTo("CaseWorkBench", data[KeyRepository.Environment]));
            
            //Click on Decision Factor Tab
            try { DecisionFactor.FindElement(By.XPath("./div/button/fa-icon/*[@role='img' and @data-icon='chevron-down']")); }
            catch { NYLDSelenium.Click("Underwriting Section", DecisionFactor); }

            //Click on Interview Required
            NYLDSelenium.Click("Interview Required", DecisionFactor_InterviewRequired);

            //Click View Results
            NYLDSelenium.Click("View Results", ViewResults);

            //Action results page load
            int count = driver.WindowHandles.Count();

            //Switch to interview page
            driver.SwitchTo().Window(driver.WindowHandles[1]);

            Thread.Sleep(3000);

            //Verify if Interview Page got loaded 
            NYLDSelenium.PageLoad("Aura Interview", InsuredReqActionResultsPage);

            Thread.Sleep(3000);

            //Click Save and exit
            NYLDSelenium.Click("Save and Exit", saveAndExitButton);
            Thread.Sleep(3000);

            driver.SwitchTo().Window(driver.WindowHandles[0]);

            //Click on Case Requireiments
            try { CaseRequirementsSection.FindElement(By.XPath("./div/button/fa-icon/*[@role='img' and @data-icon='chevron-down']")); }
            catch { NYLDSelenium.Click("Case Requirement Section", CaseRequirementsSection); }

            //Click Add Requirement Button
            NYLDSelenium.Click("Add Requirement", AddCaseRequirementButton);

            //Switch to interview page
            driver.SwitchTo().ActiveElement();

            //Select the Category
            NYLDSelenium.Click("Category", Category);
            NYLDSelenium.SelectList("Category", Category, "Customer Verification","bytext");

            //Wait for 2 seconds
            Thread.Sleep(2000);

            //Select the Requirement
            NYLDSelenium.Click("Requirement Name", RequirementName);
            NYLDSelenium.SelectList("Requirement Name", RequirementName, "Customer Self Complete","bytext");

            //Click Next
            NYLDSelenium.Click("Next", NextButton);

            //Wait for 2 seconds
            Thread.Sleep(2000);

            //Switch to interview page
            driver.SwitchTo().DefaultContent();

            string actDescription;

            //Verify if 'Customer Self Complete' requirement is addded
            for (int i = 0; i < CaseRequirementsTableRows.Count; i++)
            {
                actDescription = CaseRequirementsTableRows[i].FindElement(By.XPath(".//td[3]")).Text.Trim();

                if (actDescription == "Customer Self Complete")
                    break;

            }



        }
    
            /// <summary>
            /// Method builds string beased on current session ID to navigate to the required screen,
            /// </summary>
            /// <param name="pagename"></param>
            /// <param name="sessionid"></param>
            /// <param name="environment"></param>
            /// <returns></returns>
            public string NavigateTo(string pagename, string environment)
        {
            string pagestring = "";
            string URL = "";
            switch (pagename)
            {

                case "GroupTasks":
                    pagestring = "taskbox/TaskBoxGroupSummary.jsp";
                    break;

                case "SearchApplications":
                    pagestring = "applications/search_m/AdminSearchApplications";
                    break;

                case "SearchCustomers":
                    pagestring = "entities/search_m/AdminSearchPeople";
                    break;

                case "IntegrationHistory":
                    pagestring = "administration/reporting_monitoring/IntegrationHistory";
                    break;

                case "CaseWorkBench":
                    pagestring = "applications/NewUWWorkbench/NewUWWorkbench";
                    break;

                case "AdminHome":
                    pagestring = "/home/index";
                    break;

                case "NewUserAccountsSheet":
                    pagestring = "applications/WorkflowContainer?menuTab=APPLICATION&xmlName=adminMenu&headerContext=welcome&routePageTo=en/Applications/ApplicationPOSU.jsp";
                    break;

            }

            //Build the URL
            string token;
            if (pagename == "NewUserAccountsSheet")
            {
                token = "?headerContext=welcome&comingFrom=ContractChange";
                //sessionid = sessionid.Replace("&headerContext", "");
            }
            else
                token = "?headerContext=welcome";
            //if(pagename == "IntegrationHistory")
            //URL= GetURL(environment) + pagestring + token;
            //else
            URL = urlDetails[1] + pagestring + token;
            return URL;
        }

    }
}
