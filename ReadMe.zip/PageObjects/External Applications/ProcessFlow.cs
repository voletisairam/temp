﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using System.Threading;
using CSW.PageObjects.Login;
using OpenQA.Selenium.Support.UI;
using System.Diagnostics;
using System.IO;
using SeleniumExtras.WaitHelpers;

namespace CSW.PageObjects.External_Applications
{
    class ProcessFlow
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ProcessFlow(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////
               
        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'processflow_logo')]")]
        public IWebElement ProcessFlowHomePage { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='pzbtn-mid' and contains(text(),'Close')]")]
        public IWebElement ClosePopUP { get; set; }

        [FindsBy(How = How.Id, Using = "PM_AARP")]
        public IWebElement PMAARP { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='RULE_KEY']/div/div[1]/div/div/div/div/div/div/div/div[2][text()='PM AARP']")]
        public IWebElement PMAARPWorkQueue { get; set; }

        //[FindsBy(How = How.XPath, Using = "//*[@pl_prop='D_WorkBasket.pxResults']/tbody")]
        [FindsBy(How = How.XPath, Using = "//*[@pl_prop='.pyWorkResults']/tbody")]
        public IWebElement WorkBasketTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='workarea_header_id']")]
        public IWebElement caseOpenedTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Additional')]/following-sibling::div/span")]
        public IWebElement PFaddDetailsField { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name='pySearchFieldWorkResponsive_pyDisplayHarness_4']")]
        public IWebElement PFTaskSearch { get; set; }

        //*[@name='pySearchFieldWorkResponsive_pyDisplayHarness_4']
        [FindsBy(How = How.XPath, Using = "//input[@name='$PpyDisplayHarness$ppySearchText']")]
        public IWebElement PFTaskSearchEntry { get; set; }
        //*[@pl_prop="D_WorkBasket.pxResults"]/tbody/tr[2]/td[2]

        string[] urlDetails;

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////     Methods    ////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyProcessFlowEntry                                                                     ////////////
        ////// Description: Verify Edit Insured Entry in Process Flow                                             //////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void VerifyProcessFlowEntry(string changeType, string changeDetails = "")
        {
            TestData testData = new TestData();
            CommonFunctions.WindowsTabFocus("OpenNewTab", "newTabInstance");

            urlDetails = testData.GetEnvionmentDetails("Processflow").Split(';');
           
            try
            {
                //Navigate to Processflow URL
                driver.Navigate().GoToUrl(urlDetails[1]);

                string ExpectedDescription = "";
                string[] change = { };
                DateTime createDate;
                string AddntlDetailsText = "";
                bool entryFound = false;
                IList<IWebElement> taskTableRows;
                IList<IWebElement> taskTableHeader;
                IWebElement IDOptionSort;

                LoginPage LP = new LoginPage(driver, data);
                NYLDSelenium.AddHeader("Verify Process Flow Entry ", "SubHeader");
                switch (changeType)
                {
                    //case "RiderFlow":
                    //    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Process flow rider entry" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //    //Search for the control number
                    //    //close if a pop upis displayed
                    //    if (NYLDSelenium.ElemExist("Close Pop UP", PFclosePopUP, 20))
                    //        NYLDSelenium.Click("Close pop up", PFclosePopUP);

                    //    //wait for Page load
                    //    NYLDSelenium.PageLoad("Process Flow", PFactions);

                    //    NYLDSelenium.SendKeys("Control Number", SearchBox,CSWData.TempVal.Split(';')[1]);
                    //    NYLDSelenium.Click("Search icon", SearchButton);

                    //    Thread.Sleep(3000);
                    //    string resultPF = NoPFEntryFound.Text.ToString();
                    //    //if records exist then proceed else report
                    //    if (resultPF == "0 posts found")
                    //        NYLDSelenium.ReportStepResult("Verify rider submission entry in process flow", "Rider entry not found in process flow for the control number: " +CSWData.TempVal.Split(';')[1], "Fail", "yes");
                    //    else
                    //    {
                    //        NYLDSelenium.Click("Open record", SelectPFRecord);
                    //        driver.SwitchTo().DefaultContent();
                    //        driver.SwitchTo().Frame(driver.FindElement(By.Id("PegaGadget1Ifr")));

                    //        NYLDSelenium.VerifyText("Rider entry status", "New", NYLDSelenium.GetAttribute("Rider entry status", RiderEntryStatus, "bytext"));
                    //        NYLDSelenium.VerifyText("Rider entry created date", DateTime.Now.Date.ToString("mm/dd/yyyy"), NYLDSelenium.GetAttribute("Rider entry created date", RiderEntryCreatedDate, "bytext"));
                    //        NYLDSelenium.VerifyText("Rider company code", "AARP", NYLDSelenium.GetAttribute("Rider company code", RiderCompanyCode, "byvalue"));
                    //        NYLDSelenium.VerifyText("Rider channel ", "INBOUND MAIL", NYLDSelenium.GetAttribute("Rider channel", RiderChannel, "byvalue"));

                    //        NYLDSelenium.VerifyText("Rider Control Number",CSWData.TempVal.Split(';')[1], NYLDSelenium.GetAttribute("Rider Control Number", RiderControlNumber, "bytext"));
                    //    }

                    //    int checkOutCounter = GetSettor.failCounter;
                    //    if (checkInCounter == checkOutCounter)
                    //        NYLDSelenium.ReportStepResult("Verify Process flow entry for the rider submitted", "Process flow entry verification was successful for the rider", "Pass", "no");

                    //    break;

                    case "EditInsured":

                        if (changeDetails != "")
                            change = changeDetails.Split(':');

                        //get subject and event name to be scanned
                        switch (change[0])
                        {
                            case "Namechange":
                            case "Allchange":
                                ExpectedDescription = "Name Change - AARP - " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];
                                break;

                            case "NamechangeandDOBchange":
                                ExpectedDescription = "Name Change - AARP - " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];
                                break;

                            case "DOBchange":
                                ExpectedDescription = "Date Of Birth Change - AARP - " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];
                                break;

                            case "Genderchange":
                                ExpectedDescription = "Gender Change - AARP - " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];
                                break;
                        }

                        //To send the username and password for processflow login
                        //MUST remove and use Generic passowrd
                        string Pwd = "$ysAuto05mo@012";
                        createPopFile(Properties.Settings.Default.Tampa01UID, Pwd);
                        for (int i = 0; i <= 6; i++)
                        {
                            String ScriptPath = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.ScriptsFolder + "FillWinSecPopUp.vbs";
                            Process.Start(ScriptPath); //Windows Security logins are populated.
                            Thread.Sleep(8000); //Do not remove. Wait is needed for app to load.
                            if (NYLDSelenium.ElemExist("Process Flow Home", ProcessFlowHomePage, false, "no", "no"))
                                break;
                        }
                        Thread.Sleep(8000);
                        //Verify if Process Flow page is loaded
                        NYLDSelenium.PageLoad("Process Flow Home", ProcessFlowHomePage);

                        //close if a pop upis displayed
                        var wait = new WebDriverWait(driver, System.TimeSpan.FromSeconds(15));
                        wait.Until(ExpectedConditions.FrameToBeAvailableAndSwitchToIt("PegaGadget0Ifr"));

                        driver.SwitchTo().DefaultContent();
                        Thread.Sleep(2000);
                        if (NYLDSelenium.ElemExist("Close Pop UP", ClosePopUP, false, "no", "no"))
                            NYLDSelenium.Click("Close pop up", ClosePopUP);

                        //Switch to iFrame
                        driver.SwitchTo().Frame(NYLDSelenium.GetWE("//*[@id='PegaGadget0Ifr']"));

                        //Due to PM AARP group merge into one

                        //Click on 'PM AARP Priority' Bucket
                        NYLDSelenium.Click("PM AARP", PMAARP);

                        //Verify 'PM AARP Priority' basket is loaded
                        NYLDSelenium.PageLoad("PM AARP Work Queue", PMAARPWorkQueue,"always","always");


                        driver.Navigate().Refresh(); Thread.Sleep(2000);
                        if (NYLDSelenium.ElemExist("Find PF Task", PFTaskSearchEntry))
                        {
                            NYLDSelenium.SendKeys("PF Task Find with Policy Number", PFTaskSearchEntry, data[KeyRepository.PolicyNumber] + Keys.Enter);
                            Thread.Sleep(10000);
                            SelectElement drpCountry = new SelectElement(driver.FindElement(By.Name("$PD_pyWorkSearchPreferences$ppySearchLastUpdated")));
                            drpCountry.SelectByValue("Today");

                        }

                        // Sort by Creation Date
                        IDOptionSort = GetTableRow("OptionSort")[4];
                        NYLDSelenium.Click("Sorting by ID ASC", IDOptionSort);
                        IDOptionSort = GetTableRow("OptionSort")[4];
                        NYLDSelenium.Click("Sorting by ID DESC", IDOptionSort);

                        Thread.Sleep(10000);
                        int RowCount = GetTableRow("RowContent").Count();
                        taskTableRows = GetTableRow("RowContent");
                        taskTableHeader = taskTableRows[0].FindElements(By.TagName("th"));

                        //Get the Create Date Column Name
                        int headerindex = 0;
                        int createDate_index = 0, description_index = 0, taskid_index = 0;

                        foreach (IWebElement header in taskTableHeader)
                        {

                            if (header.Text == "Updated")
                                createDate_index = headerindex;
                            else if (header.Text == "Description")
                                description_index = headerindex;
                            else if (header.Text == "ID")
                                taskid_index = headerindex;

                            headerindex++;
                        }
                        Thread.Sleep(6000);
                        // NYLDSelenium.ReportStepResult("Process Flow table rows count", "Process Flow table rows count :" + taskTableRows.Count, "Info", "always", "always");
                        //Scan the table from below
                        for (int i = 1; i < taskTableRows.Count; i++)
                        {
                            string actualtaskrow = taskTableRows[i].Text;
                            if (actualtaskrow.Contains(ExpectedDescription))
                            {
                                // Start from the Top            
                                IList<IWebElement> RowContent = taskTableRows[i].FindElements(By.TagName("td"));



                                string dateString = NYLDSelenium.GetAttribute("Create date from table", RowContent[createDate_index]);
                                createDate = Convert.ToDateTime(dateString);
                                DateTime createDateConverted = Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy HH:mm"));
                                DateTime eventTriggertimeConverted = Convert.ToDateTime(CSWData.EventTriggerTime.ToString("MM/dd/yyyy HH:mm"));

                                // NYLDSelenium.ReportStepResult("Process Flow Created trigger time", "Process Flow Created trigger time :" + createDateConverted, "Info", "always", "always");
                                //compare deadline date with even trigger date
                                if (createDateConverted >= eventTriggertimeConverted)
                                {
                                    // NYLDSelenium.ReportStepResult("Process Flow Event trigger time", "Process Flow Event trigger time :" + eventTriggertimeConverted, "Info", "always", "always");
                                    //Capture the Subject from Table and compare with  expected subject
                                    string ActualDescription = NYLDSelenium.GetAttribute("Actual Description", RowContent[description_index]);
                                    if (ActualDescription == ExpectedDescription)
                                    {
                                        //Click on Expand option of the record verified
                                        string TaskID = NYLDSelenium.GetAttribute("Task ID", RowContent[taskid_index]);
                                        NYLDSelenium.Click("Task ID" + TaskID, RowContent[2]);
                                        Thread.Sleep(5000);

                                        driver.SwitchTo().DefaultContent();
                                        driver.SwitchTo().Frame(NYLDSelenium.GetWE("//iframe[@title='" + TaskID + "']"));
                                        NYLDSelenium.PageLoad("Case opened", caseOpenedTitle);


                                        IWebElement ContractNbr = driver.FindElement(By.XPath("//tr[@id='.ContractInformation1']/td/span"));
                                        string ContractNbrText = NYLDSelenium.GetAttribute("Get Contract Number", ContractNbr);

                                        if (data[KeyRepository.PolicyNumber] == ContractNbrText)
                                        {
                                            AddntlDetailsText = NYLDSelenium.GetAttribute("Additional Details", PFaddDetailsField);
                                            entryFound = true;
                                            i = 0;
                                            break;
                                        }
                                        else
                                        {
                                            if (i == 1)
                                                NYLDSelenium.ReportStepResult("Process Flow Task -POlicy number not mached", "Process Flow Task  Policy number not matched on after trigger time: " + CSWData.EventTriggerTime, "FAIL", "always", "yes");
                                        }
                                    }
                                    else
                                    {
                                        if (i == 1)
                                            NYLDSelenium.ReportStepResult("Process Flow Task not created", "Process Flow Task Descrption Not Matching  after event trigger time: " + CSWData.EventTriggerTime, "FAIL","always","yes");
                                    }
                                }
                                else
                                {
                                    if (i == 1)
                                        NYLDSelenium.ReportStepResult("Process Flow Task created date and event data not matched", "Process Flow Task not created on or after event trigger time: " + CSWData.EventTriggerTime, "FAIL", "always", "yes");
                                }
                            }
                        }

                        if (entryFound)
                        {

                            if (change[0] == "Namechange")
                                Namechange(change[1], AddntlDetailsText);
                            else
                            {
                                if (change[0] != "Allchange")
                                {
                                    bool Namechange = AddntlDetailsText.Contains("Change Insured Name from ");
                                    bool NamechangeReason = AddntlDetailsText.Contains("Name change reason: ");
                                    if (Namechange)
                                        NYLDSelenium.ReportStepResult("Text for Non  Name change", "No name change made in 'Edit Insured' page but 'Change Insured Name from' text is found in Additional Details section of process flow", "FAIL", "yes");

                                    if (NamechangeReason)
                                        NYLDSelenium.ReportStepResult("Text for Non Name change", "No name change made in 'Edit Insured' page but 'Name change reason' text is found in Additional Details section of process flow", "FAIL", "yes");
                                }
                            }

                            if (change[0] == "DOBchange")
                                DOBchange(change[1], AddntlDetailsText);
                            else
                            {
                                if (change[0] != "Allchange")
                                {
                                    bool DOBchange = AddntlDetailsText.Contains("Change Insured DOB from ");
                                    if (DOBchange)
                                        NYLDSelenium.ReportStepResult("Text for Non DOB change", "No DOB change made in 'Edit Insured' page but 'Change Insured DOB from' text is  found in Additional Details section of process flow", "FAIL", "yes");
                                }
                            }

                            if (change[0] == "Genderchange")
                                Genderchange(change[1], AddntlDetailsText);
                            else
                            {
                                if (change[0] != "Allchange")
                                {
                                    bool Genderchange = AddntlDetailsText.Contains("Change Insured Gender from ");
                                    if (Genderchange)
                                        NYLDSelenium.ReportStepResult("Text for Non Gender change", "NO Gender change made in 'Edit Insured' page but 'Change Insured Gender from' text is  found in Additional Details section of process flow", "FAIL", "yes");
                                }
                            }

                            if (change[0] == "Allchange")
                            {
                                Namechange(change[1], AddntlDetailsText);
                                DOBchange(change[2], AddntlDetailsText);
                                Genderchange(change[3], AddntlDetailsText);
                            }

                            if (change[0] == "NamechangeandDOBchange")
                            {
                                Namechange(change[1], AddntlDetailsText);
                                DOBchange(change[2], AddntlDetailsText);
                            }
                            else
                            {
                                if (change[0] != "Genderchange" && change[0] != "Allchange")
                                {
                                    bool Genderchange = AddntlDetailsText.Contains("Change Insured Gender from ");
                                    if (Genderchange)
                                        NYLDSelenium.ReportStepResult("Text for Non Gender change", "NO Gender change made in 'Edit Insured' page but 'Change Insured Gender from' text is  found in Additional Details section of process flow", "FAIL", "yes");
                                }
                            }

                            //Closing the record and navigating back to workbasket
                            NYLDSelenium.Click("Close Item", NYLDSelenium.GetWE("//a[@title='Close this item']"));

                            //Verify 'PM AARP' basket is loaded
                            Thread.Sleep(5000);
                            driver.SwitchTo().DefaultContent();
                            driver.SwitchTo().Frame("PegaGadget0Ifr");
                            NYLDSelenium.PageLoad("PM AARP Work Queue", PMAARPWorkQueue);

                            NYLDSelenium.AddHeader("Verify Process Flow Entry ", "Success");
                        }
                        else
                        {
                            NYLDSelenium.ReportStepResult("Process Flow Task Entry not created", "Process Flow Task not created on or after event trigger time: " + CSWData.EventTriggerTime, "FAIL", "always","yes");
                        }


                        //Navigate to Application
                        driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                        NYLDSelenium.ElemExist("Login Page", LP.LoginHeaderNewUser);
                        break;
                }
            }
            catch
            {
                NYLDSelenium.ReportStepResult("Unable to Access the Process Flow URL", "Unable to Access the Process Flow URL " + urlDetails[1] + " Report to automation team.", "FAIL", "always", "yes");
            }
            CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
            CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
        }

        public static void createPopFile(string username, string password)
        {
            string filespath = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.ScriptsFolder;
            Console.WriteLine("Environment.UserName" + Environment.UserName);
            string deaccustemail = filespath + @"FillWinSecPopUp.vbs";


            //Create Entry File
            using (StreamWriter sw = new StreamWriter(deaccustemail))
            {
                sw.WriteLine(@"set IE = CreateObject(""InternetExplorer.Application"")");
                sw.WriteLine(@"set WshShell = WScript.CreateObject(""WScript.shell"")");
                sw.WriteLine(@"WshShell.AppActivate ""Windows Internet Explorer""");
                sw.WriteLine(@"WScript.Sleep 2000");
                sw.WriteLine(@"WshShell.SendKeys """ + username + @"""");
                sw.WriteLine(@"WScript.Sleep 500");
                sw.WriteLine(@"WshShell.SendKeys ""{TAB}""");
                sw.WriteLine(@"WScript.Sleep 500");
                sw.WriteLine(@"WshShell.SendKeys """ + password + @"""");
                sw.WriteLine(@"WScript.Sleep 500");
                sw.WriteLine(@"WshShell.SendKeys ""{TAB}""");
                sw.WriteLine(@"WScript.Sleep 500");
                sw.WriteLine(@"WshShell.SendKeys ""{ENTER}""");
                sw.WriteLine(@"WScript.Sleep 2000");
                sw.WriteLine(@"IE.Quit");
            }
        }


        private IList<IWebElement> GetTableRow(string option)
        {

            Thread.Sleep(5000);
            IList<IWebElement> taskTableRows;
            IList<IWebElement> taskTableHeader;

            switch (option)
            {
                case "OptionSort":
                    taskTableRows = WorkBasketTable.FindElements(By.TagName("tr"));
                    taskTableHeader = taskTableRows[0].FindElements(By.TagName("th"));
                    return taskTableHeader;

                case "RowContent":
                    taskTableRows = WorkBasketTable.FindElements(By.TagName("tr"));
                    return taskTableRows;

            }
            return null;
        }

        //Verify if Name change activity is mentioned as expected
        public void Namechange(string args, string AddntlDetailsText)
        {
            string[] chngReason = args.Split(',');
            bool NameChange = AddntlDetailsText.Contains("Change Insured Name from " + data[KeyRepository.InsuredFullName] + " to " + chngReason[0] + ".");
            bool ChangeReason = AddntlDetailsText.ToLower().Contains(chngReason[1].ToLower());

            if (!(NameChange))
                NYLDSelenium.ReportStepResult("Text for Name change", "Change Insured Name from " + data[KeyRepository.InsuredFullName] + " to " + chngReason[0] + "." + " text is not found in Additional Details section of process flow", "FAIL", "yes");

            if (!(ChangeReason))
                NYLDSelenium.ReportStepResult("Text for Name change Reason", "Name change reason: " + chngReason[1] + " text is not found in Additional Details section of process flow", "FAIL", "always", "always");
            else
                NYLDSelenium.ReportStepResult("Text for Name change Reason", "Name change reason: " + chngReason[1] + " text is not found in Additional Details section of process flow", "PASS", "always","always");
        }

        //Verify if DOB change activity is mentioned as expected
        public void DOBchange(string args, string AddntlDetailsText)
        {
           
            string[] chngReason = args.Split(',');
            bool DOBchange = AddntlDetailsText.Contains( Convert.ToDateTime(chngReason[0]).ToString("yyyy-MM-dd"));

            if (!(DOBchange))
                NYLDSelenium.ReportStepResult("Text for DOB change", "Change Insured DOB from " + data[KeyRepository.InsuredDOBMonth] + "-" + data[KeyRepository.InsuredDOBDay] + "-" + data[KeyRepository.InsuredDOBYear] + " to " + Convert.ToDateTime(chngReason[0]).ToString("yyyy-MM-dd") + "." + " text is not found in Additional Details section of process flow", "FAIL", "yes");
        }

        //Verify if Gender change activity is mentioned as expected
        public void Genderchange(string args, string AddntlDetailsText)
        {
            string[] chngReason = args.Split(',');
            bool Genderchange = AddntlDetailsText.Contains("Change Insured Gender from " + data[KeyRepository.InsuredGender].Substring(0,1) + " to " + chngReason[0].Substring(0,1));

            if (!(Genderchange))
                NYLDSelenium.ReportStepResult("Text for Gender change", "Change Insured Gender from " + data[KeyRepository.InsuredGender] + " to " + chngReason[0] + "." + " text is not found in Additional Details section of process flow", "FAIL", "yes");
        }    
    }
}
