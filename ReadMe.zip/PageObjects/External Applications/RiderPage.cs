﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium;
using CSW.Common.Services;
using CSW.Common.Others;
using NYLDWebAutomationFramework;
using CSW.PageObjects.Login;
using CSW.Common.DataBase;
using CSW.Common.Excel;
using System.Threading;
using CSW.PageObjects.Functions;
using CSW.Common.Database;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace CSW.PageObjects.External_Applications
{
    //ToDO: This is not external app, please create a folder named Riders_Exchanges and move it there
    class RiderPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public RiderPage(IWebDriver webDriver, Dictionary<string, string> data)
        {
            this.driver = webDriver;
            this.data = data;
            PageFactory.InitElements(webDriver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'current coverage')]/following-sibling::div")]
        public IWebElement CurrentRiderCoverage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'current premium')]/following-sibling::div")]
        public IWebElement CurrentRiderPremium { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name='SelectedOffer']/../div")]
        public IList<IWebElement> RiderOffers { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name='SelectedOffer']/..")]
        public IList<IWebElement> RiderPremiums { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@type='submit' and contains(text(), 'Get Started')]")]
        public IWebElement GetStarted { get; set; } 

        [FindsBy(How = How.XPath, Using = "//h1[text()='General information']")]
        public IWebElement GeneralInformation_Header { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[text()='Your coverage']")]
        public IWebElement YourCoverage_Header { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for = 'TobaccoQuestion']")]
        public IWebElement TobaccoQuestion { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[contains(@class, 'mb-3')]")]
        public IList<IWebElement> QuestionHeaders { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@id, 'hq')]")]
        public IList<IWebElement> HealthQuestions { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@id, 'hq')]")]
        public IWebElement HealthQuestionsInfo { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='TobaccoQuestionYes' and contains(@class, 'btn')]")]
        public IWebElement Smoker_Yes { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='TobaccoAnswerNo' and contains(@class, 'btn')]")]
        public IWebElement Smoker_No { get; set; }

        [FindsBy(How = How.XPath, Using = "//Select[@id='HeightinFeet']")]
        public IWebElement Height_Feet { get; set; }

        [FindsBy(How = How.XPath, Using = "//Select[@id='HeightinInches']")]
        public IWebElement Height_Inches { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Current height')]/..//span/span")]
        public IWebElement Height_Inches_Error { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtWeightInPounds']")]
        public IWebElement Weight { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Current weight')]/..//span/span")]
        public IWebElement Weight_Error { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='container-coverage']//span[contains(text(), '$')]/..")]
        public IWebElement Coverage_Increase { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='rq-yes']/ancestor::div[contains(@class, 'm-1')]/label")]
        public IWebElement ReplacementQuestion { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='rq-yes']")]
        public IWebElement ReplacementQuestion_Yes { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='rq-no']")]
        public IWebElement ReplacementQuestion_No { get; set; }


        [FindsBy(How = How.XPath, Using = "//label[contains(text(), 'Contract number')]/../following-sibling::div[1]")]
        public IWebElement PolicyNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'hq')]/ul[1]/li[1]")]
        public IWebElement HeatthQuestions { get; set; }

        [FindsBy(How = How.XPath, Using = "(//label[contains(@for, 'Risk_Y')])[1]")]
        public IWebElement HeatthQuestionsRisk { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Review')]")]
        public IWebElement Submit_RiderForm { get; set; }//label[contains(text(), 'replace')]/../following-sibling::div

        [FindsBy(How = How.XPath, Using = "//input[@name = 'TobaccoQuestion' and  @checked = 'checked']/..")]
        public IWebElement Responses_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name = 'IsReplacement' and  @checked = 'checked']/..")]
        public IWebElement Replacement_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@data-val-model, 'readonly')]//input[contains(@name, 'Answer') and  @checked = 'checked']/..")]
        public IList<IWebElement> Health_Responses_Review { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'container')]//*[contains(text(), 'AARP Term Rider')]")]
        public IWebElement TermRiderEligibilityPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@data-ea-zone, 'Term Rider') and contains(text(), 'Get started')]")]
        public IWebElement TermRiderCheckEligibiityLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Current height')]/following-sibling::p/strong")]
        public IWebElement Height_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Current weight')]/following-sibling::p/strong")]
        public IWebElement Weight_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(text(), 'coverage by')]/../following-sibling::div/span")]
        public IWebElement Coverage_Review { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Sign &')]")]
        public IWebElement Sign_Continue_Reiview { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Call New York')]/..")]
        public IWebElement CallNewYorkLife_Text { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='ICertify']/..")]
        public IWebElement CertifyChekbox { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='review-copy']/h1")]
        public IWebElement ReviewAndSubmit_Header { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'Apply/Rider')]/i")]
        public IWebElement ViewApplicationLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Submit my')]")]
        public IWebElement Submit_Certified { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Application received')]")]
        public IWebElement ThankYouHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Thank you')]")]
        public IWebElement ThankYouBody { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'Apply/Rider') and contains(text(), 'Download')]")]
        public IWebElement ApplicationPDFLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//textarea[contains(@id,'HealthAnswers')]")]
        public IWebElement CommentsSection { get; set; }

        [FindsBy(How = How.XPath, Using = "//textarea[contains(@id,'HealthAnswers')]/../span/span")]
        public IWebElement Comments_Error { get; set; }


        [FindsBy(How = How.XPath, Using = "(//a[contains(@data-ea-zone, 'Term Rider')])[1]")]
        public IWebElement TermRiderCheckSeeImEligibleLink { get; set; }

        /// <summary>
        /// Method to veriy offers displayed
        /// </summary>
        /// <param name="args"></param>
        public void VerifyOffers(string args = "")
        {            
            NYLDSelenium.AddHeader("Verify Offers displayed ", "SubHeader");
            
            bool offerFound = false;
            List<string> riderCoverageAmount = new List<string>();
            List<string> riderPremiums = new List<string>();
            CSW.Common.Services.RestServices restService = new CSW.Common.Services.RestServices(data);
            restService.GetOffersAPI(args);

            Int32 currentCoverageAmount = Convert.ToInt32(data[KeyRepository.CoverageAmount]);
            double currentPremium = Convert.ToDouble(data[KeyRepository.Premium]);

            //Wait for offers page load
            NYLDSelenium.PageLoad("Offers", CurrentRiderCoverage);

            //Verify current Coverage and Premium
            NYLDSelenium.VerifyText("Current Coverage", data[KeyRepository.CoverageAmount], CurrentRiderCoverage.Text.Replace("$", "").Replace(",", "").Trim());
            NYLDSelenium.VerifyText("Current Premium", data[KeyRepository.Premium] + " per month", CurrentRiderPremium.Text.Replace("$", "").Trim());

            //Report mismatgch in rider offer counts            
            if (RiderOffers.Count != CSWData.RiderInfo.Count())
                NYLDSelenium.ReportStepResult("Rider offers count do not match", "Rider offer counts displayed in UI does not match with serice result", "Fail");

            //Collect the rider offers
            foreach (List<string> offer in CSWData.RiderInfo)
            {
                riderPremiums.Add(Convert.ToString(currentPremium + Convert.ToDouble(offer[0])));
                riderCoverageAmount.Add(Convert.ToString(currentCoverageAmount + Convert.ToInt32(offer[1].Split('.')[0])));
            }

            //verify Offers
            foreach(IWebElement we in RiderOffers)
            {
                string actualOffer = we.Text.Replace("$", "").Replace(",", "").Trim();
                
                offerFound = false;
                for(int i=0; i<riderCoverageAmount.Count; i++)
                {
                    string actualPremium = "$" + RiderPremiums[i].Text.Split('$')[2].Replace("per month", "").TrimEnd('1').Trim();
                    if (actualOffer == riderCoverageAmount[i])
                    {
                        if(!actualPremium.Contains(riderPremiums[i]))
                            NYLDSelenium.ReportStepResult("Rider offer Premium displayed for Coverage - " + riderCoverageAmount[i] + " is not as expected.", "Expected Premium - " + riderPremiums[i], "Fail");
                        offerFound = true;
                        break;
                    }
                    else if (i == riderCoverageAmount.Count && !offerFound)
                        NYLDSelenium.ReportStepResult("Rider offer could not be found", "Term rider offer - " + actualOffer + " could not be found", "Fail");
                }
            }

                NYLDSelenium.AddHeader("Verify Offers displayed ", "Success");
        }

        /// <summary>
        /// Method to select the required offer
        /// </summary>
        /// <param name="args"></param>
        public void SelectOffer(string args = "")
        {
            NYLDSelenium.AddHeader("Select the Offer ", "SubHeader");

            LoginPage Login = new LoginPage(driver, data);

            //Collect the Coverage Amount and Premium from Banner
            string coverage = RiderOffers[0].Text.Replace("$", "").Replace(",", "");

            data[KeyRepository.DeltaCoverage] = (Convert.ToInt32(coverage) - Convert.ToInt32(data[KeyRepository.CoverageAmount])).ToString().Replace("-", "");
            data[KeyRepository.CoverageAmount] = coverage;
            data[KeyRepository.Premium] = RiderPremiums[0].Text.Replace("for just", "").Replace("per month", "").Replace("$", "").Replace("1", "").Trim();

            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", Login.CloseMockBanner,false,"no", "no"))
                NYLDSelenium.Click("Mock banner", Login.CloseMockBanner);

            //Select Offer
            //NYLDSelenium.ScrollToView(RiderOffers[0]);
            NYLDSelenium.Click("Select Offer", RiderOffers[0]);

            //Click on Get started
            NYLDSelenium.Click("Get Started", GetStarted);
            NYLDSelenium.AddHeader("Select the Offer ", "Success");
        }

        /// <summary>
        /// Verify Rider application form
        /// </summary>
        public void VerifyHealthHistoryQuestions(string args)
        {
            NYLDSelenium.AddHeader("Verify Health Questions ", "SubHeader");

            Thread.Sleep(1000);

            //Fetch health question as it is displayed in UI          
            List<string> expectedHealthQuestions = new List<string>();
            List<string> expectedHealthQuestionheaders = new List<string>();
            List<string> formattedHealthQuestions = new List<string>();
            int index = -1;
            bool headerfound = false;
            
            IList<IWebElement> actualHeaders = QuestionHeaders, actualQuestions = null; 

            //Get health questions from DB
            expectedHealthQuestions = new LSPDatabase(driver, data).GetHealthQuestionsNumbers("Text");

            //Rearrange the DB questions to the format as it is displayed in UI and Remove smoker question
            foreach (string hq in expectedHealthQuestions)
            {
                //Tobacco questions ar displayed in first page
                if (hq.Contains("tobacco or"))
                    break;
                
                //For non PL products questions appear in split with headers displayed in common so segregating accordingly
                headerfound = false;
                string question = hq.Split(',')[0].Trim();

                foreach (string header in expectedHealthQuestionheaders)
                {
                    if (header.Trim() == question)
                        headerfound = true;
                }
                if (!headerfound)
                {
                    expectedHealthQuestionheaders.Add(hq.Split(',')[0].Trim());
                    index++;
                    formattedHealthQuestions.Add(hq.Replace(expectedHealthQuestionheaders[index], "").TrimStart(',').Trim());

                }
                if (headerfound)
                {
                    formattedHealthQuestions.Add(hq.Replace(expectedHealthQuestionheaders[index], "").TrimStart(',').Trim());
                }               
                
            }

            //Fetch actual Headers and questions displayed in UI  
         
           Thread.Sleep(1500);
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(1));
            string elementsearch = "";

            if (NYLDSelenium.ElemExist("Health & history", HeatthQuestions,false,"no","no","no"))
                elementsearch = "//div[contains(@class, 'hq')]/ul/li";
            else
                elementsearch = "//label[contains(@id, 'hq')]";


            try
            {
                actualQuestions = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath(elementsearch))));
            }
            catch
            {
                actualQuestions = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath(elementsearch))));
            }



            // Compare Header
            int i = 0;
            
            foreach (string header in expectedHealthQuestionheaders)
            {
                string expectedHeader = header + ", have you";
                string actualHeader = actualHeaders[i].Text.Split('.')[1].TrimEnd(':').Trim();
                if (expectedHeader != actualHeader)
                {
                    NYLDSelenium.ReportStepResult("Verify Health Question Header", "Health Question header <p> Expected: " + expectedHeader + " </p><p>Actual: " + actualHeader + "</p>", "Fail", "Yes");
                }
                i++;
            }
            
            //Compare Questions
            int j = 0;
            

            foreach (string question in formattedHealthQuestions)
                {
                    string expectedQuestion, actualQuestion, additionalPhrase;
                    try
                    {
                        expectedQuestion = question.Replace("have you", "").Trim();
                        additionalPhrase = " (check all that apply below):";
                        actualQuestion = actualQuestions[j].Text.Replace("\r\n", "|").Split('|')[0].Trim();

                        //if (actualQuestion.Contains("any of the following") && !(actualQuestion.Contains("check all")))
                        if (actualQuestion.Contains("any of the following") && !(expectedQuestion.Contains("check")))
                        {
                            expectedQuestion = expectedQuestion + additionalPhrase;
                        }

                        if (expectedQuestion != actualQuestion)
                        {
                            NYLDSelenium.ReportStepResult("Verify Health Question", "Health Question <p> Expected: " + expectedQuestion + " </p><p>Actual: " + actualQuestion + "</p>", "Fail", "Yes");
                        }
                        j++;
                    }
                    catch
                    {


                        expectedQuestion = question.Replace("have you", "").Trim();
                        additionalPhrase = " (check all that apply below):";
                        actualQuestion = actualQuestions[0].Text.Replace("\r\n", "|").Split('|')[0].Trim();

                        //if (actualQuestion.Contains("any of the following") && !(actualQuestion.Contains("check all")))
                        if (actualQuestion.Contains("any of the following") && !(expectedQuestion.Contains("check")))
                        {
                            expectedQuestion = expectedQuestion + additionalPhrase;
                        }

                        if (expectedQuestion != actualQuestion)
                        {
                            NYLDSelenium.ReportStepResult("Verify Health Question", "Health Question <p> Expected: " + expectedQuestion + " </p><p>Actual: " + actualQuestion + "</p>", "Fail", "Yes");
                        }
                        j++;
                    }
                }            

            NYLDSelenium.AddHeader("Verify Health Questions", "Success");
        }
        public void VerifyRideForm()
        {            
            NYLDSelenium.AddHeader("Verify Rider Form", "SubHeader");

            //Page load
            NYLDSelenium.PageLoad("Rider Form", GeneralInformation_Header);

            //Verify Call Newyork life Text
            string expectedContactText = new TestData().GetContent("CallNYL_Rider");
            string actualContactText = CallNewYorkLife_Text.Text.Replace("\r\n", " ");
            NYLDSelenium.VerifyText("Call New york Life Info", expectedContactText, actualContactText);

            //Genreal Informatin header
            NYLDSelenium.ElemExist("General Information Header", GeneralInformation_Header);

            //Verify Smoker question            
            NYLDSelenium.VerifyText("Smoker Question", "In the past 12 months, have you used tobacco or nicotine in any form?", NYLDSelenium.GetAttribute("Tobacco Question", TobaccoQuestion).Trim());

            //Verify Height and Weight
            NYLDSelenium.ElemExist("Height_Foot", Height_Feet);
            NYLDSelenium.ElemExist("Height_Foot", Height_Inches);
            NYLDSelenium.ElemExist("Weight", Weight);

            //Your Coverage header
            NYLDSelenium.ElemExist("Your Coverage Header", YourCoverage_Header);

            //Verify Coverage Increase
            string actualCoverage = NYLDSelenium.GetAttribute("Coverage", Coverage_Increase).Split('(')[0].Trim();
            NYLDSelenium.VerifyText("Delta Coverage", data[KeyRepository.DeltaCoverage], actualCoverage.Replace("$", "").Replace(",", "").Trim());

            //Verify Policy NUmber
            NYLDSelenium.VerifyText("Contract Number", data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Policy Number", PolicyNumber).Trim());

            //Replacement Question                        
            NYLDSelenium.VerifyText("Replacement Question", "Is the insurance applied for intended to replace, discontinue or change any existing insurance or annuity?", NYLDSelenium.GetAttribute("Replacement Question", ReplacementQuestion).Trim());

            //Verify Health Questions //TODO: Add Health question header as a place holder
            VerifyHealthHistoryQuestions("");

            NYLDSelenium.AddHeader("Verify Rider Form", "Success");

        }


        /// <summary>
        /// Methdo to fill the rider form
        /// </summary>
        public void FillRiderForm()
        {
            NYLDSelenium.AddHeader("Fill Rider form", "SubHeader");
            TestData testData = new TestData();
            //Get Rider form responses
            IWebElement smoker = null, replacement = null;
            data[KeyRepository.Height] = @"5'9""";
            data[KeyRepository.Weight] = "130";
            data[KeyRepository.HQAnswers] = testData.GetInputData("Rider HQ Responses");
            data[KeyRepository.HQComments] = testData.GetInputData("Rider HQ Commnets");
            data[KeyRepository.HealthRisks] = testData.GetInputData("Rider Impairments");
            data[KeyRepository.Member] = "Yes";
            data[KeyRepository.Age] = NYLDGeneric.GetAge(data[KeyRepository.DOB]);

            //Get Smoker option
            data[KeyRepository.Smoker] = data[KeyRepository.HQAnswers].Split('|').Last().Trim();
            if (data[KeyRepository.Smoker] == "Yes")
                smoker = Smoker_Yes;
            else
                smoker = Smoker_No;

            //Get Replacement option
            data[KeyRepository.Replacement] = testData.GetInputData("Rider Replacement Question");
            if (data[KeyRepository.Replacement] == "Yes")
                replacement = ReplacementQuestion_Yes;
            else
                replacement = ReplacementQuestion_No;

            //Page load
            NYLDSelenium.PageLoad("Rider Form", GeneralInformation_Header);

            //Select Smoker
            NYLDSelenium.Click("Smoker Option -" + data[KeyRepository.Smoker], smoker);

            //Select Height and Weight            
            NYLDSelenium.SelectList("Height_Foot", Height_Feet, data[KeyRepository.Height].Split('\'')[0]);
            NYLDSelenium.SelectList("Height_Foot", Height_Inches, data[KeyRepository.Height].Split('\'')[1].Substring(0, 1));
            NYLDSelenium.SendKeys("Weight", Weight, data[KeyRepository.Weight]);

            //Select Replacement Question           
            NYLDSelenium.Click("Replacement Question", replacement);

            //Select Health Responses //data[KeyRepository.HQAnswers] = "No|No|No|No|No|No|No";        
            string[] responses = data[KeyRepository.HQAnswers].Split('|');
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(1));
            for (int i = 0; i <= responses.Length; i++)
            {
                string answerXpath_Yes = "//label[@for = 'hq-" + i + "-y']";
                string answerXpath_No = "//label[@for = 'hq-" + i + "-n']";
                string responseXpath = "";

               var testvisible= wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(@for, 'hq') and contains(@for,'y')]"))));

                if (i < testvisible.Count)
                {
                    if (responses[i] == "Yes")
                        responseXpath = answerXpath_Yes;
                    else
                        responseXpath = answerXpath_No;

                
                    //Select Response for the quesstions
                    if (NYLDSelenium.ElemExist("Select response for the question -" + (i + 1), NYLDSelenium.GetWE(responseXpath),false,"no"))
                        NYLDSelenium.Click("Select response for the question -" + (i + 1), NYLDSelenium.GetWE(responseXpath));
                }
            }

            var countfail =  GetSettor.failCounter;
            //Select Health Impairments from datasheet
            string[] impairments = data[KeyRepository.HealthRisks].Split('|');
           

            if (!NYLDSelenium.ElemExist("Health Questions Risk", HeatthQuestionsRisk,false,"no","no","no"))
            {
                if (impairments != null)
                {
                    foreach (string impairment in impairments)
                    {
                        string impairmentXpath = "//label[contains(@for, 'QuestionRisk') and contains(text(), '" + impairment.Trim() + "')]";

                        NYLDSelenium.Click("Select Impairment -" + impairment, NYLDSelenium.GetWE(impairmentXpath));
                    }
                }
            }
            else
            {
                var Impairmentcount = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(@for, 'Risk_Y')]"))));
                bool findelement = false;

                for (int i = 1; i <= Impairmentcount.Count; i++)
                {
                    if (impairments != null && findelement == false)
                    {
                        foreach (string impairment in impairments)
                        {
                            string impairmentXpath = "//label[contains(@for, 'QuestionRisk') and contains(text(), '" + impairment.Trim() + "')]";
                            string YesElement = "(//label[contains(@for, 'Risk_Y')])[" + i + "]";

                            if (NYLDSelenium.ElemExist("Select Impairment -" + impairment, NYLDSelenium.GetWE(impairmentXpath)))
                                NYLDSelenium.Click("Select Impairment -" + impairment, NYLDSelenium.GetWE(YesElement));

                            findelement = true;
                        }
                    }
                    else
                    {
                        string NoElement = "(//label[contains(@for, 'Risk_N')])[" + i + "]";
                        NYLDSelenium.Click("Select Impairment -Option No", NYLDSelenium.GetWE(NoElement));
                    }
                }
            }
            //Enter Comments
            if (data[KeyRepository.HQComments] != "")
                NYLDSelenium.SendKeys("Comments", CommentsSection, data[KeyRepository.HQComments]);

            //Submit Rider Form
            NYLDSelenium.Click("Review and Finish", Submit_RiderForm);
            NYLDSelenium.AddHeader("Fill Rider form", "Success");
        }


        /// <summary>
        /// Method to verify the entered details in review and confirm screen
        /// </summary>
        public void VerifyReviewAndConfirmScreen()
        {
            NYLDSelenium.AddHeader("Verify Review and confirmation screen", "SubHeader");
            int startCounter = GetSettor.failCounter;

            string[] responses = data[KeyRepository.HQAnswers].Split('|');            
            string expectedResponse = "";
            CommonFunctions cmmonFunctions = new CommonFunctions(data);


            //Verify Generic information
            //cmmonFunctions.GetAddress();
            string[] generalInformation = { "First name", "Last name", "Address", "Date of birth", "Contract number", "Email", "Phone number", "Gender" };
            string[] expected_GeneralInfo = { data[KeyRepository.FirstName], data[KeyRepository.LastName], data[KeyRepository.AddressLine1], data[KeyRepository.DOB].Replace("0", ""), data[KeyRepository.PolicyNumber], data[KeyRepository.EmailId].ToLower(), data[KeyRepository.Phone].Replace(" ", ""), data[KeyRepository.InsuredGender] };

            for(int i=0; i< generalInformation.Count(); i++)
            {
                string xpath = "//p[contains(text(), '"+ generalInformation[i] + "')]/following-sibling::p";
                string actualInformation = NYLDSelenium.GetWE(xpath).Text.Replace("\r\n", " ").Replace("(", "").Replace(")", "").Replace("-", "").Trim();

                if (generalInformation[i] == "Date of birth")
                    actualInformation = actualInformation.Replace("0", "");
                if (generalInformation[i] == "Phone number")
                    actualInformation = actualInformation.Replace(" ", "");

                if (expected_GeneralInfo[i].ToLower() != actualInformation.ToLower())
                    NYLDSelenium.ReportStepResult("Mismatch in General Information section - "+ generalInformation[i], "Expected: "+ expected_GeneralInfo[i] + " \n Actual: " + actualInformation, "Fail");
            }

            //Verify Height and Weight
            NYLDSelenium.VerifyText("Height", data[KeyRepository.Height], NYLDSelenium.GetAttribute("Height_review", Height_Review).Replace(" ", "").Trim());
            NYLDSelenium.VerifyText("Weight", data[KeyRepository.Weight], NYLDSelenium.GetAttribute("Weight_review", Weight_Review).Trim());

            //Verify Smker Response
            NYLDSelenium.VerifyText("Smoker_Review", data[KeyRepository.Smoker], NYLDSelenium.GetAttribute("Smoker_Review", Responses_Review).Trim());

            //Verify Coverage
            string actualCoverage = NYLDSelenium.GetAttribute("Coverage", Coverage_Review).Split('(')[0].Trim();
            NYLDSelenium.VerifyText("Delta Coverage", data[KeyRepository.DeltaCoverage], actualCoverage.Replace("$", "").Replace(",", "").Trim());

            //Verify Replacement response
            NYLDSelenium.VerifyText("Replacement_Review", data[KeyRepository.Replacement], NYLDSelenium.GetAttribute("Replacement_Review", Replacement_Review).Trim());

            //Verify Health repsonses
            for (int i= 0; i < Health_Responses_Review.Count; i++)
            {
                if (responses[i] == "No")
                    expectedResponse = "No";
                else
                    expectedResponse = "Yes";

                string actualResponse = NYLDSelenium.GetAttribute("Response", Health_Responses_Review[i]);
                if (expectedResponse != actualResponse)
                {
                   NYLDSelenium.ReportStepResult("Mismatch found in review page", "Mimacth fro for Question No: " + i + "Expected: " + expectedResponse + " \n  Actual: " + Health_Responses_Review[i].Text.Trim(), "Fail");                    
                }

                //Verify Health Impairments selected
                if (i == 5 && expectedResponse == "Yes")
                {
                    //label[contains(text(), 'Stroke')]/../input
                    string[] impairments = data[KeyRepository.HealthRisks].Split('|');
                    if (impairments != null)
                    {
                        foreach (string impairment in impairments)
                        {
                            string impairmentXpath = "(//label[contains(text(), '" + impairment.Trim() + "')]/../input)[1]";
                            IWebElement inputElement = driver.FindElement(By.XPath(impairmentXpath));
                            if (!inputElement.Selected)
                                NYLDSelenium.ReportStepResult("Exchange option is not selected", "Exchange with coverage of " + data[KeyRepository.CoverageAmount] + "  is not selected", "Fail");
                        }
                    }
                }
            }

            //Sign and Continue
            NYLDSelenium.Click("Sign anf Continue", Sign_Continue_Reiview);

            NYLDSelenium.AddHeader("Verify Review and confirmation screen", "Success");
        }

        /// <summary>
        /// Method to review and submit the rider form
        /// </summary>
        /// <param name="args"></param>
        public void ReviewAndCertify()
        {
            NYLDSelenium.AddHeader("Verify Review and Certify Screen", "SubHeader");
            
            //Verify Certify Page load
            NYLDSelenium.PageLoad("Certify Screen", ReviewAndSubmit_Header);

            //Verify Page header name
            NYLDSelenium.VerifyText("Certify Page header", "Review and submit your application", NYLDSelenium.GetAttribute("Certify Header", ReviewAndSubmit_Header));

            //Verify Link to download PDF is available
            NYLDSelenium.ElemExist("View Application Link", ViewApplicationLink);

            //Click on Certify check
            CSWData.EventTriggerTime = DateTime.Now;
            NYLDSelenium.Click("Certify", CertifyChekbox);

            //Submit the application
            NYLDSelenium.Click("Submit certified", Submit_Certified);
            NYLDSelenium.AddHeader("Verify Review and Certify Screen", "Success");
        }       

        /// <summary>
        /// Method to verify Thank you page of E sig
        /// </summary>
        /// <param name="args"></param>
        public void VerifyThankYouPage()
        {
            TestData testdata = new TestData();
            NYLDSelenium.AddHeader("Verify Thank You page for the Rider form submission", "SubHeader");
            //Precautionary wait for page components to load
            Thread.Sleep(2000);

            //Thank you page
            NYLDSelenium.PageLoad("Esig Thank you", ThankYouHeader);

            //Get expected results from datasheet based on result column in scenario sheet
            NYLDSelenium.VerifyText("E sig Thank you header", "Thank you for applying", ThankYouBody.Text);
            //NYLDSelenium.containsText("E sig Thank you Body", EsigThankYouBody.Text, "Watch your email for important updates about your application status.");

            //Publish report
            NYLDSelenium.AddHeader("Verify Thank You page for the Rider form submission", "Success");

        }


        /// <summary>
        /// Method to verify PDF downloaded after submitting Esig form
        /// </summary>
        public void VerifyEsigApplicationPDFDownload()
        {
            //PDF validation      
            CommonFunctions commonfunctions = new CommonFunctions(data);
           

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Download PDF" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Delete Existing file
            string filePath = @"C:\Users\" + Environment.UserName + @"\Downloads";
            NYLDGeneric.DeleteFiles(filePath, "ExchangeApp*");
            NYLDGeneric.DeleteFiles(filePath, "NYLApplication*");
            NYLDGeneric.DeleteFiles(filePath, "PDFConvertedTOText.txt");


            //Click download pdf link
            //NYLDSelenium.ScrollToView(ApplicationPDFLink);
            NYLDSelenium.Click("Download PDF Link", ApplicationPDFLink);
            Thread.Sleep(10000);
        }



            /// <summary>
            /// Method to check if the contract if rider is eligible
            /// </summary>
            /// <param name="args"></param>
            public void CheckEligibility_Rider(string args)
        {

            //"https://digital-qa-1.nylaarp.nt.newyorklife.com/Life-Insurance/Term-Rider";
            NYLDSelenium.AddHeader("Rider Page Launch", "SubHeader");
            TestData testData = new TestData();
            string[] urlDetails = null;
            string type = "";

            //Fetch Exchange Url
            if (args == "")
            {
                urlDetails = testData.GetEnvionmentDetails("Findability").Split(';');
                type = "Findability";
            }
            else
            {
                urlDetails = testData.GetEnvionmentDetails("Email URL").Split(';');
                type = "Email Link";
            }
            string url = urlDetails[1];

            //Print Header
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Launch Rider Page - "+ type + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Build URL
            BuildUrl(url, type);

            //Launch URL
            url = data[KeyRepository.URL];
            driver.Navigate().GoToUrl(url);

            //Term rider page displayed
           NYLDSelenium.PageLoad("Term Rider", TermRiderEligibilityPage);
            
            //Click on Eligibility Link
                if (NYLDSelenium.ElemExist("See I'm Eligible", TermRiderCheckSeeImEligibleLink))
                    NYLDSelenium.Click("Click on See I'm Eligible", TermRiderCheckSeeImEligibleLink);
                else
                    NYLDSelenium.Click("Click on Eligibility", TermRiderCheckEligibiityLink);

            //Publish report
            NYLDSelenium.AddHeader("Rider Page Launch", "Success");
        }        
        
        /// <summary>
        /// Build the Url based on the type
        /// </summary>
        /// <param name="url"></param>
        /// <param name="type"></param>
        public void BuildUrl(string url, string type)
        {
            RestServices restService = new RestServices(data);
            LSPDatabase lspDatabase = new LSPDatabase(driver, data);

            List<string> offersList = new List<string>();
            string offers = "";

            string channel = "Term-Rider";

            //Get control Number
            lspDatabase.QueryControlNumber();

            //Build URL
            //url = data[KeyRepository.URL].Replace("/Account/Login", "") + url.Replace("{channel}", channel);
            url = data[KeyRepository.URL].Replace("/Account/Login", "").Replace("/login", "") + url.Replace("{channel}", channel);

            if (type == "Email Link")
            {
                //Get Offers listed
                restService.GetOffersAPI("Rider");                

                //Build url with Channel, State an First Name
                url = url.Replace("{channel}", "term-rider").Replace("{p1}", data[KeyRepository.State]).Replace("{p2}", data[KeyRepository.FirstName]);

                //Replace coverage and premium information
                string frequency = "", coverage = "";

                //Derive Frequency
                if (data[KeyRepository.CurrentPaymentFrequency] == "Q")
                    frequency = "quarter";
                else if (data[KeyRepository.CurrentPaymentFrequency] == "M")
                    frequency = "month";
                else if (data[KeyRepository.CurrentPaymentFrequency] == "S")
                    frequency = "semiannual";
                else if (data[KeyRepository.CurrentPaymentFrequency] == "A")
                    frequency = "annual";

                //Derive coverage
                coverage = (Convert.ToDouble(data[KeyRepository.CoverageAmount]) / 2000).ToString();

                url = url.Replace("{p3}", coverage + "%2C000").Replace("{p4}", data[KeyRepository.Premium]).Replace("{p5}", "per%20" + frequency);

                //Derive coverage and Premium for offers
                foreach (List<string> ls in CSWData.RiderInfo)
                {
                    string offerCoverage = "%24" + (Convert.ToDouble(ls[1]) / 2000).ToString() + "%2C000";
                    string offerPremium = "%24" + ls[0];

                    offersList.Add(offerCoverage + ":" + offerPremium);
                }
                offers = String.Join("|", offersList);

                //Build Url with offers
                url = url.Replace("{offers}", offers).Replace("{p6}", data[KeyRepository.ControlNumber]);                
            }

            data[KeyRepository.URL] = url;

        }

        /// <summary>
        /// Method to validate form fields of rider form
        /// </summary>
        /// <param name="args"></param>
        public void ValidateFormFields(string args)
        {
            string[] fields = { "Height", "Feet", "Weight" };
            string values = "", message = "";
            IWebElement element = null;
            IWebElement errorElement = null;
            bool list = false;

            //Assign required elements and their values with their field types
            foreach(string field in fields)
            {
                list = false;
                switch(field.Trim())
                {
                    case "Height":
                        element = Height_Feet;
                        errorElement = Height_Inches_Error;
                        values = "-;5";
                        message = "Please enter your height.";
                        list = true;
                        break;

                    case "Feet":
                        element = Height_Inches;
                        errorElement = Height_Inches_Error;
                        values = "-;9";
                        message = "Please enter your height.";
                        list = true;
                        break;

                    case "Weight":
                        element = Weight;
                        errorElement = Weight_Error;
                        values = "49,501;50,500";
                        message = "Please enter a weight between 50-500 lbs.";
                        break;

                    case "Comments":
                        element = CommentsSection;
                        errorElement = Comments_Error;
                        values = ";This test statement is to check the field validation for the term rider submit form. Comments section displayed as part of the health question is to be validated for the limitation. Number of characters text for the health and questions comments section. Text limit should not exceed 500 characters in the text box field. Field validation is to be performed and test results is to be reported. Element for error message is to be captured and the message text is to be verified as applicable for the fields.";
                        message = "Please limit your response to letters, numbers, and the following special characters: ! \" $ % &' ( ) * + , - . : < = > ? @ ^ _ ` |";
                        break;
                }

                //Segregate valid an invalid values
                string[] valid = values.Split(';')[1].Split(',');
                string[] invalid = values.Split(';')[0].Split(',');

                //Loop through invalid values and verify error message
                foreach(string value in invalid)
                {
                    if (list)
                    {
                        if (value == "-")
                        {
                            SelectElement oSelect = new SelectElement(element);
                            oSelect.SelectByText(value);
                        }
                        else
                        NYLDSelenium.SelectList(field, element, value);
                    }
                    else
                        NYLDSelenium.SendKeys(field, element, value);
                    
                    //Click on submit
                    NYLDSelenium.Click("Review and Finish", Submit_RiderForm);

                    //Verify Error message
                    if (NYLDSelenium.ElemExist(field + " Error message", element, false, "no", "no"))
                        NYLDSelenium.VerifyText(field + " Error message", message, element.Text, "yes");
                }

                //Loop through invalid value and verify no error message is displayed
                foreach (string value in valid)
                {
                    if (list)
                    {
                        if (value == "-")
                        {
                            SelectElement oSelect = new SelectElement(element);
                            oSelect.SelectByText(value);
                        }
                        else
                            NYLDSelenium.SelectList(field, element, value);
                    }
                    else
                        NYLDSelenium.SendKeys(field, element, value);

                    //Click on submit
                    NYLDSelenium.Click("Review and Finish", Submit_RiderForm);

                    //Verify error message is not displayed
                    NYLDSelenium.ElemNotExist(field + " Error message", errorElement);
                }
            }
        }
    }
}
