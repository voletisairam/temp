﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using System.Threading;
using CSW.PageObjects.Login;
using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.PageObjects.Payments;
using CSW.PageObjects.Home;
using CSW.PageObjects.Functions;
using CSW.Drivers;
using Spire.Pdf.Graphics;

namespace CSW.PageObjects.Coverage
{
    //TODO: Lets create seperate class of this
    class PolicyDetails
    {
        public static string index;
        public string contractName;
        public string contractNumber;
        public string coverageAmount;
        public string effectiveDate;
        public string paymentDue;
        public string policyStatus;
        public string actStatusInfo;
        public string statusInfoBubble;
        public string viewDetailsLink;
        public string makePaymentButton;
        public string shadowBox;
        public string paymentDueInformation;
        public string ViewContractLink;

        public PolicyDetails(string level)
        {
            if (level != "")
                index = level;

            string cardClass = "//section//div[contains(@class,'shadow')][";
            string cardClassIndex = cardClass + index;
            contractName = cardClassIndex + "]//*[@class='card-title']";
            contractNumber = cardClassIndex + "]//*[contains(@class,'card-subtitle')]";
            //Coverage Amount
            coverageAmount = cardClassIndex + "]//ul/li[1]";
            //Effective date
            effectiveDate = cardClassIndex + "]//ul/li[2]";
            // Payment Due
            paymentDue = cardClassIndex + "]//ul/li[3]";
            //Status
            policyStatus = cardClassIndex + "]//ul/li[4]";
            //status info
            actStatusInfo = cardClassIndex + "]//ul/li[4]/i";
            //status info bubble
            statusInfoBubble = cardClassIndex + "]//ul/li[4]/i";
            viewDetailsLink = cardClassIndex + "]//a[contains(@href,'Detail')]";
            makePaymentButton = cardClassIndex + "]//a[1]";
            paymentDueInformation = cardClassIndex + "]//div[@class='pt-4']";
            shadowBox = cardClassIndex + "][contains(@class,'card')]";
            ViewContractLink = cardClassIndex + "]//a[contains(@href,'ViewContract')]";
        }
    }

    class SummaryPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public SummaryPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////


        [FindsBy(How = How.XPath, Using = "//a[contains(@data-ea-zone, 'Top Nav')]/img[contains(@src,'NYLAARP_logo')]")]
        public IWebElement Logo { get; set; }

        [FindsBy(How = How.XPath, Using = "//section//div[contains(@class,'shadow')]//*[@class='card-title']")]
        public IList<IWebElement> NoOfContractsDisplayed { get; set; }

        [FindsBy(How = How.XPath, Using = "//footer/div[@class='container']/p")]
        public IList<IWebElement> Disclaimer { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href,'FAQ') and contains(text(), 'Frequently')]")]
        public IWebElement FAQLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[text() = 'FAQs']")]
        public IWebElement FAQPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Back to dash')]")]
        public IWebElement BackToDashboardLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'View my contract')]")]
        public IWebElement ViewContractLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='row bg-pale-lt-pine shadow mb-3 p-3']")]
        public IWebElement ImpNoticeDisplayed { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='viewer']")]
        public IWebElement PdfView { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), '©')]")]
        public IWebElement CopyRight { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[contains(@data-ea-type, 'Footer Link')])[2]")]
        public IWebElement QuickLinksMoveto { get; set; }

        public string QuickLinks = "//*[@class='list-unstyled global-foot']/li/a";

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'View coverage details')]/..//a[contains(@href, 'Coverage/Detail')]")]
        public IWebElement ViewCoverageLink { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Methods    ///////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifySummaryPage                                                                           ////////////
        ////// Description: verify all the details of the summary page, page representation and navigation links ////////////
        ////////             also verify the details page of each contract                                      /////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
        public void VerifySummaryPage(string args)
        {
            //HeaderandFooter HF = new HeaderandFooter(driver);
            LSPDatabase DB = new LSPDatabase(driver, data);
            HomePage home = new HomePage(driver, data);
            LoginPage login = new LoginPage(driver, data);
            DetailsPage DP = new DetailsPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            //FAQsPage FAQ = new FAQsPage(driver);
            TestData testData = new TestData();
            bool viewcoverageEligible;
            string tempPolicyNumber = data[KeyRepository.PolicyNumber];
            int expectedNumbOfPolicies;
            string[] expectedPolicyList;
            string userName;

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Dashboard Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Query Associated policies and sort the policy list
            DB.QueryAssociatedPolicies("SummaryPage");
            CF.SortContracts(CSWData.AssociatedPolicies);
            DB.QueryAssociatedPolicies();
            data[KeyRepository.PolicyNumber] = tempPolicyNumber;

            expectedPolicyList = CSWData.TempVal.Split(',');

            NYLDSelenium.PageLoad("Dashboard", home.SummaryPage);

            //verify the count of policies

            if (expectedPolicyList.Length > 40)
                expectedNumbOfPolicies = 40;
            else
                expectedNumbOfPolicies = expectedPolicyList.Length;
            if (NoOfContractsDisplayed.Count() != expectedNumbOfPolicies)
            {
                if (NoOfContractsDisplayed.Count() > expectedNumbOfPolicies)
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is more than the Expected policy count", "Fail");
                else
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is less than the Expected policy count", "Fail");
            }
            //verify full name
            DB.QueryPolicyDetails();

            //Click on My account drop down and verify user name
            if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded", false, "no", "no") != "true")
                NYLDSelenium.Click("My Account", home.MyAccountDropDown);
            Thread.Sleep(2000);
            userName = "Welcome, " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];
            Thread.Sleep(1000);

            //Verify if Welcome Header is populatede correctly
            //TODO: How it will look for NoPolicyContract condition - I believe owner name still displayed?
            if (args != "Payments" && data[KeyRepository.ContractType] != "NoPolicyContract")
                NYLDSelenium.VerifyText("Welcome Header", "welcome, " + data[KeyRepository.FirstName].ToLower().Trim(), home.WelcomeUser.Text.ToLower().Trim(), "always", "always");

            //Click on My account drop down and verify user name
            if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded", false, "no", "no") == "true")
                NYLDSelenium.Click("My Account", home.MyAccountDropDown);

            IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-2000);");
            //TODO: This should go to common header/footer class
            if (args == "Detailed")
            {
                NYLDSelenium.AddHeader("SummaryPage Detailed - " + data[KeyRepository.PolicyNumber], "SubHeader");
                //verify logo and Logout option
                NYLDSelenium.ElemExist("Logo", Logo);

                //verify FAQ link display and navigates to corresponding page
                NYLDSelenium.ElemExist("FAQ icon", FAQLink);
                NYLDSelenium.Click("FAQ icon ", FAQLink);

                NYLDSelenium.PageLoad("FAQ", FAQPage);
                NYLDSelenium.VerifyText(" FAQ Page", "FAQs", FAQPage.Text, "always", "always");
                home.NavigateToPage(KeyRepository.CoveragePage);

                Thread.Sleep(1000);

                NYLDSelenium.PageLoad("Dashboard", home.SummaryPage);
                //Footer links
                NYLDSelenium.ElemExist("Dashboard-I want to & Footer links", QuickLinksMoveto, true, "no");
                CF.ValidateIWantToLinks("Dashboard-I want to & Footer links", QuickLinks);
                //notes and copyright at the bottom 

                js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,+2000);");
                NYLDSelenium.VerifyText("Disclaimer text", testData.GetContent("Copyright - Disclaimer Text").ToString().Trim(), CF.FormatString(NYLDSelenium.GetAttribute("Disclaimer", Disclaimer[0]) + " " + NYLDSelenium.GetAttribute("Disclaimer", Disclaimer[1])).Trim(), "always");
                NYLDSelenium.VerifyText("Copyright text", testData.GetContent("Copyright - Copyright Text").ToString().Trim(), CF.FormatString(NYLDSelenium.GetAttribute("Copyright", CopyRight)).Trim(), "always");

                NYLDSelenium.AddHeader("SummaryPage Detailed - " + data[KeyRepository.PolicyNumber], "Success");
            }

            js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-2000);");
            //Stop Test from further progress if Test data is not Multi contract
            if (data[KeyRepository.ContractCount].Contains("Multi"))
            {
                if (CSWData.AssociatedPolicies.Count() <= 1)
                    NYLDSelenium.ReportStepResult("Verify " + data[KeyRepository.PolicyNumber] + " is a Multi contract policy", "User does not have multiple policies, data sheet needs to be udpated with valid policy number", "Fail", "always", "yes");
            }

            //No of policies listed in summary page
            if (NoOfContractsDisplayed.Count() > 40)
                NYLDSelenium.ReportStepResult("Verify the number of contracts displayed in the Dashboard page", "Dashboard page is displaying more than 25 contracts", "Fail", "always");

            //if Multi contract or Family contract verify the summary page and details page for every contract
            if (data[KeyRepository.ContractType].Contains("Multi") || data[KeyRepository.ContractType].Contains("FamilyBillContract"))
            {
                bool verifyPage = false;
                int ch = NoOfContractsDisplayed.Count();

                Thread.Sleep(3000);
                //TODO added for policy payment remainder message    
                int k = Convert.ToInt32(DetailsInfolink());
                js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);");
                for (int i = k; i <= NoOfContractsDisplayed.Count(); i++)
                {
                    PolicyDetails PI = new PolicyDetails(i.ToString());

                    js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);");

                    Thread.Sleep(1000);

                    //Contract Name and Number
                    string contractName = CF.FormatString(NYLDSelenium.GetAttribute("Contract Name", NYLDSelenium.GetWE(PI.contractName, true, 0)));
                    data[KeyRepository.PolicyNumber] = NYLDSelenium.GetAttribute("Contract Number", NYLDSelenium.GetWE(PI.contractNumber, true, 0)).Split(':')[1].Trim();

                    //query policy and paycode details
                    DB.QueryPolicyDetails();
                    DB.QueryPaymentDetails();
                    CF.GetContractCardcolor();
                    viewcoverageEligible = DB.GetViewByCoverageEligible();

                    Thread.Sleep(1000);

                    //verify the order of display of the contracts
                    if (args == "Detailed" || args == "")
                        verifyPage = true;
                    else if (args == "GoodValue" && data[KeyRepository.PayCode] == "NN")
                        verifyPage = true;
                    else if (i == NoOfContractsDisplayed.Count() && !verifyPage)
                        NYLDSelenium.ReportStepResult("Could not find the policy to verify coverage", "Policy with matching criteria could not be found, criteria: " + args, "Fail", "always", "yes");

                    if (verifyPage)
                    {
                        NYLDSelenium.AddHeader("Verify Multicontract Dashboard Page details for policy  - " + data[KeyRepository.PolicyNumber], "SubHeader");
                        Thread.Sleep(1000);
                        //Due to extra banner in dashboard page
                        int j = 0; j = i;
                        if (Convert.ToInt32(DetailsInfolink()) == 2)
                        {
                            j = j - 1;
                            k = 1;
                        }

                        if (!(expectedPolicyList[j - k] == data[KeyRepository.PolicyNumber]))
                            NYLDSelenium.ReportStepResult("Verify the order of display of the contracts", "Contract Number: " + data[KeyRepository.PolicyNumber] + " is displayed, Contract Number: " + expectedPolicyList[j - k] + " is expected as per the policy display order", "Fail", "always");

                        //verify contract name & numb, coverage amount, effective date, payment date & status                   
                        NYLDSelenium.VerifyText("contract Name", data[KeyRepository.PolicyName], contractName, "always");
                        //Contains TExt
                        NYLDSelenium.VerifyText("coverage amount ", CF.FormatString(NYLDSelenium.GetAttribute("Coverage Amount", NYLDSelenium.GetWE(PI.coverageAmount, true, 0))), "Coverage Amount: $" + string.Format("{0:n0}", Convert.ToInt32(data[KeyRepository.CoverageAmount])), "always");
                        Thread.Sleep(500);
                        NYLDSelenium.VerifyText("effective date ", "Effective Date: " + Convert.ToDateTime(data[KeyRepository.EffectiveDate]).ToString("M/d/yyy"), CF.FormatString(NYLDSelenium.GetAttribute("Effective Date", NYLDSelenium.GetWE(PI.effectiveDate, true, 0))), "always");
                        Thread.Sleep(2000);
                        //get payment due 
                        string expectedPaymentDue;
                        if (data[KeyRepository.PayCode] == "NN")
                            expectedPaymentDue = "Payment Due: No Premium Due:";
                        else if (data[KeyRepository.PolicyStatus] == "Inforce" || data[KeyRepository.PolicyStatus] == "Lapse")
                        {
                            if (data[KeyRepository.ContractCardColor] == "Red" || data[KeyRepository.ContractCardColor] == "Grey")
                                expectedPaymentDue = "Past Due: " + Convert.ToDateTime(data[KeyRepository.PaidToDate]).ToString("M/d/yyy");
                            else
                                expectedPaymentDue = "Payment Due: " + Convert.ToDateTime(data[KeyRepository.PaidToDate]).ToString("M/d/yyy");
                        }
                        else
                            expectedPaymentDue = "Payment Due: " + Convert.ToDateTime(data[KeyRepository.PaidToDate]).ToString("M/d/yyy");

                        //verify Due amount, Status, status description and View details display
                        NYLDSelenium.VerifyText("payment due ", expectedPaymentDue, CF.FormatString(NYLDSelenium.GetAttribute("Payment due", NYLDSelenium.GetWE(PI.paymentDue, true, 0))));
                        NYLDSelenium.VerifyText("policy status ", "Status: " + data[KeyRepository.PolicyStatus], CF.FormatString(NYLDSelenium.GetAttribute("Policy status", NYLDSelenium.GetWE(PI.policyStatus, true, 0))).Replace("  ", " "));
                        NYLDSelenium.ElemExist("status bubble", NYLDSelenium.GetWE(PI.statusInfoBubble, true, 0));
                        Thread.Sleep(1000);
                        //Contract Name and Number
                        NYLDSelenium.VerifyText("status information", testData.GetContent(data[KeyRepository.PolicyStatus].Trim()).ToLower(), CF.FormatString(NYLDSelenium.GetAttribute("Status Info", NYLDSelenium.GetWE(PI.actStatusInfo, true, 0), "data-original-title")).Trim().ToLower());
                        NYLDSelenium.ElemExist("View Details link", NYLDSelenium.GetWE(PI.viewDetailsLink, true, 0));

                        //Verify View my Coverage elligible
                        if (viewcoverageEligible)
                        {
                            VerifyWelcomKitPDF(PI.ViewContractLink);
                            CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
                            CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
                        }

                        //Verify Contract card color
                        string actualContractCardColor = NYLDSelenium.GetAttribute("Payment Button Source", NYLDSelenium.GetWE(PI.shadowBox), "class");
                        NYLDSelenium.VerifyText("Contract Card color", data[KeyRepository.ContractCardColor], CF.GetActualContractCardColor(actualContractCardColor), "always", "always");

                        //Verify Paument due inforamtion
                        if (data[KeyRepository.PaymentDueAbove52] == "true" && data[KeyRepository.PayCode] != "NN" && data[KeyRepository.ContractCardColor] != "White" && data[KeyRepository.ContractCardColor] != "Grey")
                        {
                            if (!NYLDSelenium.ElemExist("Past Due information", NYLDSelenium.GetWE(PI.paymentDueInformation), false, "no", "no"))
                                NYLDSelenium.ReportStepResult("Payment Due informtion not displayed", "Past due information is not displayed for the contract", "Fail");
                            else
                                CF.VerifyPaymentDueInformation(CF.FormatString(NYLDSelenium.GetAttribute("Due information", NYLDSelenium.GetWE(PI.paymentDueInformation))));
                        }
                        NYLDSelenium.AddHeader("Verify Multicontract Dashboard Page details for policy  - Contract Name & Number, Coverage amount, Effective date, Payment due amount, Policy status & status bubble information and View details link verification in summary page was successful for policy" + data[KeyRepository.PolicyNumber], "Success");
                        ////Close Account panel
                        //if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded", "no", "no", false, 30) == "true")
                        //    NYLDSelenium.Click("My Coverage", home.MyAccountDropDown);

                        //verify details page
                        Thread.Sleep(2000);
                        NYLDSelenium.Click("View Coverage Details", NYLDSelenium.GetWE(PI.viewDetailsLink, true, 0));
                        DP.VerifyDetailsPage("");

                        //Return to Summary page
                        home.NavigateToPage(KeyRepository.CoveragePage);
                        NYLDSelenium.PageLoad("Life Insurance overview", home.SummaryPage);
                    }
                }
            }
            else
            {
                PolicyDetails PI = new PolicyDetails(DetailsInfolink());

                //   //Close Account panel
                //if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded", "yes", "yes", false, 30) == "true")
                //       NYLDSelenium.Click("My Coverage", home.MyAccountDropDown);

                //verify details page
                Thread.Sleep(2000);
                //query policy and paycode details
                DB.QueryPolicyDetails();
                DB.QueryPaymentDetails();
                CF.GetContractCardcolor();
                viewcoverageEligible = DB.GetViewByCoverageEligible();
                //Verify View my Coverage elligible
                if (viewcoverageEligible)
                {
                    VerifyWelcomKitPDF(PI.ViewContractLink);
                    CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
                    CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
                }

                //Back to dashboard page
                NYLDSelenium.Click("View Details", NYLDSelenium.GetWE(PI.viewDetailsLink, true, 0));
                DP.VerifyDetailsPage("");

            }


        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
        public void VerifySummaryPageInfo(string args)
        {
            //TODO: Lets find ways to break up this method

            //HeaderandFooter HF = new HeaderandFooter(driver);
            LSPDatabase DB = new LSPDatabase(driver, data);
            HomePage home = new HomePage(driver, data);
            LoginPage login = new LoginPage(driver, data);
            DetailsPage DP = new DetailsPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            //FAQsPage FAQ = new FAQsPage(driver);
            TestData testData = new TestData();
            string tempPolicyNumber = data[KeyRepository.PolicyNumber];
            int expectedNumbOfPolicies;
            //string disclaimer = "New York Life Insurance Company pays royalty fees to AARP for the use of its intellectual property. These fees are used for the general purposes of AARP. AARP and its affiliates are not insurers. AARP has established the AARP Life Insurance Trust to hold group life insurance policies for the benefit of AARP members. The AARP Life Insurance Program is underwritten by New York Life Insurance Company, New York, NY 10010. AARP membership is required for Program eligibility. Specific products, features and/or gifts not available in all states or countries. New York Life Insurance Company is licensed in all 50 states. Complete terms and conditions are set forth in the group policy issued by New York Life to the Trustee of the AARP Life Insurance Trust. Young Start is a service mark of New York Life Insurance Company.";
            //string copyright = "© 2020 New York Life Insurance Company. All rights reserved.";
            string[] expectedPolicyList;
            string userName;

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Dahboard Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Query Associated policies and sort the policy list
            DB.QueryAssociatedPolicies("SummaryPage");
            CF.SortContracts(CSWData.AssociatedPolicies);
            DB.QueryAssociatedPolicies();
            data[KeyRepository.PolicyNumber] = tempPolicyNumber;

            expectedPolicyList = CSWData.TempVal.Split(',');

            NYLDSelenium.PageLoad("Summary", home.SummaryPage);

            if (expectedPolicyList.Length > 40)
                expectedNumbOfPolicies = 40;
            else
                expectedNumbOfPolicies = expectedPolicyList.Length;
            if (NoOfContractsDisplayed.Count() != expectedNumbOfPolicies)
            {
                if (NoOfContractsDisplayed.Count() > expectedNumbOfPolicies)
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is more than the Expected policy count", "Fail");
                else
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is less than the Expected policy count", "Fail");
            }
            //verify full name
            DB.QueryPolicyDetails();

            //Click on My account drop down and verify user name
            if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded", false, "no", "no") != "true")
                NYLDSelenium.Click("My Account", home.MyAccountDropDown);

            userName = "Welcome, " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];
            Thread.Sleep(1000);

            //Verify if Welcome Header is populatede correctly
            //TODO: How it will look for NoPolicyContract condition - I believe owner name still displayed?
            if (args != "Payments" && data[KeyRepository.ContractType] != "NoPolicyContract")
                NYLDSelenium.VerifyText("Welcome Header", "welcome, " + data[KeyRepository.FirstName].ToLower().Trim(), home.WelcomeUser.Text.ToLower().Trim(), "always", "always");

            //Click on My account drop down and verify user name
            if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded", false, "no", "no") == "true")
                NYLDSelenium.Click("My Account", home.MyAccountDropDown);

            //Stop Test from further progress if Test data is not Multi contract
            if (data[KeyRepository.ContractCount].Contains("Multi"))
            {
                if (CSWData.AssociatedPolicies.Count() <= 1)
                    NYLDSelenium.ReportStepResult("Verify " + data[KeyRepository.PolicyNumber] + " is a Multi contract policy", "User does not have multiple policies, data sheet needs to be udpated with valid policy number", "Fail", "always", "yes");
            }
        }

        /// <summary>
        /// Method helps to navigate on details page based on important notice 
        /// </summary>
        /// <returns></returns>
        public string DetailsInfolink()
        {
            //TODO added for policy payment remainder message
            string index = "1";
            if (NYLDSelenium.ElemExist("Important Notice", ImpNoticeDisplayed, false, "no", "no", "no", 30))
            {
                index = Convert.ToString(Convert.ToInt32(index) + 1);
            }
            Console.WriteLine("Verify Important Notice :" + Convert.ToInt32(index));
            return index;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifySummaryPageContractElligible                                                                           ////////////
        ////// Description: verify all the details of the summary page, page representation and navigation links ////////////
        ////////             also verify the details page of each contract                                      /////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
        public void VerifySummaryPageContractElligible(string args)
        {
            //TODO: Lets find ways to break up this method

            //HeaderandFooter HF = new HeaderandFooter(driver);
            LSPDatabase DB = new LSPDatabase(driver, data);
            HomePage home = new HomePage(driver, data);
            LoginPage login = new LoginPage(driver, data);
            DetailsPage DP = new DetailsPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            //FAQsPage FAQ = new FAQsPage(driver);
            TestData testData = new TestData();

            string tempPolicyNumber = data[KeyRepository.PolicyNumber];
            int expectedNumbOfPolicies;
            bool viewcoverageEligible;
            //string disclaimer = "New York Life Insurance Company pays royalty fees to AARP for the use of its intellectual property. These fees are used for the general purposes of AARP. AARP and its affiliates are not insurers. AARP has established the AARP Life Insurance Trust to hold group life insurance policies for the benefit of AARP members. The AARP Life Insurance Program is underwritten by New York Life Insurance Company, New York, NY 10010. AARP membership is required for Program eligibility. Specific products, features and/or gifts not available in all states or countries. New York Life Insurance Company is licensed in all 50 states. Complete terms and conditions are set forth in the group policy issued by New York Life to the Trustee of the AARP Life Insurance Trust. Young Start is a service mark of New York Life Insurance Company.";
            //string copyright = "© 2020 New York Life Insurance Company. All rights reserved.";
            string[] expectedPolicyList;
            string userName;

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Dashboard Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Query Associated policies and sort the policy list
            DB.QueryAssociatedPolicies("SummaryPage");
            CF.SortContracts(CSWData.AssociatedPolicies);
            DB.QueryAssociatedPolicies();
            data[KeyRepository.PolicyNumber] = tempPolicyNumber;

            expectedPolicyList = CSWData.TempVal.Split(',');

            NYLDSelenium.PageLoad("Dashboard", home.SummaryPage);

            //verify the count of policies

            if (expectedPolicyList.Length > 40)
                expectedNumbOfPolicies = 40;
            else
                expectedNumbOfPolicies = expectedPolicyList.Length;
            if (NoOfContractsDisplayed.Count() != expectedNumbOfPolicies)
            {
                if (NoOfContractsDisplayed.Count() > expectedNumbOfPolicies)
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is more than the Expected policy count", "Fail");
                else
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is less than the Expected policy count", "Fail");
            }

            //verify full name
            DB.QueryPolicyDetails();
            userName = "Welcome, " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName];


            //Stop Test from further progress if Test data is not Multi contract
            if (data[KeyRepository.ContractCount].Contains("Multi"))
            {
                if (CSWData.AssociatedPolicies.Count() <= 1)
                    NYLDSelenium.ReportStepResult("Verify " + data[KeyRepository.PolicyNumber] + " is a Multi contract policy", "User does not have multiple policies, data sheet needs to be udpated with valid policy number", "Fail", "always", "yes");
            }

            //No of policies listed in summary page
            if (NoOfContractsDisplayed.Count() > 40)
                NYLDSelenium.ReportStepResult("Verify the number of contracts displayed in the Dashboard page", "Dashboard page is displaying more than 25 contracts", "Fail", "always");


            //if Multi contract or Family contract verify the summary page and details page for every contract
            if (data[KeyRepository.ContractType].Contains("Multi") || data[KeyRepository.ContractType].Contains("FamilyBillContract"))
            {
                int ch = NoOfContractsDisplayed.Count();
                var c = Convert.ToInt32(DetailsInfolink());
                for (int i = c; i <= NoOfContractsDisplayed.Count(); i++)
                {
                    PolicyDetails PI = new PolicyDetails(i.ToString());
                    //Contract Name and Number
                    string contractName = CF.FormatString(NYLDSelenium.GetAttribute("Contract Name", NYLDSelenium.GetWE(PI.contractName, true, 0)));
                    data[KeyRepository.PolicyNumber] = NYLDSelenium.GetAttribute("Contract Number", NYLDSelenium.GetWE(PI.contractNumber, true, 0)).Split(':')[1].Trim();

                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Multicontract Dashboard Page details for policy - " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                    //query policy and paycode details
                    DB.QueryPolicyDetails();
                    DB.QueryPaymentDetails();
                    CF.GetContractCardcolor();
                    viewcoverageEligible = DB.GetViewByCoverageEligible();

                    Thread.Sleep(1000);
                    //Due to extra banner in dashboard page
                    int j = 0; j = i;
                    if (Convert.ToInt32(DetailsInfolink()) == 2)
                    {
                        j = j - 1;
                        c = 1;
                    }
                    if (!(expectedPolicyList[j - c] == data[KeyRepository.PolicyNumber]))
                        NYLDSelenium.ReportStepResult("Verify the order of display of the contracts", "Contract Number: " + data[KeyRepository.PolicyNumber] + " is displayed, Contract Number: " + expectedPolicyList[j - c] + " is expected as per the policy display order", "Fail", "always");

                    //verify contract name & numb, coverage amount, effective date, payment date & status                   
                    NYLDSelenium.VerifyText("contract Name", data[KeyRepository.PolicyName], contractName, "always");
                    //Contains TExt
                    NYLDSelenium.VerifyText("coverage amount ", CF.FormatString(NYLDSelenium.GetAttribute("Coverage Amount", NYLDSelenium.GetWE(PI.coverageAmount, true, 0))), "Coverage Amount: $" + string.Format("{0:n0}", Convert.ToInt32(data[KeyRepository.CoverageAmount])), "always");
                    Thread.Sleep(500);
                    NYLDSelenium.VerifyText("effective date ", "Effective Date: " + Convert.ToDateTime(data[KeyRepository.EffectiveDate]).ToString("M/d/yyy"), CF.FormatString(NYLDSelenium.GetAttribute("Effective Date", NYLDSelenium.GetWE(PI.effectiveDate, true, 0))), "always");
                    Thread.Sleep(2000);
                    if (viewcoverageEligible)
                    {
                        VerifyWelcomKitPDF(PI.ViewContractLink);
                    }
                }
            }
            else
            {
                PolicyDetails PI = new PolicyDetails(1.ToString());
                //Contract Name and Number
                string contractName = CF.FormatString(NYLDSelenium.GetAttribute("Contract Name", NYLDSelenium.GetWE(PI.contractName, true, 0)));
                data[KeyRepository.PolicyNumber] = NYLDSelenium.GetAttribute("Contract Number", NYLDSelenium.GetWE(PI.contractNumber, true, 0)).Split(':')[1].Trim();

                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Singlecontract Dashboard Page details for policy - " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                //query policy and paycode details
                DB.QueryPolicyDetails();
                DB.QueryPaymentDetails();
                CF.GetContractCardcolor();
                viewcoverageEligible = DB.GetViewByCoverageEligible();

                if (!(expectedPolicyList[1 - 1] == data[KeyRepository.PolicyNumber]))
                    NYLDSelenium.ReportStepResult("Verify the order of display of the contracts", "Contract Number: " + data[KeyRepository.PolicyNumber] + " is displayed, Contract Number: " + expectedPolicyList[1 - 1] + " is expected as per the policy display order", "FAIL", "always", "yes");

                //verify contract name & numb, coverage amount, effective date, payment date & status                   
                NYLDSelenium.VerifyText("contract Name", data[KeyRepository.PolicyName], contractName);
                //Contains TExt
                NYLDSelenium.VerifyText("coverage amount ", CF.FormatString(NYLDSelenium.GetAttribute("Coverage Amount", NYLDSelenium.GetWE(PI.coverageAmount, true, 0))), "Coverage Amount: $" + string.Format("{0:n0}", Convert.ToInt32(data[KeyRepository.CoverageAmount])));
                Thread.Sleep(500);
                NYLDSelenium.VerifyText("effective date ", "Effective Date: " + Convert.ToDateTime(data[KeyRepository.EffectiveDate]).ToString("M/d/yyy"), CF.FormatString(NYLDSelenium.GetAttribute("Effective Date", NYLDSelenium.GetWE(PI.effectiveDate, true, 0))));
                Thread.Sleep(2000);
                if (viewcoverageEligible)
                {
                    VerifyWelcomKitPDF(PI.ViewContractLink);
                }

                CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
                CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
            }
        }

        /// </summary>
        public void VerifyWelcomKitPDF(string ViewContractLink = "")
        {
            if(ViewContractLink == "")
                ViewContractLink = "//a[contains(text(), 'View my contract')]";
            //PDF validation      
            CommonFunctions commonfunctions = new CommonFunctions(data);
            ValidatePDF validatePdf = new ValidatePDF(driver, data);

            //Delete Existing file
            string filePath = @"C:\Users\" + Environment.UserName + @"\Downloads";
            // commonfunctions.DeleteAllPDFFiles(filePath);
            NYLDGeneric.DeleteFiles(filePath, "ViewContract*");

            //If the Survey window pops up
            Thread.Sleep(300);
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            //TODO: This template type need to be driven from spreadsheet?
            data[KeyRepository.TemplateType] = "3628-00-NAT";
            //If the Survey window pops up
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            if (NYLDSelenium.ElemExist("ViewContract", NYLDSelenium.GetWE(ViewContractLink, true, 0)))
            {
                NYLDSelenium.ReportStepResult("Verify 'View my Contract' button is displayed in  Dashboard page", "'View my Contract' button is displayed in Dashboard page", "Pass", "always", "no");
            }
            else
                NYLDSelenium.ReportStepResult("User Unable to find  'View my Contract' button in Dashboard page", "User Unable to find 'view my Contract' button in Dashboard page", "Fail", "always", "yes");

            NYLDSelenium.Click("View Contract", NYLDSelenium.GetWE(ViewContractLink, true, 0));
            CommonFunctions.WindowsTabFocus("NavigateNewTab", "newTabInstance");
            Thread.Sleep(50000);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify View my contract PDF Page loaded" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            if (driver.Url.Contains("ViewContract/Download?fKey"))
            {
                NYLDSelenium.ReportStepResult("WelcomeLetter PDF is loaded", "View PDF page is loaded", "Pass", "always", "no");
                Thread.Sleep(50000);
            }
            else
                NYLDSelenium.ReportStepResult("WelcomeLetter PDF is not loaded", "View PDF page is not loaded", "Fail", "always", "yes");
            //TODO PDF is not working at application level need to look into

            //Print the Template type
            // NYLDSelenium.ReportStepResult("Esig PDF: Control Number Validation", "Template type of PDF is: " + data[KeyRepository.TemplateType], "INFO", "no");

            //Verify PDF
            validatePdf.VerifyContractViewPDFFormContent();
        }



        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verify25Multis                                                                      ////////////
        ////// Description: verify summary page of a multicontract with more than 25 associated contracts        ////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void Verify25Multis(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            int expectedNumbOfPolicies;
            //Query Associated policies
            DB.QueryAssociatedPolicies("SummaryPage");

            string[] expectedPolicyList;


            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Multicontracts with 40 policies" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Stop Test from further progress if Test data is not Multi contract
            if (data[KeyRepository.ContractType].Contains("Multi") && CSWData.AssociatedPolicies.Count() <= 1)
                NYLDSelenium.ReportStepResult("Verify " + data[KeyRepository.PolicyNumber] + " is a Multi contract policy", "User does not have multiple policies, data sheet needs to be udpated with valid policy number", "Fail", "always", "yes");

            //No of policies listed in summary page
            if (NoOfContractsDisplayed.Count() > 40)
                NYLDSelenium.ReportStepResult("Verify the number of contracts displayed in the Summary page", "Summary page is displaying more than 40 contracts", "Fail", "always");

            //sort contracts
            CF.SortContracts(CSWData.AssociatedPolicies);
            expectedPolicyList = CSWData.TempVal.Split(',');

            //verify the count of policies
            if (expectedPolicyList.Length > 40)
                expectedNumbOfPolicies = 40;
            else
                expectedNumbOfPolicies = expectedPolicyList.Length;
            if (NoOfContractsDisplayed.Count() != expectedNumbOfPolicies)
            {
                if (NoOfContractsDisplayed.Count() > expectedNumbOfPolicies)
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is more than the Expected policy count", "Fail");
                else
                    NYLDSelenium.ReportStepResult("Verify count of Actual and Expected number of policies", "Actual Policy count displayed is less than the Expected policy count", "Fail");
            }
            NYLDSelenium.AddHeader("Verify sort order of policies", "SubHeader");
            //Unncessary Records remove from tampa
            List<string> expectedPolicyRemoveafterList = new List<string>(expectedPolicyList);
            expectedPolicyRemoveafterList.Remove("A21312877");
            expectedPolicyRemoveafterList.Remove("A21312878");
            expectedPolicyRemoveafterList.Remove("A21314237");
            expectedPolicyRemoveafterList.Remove("A21316904");
            expectedPolicyRemoveafterList.Remove("A21316111");

            var k = Convert.ToInt32(DetailsInfolink());
            for (int i = k; i < NoOfContractsDisplayed.Count(); i++)
            {
                PolicyDetails PI = new PolicyDetails(i.ToString());
                data[KeyRepository.PolicyNumber] = CF.FormatString(NYLDSelenium.GetAttribute("Contract Name and Number", NYLDSelenium.GetWE(PI.contractNumber, true, 0))).Split(':')[1].Trim();

                Thread.Sleep(1000);
                //Due to extra banner in dashboard page
                int j = 0;
                j = i;

                if (Convert.ToInt32(DetailsInfolink()) == 2)
                {
                    j = j - 1;
                    k = 1;
                }

                //verify the order of display of the contracts
                if (!(expectedPolicyRemoveafterList[j - k] == data[KeyRepository.PolicyNumber]))
                {
                    //Console.WriteLine("Verify the order of display of the contracts"+ "Contract Number: " + data[KeyRepository.PolicyNumber] + " is displayed, Contract Number: " + expectedPolicyList[i - 1] + " is expected as per the policy display order");
                    NYLDSelenium.ReportStepResult("Verify the order of display of the contracts", "Contract Number: " + data[KeyRepository.PolicyNumber] + " is displayed, Contract Number: " + expectedPolicyRemoveafterList[j - k] + " is expected as per the policy display order", "FAIL", "always", "yes");
                }
                if (i == 40)
                    break;
            }
            NYLDSelenium.AddHeader("Verify sort order of policies", "Success");
        }       

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SelectContract                                                                             ////////////
        ////// Description: Select the contract from details page based on criteria requested                   ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void SelectContract(string criteria)
        {
            CommonFunctions CF = new CommonFunctions(data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            bool contractEligibility = false;
            DB.QueryAssociatedPolicies();

            //select contract based on criteria
            var G = Convert.ToInt32(DetailsInfolink());
            for (int i = G; i <= NoOfContractsDisplayed.Count(); i++)
            {
                //Contract Name and Number                
                PolicyDetails PI = new PolicyDetails(i.ToString());
                data[KeyRepository.PolicyNumber] = CF.FormatString(NYLDSelenium.GetAttribute("Contract Name and Number", NYLDSelenium.GetWE(PI.contractNumber, true, 0))).Split(':')[1].Trim();

                DB.QueryPaymentDetails();
                if (criteria == "NN")
                    contractEligibility = data[KeyRepository.PayCode] == "NN";
                if (criteria == "NonVIPER")
                    contractEligibility = data[KeyRepository.PolicyStatus] == "L";
                else
                    contractEligibility = data[KeyRepository.PayCode] != "NN";

                if (contractEligibility)
                    i = NoOfContractsDisplayed.Count() + 1;
                else if (!contractEligibility && i == NoOfContractsDisplayed.Count())
                    NYLDSelenium.ReportStepResult("Policy not found for the criteria " + criteria, "Policy with criteira " + criteria + " is not found in Multicontract list", "Fail", "always", "yes");
            }
        }

    }
}
