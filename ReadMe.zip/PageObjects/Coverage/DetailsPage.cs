﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using CSW.PageObjects.Payments;
using CSW.Common.DataBase;
using CSW.PageObjects.Login;
using CSW.Common.Email;
using CSW.Common.Excel;
using CSW.PageObjects.Home;

namespace CSW.PageObjects.Coverage
{
    class DetailsPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public DetailsPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        [FindsBy(How = How.XPath, Using = "//p/strong[contains(text(),'Important Notice:')]")]
        public IWebElement ImpNoticeDisplayed { get; set; }

        [FindsBy(How = How.Id, Using = "policy-toggle")]
        public IWebElement ContractNumberDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Choose a contract')]")]
        public IWebElement ChooseContractHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]")]
        public IWebElement DetailsForm { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Contract Number')]")]
        public IWebElement ContractNumberHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'duplicate contract by mail')]")]
        public IWebElement Request_DuplicateContract { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'cash value letter by mail')]")]
        public IWebElement Request_CashValueMail { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'cash value letter by fax')]")]
        public IWebElement Request_CashValueFax { get; set; }

        [FindsBy(How = How.Id, Using = "requestType")]
        public IWebElement AvaiableRequests { get; set; }

        //Fax Cash Value Letter
        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a cash value letter by')]/../..")]
        public IWebElement FaxBoxRequest { get; set; }

        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a cash')]")]
        public IWebElement FaxBoxTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a cash')]/../p")]
        public IWebElement FaxBoxInst { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(., 'Fax number')]")]
        public IWebElement FaxBoxLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(., 'Cancel')]")]
        public IWebElement FaxBoxCancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnFaxCashValue")]
        public IWebElement FaxBoxConfirm { get; set; }

        [FindsBy(How = How.Id, Using = "txtFaxNumber")]
        public IWebElement FaxBoxInputNumber { get; set; }


        [FindsBy(How = How.XPath, Using = "//*[@id='modal-dialog']/div[2]")]
        public IWebElement FaxBoxThankYou { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='dialog-accept']/img")]
        public IWebElement FaxBoxClose { get; set; }

        //Duplicate Contract and Cash Value Letters
        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a duplicate')]")]
       public IWebElement ConfirmRequestBox_DuplicateContract { get; set; }

        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a cash value letter by mail')]")]
        public IWebElement ConfirmRequestBox_CashLetter { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'Enter the address where you would like your cash value letter sent')]")]
        public IWebElement SendtoAnotherAddress_ConfirmRequestBox_CashLetter { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='modal-dialog']/div[2]")]
        public IWebElement RequestBody { get; set; }

        //DC-RequestConfirm
        [FindsBy(How = How.XPath, Using = "//button[@type ='submit' and text() ='Confirm']")]
        public IWebElement RequestConfirmButton { get; set; }

        //CV-RequestConfirm Button
        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/button/img")]
        public IWebElement RequestConfirmBtn { get; set; }

        //SendToDiffAddress
        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Send to')]")]
        public IWebElement SendToDiffAddress { get; set; }

        //Please Confirm Address
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'Please confirm address')]")]
        public IWebElement PlsCnfrmAddr { get; set; }

        // Address Entered tab
        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/table/tbody/tr[3]/td[1]/h3")]
        public IWebElement AddEnterTab { get; set; }

        //Address Enter radio button
        [FindsBy(How = How.Id, Using = "entered-address")]
        public IWebElement AddEntrRadioButton { get; set; }

        //Address Enter radio button
        [FindsBy(How = How.Id, Using = "suggested-address")]
        public IWebElement AddSuggRadioButton { get; set; }

        // submit button
        [FindsBy(How = How.XPath, Using = "//*[@id='form0']//button[@class='submitButton']/img")]
        public IWebElement SubmitAltAddBtn { get; set; }

        // Submit address thank you page
        [FindsBy(How = How.XPath, Using = "//div[@id='cashValueAlternativeAddress']//h2[contains(text(), 'Thank You')]")]
        public IWebElement AltAddThankYouPage { get; set; }

        // Submit address thank you message
        [FindsBy(How = How.XPath, Using = "//div[@id='cashValueAlternativeAddress']//p")]
        public IWebElement AltAddThankYouMessage { get; set; }

        // Submit address return to home
        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Back')]")]
        public IWebElement BacktoDetailsLink { get; set; }

        //CV Dialog Close Button
        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'Back')]")]
        public IWebElement CloseBtn { get; set; }

        //DC Dialog Close Button
        [FindsBy(How = How.XPath, Using = "//*[@id='modal-dialog']//span/img")]
        public IWebElement CloseButton { get; set; }

        //CV & DC Confirm Dialog
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(), 'Thank you')]/../..")]
        public IWebElement ConfirmDialog { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'We are unable to process your')]")]
        public IWebElement LapseErrorDialog { get; set; }

        //cvThank you page
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(), 'Thank you')]")]
        public IWebElement CVThankYouPage { get; set; }

        // CV Alt Address 
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'Enter the address')]")]
        public IWebElement CVAltAddressHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddressee']")]
        public IWebElement CVAltAddressee { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress1']")]
        public IWebElement CVAltAddressLine1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress2']")]
        public IWebElement CVAltAddressLine2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtCity']")]
        public IWebElement CVAltAddressCity { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='State']")]
        public IWebElement CVAltAddressState { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtZip']")]
        public IWebElement CVAltAddressZip { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/p[7]//button/img")]
        public IWebElement CVAltAddressSubmitBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='modal-dialog']/div[2]/h1")]
        public IWebElement RequestHeader { get; set; }


        [FindsBy(How = How.XPath, Using = "//*[@id='dialog-cancel']/a")]
        public IWebElement CVRequestCancel { get; set; }

        [FindsBy(How = How.Id, Using = "duplicatemodelclosebutton")]
        public IWebElement DCRequestCancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='form0']/button/img")]
        public IWebElement CVRequestConfirm { get; set; }

        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a duplicate')]/../p")]
        public IWebElement RequestBody_DuplicateLetter { get; set; }

        [FindsBy(How = How.XPath, Using = "//h5[contains(text(), 'Get a cash value letter by mail')]/../p")]
        public IWebElement RequestBody_CashValue { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='cash-value-by-mail-form']/div[1]/div/p[1]")]
        public IWebElement CVLOwnerAddress { get; set; }

        // Billing Section
        //Billing Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]")]
        public IWebElement BillingHeader { get; set; }

        //PayCode NN Message
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]/..//p")]
        public IWebElement PayCodeNNMessage { get; set; }

        //Payments information table Header - current premium
        
        //[FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Premium')]/..")]
        [FindsBy(How = How.XPath, Using = "(//h5[contains(text(), 'Billing information')]/following-sibling::div/descendant::div)[1]")]
        public IWebElement CurrentPremiumHeader { get; set; }

        //Payments information table Header - Status
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Status:')]/..")]
        public IWebElement PolicyStatusLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='policyStatus']")]
        public IWebElement PolicyStatusText { get; set; }

        //Payments information table Header - Status Info icon
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Status:')]/../i")]
        public IWebElement StatusInfoIcon { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing')]/../div[2]/div")]
        public IList<IWebElement> BillingSection_PaymentInfo { get; set; }

        //Payments information table Header -  Status info icon Text
        [FindsBy(How = How.XPath, Using = "//div[@id='statusHelpIcon']/span/span[@class = 'help-icon-text']/span")]
        public IWebElement StatusInfoText { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]/..//div[@class= 'pt-4']")]
        //[FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]/..//strong[contains(text(), 'Payment Due:') or contains(text(), 'Past Due:')]")]
        public IWebElement PaymentDueInformation { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]/..//a[contains(@href, 'Payments/Manage')]")]
        public IWebElement MakeAPayment_Button { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]/..//a[contains(@href, 'History')]")]
        public IWebElement PaymentHistoryLink{ get; set; }

        //Learn more link
        [FindsBy(How = How.Id, Using = "goodValueLink")]
        public IWebElement LearnMoreLink { get; set; }

        //Coverage Section
        //Coverage Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Coverage Summary')]")]
        public IWebElement CoverageHeader { get; set; }

        //Available Request List
        [FindsBy(How = How.XPath, Using = "//*[@id='requestType']")]
        public IWebElement AvailReqList { get; set; }

        //Coverage Table
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Coverage Summary')]/..//thead//th")]
        public IList<IWebElement> CoverageTable_Headers { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Coverage Summary')]/..//table")]
        public IWebElement CoverageTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'mb-3')]")]
        public IWebElement BeneNotEligible { get; set; }

        //Beneficiaries Section
        //Beneficiaries Header
        [FindsBy(How = How.XPath, Using = "//*/h5[contains(text(), 'Beneficiaries')]")]
        public IWebElement BeneficiariesHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Beneficiaries')]/..//thead//th")]
        public IList<IWebElement> BeneficiaryTable_Header { get; set; }

        //Manage Benes Link
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Beneficiaries')]/..//a[contains(@href, 'Coverage/Beneficiaries')]")]
        public IWebElement AddBeneficiaryLink { get; set; }

        //Beneficiaries Table
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Beneficiaries')]/..//table/tbody")]
        public IWebElement BeneficiariesTable { get; set; }

        //See All Beneficiaries
        [FindsBy(How = How.XPath, Using = "//*[@id='BeneCollapseImg']/..")]
        public IWebElement SeeAllBeneficiaries { get; set; }

        //See All Beneficiaries + Icon
        [FindsBy(How = How.XPath, Using = "//*[@id='BeneCollapseImg']")]
        public IWebElement SeeAllBeneficiariesIcon { get; set; }

        //**************** Buttons **********//
        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Billing information')]/..")]
        public IWebElement Shadowbox_DetailsPage { get; set; }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyDetailsPage                                                                           ///////////
        ////// Description: Select request if a multicontract and call verify details method                    ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyDetailsPage(string args = "")
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            SummaryPage SP = new SummaryPage(driver, data);
            bool policyFound = false;
            string[] policyList;
            string tempPolicyNumber = "";
           
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Dashboard Details Page" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Page Load
            NYLDSelenium.PageLoad("Details", DetailsForm);

            //scroll to top of the page
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollBy(0,-5000);");

            //Save current policy Number
            if (data[KeyRepository.PolicyNumber] != null || data[KeyRepository.PolicyNumber] != "")
                tempPolicyNumber = data[KeyRepository.PolicyNumber];
                       
            if (data[KeyRepository.ContractCount].Contains("Multi"))
            {
                policyList = CSWData.AssociatedPolicies.Split(';'); 
                //verify Dropdown list and header and content
                NYLDSelenium.VerifyText("choose contract header", "Choose a contract number", NYLDSelenium.GetAttribute("Choose contract header", ChooseContractHeader).Trim());
                for (int j = 0; j <= (policyList.Count() - 1); j++)
                {
                    //Get Policy Number
                    string[] phrasePolicy = policyList[j].Split(' ');
                    string polnum = phrasePolicy.Last();

                    //get options in Drop down
                    //Navigate to th eelement -no need to display in report
                    NYLDSelenium.ElemExist("Contract header ", ChooseContractHeader, true, "no", "no", "no");
                    //IList<IWebElement> options = NYLDSelenium.GetDropdownValues("Get Contractnumbers", ContractNumberDropDown,true);
                    //get options in Drop down
                    SelectElement select = new SelectElement(ContractNumberDropDown);
                    IList<IWebElement> options = select.Options;
                    int actOptCount = options.Count;

                    //verify policy is listed in UI
                    for (int i = 0; i < actOptCount; i++)
                    {
                        string actPolName = options.ElementAt(i).GetAttribute("text").Split('-')[1].Trim();
                      

                        //Verify the Policy is listed in dropdwon
                        if (actPolName == policyList[j].Trim())
                        {
                            policyFound = true;
                            i = actOptCount + 1;
                        }
                        else if (policyFound == false && i == actOptCount)
                        {
                            NYLDSelenium.ReportStepResult("Policy " + policyList[j].Trim() + " not found in details page dropdown list", policyList[j].Trim() + " is part of expected associated policies list but not listed in detail page droddown", "Fail");
                        }
                    }
                }
            }
            else if (data[KeyRepository.ContractCount].Contains("Single"))
            {
                //Verify drop down and choose contract header is not present
                NYLDSelenium.ElemNotExist("choose contract header", ChooseContractHeader);
                NYLDSelenium.ElemNotExist("Drop down list", ContractNumberDropDown);
                DB.QueryPolicyDetails();
            }

            //verify details page
            VerifyDetails(args);
        }

        //TODO: Shall we break up this method for each section and get directly called from above method?
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyDetails                                                                               ///////////
        ////// Description: Verify all information ofor a policy in the details page                            ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyDetails(string args)
        {
            //Page Objexts
            LSPDatabase DB = new LSPDatabase(driver, data);
            LoginPage LP = new LoginPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            SummaryPage SP = new SummaryPage(driver, data);
            ManagePaymentsPage MP = new ManagePaymentsPage(driver, data);
            TestData testData = new TestData();

            //Owner and Insured variables

            //Billing variables
            string expPaymentColumn;
            string actContractCardColor;

            //Product Description
            string productDescription = "";

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify details page for policy - " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            NYLDSelenium.AddHeader("Verify Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "SubHeader");
            
            //Verify Contract Owner details            
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Owner and Insured Name" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
           
            CF.GetOwnerandInsuredDetails(MP.ContractOwner, MP.ContractInsured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName);

            //Verify Owner details
            NYLDSelenium.VerifyText("Contract Owner", ExpOwnerNameandAddr.Trim(), ActualOwnerNameandAddr,"always","always");

            //Verify Insured details
            NYLDSelenium.VerifyText("Insured", ExpectedInsuredName, ActualInsuredName, "always");
            
            NYLDSelenium.AddHeader("Verify Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "Success");

            //Verify Contract Number Heading
            NYLDSelenium.VerifyText("Contract Number", "Contract Number: " + data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract Number", ContractNumberHeading), "always");

            //Verify Payment Button and Color
            CF.GetContractCardcolor();
            if (data[KeyRepository.PayCode] != "NN")
            {
                //For Inforce and Lapse
                if (data[KeyRepository.ContractCardColor] == "Red")
                        expPaymentColumn = "Past Due";
                else
                    expPaymentColumn = "Payment Due";

                //Verify Contract Card color
                actContractCardColor = NYLDSelenium.GetAttribute("Payment Button Source", Shadowbox_DetailsPage, "class");
                NYLDSelenium.VerifyText("Contract Card color", data[KeyRepository.ContractCardColor], CF.GetActualContractCardColor(actContractCardColor), "always");

                //Check Payment button availability
                bool paymentButtoDisplayed = NYLDSelenium.ElemExist("Payment Button", MakeAPayment_Button, true, "no", "no","no");
                if (data[KeyRepository.PolicyStatus] == "Inforce" && !paymentButtoDisplayed)
                {
                    NYLDSelenium.ReportStepResult("Verify Make a Payment Button", "In contract " + data[KeyRepository.PolicyNumber] + " Details Page - 'Make a Payment' button is not displayed ", "INFO", "no");
                }
                else if (data[KeyRepository.PaymentButtonColor] == "NoButton" && paymentButtoDisplayed)
                {
                    //expPaymentColumn = "Payment Due";
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Make a Payment Button" + "</h3>", "<h3 style=\"color:Blue\">" + "In contract " + data[KeyRepository.PolicyNumber] + " Details Page - 'Make a Payment' button should not be displayed but displayed for the contract." + "</h3>", "INFO", "no");
                }                
            }
            else
            {
                expPaymentColumn = "Payment Due";
            }

            //Set Table Indexes
            #region//*******************************************************Billing table verifications*******************************************************************
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Billing Section for -"+data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //verify payment info header
            NYLDSelenium.AddHeader("Billing table verifications - " + data[KeyRepository.PolicyNumber], "SubHeader");
            if (data[KeyRepository.PayCode] == "FB")
            { //Group Billing Banner
                DB.QueryFamilyBill();
                VerifyFamilyBillBanner("");
                NYLDSelenium.VerifyText("Billing header", "Billing information", NYLDSelenium.GetAttribute("Billing header", BillingHeader).Trim(), "always", "always");

                //prefix '0' for paid to date
                string[] PaidToDateSplit = data[KeyRepository.PaidToDate].Split('/');
               data[KeyRepository.PaidToDate] = PaidToDateSplit[0].PadLeft(2, '0') + "/" + PaidToDateSplit[1].PadLeft(2, '0') + "/" + PaidToDateSplit[2];
            }
            else
                NYLDSelenium.VerifyText("Billing header", "Billing information", NYLDSelenium.GetAttribute("Billing Header", BillingHeader).Trim(), "always", "always");
            
            //Get Pay frequency 
          
            //verify Table content
            if (data[KeyRepository.PayCode] == "NN")
                NYLDSelenium.VerifyText("Payment due message for Good value policy", testData.GetContent("PaycodeNN").Replace("{PayCode}", CF.GetCurrentFrequencyWithPremium("").Split(',')[0].ToLower()).Trim(), CF.FormatString(NYLDSelenium.GetAttribute("Good value policy billing message", PayCodeNNMessage).Trim()), "always", "always");
            else
            {
                if (data[KeyRepository.PayCode] != "FB")
                {
                    string pamountUI = NYLDSelenium.GetAttribute("Premium Amount", CurrentPremiumHeader).Replace(",", "");
                    NYLDSelenium.VerifyText("Current Payment Frequency", "Current " + CF.GetCurrentFrequencyWithPremium("").Split(',')[0] + " Premium: $" + data[KeyRepository.Premium], pamountUI,"always");
                }
                else
                    NYLDSelenium.VerifyText("Current Payment Frequency", "Current Group " + CF.GetCurrentFrequencyWithPremium("").Split(',')[0] + " Premium: $" + data[KeyRepository.Premium], NYLDSelenium.GetAttribute("Contract header", CurrentPremiumHeader),"always");

                //verify policy status and status information
                NYLDSelenium.VerifyText("Contract Status", "Status: " + data[KeyRepository.PolicyStatus], NYLDSelenium.GetAttribute("Contract Status", PolicyStatusLabel).Trim(),"always");
              
                NYLDSelenium.Click("Contract Status Information Bubble", StatusInfoIcon,true);

                if (data[KeyRepository.PolicyStatus]!= "Reduced Paid-Up")
                    NYLDSelenium.VerifyText("status Information", testData.GetContent(data[KeyRepository.PolicyStatus].Trim()), NYLDSelenium.GetAttribute("Status Info Text", StatusInfoIcon, "data-original-title"),"always");
                else
                {
                    string info = NYLDSelenium.GetAttribute("Status Info Text", StatusInfoIcon, "data-original-title");
                    info = info.Replace("  ", " ");
                    NYLDSelenium.VerifyText("status Information", testData.GetContent(data[KeyRepository.PolicyStatus].Trim()), info.Trim(), "always");
                }

                //Verify Last Payment Date header and value  
                NYLDSelenium.VerifyText("Last Payment Received Label", "Last Payment Received", CF.FormatString(NYLDSelenium.GetAttribute("Last Payment Received Label", BillingSection_PaymentInfo[0])).Split(':')[0].Trim(),"always");
                string lastPaymentReceived = data[KeyRepository.LastPaymentDate];

                if (lastPaymentReceived != "")
                    lastPaymentReceived = Convert.ToDateTime(lastPaymentReceived).ToString("M/d/yyyy");
                NYLDSelenium.VerifyText("Last Payment Received Value", lastPaymentReceived, CF.FormatString(NYLDSelenium.GetAttribute("Last Payment Received Value", BillingSection_PaymentInfo[0])).Split(':')[1].Trim(), "always");

                //Verify Last Payment Amount header and value    
                NYLDSelenium.VerifyText("Last Payment Amount Label", "Last Payment", CF.FormatString(NYLDSelenium.GetAttribute("Last Payment Amount Label", BillingSection_PaymentInfo[1])).Split(':')[0].Trim(), "always");
                if (data[KeyRepository.PayCode] == "FB")
                    NYLDSelenium.VerifyText("Last Payment Amount Value",data[KeyRepository.Premium], CF.FormatString(NYLDSelenium.GetAttribute("Last Payment Amount Value", BillingSection_PaymentInfo[1])).Split(':')[1].Replace("$", "").Replace(",", "").Trim(), "always");
                else
                    NYLDSelenium.VerifyText("Last Payment Amount Value", data[KeyRepository.LastPaymentAmt], CF.FormatString(NYLDSelenium.GetAttribute("Last Payment Amount Value", BillingSection_PaymentInfo[1])).Split(':')[1].Replace("$", "").Replace(",", "").Trim(), "always");

                //Verify Payment/Past Due header and value
                NYLDSelenium.VerifyText("Payment-Past Due Label", expPaymentColumn, CF.FormatString(NYLDSelenium.GetAttribute("Payment-Past Due Label", BillingSection_PaymentInfo[2])).Split(':')[0].Trim(), "always");
                NYLDSelenium.VerifyText("Payment-Past Due Value",data[KeyRepository.PaidToDate], CF.FormatString(NYLDSelenium.GetAttribute("Payment-Past Due Value", BillingSection_PaymentInfo[2])).Split(':')[1].Trim(), "always");

                //Verify Total AMount Due
                NYLDSelenium.VerifyText("Total Amount Due Label", "Total Amount Due", CF.FormatString(NYLDSelenium.GetAttribute("Total Amount Due Label", BillingSection_PaymentInfo[3])).Split(':')[0].Trim(), "always");

                //Verify Payment due information
                if (data[KeyRepository.PaymentDueAbove52] == "true" && data[KeyRepository.PayCode] != "NN" && data[KeyRepository.ContractCardColor] != "White" && data[KeyRepository.ContractCardColor] != "Grey")
                {
                    if (!NYLDSelenium.ElemExist("Past Due information", PaymentDueInformation, false, "no", "no"))
                        NYLDSelenium.ReportStepResult("Payment Due informtion not displayed", "Past due information is not displayed for the contract", "Fail", "always");
                    else
                        CF.VerifyPaymentDueInformation(CF.FormatString(NYLDSelenium.GetAttribute("Due information", PaymentDueInformation)));
                }
            }

            // Verify View payment history Link
            if (data[KeyRepository.PaymentHistoryLink] == "NoLink")
                NYLDSelenium.ElemNotExist("View payment history link not ", PaymentHistoryLink, false, "no", "always", "always");
            else
                NYLDSelenium.ElemExist("View payment history link ", PaymentHistoryLink, false, "no", "always", "always");           

                NYLDSelenium.AddHeader("Billing table verifications - " + data[KeyRepository.PolicyNumber], "Success");
            #endregion

            #region//*******************************************************Coverage table verifications*******************************************************************
            // Coverage summery Section only for VIPER policies
            if (CSWData.VIPERPolicies.Contains(data[KeyRepository.PolicyNumber]))
            {               
                NYLDSelenium.AddHeader("Coverage Summary Section verifications - " + data[KeyRepository.PolicyNumber], "SubHeader");
                //Query 
                DB.QueryCoverageSummary();

                //verify Coverage header
                NYLDSelenium.VerifyText("Coverage header", "Coverage Summary", NYLDSelenium.GetAttribute("Coverage header", CoverageHeader).Trim(), "always", "always");

                //Verify Available Request List
                bool bDuplicateLetter; bool viewcoverageEligible;
                string tempPolicy = data[KeyRepository.PolicyNumber];
                DB.QueryAssociatedPolicies();
                data[KeyRepository.PolicyNumber] = tempPolicy;
                DB.QueryPolicyDetails();

                if (CSWData.VIPERPolicies.Contains(data[KeyRepository.PolicyNumber]))
                    bDuplicateLetter = true;
                else
                    bDuplicateLetter = false;

                string expList = "";
                if (bDuplicateLetter)
                    expList = "Select a Request|Get a duplicate contract by mail|Get a cash value letter by mail|Get a cash value letter by fax";
                else
                    expList = "Select a Request|Get a cash value letter by mail|Get a cash value letter by fax";

                //Coverage Table headers and labels verifications
                NYLDSelenium.AddHeader("Verify Coverage Summary section of contract - " + data[KeyRepository.PolicyNumber], "SubHeader");
                //Description header and value
                NYLDSelenium.VerifyText("Description Label", "Description:", NYLDSelenium.GetAttribute("Description Label", CoverageTable_Headers[0]).Trim(), "always");

                //Verify Last Payment Amount header and value
                NYLDSelenium.VerifyText("Effective Date Label", "Effective Date:", NYLDSelenium.GetAttribute("Effective Date Label", CoverageTable_Headers[1]).Trim(), "always");

                //Verify Payment/Past Due header and value  
                NYLDSelenium.VerifyText("Coverage Amount Label", "Coverage Amount:", NYLDSelenium.GetAttribute("Coverage Amount Label", CoverageTable_Headers[2]).Trim(), "always");

                //Verify Total AMount Due
                NYLDSelenium.VerifyText("Cash Surrender Value Label", "Cash Surrender Value:", NYLDSelenium.GetAttribute("Cash Surrender Value", CoverageTable_Headers[3]).Trim(), "always");

                viewcoverageEligible = DB.GetViewByCoverageEligible();
                if (viewcoverageEligible)
                {
                    SP.VerifyWelcomKitPDF("");
                    CommonFunctions.WindowsTabFocus("CloseTab", "newTabInstance");
                    CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
                }

                bool CovEntryFound = false;
                IList<IWebElement> NumberOfCovRows = CoverageTable.FindElements(By.TagName("tr"));
                List<List<string>> CoverageInfoFromApplication = new List<List<string>>();
                int r = 0;
                for (int p = 1; p < NumberOfCovRows.Count; p++)
                {
                    IList<IWebElement> CoverageData = NumberOfCovRows[p].FindElements(By.TagName("td"));
                    if (CoverageData.Count == 4)
                    {
                        CoverageInfoFromApplication.Add(new List<string>());
                        foreach (IWebElement td in CoverageData)
                        {

                            CoverageInfoFromApplication[r].Add(td.Text.Replace("$", "").Replace(",", "").Replace("*", "").Replace("(", "-").Replace(")", ""));
                        }
                        r++;
                    }
                }
                //Verify No. of rows are equal
                if (CSWData.CoverageSummaryInfo.Count() == CoverageInfoFromApplication.Count())
                {
                    string cashsurrendervalue;

                    //verify the UI and Database list
                    for (int i = 0; i < CSWData.CoverageSummaryInfo.Count(); i++)
                    {
                        CovEntryFound = false;
                        for (int j = 0; j < CoverageInfoFromApplication.Count(); j++)
                        {
                            if (CSWData.CoverageSummaryInfo[i][0].Trim() == CoverageInfoFromApplication[j][0].Trim() && CSWData.CoverageSummaryInfo[i][1].Trim() == CoverageInfoFromApplication[j][1].Trim())
                            {
                                CovEntryFound = true;
                                NYLDSelenium.VerifyText("Product Description - Table Row " + i, CSWData.CoverageSummaryInfo[i][0].Trim(), CoverageInfoFromApplication[j][0].Trim(), "always");
                                NYLDSelenium.VerifyText("Effective Date - Table Row " + i, CSWData.CoverageSummaryInfo[i][1].Trim(), CoverageInfoFromApplication[j][1].Trim(), "always");
                                NYLDSelenium.VerifyText("Coverage Amount - Table Row " + i, CSWData.CoverageSummaryInfo[i][2].Trim(), CoverageInfoFromApplication[j][2].Trim(), "always");

                                productDescription = CSWData.CoverageSummaryInfo[i][0];

                                if (j == 0)
                                    cashsurrendervalue = CSWData.CoverageSummaryInfo[i][3].Trim();
                                else
                                    cashsurrendervalue = "0.00";

                                NYLDSelenium.VerifyText("Cash Surrender Value - Table Row " + i, cashsurrendervalue, CoverageInfoFromApplication[j][3].Trim(), "always");

                                break;
                            }
                            else if (!CovEntryFound && j == CoverageInfoFromApplication.Count() - 1)
                            {
                                NYLDSelenium.ReportStepResult("Verify " + CSWData.CoverageSummaryInfo[i][j].Trim() + " entry exists in Coverage Summary section", CSWData.CoverageSummaryInfo[i][j].Trim() + " entry is not found in Coverage Summary section", "Fail", "always");                               
                            }
                        }
                    }

                }
                else
                {
                    NYLDSelenium.ReportStepResult("Veriy number of records in Coverage Summary section", "Number of records in Coverage Summary section do not match with expected records.", "FAIL", "always", "yes");                   
                }

                NYLDSelenium.AddHeader("Coverage Summary Section verifications - " + data[KeyRepository.PolicyNumber], "Success");
               
            }
            else
                //verify Coverage header
                NYLDSelenium.ElemNotExist("Coverage Summary header ", CoverageHeader, true, "no");
            #endregion

            #region//*******************************************************Beneficiaries table verifications*******************************************************************
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Beneficiaries Section for - "+data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            NYLDSelenium.AddHeader("Beneficiaries table verifications - " + data[KeyRepository.PolicyNumber], "SubHeader");
            //Query Bene Details
            DB.GetBeneInfo();

            //verify Coverage header
            NYLDSelenium.MoveToElement("View Beneficiaries Table", BeneficiariesHeader, true);

            NYLDSelenium.VerifyText("Beneficiaries header", "Beneficiaries", NYLDSelenium.GetAttribute("Beneficiaries header", BeneficiariesHeader).Substring(0,13).Trim(),"always","always");
            
          
            //Bene Name header
            NYLDSelenium.VerifyText("Beneficiary Name Label", "Name:", NYLDSelenium.GetAttribute("Beneficiary Name", BeneficiaryTable_Header[0]).Trim(), "always");

            //Verify Bene Share header
            NYLDSelenium.VerifyText("Beneficiary Share Label", "Share:", NYLDSelenium.GetAttribute("Beneficiary Share Label", BeneficiaryTable_Header[1]).Trim(), "always");

            //verify  Beneficiary Class header
            NYLDSelenium.VerifyText("Beneficiary Class Label", "Class:", NYLDSelenium.GetAttribute("Beneficiary Class Label", BeneficiaryTable_Header[2]).Trim(), "always");
           
            bool BeneEntryFound = false;
             
            IList<IWebElement> NumberOfBeneRows = BeneficiariesTable.FindElements(By.TagName("tr"));
            IList<List<string>> BeneInfoFromApplication = new List<List<string>>();
            int rw = 0; 
            for (int p = 0; p < NumberOfBeneRows.Count; p++)
            {
                IList<IWebElement> BeneData = NumberOfBeneRows[p].FindElements(By.TagName("td"));
                if (BeneData.Count == 3)
                {
                    BeneInfoFromApplication.Add(new List<string>());
                    //foreach (IWebElement td in CoverageData)
                    for (int q = 0; q < 3; q++)
                    {

                        BeneInfoFromApplication[rw].Add(BeneData[q].Text.Replace("%", ""));
                    }
                    rw++;
                }
            }
            //Verify No. of rows are equal
            if (productDescription != "Young Start Life")
            {
                if (CSWData.BeneInfo.Count() == BeneInfoFromApplication.Count())
                {
                    for (int i = 0; i <= CSWData.BeneInfo.Count - 1; i++)
                    {
                        BeneEntryFound = false;

                        //Get the expected Bene Name
                        string fullname, beneclass;
                        string[] name;

                        if (CSWData.BeneInfo[i][0].Contains("/"))
                        {
                            name = CSWData.BeneInfo[i][0].Split('/');

                            if (name.Length > 2)
                            {

                                if (name[2].Trim() == "" && name.Length > 3)
                                {
                                    if (name.Length > 4)
                                        fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim() + " " + name[4].Trim();
                                    else
                                        fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim();
                                }
                                else if (name.Length > 3)
                                {
                                    fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[2].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim() + " " + name[4].Trim();
                                }
                                else
                                    fullname = name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim();

                            }
                            else
                                fullname = name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim();


                            //if (CSWData.BeneInfo[i][15] == "Trust")
                            //    fullname = "Trust of " + fullname;

                            if (CSWData.BeneInfo[i][15] == "Estate")
                                fullname = name[0].Replace(",", "").Replace("Per Stirpes", "");

                            if (fullname.Length > 43)
                                fullname = fullname.Substring(0, 43);
                        }
                        else
                        {
                            fullname = CSWData.BeneInfo[i][0].Replace(",", "").Replace("Per Stirpes", "").Trim();

                            if (CSWData.BeneInfo[i][15] == "Estate")
                                fullname = "Estate";
                        }

                        switch (CSWData.BeneInfo[i][2])
                        {
                            case "BN1":
                            case "IRB":
                                beneclass = "1st";
                                break;
                            case "BN2":
                                beneclass = "2nd";
                                break;
                            case "BN3":
                                beneclass = "3rd";
                                break;
                            default:
                                beneclass = CSWData.BeneInfo[i][2];
                                break;

                        }
                        for (int j = 0; j < BeneInfoFromApplication.Count(); j++)
                        {
                            if (fullname.Trim() == BeneInfoFromApplication[j][0].Trim() && BeneInfoFromApplication[j][2].Contains(beneclass))
                            {
                                BeneEntryFound = true;
                                //NYLDSelenium.VerifyText("Beneficiary Name" + i, fullname.Trim(), BeneInfoFromApplication[j][0].Trim());
                                if (CSWData.BeneInfo[i][1].Trim() == "0")
                                    CSWData.BeneInfo[i][1] = Convert.ToInt32(CSWData.BeneInfo[i][1].Trim()).ToString("0.00");
                                var actual = Math.Round((Convert.ToDouble(BeneInfoFromApplication[j][1])), 2, MidpointRounding.AwayFromZero);
                                var expected = Math.Round((Convert.ToDouble(CSWData.BeneInfo[i][1])), 2, MidpointRounding.AwayFromZero);
                                NYLDSelenium.VerifyText("Beneficiary Share" + i, expected.ToString(), actual.ToString());
                                NYLDSelenium.VerifyText("Beneficiary Class" + i, beneclass.Trim(), BeneInfoFromApplication[j][2].Trim());
                                break;
                            }
                            else if (BeneInfoFromApplication[j][0].Trim() == "Estate")
                            {

                            }
                            else if (!BeneEntryFound && j == BeneInfoFromApplication.Count() - 1)
                            {
                                if (fullname != "Ben1")
                                {                                   
                                    NYLDSelenium.ReportStepResult("Verify " + fullname.Trim() + " entry exists in Beneficiaries section", fullname.Trim() + " entry is not found in Beneficiaries section", "Fail", "always");                                    
                                }
                            }
                        }
                    }
                }

                //Verify Manage Beneficiary Link
                if (data[KeyRepository.PayCode] == "FB")
                {
                    NYLDSelenium.Click("Manage Beneficiaries Link", AddBeneficiaryLink); Thread.Sleep(1000);
                    string notElligibleText = NYLDSelenium.GetAttribute("Beneficiaries Not Eligible", BeneNotEligible);
                    NYLDSelenium.VerifyText("Manage Bene option Not Available", testData.GetContent("FamilyBill"), notElligibleText.Replace("\r\n", ""), "always");
                    NYLDSelenium.driver.Navigate().Back(); Thread.Sleep(500);
                }
                else
                    NYLDSelenium.ElemExist("Manage Beneficiaries Link", AddBeneficiaryLink);

                //Verify Duplicate Contract
                //if (data[KeyRepository.PolicyStatus].Substring(0, 1).IndexOfAny(new char[] { 'V', 'I', 'P', 'E', 'R' }) == -1)
                //{
                //    NYLDSelenium.Click("Duplicate Letter Submission", NYLDSelenium.GetWE("//a[contains(text(), 'Get a duplicate')]"));

                //    NYLDSelenium.PageLoad("Duplicate Contract confirmation Window", ConfirmRequestBox_DuplicateContract);                    

                //    NYLDSelenium.Click("Duplicate Contract Confirm", RequestConfirmButton);

                //    if (NYLDSelenium.GetAttribute("Thank You Body", ConfirmDialog).Contains("Thank"))
                //        NYLDSelenium.ReportStepResult("Duplicate Letter submission options is displayed for policy with Status: "+ data[KeyRepository.PolicyStatus], "Duplicate cashvalue letter option is not expected to be displayed", "Fail");
                //}
            }
            else if(productDescription == "Young Start Life")
            {
                if (BeneInfoFromApplication.Count() != 0)
                {
                    NYLDSelenium.ReportStepResult("Verify number of records in Beneficiaries section for " + productDescription, "Not expecting the beneficiary for " + productDescription, "Fail", "always");                    
                }
            }
            else
            {
               NYLDSelenium.ReportStepResult("Verify number of records in Beneficiaries section", "Number of records in Beneficiaries section do not match with expected records.", "Fail", "always");               
            }

            NYLDSelenium.AddHeader("Verify Beneficiaries section of contract - " + data[KeyRepository.PolicyNumber], "Success");          
            #endregion

            NYLDSelenium.ElemExist("Duplicate Letter Submission", Request_DuplicateContract);

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyRequestType                                                                           ///////////
        ////// Description: Selct different request types and verify their pop up messages                       ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyRequestType(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            DetailsPage DP = new DetailsPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            HomePage home = new HomePage(driver, data);
            TestData testData = new TestData();
            IWebElement ThankyouPage;
            IWebElement ThankYouMessage;
            IWebElement ReturnToDetailsPage;
            SummaryPage summaryPage = new SummaryPage(driver, data);
            string item, ExpConfirmMsg, ExpThankMsg, ExpContractOwner, ExpDesc, requestType, info;
            string cvAltAdd = null;
            EmailVerification OE = new EmailVerification(driver, data);
                       
            string[] splitStr = args.Split(',');
            if (splitStr.Length > 1)
            {
                requestType = splitStr[0].Trim();
                info = splitStr[1].Trim();
            }
            else
            {
                requestType = splitStr[0].Trim();
                info = "";
            }

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Request Type " + splitStr[0].Trim() + "</h3>", "Verify Request Type " + splitStr[0].Trim(), "Info", "always", "no");

            //Close Account panel //TODO: Need to add logic if email timed out, no need to do it
            //if (NYLDSelenium.GetAttribute("Account Panel", home.MyAccountDropDown, "aria-expanded","no","no",false,40) != "true")
            //    NYLDSelenium.Click("My Coverage", home.MyAccountDropDown);

            //verify details page
            Thread.Sleep(4000);
            //query policy and paycode details
            DB.QueryPolicyDetails();
            DB.QueryPaymentDetails();
            CF.GetContractCardcolor();

            if (!args.Contains("Lapse"))
            {
                //this change related to paerless banner in summary page 
                string index = "1";
                index = summaryPage.DetailsInfolink().ToString();
                NYLDSelenium.Click("View Details", NYLDSelenium.GetWE(new CSW.PageObjects.Coverage.PolicyDetails(index).viewDetailsLink));

                //Verify Page Load
                NYLDSelenium.PageLoad("Details", DetailsForm);
            }
            if (requestType == "Duplicate Contract")
            {
                ExpConfirmMsg = "Click \"Confirm\" to receive a duplicate copy of Contract Number " + data[KeyRepository.PolicyNumber] + " mailed to the address below:";
                //otherlink = " « Cancel";
                item = "contract";
            }
            else
            {
                ExpConfirmMsg = "Click \"Confirm\" to receive a cash value letter for Contract Number " + data[KeyRepository.PolicyNumber] + ". We'll mail the letter to the address below:";
                //otherlink = " Send to a different address »  ";
                item = "letter";
            }

            //ExpConfirmMsg = "Click \"Confirm\" to receive a " + requestType.ToLower().Trim() + " for Contract Number " + data[KeyRepository.PolicyNumber] + ". We'll mail the " + item + " to the address below: " + ExpContractOwner + otherlink;

            if (requestType == "CashValueLetter")
            {
                //Select Cash Value Letter
                NYLDSelenium.Click("Select cash value by mail Request", Request_CashValueMail);

                //Verfiy Header and Body of CashValue Letter box
                NYLDSelenium.PageLoad("Cash Value Letter Confirmation Window", ConfirmRequestBox_CashLetter);

                //verify Text//
                NYLDSelenium.VerifyText("Confirmation message", ExpConfirmMsg.Replace(" ", ""), NYLDSelenium.GetAttribute("get message text", RequestBody_CashValue).Replace(" ", "").Replace("\r\n", ""),"always");
                if (data[KeyRepository.AddressLine2] == " ")
                    ExpContractOwner = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + data[KeyRepository.AddressLine1] + data[KeyRepository.City] + ", " + data[KeyRepository.State] + " " + data[KeyRepository.Zip];
                else
                    ExpContractOwner = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + data[KeyRepository.AddressLine1] + data[KeyRepository.AddressLine2] + data[KeyRepository.City] + ", " + data[KeyRepository.State] + " " + data[KeyRepository.Zip];


                NYLDSelenium.VerifyText("CVL Owner Address", ExpContractOwner.Replace(" ", "").Replace(",",""), NYLDSelenium.GetAttribute("Cash value Letter Owner Name", CVLOwnerAddress).Replace(" ", "").Replace("\r\n", "").Replace(",", ""), "always");
              
                //Address2, Address3 are ""
                data[KeyRepository.CVLAddressData] = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + "|" + data[KeyRepository.AddressLine1] +" |" + data[KeyRepository.AddressLine2] + " |" + "" + " |" + data[KeyRepository.City] + " " + data[KeyRepository.State] + "  " + data[KeyRepository.ZipCode];
             
                //alt address
                if (info == "AlternateAddress-Entered" || info == "AlternateAddress-Suggested")
                {
                    NYLDSelenium.Click("Cash Value Letter To Different Address", SendToDiffAddress);
                    data[KeyRepository.CVLAddressData] = CashValueLetterDiffAddress(info);
                    if (!string.IsNullOrEmpty(data[KeyRepository.CVLAddressData]))
                    {
                        //click to select  Confirmation to send the another address
                        NYLDSelenium.Click("Confirm Button", RequestConfirmButton, true, "always", "always");
                    }
                    else
                        NYLDSelenium.ReportStepResult("Cash Value Letter- Send To Different Address", "Cash Value Letter- Send To Different Address, so could not proceed with this data." + cvAltAdd, "FAIL", "always", "yes");


                    //SendtoAnotherAddress_ConfirmRequestBox_CashLetter
                    if (NYLDSelenium.ElemExist("Send to other address confirmation", SendtoAnotherAddress_ConfirmRequestBox_CashLetter, false, "no", "no"))
                    {
                        NYLDSelenium.ElemExist("Send to other address confirmation", SendtoAnotherAddress_ConfirmRequestBox_CashLetter, false, "no", "always", "always");
                        NYLDSelenium.Click("Confirm Button", RequestConfirmButton, true, "always", "always");
                    }

                    //Select confirm address box request 
                    if (NYLDSelenium.ElemExist("Please confirm address box", PlsCnfrmAddr, false, "no", "no"))
                    {

                        if (info == "AlternateAddress-Entered")
                            NYLDSelenium.Click("Street address Radio Button", AddEntrRadioButton, true, "always", "always");
                        else if (info == "AlternateAddress-Suggested")
                        {
                            if (NYLDSelenium.ElemExist("Address entered tab", AddSuggRadioButton, false, "no", "no"))
                                NYLDSelenium.Click("Street address Radio Button", AddSuggRadioButton, true, "always", "always");
                        }
                    }
                    else
                        NYLDSelenium.ReportStepResult("Cash Value Letter- Send To Different Address  - confirm address box", "Please confirm address box selection is not display", "FAIL", "always", "yes");
                }

                //Request confirmation
                NYLDSelenium.Click("Submit Button", RequestConfirmButton,true,"always","always");
                
                // For Alternet Address also same thank you msg, remove 
                ThankyouPage = CVThankYouPage;
                ThankYouMessage = ConfirmDialog;
                ReturnToDetailsPage = BacktoDetailsLink;
                ExpThankMsg = "Thank you, " + data[KeyRepository.FirstName] + ". We've received your request. Please allow up to 7-10 days for your letter to arrive.";

                //ThankYou page and message
                NYLDSelenium.PageLoad("Cash Value ThankYou", ThankyouPage);
                NYLDSelenium.VerifyText("Thank you message", ExpThankMsg, CF.FormatString(NYLDSelenium.GetAttribute("get message text", ThankYouMessage)));

                //Scroll Up
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript("window.scrollBy(0,-1000);");
                Thread.Sleep(100);
                if (NYLDSelenium.ElemExist("Back to detailed View", ReturnToDetailsPage, false, "no", "no"))
                    NYLDSelenium.Click("Back to detailed View", ReturnToDetailsPage);               
            }
            else if (requestType == "FaxCashValueLetter")
            {
                //Select 'Request Fax Cash Value letter' 
                NYLDSelenium.Click("Select Cash Value by fax Request", Request_CashValueFax);

                NYLDSelenium.PageLoad("Fax Cash Value Request", FaxBoxRequest);

                if (NYLDSelenium.ElemExist("Cancel", FaxBoxCancel, false, "no", "no"))
                {
                    NYLDSelenium.Click("Cancel", FaxBoxCancel);
                    Thread.Sleep(1000);
                    NYLDSelenium.PageLoad("Details", DetailsForm);
                    NYLDSelenium.Click("Select Cash Value by fax Request", Request_CashValueFax);
                    Thread.Sleep(1000);
                    NYLDSelenium.PageLoad("Fax Cash Value Request", FaxBoxRequest);

                }
                else
                    NYLDSelenium.ReportStepResult("Cancel button not displayed", "The cancel button is not displayed", "FAIL");

                NYLDSelenium.VerifyText("Fax Cash Value Title", testData.GetContent("FaxCashValueLetter - Title").ToString().Replace("\r", "").Replace("\n", ""), NYLDSelenium.GetAttribute("get message text", FaxBoxTitle).Replace("\r", "").Replace("\n", ""));
                NYLDSelenium.VerifyText("Fax Cash Value Instructions", testData.GetContent("FaxCashValueLetter - Instructions").ToString().Replace("\r", "").Replace("\n", ""), NYLDSelenium.GetAttribute("get message text", FaxBoxInst).Replace("\r", "").Replace("\n", ""));

                NYLDSelenium.ElemExist("Fax Number Label", FaxBoxLabel);
                NYLDSelenium.ElemExist("Cancel Button", FaxBoxCancel);
                NYLDSelenium.ElemExist("Confirm Button", RequestConfirmButton);
                data[KeyRepository.CVLFaxNumber] = "(813)639-8538";
                NYLDSelenium.SendKeys("Fax Number", FaxBoxInputNumber, data[KeyRepository.CVLFaxNumber], true,"always","always");

                NYLDSelenium.Click("Confirm Button", RequestConfirmButton);

                NYLDSelenium.PageLoad("Fax Thank you", ConfirmDialog);
                NYLDSelenium.VerifyText("Fax Cash Thank You", "Thank you, " + data[KeyRepository.FirstName] + ". " + testData.GetContent("FaxCashValueLetter - Thank You msg").ToString().Replace("\r", "").Replace("\n", ""), NYLDSelenium.GetAttribute("Fax confirmation text", ConfirmDialog).Replace("\r", "").Replace("\n", ""),"always","always");

                NYLDSelenium.Click("Backto Details Link", BacktoDetailsLink);
                //Adding to Keyrepo for Address tables verification, 
                if (data[KeyRepository.AddressLine2] == " ")
                    ExpContractOwner = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + data[KeyRepository.AddressLine1] + data[KeyRepository.City] + " " + data[KeyRepository.State] + " " + data[KeyRepository.Zip];
                else
                    ExpContractOwner = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + data[KeyRepository.AddressLine1] + data[KeyRepository.AddressLine2] + data[KeyRepository.City] + " " + data[KeyRepository.State] + " " + data[KeyRepository.Zip];

                //Address2, Address3 are ""
                data[KeyRepository.CVLAddressData] = data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + "|" + data[KeyRepository.AddressLine1] + " |" + data[KeyRepository.AddressLine2] + " |" + "" + " |" + data[KeyRepository.City] + " " + data[KeyRepository.State] + "  " + data[KeyRepository.ZipCode];


            }
            else                         // request for Duplicate Contract  //
            {
                //Select 'Request Duplicate Contract' 
                NYLDSelenium.Click("Select Duplicate Request", Request_DuplicateContract);

                NYLDSelenium.PageLoad("Duplicate Contract confirmation Window", ConfirmRequestBox_DuplicateContract);

                //verify Text//
                NYLDSelenium.VerifyText("Confirmation message", ExpConfirmMsg.Replace(" ", ""), NYLDSelenium.GetAttribute("get message text", RequestBody_DuplicateLetter).Replace(" ", "").Replace("\r\n", ""),"always","always");

                if (!args.Contains("Lapse"))
                    NYLDSelenium.Click("Duplicate Contract Confirm", RequestConfirmButton);

                if (info == "Exists" && !args.Contains("Lapse"))
                {
                    //Verify Text based on Query return value //
                    if (DB.GetDupContractTTP1Entry())   //with in 30 days
                    {
                        ExpDesc = "Thank you " + data[KeyRepository.FirstName] + ". We've received your request.According to our records, you have already requested a copy of this contract within the last 30 days. If you have not received your contract in the mail, please call New York Life at:(800)865-7927 Monday - Friday: 8 a.m. to 8 p.m. (ET)";

                        NYLDSelenium.VerifyText("Duplicate Contract Denial dialog Body", ExpDesc.Replace(" ", ""), NYLDSelenium.GetAttribute("get message text", ConfirmDialog).Replace(" ", "").Replace("\r\n", ""),"always","always");
                    }
                    else        //Soft failure
                    {
                        NYLDSelenium.ReportStepResult("Duplicate Contract Denial dialog Body", "A duplicate records was not found in the database, so could not proceed with testcase", "FAIL");
                    }
                }
                else if (!args.Contains("Lapse"))
                {
                    if (DB.GetDupContractTTP1Entry() == false)   //with in 30 days
                    {
                        ExpThankMsg = "Thank you, " + data[KeyRepository.FirstName] + ". We've received your request. Please allow upto 7-10 days for your " + item + " to arrive.";

                        NYLDSelenium.VerifyText("Duplicate Contract Confirm dialog Body", ExpThankMsg.Replace(" ", ""), NYLDSelenium.GetAttribute("get message text", ConfirmDialog).Replace(" ", "").Replace("\r\n", ""),"always","always");

                    }
                    else        //More than 30 days
                    {
                        NYLDSelenium.ReportStepResult("Duplicate Contract Denial dialog Body", "A duplicate records was found in the database, so could not proceed with testcase.", "FAIL");
                    }
                }

                //Due to lapse contract couldn't take a request and it should stop the process
                if (args.Contains("Lapse"))
                {
                    ExpDesc = "We are unable to process your request at this time. For assistance,please contact New York Life at:(800)865-7927 Monday - Friday: 8 a.m. to 8 p.m. (ET)×";
                    NYLDSelenium.VerifyText("Duplicate Contract Confirm dialog Body", ExpDesc.Replace(" ", "").Trim(), NYLDSelenium.GetAttribute("get message text", LapseErrorDialog).Replace(" ", "").Replace("\r\n", "").Trim(),"always","always");
                }

                if (!args.Contains("Lapse"))
                    NYLDSelenium.Click("Duplicate Contract - Back to detailed view", BacktoDetailsLink);
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: CashValueLetterDiffAddress                                                                  ///////////
        ////// Description:  Method to fill up the AlternateAddress to CashValue letter request                  ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public string CashValueLetterDiffAddress(string args)
        {
            string Addressee = null;
            string AddressLine1 = null;
            string AddressLine2 = null;
            string City = null;
            string State = null;
            string Zip = null;
            string CVAltAdd = null;

            //Verfiy Header 
            NYLDSelenium.PageLoad("CV Alternate Address Header", CVAltAddressHeader);

            //TODO: Suggested mean we should be taking what system is giving but why are we hard coding it?
            switch (args.Trim())
            {
                case "AlternateAddress-Suggested":
                    Addressee = "Mary Williams";
                    AddressLine1 = "345 Lincoln Avenue";
                    AddressLine2 = "Suite # 110";
                    City = "Edison";
                    State = "NJ";
                    Zip = "07005";
                    break;

                case "AlternateAddress-Entered":
                    Addressee = "Don Haynie";
                    AddressLine1 = "18006 Wynthorne Drive";
                    AddressLine2 = "";
                    City = "Tampa";
                    State = "FL";
                    Zip = "33647";
                    break;
            }

            //fill up the Alt Addreess
            NYLDSelenium.SendKeys("Alt Addressee", CVAltAddressee, Addressee);
            NYLDSelenium.SendKeys("Alt Address line1", CVAltAddressLine1, AddressLine1);
            NYLDSelenium.SendKeys("Alt Address line2", CVAltAddressLine2, AddressLine2);
            NYLDSelenium.SendKeys("Alt Address City", CVAltAddressCity, City);
            NYLDSelenium.SelectList("Alt Address State", CVAltAddressState, State, "byvalue");
            NYLDSelenium.SendKeys("Alt Address Zip", CVAltAddressZip, Zip);

            CVAltAdd = Addressee + "|" + AddressLine1 + "|" + AddressLine2 + "|" + "" + "|" + City + ", " + State + "  " + Zip;
            // query table results
            //temp[0][0] = LDLNAM
            //temp[0][1] = LDLAD1
            //temp[0][2] = LDLAD2
            //temp[0][3] = LDLAD3
            //temp[0][4] = LDLCSZ
            //temp[0][5] = LDKEYF
            return CVAltAdd;
        }

        public string CashValueLetterOwnerAddress(string args)
        {
            string Addresse = null;
            string AddressLine1 = null;
            string AddressLine2 = null;
            string City = null;
            string State = null;
            string Zip = null;
            string CVAltAdd = null;

            //Verfiy Header 
            NYLDSelenium.PageLoad("CV Alternate Address Header", CVAltAddressHeader);

            //TODO: Suggested mean we should be taking what system is giving but why are we hard coding it?
            switch (args.Trim())
            {
                case "AlternateAddress-Suggested":
                    Addresse = "Mary Williams";
                    AddressLine1 = "345 Lincoln Avenue";
                    AddressLine2 = "Suite # 110";
                    City = "Edison";
                    State = "NJ";
                    Zip = "07005";
                    break;

                case "AlternateAddress-Entered":
                    Addresse = "Don Haynie";
                    AddressLine1 = "18006 Wynthorne Drive";
                    AddressLine2 = "";
                    City = "Tampa";
                    State = "FL";
                    Zip = "33647";
                    break;
            }

            //fill up the Alt Addreess
            NYLDSelenium.SendKeys("Alt Addressee", CVAltAddressee, Addresse);
            NYLDSelenium.SendKeys("Alt Address line1", CVAltAddressLine1, AddressLine1);
            NYLDSelenium.SendKeys("Alt Address line2", CVAltAddressLine2, AddressLine2);
            NYLDSelenium.SendKeys("Alt Address City", CVAltAddressCity, City);
            NYLDSelenium.SelectList("Alt Address State", CVAltAddressState, State, "byvalue");
            NYLDSelenium.SendKeys("Alt Address Zip", CVAltAddressZip, Zip);

            CVAltAdd = Addresse + "|" + AddressLine1 + "|" + AddressLine2 + "|" + City + "|" + State + "|" + Zip;
            return CVAltAdd;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyFamilyBillBanner                                                                      ///////////
        ////// Description:  Verify Family banner displayed for the policy                                       ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyFamilyBillBanner(string args)
        {
            ManagePaymentsPage payment = new ManagePaymentsPage(driver, data);

            payment.VerifyFamilyBillBanner();
        }
      
        public void BtnClick(string display, IWebElement elemetdata,string element)
        {
          
            try
            {
                //NYLDSelenium.ScrollToView(elemetdata, true);
                NYLDSelenium.Click(display, elemetdata,true);
            }
            catch
            {
                try
                {
                    driver.FindElement(By.XPath(element)).Click();
                }
                catch
                {
                    CommonFunctions cf = new CommonFunctions(data);
                    cf.MovetoElement(element, driver);
                }
            }
        }

        public void ClickPaymentHistory()
        {
            // Click payment history Link
            NYLDSelenium.Click("payament history link", PaymentHistoryLink, true, "always", "always",60);
        }

    }
}