﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Drivers;
using CSW.PageObjects.Functions;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using iText.Signatures;
using Newtonsoft.Json;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using Spire.Pdf.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using static iText.StyledXmlParser.Jsoup.Select.Evaluator;

namespace CSW.PageObjects.Coverage
{
    class MyBeneficiariesPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;
        public static List<string> newBeneAdded = new List<string>();

        public MyBeneficiariesPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////
        /////////    My Beneficiaries Page Section    /////////
        ///////////////////////////////////////////////////////

        [FindsBy(How = How.Id, Using = "policy-toggle")]
        public IWebElement ContractNumberDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Choose a contract')]")]
        public IWebElement ChooseContractHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[contains(text(), 'Manage Beneficiaries')]")]
        public IWebElement BeneficiaryPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//h3[contains(text(), 'Manage Beneficiaries')]/../div[contains(@class, 'alert')]")]
        public IWebElement BeneMessage13 { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, '/Coverage/Beneficiaries') and contains(text(), 'Add')]")]
        public IWebElement AddBeneficiaryLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, '/Coverage/Beneficiaries/Edit') and contains(text(), 'edit')]")]
        public IWebElement EditBeneficiaryLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, '/Coverage/Beneficiaries') and contains(text(), 'distribution')]")]
        public IList<IWebElement> EditDistributionLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, '/Coverage/Beneficiaries')]/*[contains(text(), 'Delete')]")]
        public IWebElement DeleteBeneficiariesLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'align-items-start')]")]
        public IList<IWebElement> BeneficiaryClasses { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[(@class='mt-4')]")]
        public IList<IWebElement> BeneficiaryDistribution { get; set; }

        //////////////////////////////////////////////////////
        /////////    Add Beneficiary Page Section    /////////
        //////////////////////////////////////////////////////


        //No Bene
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'No beneficiaries are listed for this contract.')]")]
        public IWebElement NoBeneMessage { get; set; }

        [FindsBy(How = How.Id, Using = "add-beneficiary-form")]
        public IWebElement AddBeneficiaryPage { get; set; }

        [FindsBy(How = How.Id, Using = "//*[@id='add-beneficiary-form']/div[1]//p[contains(text(),'Beneficiary class')]")]
        public IWebElement AddBeneficiaryClass { get; set; }

        [FindsBy(How = How.Id, Using = "//*[@id='add-beneficiary-form']/div[1]//p[contains(text(),'Beneficiary type')]")]
        public IWebElement AddBeneficiaryType { get; set; }

        //Choose Bene Type Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Choose a beneficiary type')]")]
        public IWebElement ChooseBeneTypeHeader { get; set; }

        //Choose Bene Class Type Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Choose a beneficiary class')]")]
        public IWebElement ChooseBeneClassTypeHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id, 'entity-type')]")]
        public IList<IWebElement> EntityTypes { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'entity-type')]")]
        public IList<IWebElement> EntityTypeLabels { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id, 'beneficiary-type')]")]
        public IList<IWebElement> BeneficiaryTypes { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(@for, 'beneficiary-type')]")]
        public IList<IWebElement> BeneficiaryTypeLabels { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@class, 'btn') and contains(text(), 'Cancel')]")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(@type, 'submit') and contains(text(), 'Continue')]")]
        public IWebElement Continue { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[contains(@id, 'entity-type-estate')]//following::label/strong[contains(text(),'Funeral Home')]")]
        public IWebElement FuneralEntity { get; set; }


        ////////////////////////////////////////////////////////
        /////////    Add Beneficiary Page 2 Section    /////////
        ////////////////////////////////////////////////////////

        //Contract Number
        [FindsBy(How = How.XPath, Using = "//div[contains(text(), 'Contract Number')]/strong")]
        public IWebElement ContractNumber_Page2 { get; set; }

        //Beneficiary Entity
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Beneficiary type')]/following-sibling::div[1]")]
        public IWebElement BeneficiaryEntity_Page2 { get; set; }

        //Beneficiary Type
        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Beneficiary class')]/following-sibling::div")]
        public IWebElement BeneficiaryType_Page2 { get; set; }

        //First Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtFirstName']")]
        public IWebElement FirstName { get; set; }

        //First Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[contains(@readonly,'readonly') and @id='txtFirstName']")]
        public IWebElement FirstNameReadOnly { get; set; }

        //First Name Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtFirstName-error']")]
        public IWebElement FirstNamePopUp { get; set; }

        //Company Name
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCompanyName']")]
        public IWebElement CompanyName { get; set; }

        //Last Name Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblLastName']")]
        public IWebElement LastNameHeader { get; set; }

        //Last Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtLastName']")]
        public IWebElement LastName { get; set; }

        //Last Name Text Box
        [FindsBy(How = How.XPath, Using = "//*[contains(@readonly,'readonly') and @id='txtLastName']")]
        public IWebElement lastNameReadOnly { get; set; }

        //Last Name Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtLastName-error']")]
        public IWebElement LastNamePopUp { get; set; }

        //Social Security Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblSsn']")]
        public IWebElement SocialSecurityHeader { get; set; }

        //Social Security Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='Ssn']")]
        public IWebElement SocialSecurity { get; set; }

        //Social Security Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='lblSsn']/following::div[@class='readonly bullet-list']")]
        public IWebElement SocialSecurityEditPage { get; set; }

        //Social Security Show button
        [FindsBy(How = How.XPath, Using = "//*[@id='add-beneficiary-form']/div[2]/div[1]/div[3]/a")]
        public IWebElement SocialSecurityShow { get; set; }

        //Social Security Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='Ssn-error']")]
        public IWebElement SocialSecurityPopup { get; set; }

        //Social Security Edit Button
        [FindsBy(How = How.XPath, Using = "//*[@id='taxidreadonly']/div")]
        public IWebElement SocialSecurityEdit { get; set; }

        //Relationship Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblRelationship']")]
        public IWebElement RelationshipHeader { get; set; }

        //Relationship Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='Relationship']")]
        public IWebElement RelationshipDropdown { get; set; }

        //Phone Number Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblPhoneNumber']")]
        public IWebElement PhoneNumberHeader { get; set; }

        //Phone Number Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPhoneNumber']")]
        public IWebElement PhoneNumber { get; set; }

        //Phone Number Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPhoneNumber-error']")]
        public IWebElement PhoneNumberPopUp { get; set; }

        //Phone Number Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtEmail']")]
        public IWebElement Email { get; set; }

        //Phone Number Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtEmail-error']")]
        public IWebElement EmailErrorPopUp { get; set; }

        //Date of Birth Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblDateOfBirth']")]
        public IWebElement DateOfBirthHeader { get; set; }

        //Date of Birth Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtDateOfBirth']")]
        public IWebElement DateOfBirth { get; set; }

        //Date of Birth Validation message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtDateOfBirth-error']")]
        public IWebElement DateOfBirthPopUp { get; set; }

        //Per Stirpes Option button
        [FindsBy(How = How.XPath, Using = "//*[@id='PerStirpesTrue']/../label")]
        public IWebElement PerStirpeslabel { get; set; }

        //None Option button
        [FindsBy(How = How.XPath, Using = "//*[@id='PerStirpesFalse']/../label")]
        public IWebElement NoneLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='PerStirpesTrue']/../label/../input")]
        public IWebElement PerStirpesInput { get; set; }

        //None Option button
        [FindsBy(How = How.XPath, Using = "//*[@id='PerStirpesFalse']/../label/../input")]
        public IWebElement NoneInput { get; set; }

        //Addresss Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblAddress1']")]
        public IWebElement AddressHeader { get; set; }

        //Address Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress1']")]
        public IWebElement AddresLine1 { get; set; }

        //Payor Addresss Line Validation message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress1-error']")]
        public IWebElement AddressPopUp { get; set; }

        //Addresss Line 2 Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblAddress2']")]
        public IWebElement AddressLine2Header { get; set; }

        //Addresss Line 2 Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress2']")]
        public IWebElement AddressLine2 { get; set; }

        //Address Line 2 Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress2-error']")]
        public IWebElement AddressLine2PopUp { get; set; }

        //City Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblCity']")]
        public IWebElement CityHeader { get; set; }

        //City Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCity']")]
        public IWebElement City { get; set; }

        //City validation message pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCity-error']")]
        public IWebElement CityPopUp { get; set; }

        //State Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblState']")]
        public IWebElement StateHeader { get; set; }

        //State Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='State']")]
        public IWebElement State { get; set; }

        //Payor State Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='Address_State-error']")]
        public IWebElement StatePopUp { get; set; }

        //Zip Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblZip']")]
        public IWebElement ZipHeader { get; set; }

        //Zip Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtZip']")]
        public IWebElement Zip { get; set; }

        //Zip validation message pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtZip-error']")]
        public IWebElement ZipPopUp { get; set; }

        //Province Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblProvince']")]
        public IWebElement ProvinceHeader { get; set; }

        //Province Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='Province']")]
        public IWebElement Province { get; set; }

        //Province Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='Address_Province-error']")]
        public IWebElement ProvincePopUp { get; set; }

        //Postal code Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblPostalCode']")]
        public IWebElement PostalCodeHeader { get; set; }

        //Postal code Text box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPostalCode']")]
        public IWebElement PostalCode { get; set; }

        //Postal Code validation message pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPostalCode-error']")]
        public IWebElement PostalCodePopUp { get; set; }

        //Country Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblCountry']")]
        public IWebElement CountryHeader { get; set; }

        //Country Dropdown
        [FindsBy(How = How.XPath, Using = "//*[@id='Country']")]
        public IWebElement Country { get; set; }

        //Country validation message pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='Address_Country-error']")]
        public IWebElement CountryPopup { get; set; }

        /////////////////////////////////////////////////////////
        /////////    Share Distribution Page Section    /////////
        /////////////////////////////////////////////////////////

        [FindsBy(How = How.XPath, Using = "//p[contains(text(), 'Edit beneficiary distribution')]")]
        public IWebElement BenePage3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@aria-modal='true']//div/div/p[@id='delete-bene-body']")]
        public IWebElement DeleteBeneMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@aria-modal='true']//button[contains(text(),'Cancel')]")]
        public IWebElement CancelDeleteButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@aria-modal='true']//button[contains(text(),'Delete')]")]
        public IWebElement DeleteButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@aria-modal='true']//button[contains(text(),'Add a new beneficiary')]")]
        public IWebElement AddNewBeneButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='delete-bene-body']")]
        public IWebElement ShareTotalError { get; set; }



        /////////////////////////////////////////////////////////
        /////////    Edit Beneficiaries Page Section    /////////
        /////////////////////////////////////////////////////////

        //Edit beneficiaries Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Edit')]")]
        public IWebElement EditBeneficiariesHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='ReviewAndConfirm']")]
        public IWebElement ReviewAndConfirm { get; set; }

        ////////////////////////////////////////////////
        /////////    Thank You Page Section    /////////
        ////////////////////////////////////////////////

        //Thank You Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Thank you')]")]
        public IWebElement ThankYouHeader { get; set; }

        //Back to Dashboard Link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to Manage')]")]
        public IWebElement BackToManageBeneficiariesLink { get; set; }

        //Funeral Home
        [FindsBy(How = How.XPath, Using = "//p[@class='pb-4']/parent::div/p")]
        public IList<IWebElement> FuneralHomeText { get; set; }

        //Bene Type Choice
        [FindsBy(How = How.XPath, Using = "//*[@id='add-beneficiary-form']/div[1]/div[1]/strong")]
        public IWebElement BeneTypeChoice { get; set; }

        //Bene Class Choice
        [FindsBy(How = How.XPath, Using = "//*[@id='add-beneficiary-form']/div[1]/div[2]/strong")]
        public IWebElement BeneClassChoice { get; set; }

        //Enter Bene Info Header
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Enter beneficiary information')]")]
        public IWebElement EnterBeneInfoHeader { get; set; }


        //Company Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblCompanyName']")]
        public IWebElement CompanyHeader { get; set; }

        //Company Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCompanyName']")]
        public IWebElement Company { get; set; }

        //Company Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCompanyName-error']")]
        public IWebElement CompanyPopUp { get; set; }

        //TaxID Header
        [FindsBy(How = How.XPath, Using = "//div[@id='taxidreadonly']//label[@id='lblTaxIdNumber']")]
        public IWebElement TaxIDHeader { get; set; }

        //TaxID Text Box
        [FindsBy(How = How.XPath, Using = "//*[@id='lblTaxIdNumber']/following::div[@class='readonly bullet-list']")]
        public IWebElement TaxID { get; set; }

        //TaxID Show button
        [FindsBy(How = How.XPath, Using = "//*[@id='taxidedit']/a")]
        public IWebElement TaxIDShow { get; set; }

        //TaxID Validation Message Pop Up
        [FindsBy(How = How.XPath, Using = "//*[@id='TaxIdNumber-error']")]
        public IWebElement TaxIDPopup { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(@type, 'submit') and contains(text(), 'Update')]")]
        public IWebElement Update { get; set; }

        //Edit Bene Distribution Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Edit beneficiary distribution')]")]
        public IWebElement EditBeneDistributionHeader { get; set; }

        //Choose Bene Class Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Choose a beneficiary class')]")]
        public IWebElement ChoseBeneClassHeader { get; set; }

        //Total Percentage for share distribution
        [FindsBy(How = How.XPath, Using = "//*[@id='total-2']")]
        public IWebElement TotalPercentage { get; set; }

        //Review and Confirm Header
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Review and Confirm')]")]
        public IWebElement ReviewAndConfirmHeader { get; set; }

        //Thank You Message
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Thank you')]")]
        public IWebElement ThankYouMessage { get; set; }        

        //Cant Add Online Message
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'This type of beneficiary cannot be added online.')]")]
        public IWebElement CantAddOnlineMessage { get; set; }

        //Bene Form Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Beneficiary Form')]")]
        public IWebElement BeneFormHeader { get; set; }

        //Bene Form Button
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Beneficiary form')]")]
        public IWebElement BeneFormButton { get; set; }

        //Trust Form Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Statement of Trust Form')]")]
        public IWebElement TrustFormHeader { get; set; }

        //Trust Form Message
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'In addition to the Beneficiary Form above')]")]
        public IWebElement TrustFormMessage { get; set; }

        //Trust Form button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Start Survey')]")]
        public IWebElement TrustFormButton { get; set; }

        //Pre Need Agreement Header
        [FindsBy(How = How.XPath, Using = "//strong[contains(text(),'Pre-need Agreement:')]")]
        public IWebElement PreNeedAgreementHeader { get; set; }

        //Pre Need Agreement Message
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'To protect your death benefit, New York Life')]")]
        public IWebElement PreNeedAgreementMessage { get; set; }

        //NYL Mailing Address
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'New York Life Insurance Company, AARP Operations')]")]
        public IWebElement NYLAddress { get; set; }

        //Prevent Bene Change Subheader
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'You can easily edit, add or delete your beneficiary')]")]
        public IWebElement PreventBeneChangeSubheader { get; set; }

        //Prevent Bene Change Subheader
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'This policy is not eligible to manage beneficiaries online')]")]
        public IWebElement PreventBeneChangeMessage { get; set; }

        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Method to verify beneficiaries listed
        /// </summary>
        /// <param name="args"></param>
        public void VerifyBeneficiaries(string args)
        {
            int beneClass = 0;
            string expectedBeneClassCategory = "";
            string expectedBeneClassName = "";
            string tempPolicy = data[KeyRepository.PolicyNumber];
            bool irb = false;
            IWebElement beneClassElement = null;
            IWebElement beneClassCategoryElement = null;
            IWebElement beneClassHeading = null;
            IList<IWebElement> beneDetails = new List<IWebElement>();
            int contractCount = 0;

            LSPDatabase database = new LSPDatabase(driver, data);
            CommonFunctions commonFunctions = new CommonFunctions(data);
            TestData testData = new TestData();

            database.QueryAssociatedPolicies("Beneficiaries");

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify My Benficiaries Section" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            Thread.Sleep(1000);
            //Verify Page Load
            NYLDSelenium.PageLoad("Manage Bene", BeneficiaryPage);
            NYLDSelenium.AddHeader("Manage Bene verification - " + data[KeyRepository.PolicyNumber], "SubHeader");
            if (args == "13Bene")
            {
                NYLDSelenium.VerifyText("13 Beneficiary message", testData.GetContent("13Beneficiary"), commonFunctions.FormatString(NYLDSelenium.GetAttribute("13 Bene", BeneMessage13)));
            }
            else
            {
                //Verify links to manage Beneficiaries
                NYLDSelenium.ElemExist("Add Beneficiary", AddBeneficiaryLink);
                NYLDSelenium.ElemExist("Delete Beneficiary", DeleteBeneficiariesLink);
                NYLDSelenium.ElemExist("Edit Beneficiary Distribution", EditDistributionLink[0]);

                IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-8000);"); Thread.Sleep(4000);
                //Verify Drop down Menu
                string[] policies = CSWData.AssociatedPolicies.Split(';');
                if (policies.Count() > 1)
                    NYLDSelenium.ElemExist("Policies Dropdown Menu", ContractNumberDropDown);
                else
                    NYLDSelenium.ElemNotExist("Policies Dropdown Menu", ContractNumberDropDown);

                NYLDSelenium.AddHeader("Verify Manage Beneficiaries Links Add Beneficiary - Delete Beneficiary, Edit Beneficiary Distribution links verification SUCCESS - " + data[KeyRepository.PolicyNumber], "Success");
                int counti = 0; string ActualPolicyName = "";
                foreach (string policy in policies)
                {
                    js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-8000);"); Thread.Sleep(4000);
                    if (policies.Count() > 1)
                    {
                        contractCount++;
                        SelectElement select = new SelectElement(ContractNumberDropDown);
                        IList<IWebElement> options = select.Options;

                        ActualPolicyName = options[counti].GetAttribute("text").Trim();
                        data[KeyRepository.PolicyNumber] = ActualPolicyName.Split('-')[1].Trim();

                        //Select the contract from dropdown
                        js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-8000);"); Thread.Sleep(6000);
                        NYLDSelenium.SelectList("Policy drop down", ContractNumberDropDown, ActualPolicyName, "bytext", true);
                    }
                    else
                    {
                        data[KeyRepository.PolicyNumber] = policy.Split('-')[1].Trim();
                        contractCount++;
                    }

                    //Query Policy details and corresponding bene info  
                    database.QueryPolicyDetails();
                    database.GetBeneInfo();
                    database.QueryPaymentDetails();

                    //Other than lapse contract verify the bene details
                    if (!data[KeyRepository.PolicyStatus].StartsWith("L"))
                    {
                        string expectedcpolurl = testData.GetContent("Beneficiariescpol").Replace("{Index}", (contractCount - 1).ToString());
                        //Verify the cpol index of page URL
                        if ((contractCount - 1) == 0)
                        {
                            Uri uri = new Uri(expectedcpolurl);
                            string baseUrl = uri.GetLeftPart(UriPartial.Path);
                            NYLDSelenium.VerifyText("Beneficiary of " + data[KeyRepository.PolicyNumber] + " url's cpol index", baseUrl, driver.Url);
                        }
                        else
                            NYLDSelenium.VerifyText("Beneficiary of " + data[KeyRepository.PolicyNumber] + " url's cpol index", expectedcpolurl, driver.Url);

                        for (int i = 0; i < CSWData.BeneInfo.Count; i++)
                        {
                            NYLDSelenium.AddHeader("Verify bene " + CSWData.BeneInfo[i][2] + "-" + CSWData.BeneInfo[i][0] + " details :", "SubHeader");
                            if (CSWData.BeneInfo[i][2] == "IRB")
                            {
                                beneClass = 1;
                                irb = true;
                            }
                            else
                            {
                                beneClass = Convert.ToInt16(CSWData.BeneInfo[i][2].Substring(CSWData.BeneInfo[i][2].Length - 1));
                                irb = false;
                            }

                            //Find Expected Bene class and verify if it is in UI          
                            if (beneClass > BeneficiaryClasses.Count)
                            {
                                NYLDSelenium.ReportStepResult("Bene count mismatch found", "Bene of class " + beneClass + " is found in DB but displayed in My Beneficiaries screen", "Fail");
                                break;
                            }
                            else
                                beneClassElement = BeneficiaryClasses[beneClass - 1];


                            //Get Bene details for the table rows for the corresponding Bene class
                            beneDetails = beneClassElement.FindElements(By.XPath("./following-sibling::div//table//tbody/tr"));
                            beneClassCategoryElement = beneClassElement.FindElement(By.XPath(".//span"));
                            beneClassHeading = beneClassElement.FindElement(By.XPath(".//strong"));

                            //Verify Bene class Heading
                            switch (CSWData.BeneInfo[i][2])
                            {
                                case "BN1":
                                case "IRB":
                                    expectedBeneClassCategory = "1st";
                                    break;
                                case "BN2":
                                    expectedBeneClassCategory = "2nd";
                                    break;
                                case "BN3":
                                    expectedBeneClassCategory = "3rd";
                                    break;
                                default:
                                    expectedBeneClassCategory = CSWData.BeneInfo[i][2];
                                    break;
                            }
                            expectedBeneClassName = commonFunctions.ExpectedBeneClassName(CSWData.BeneInfo[i][2]);
                            NYLDSelenium.VerifyText("Bene class category", expectedBeneClassCategory, beneClassCategoryElement.Text);
                            NYLDSelenium.VerifyText("Bene class heading", expectedBeneClassName + " Class Beneficiaries", beneClassHeading.Text);

                            NYLDSelenium.AddHeader("Verify Manage Beneficiaries Class heading - " + data[KeyRepository.PolicyNumber] + "Bene class category and Bene class heading verification SUCCESS", "Success");
                            
                            //Format Name as displayed in UI
                            string fullname;
                            string[] name; 
                            NYLDSelenium.AddHeader("Verify Manage Beneficiaries details - " + data[KeyRepository.PolicyNumber], "SubHeader");
                            if (CSWData.BeneInfo[i][0].Contains("/"))
                            {
                                name = CSWData.BeneInfo[i][0].Split('/');

                                if (name.Length > 2)
                                {

                                    if (name[2].Trim() == "")
                                    {
                                        fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim() + " " + name[4].Trim();
                                    }
                                    else
                                    {
                                        fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[2].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim() + " " + name[4].Trim();
                                    }
                                }
                                else
                                    fullname = name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim();


                                if (CSWData.BeneInfo[i][15] == "Trust")
                                    fullname = "Trust of " + fullname;

                                if (CSWData.BeneInfo[i][15] == "Estate")
                                    fullname = name[0].Replace(",", "").Replace("Per Stirpes", "");
                            }
                            else
                            {
                                fullname = CSWData.BeneInfo[i][0].Replace(",", "").Replace("Per Stirpes", "").Trim();

                                if (CSWData.BeneInfo[i][15] == "Estate")
                                    fullname = "Estate";
                            }

                            //Bene Class wise details verification
                            for (int j = 0; j < beneDetails.Count - 1; j++)
                            {
                                IList<IWebElement> beneInfo = new List<IWebElement>();

                                beneInfo = beneDetails[j].FindElements(By.XPath("./td"));
                                if (fullname.Trim() == beneInfo[1].Text.Trim() && CSWData.BeneInfo[i][15] == beneInfo[2].Text.Trim())
                                {
                                    if (irb || CSWData.BeneInfo[i][0] == "Trust")
                                    {
                                        IWebElement lockElement = beneInfo[0].FindElement(By.XPath(".//i"));
                                        IWebElement irbContent = lockElement.FindElement(By.XPath("ancestor::tr/following-sibling::tr[1]"));
                                        string lockText = NYLDSelenium.GetAttribute("Lock Text", lockElement, "data-original-title");
                                        NYLDSelenium.VerifyText("Beneficiary lock text ", "This beneficiary cannot be edited online.", lockText.Trim());
                                        if (CSWData.BeneInfo[i][0] == "Trust")
                                            NYLDSelenium.VerifyText("bene cannot be edited Content", testData.GetContent("TrustEditIconText"), commonFunctions.FormatString(irbContent.Text));
                                        else
                                            NYLDSelenium.VerifyText("bene cannot be edited Content", testData.GetContent("IRBContent"), commonFunctions.FormatString(irbContent.Text));
                                    }
                                    else
                                        NYLDSelenium.VerifyText("Beneficiary Edit link " + i, "edit", beneInfo[0].Text.Trim());

                                    NYLDSelenium.VerifyText("Beneficiary Name " + i, fullname.Trim(), beneInfo[1].Text.Trim());
                                    if (CSWData.BeneInfo[i][1].Trim() == "0")
                                        CSWData.BeneInfo[i][1] = Convert.ToInt32(CSWData.BeneInfo[i][1].Trim()).ToString("0.00");

                                    // NYLDSelenium.VerifyText("Beneficiary Share " + i, CSWData.BeneInfo[i][1].Replace(".00", "").Trim(), beneInfo[3].Text.Replace("%", "").Trim());
                                    var actual = Math.Round(Convert.ToDouble(beneInfo[3].Text.Replace("%", "").Replace(".00", "").Trim()), 2, MidpointRounding.AwayFromZero);
                                    var expected = Math.Round(Convert.ToDouble(CSWData.BeneInfo[i][1].Replace("%", "").Replace(".00", "").Trim()), 2, MidpointRounding.AwayFromZero);
                                    NYLDSelenium.VerifyText("Beneficiary Share" + i, expected.ToString(), actual.ToString());

                                    break;
                                }

                            }

                        }
                        NYLDSelenium.AddHeader("Verify Manage Beneficiaries details - " + data[KeyRepository.PolicyNumber], "Success");
                    }
                    else if (data[KeyRepository.PolicyStatus].StartsWith("L"))
                        NYLDSelenium.VerifyText("Beneficiary message", "No Beneficiaries to display /not in edit mode", "No Beneficiaries to display /not in edit mode");
                    counti = counti + 1;
                    if (counti != 0)
                        NYLDSelenium.AddHeader("Verify bene details steps completed successfully", "SubHeader");
                }
            }
        }

        /// <summary>
        /// Method to Add a new beneficiary
        /// </summary>
        /// <param name="args"></param>
        public void AddBeneficiary(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Add Beneficiary: " + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Page Load
            NYLDSelenium.PageLoad("Add Beneficiary", AddBeneficiaryPage);

            //Page 1
            VerifyPage1(args);
            FillPage1(args);

            //Page 2
            VerifyPage2(args);
            if (args.Split('-')[0].Trim() != "FuneralHome" && args.Split('-')[0].Trim() != "Trust")
            {
                string[] options = args.Split('-');
                string entity = args.Split('-')[0].Trim();
                bool perStirpes = false;
                string country = "US";
                if (options.Count() > 2)
                {
                    if (options[2].Trim() == "PerStirpe")
                        perStirpes = true;

                    if (options.Count() > 3)
                        country = options[3].Trim();
                }
                FillPage2(country, args.Split('-')[1], entity, perStirpes);

                //Page 3   
                VerifyPage3(args);
                FillPage3(args);
            }
            else if (args.Split('-')[0].Trim() == "FuneralHome")
            {
                //pdf verification
                VerifyFuneralHomeBeneformPDF();
            }
        }

        /// </summary>
        public void VerifyFuneralHomeBeneformPDF()
        {
            //PDF validation      
            CommonFunctions commonfunctions = new CommonFunctions(data);
            ValidatePDF validatePdf = new ValidatePDF(driver, data);


            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Download PDF" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Delete Existing file
            string filePath = @"C:\Users\" + Environment.UserName + @"\Downloads";
            NYLDGeneric.DeleteFiles(filePath, "Beneficiary Change Form*");

            // NYLDSelenium.ScrollToView(BeneFormButton);
            NYLDSelenium.Click("Download PDF Link", BeneFormButton, true);
            System.Threading.Thread.Sleep(10000);

            int count = 0;
            string[] fileEntries = Directory.GetFiles(filePath);
            foreach (string fileName in fileEntries)
            {
                if (fileName.Contains("Beneficiary Change Form"))
                {
                    count = count + 1;
                    NYLDSelenium.ReportStepResult("Download PDF", "Download PDF is: " + fileName, "INFO", "no");
                }
            }

            if (count == 0)
                NYLDSelenium.ReportStepResult("Download PDF", "Download PDF - Beneficiary Change Form.pdf", "FAIL", "always", "yes");
        }

        /// <summary>
        /// Method to delete multiple beneficiaries
        /// </summary>
        /// <param name="args">Arguments to specify the beneficiaries to delete</param>
        /// <returns>Status of the delete operation</returns>
        public string DeleteMultipleBene(string args)
        {
            LSPDatabase Tampa01 = new LSPDatabase(driver, data);
            TestData testData = new TestData();
            int beneClass;
            int beneCountBeforeDelete;
            int beneCountAfterDelete;

            string[] getOptions = args.Split('-');
            string type = getOptions[0].Trim();
            string editStatus = "Success";

            // Get the class to be edited
            beneClass = Convert.ToInt16(type.Substring(type.Length - 1));

            // Click on edit Distribution link
            NYLDSelenium.Click("Delete a beneficiary", DeleteBeneficiariesLink);
            NYLDSelenium.PageLoad("Edit Distribution", EditBeneDistributionHeader);

            beneCountBeforeDelete = CSWData.BeneInfo.Count;
            // Find Expected Bene class to be edited and verify if it is in UI          
            if (beneClass > BeneficiaryDistribution.Count || beneClass < 1)
            {
                NYLDSelenium.ReportStepResult("Bene count mismatch found", "Bene of class " + beneClass + " not displayed in My Beneficiaries screen", "Fail");
                return "Fail";
            }

            // Find the bene to be edited when multiple benes of same class is displayed with filter information
            IList<IWebElement> beneDetails = BeneficiaryDistribution[beneClass - 1].FindElements(By.XPath("//table[@id='bene-class-" + beneClass + "']//tbody/tr"));
            foreach (var beneInfo in beneDetails)
            {
                IList<IWebElement> beneInfoCells = beneInfo.FindElements(By.XPath("./td"));
                editStatus = DeleteBeneficiary(args, beneInfoCells[4], beneClass, "", beneDetails.Count, beneDetails.IndexOf(beneInfo));
                if (editStatus == "Success")
                {
                    NYLDSelenium.ReportStepResult("Delete multiple bene works as expected", "Bene of class " + beneClass + " and beneficiary number " + (beneDetails.IndexOf(beneInfo) + 1), "Pass");
                }
                else
                {
                    NYLDSelenium.ReportStepResult("Delete multiple bene not works as expected", "Bene of class " + beneClass + " and beneficiary number " + (beneDetails.IndexOf(beneInfo) + 1), "Fail");
                }
            }

            if (getOptions[1] != "AddNewBene" && editStatus == "Success")
            {
                DistributeBeneShare(beneClass);
                // Verify the bene count after the delete
                Tampa01.GetBeneInfo();
                beneCountAfterDelete = CSWData.BeneInfo.Count;
                if (beneCountAfterDelete == beneCountBeforeDelete)
                    NYLDSelenium.ReportStepResult("Bene count are same before and after delete", "Bene of class " + beneClass, "Fail");
            }

            return editStatus;
        }


        /// <summary>
        /// Method to update distribution by cchanging share or deleting a  beneficiary based on filter conditions
        /// </summary>
        /// <param name="args"></param>
        public string UpdateDistribution(string args)
        {
            IWebElement beneClassElement = null;
            IList<IWebElement> beneDetails = new List<IWebElement>();
            int beneClass;

            string[] getOptions = args.Split('-');

            string type = getOptions[0].Trim();
            string action = getOptions[1].Trim();
            string filterInformation = getOptions[2].Trim();
            string editStatus = "Success";

            //Get the class to be edited
            beneClass = Convert.ToInt16(type.Substring(type.Length - 1));

            //Click on edit Distribution link
            NYLDSelenium.Click("Edit Distribuion", EditDistributionLink[beneClass - 1]);
            NYLDSelenium.PageLoad("Edit Distribution", EditBeneDistributionHeader);

            //Find Expected Bene class to be edited and verify if it is in UI          
            if (beneClass > BeneficiaryDistribution.Count || beneClass < 1)
            {
                NYLDSelenium.ReportStepResult("Bene count mismatch found", "Bene of class " + beneClass + " not displayed in My Beneficiaries screen", "Fail");
            }
            else
                beneClassElement = BeneficiaryDistribution[beneClass - 1];

            //Find the bene to be edited when mutiple benes of same class is displayed with filter information       
            beneDetails = beneClassElement.FindElements(By.XPath("//table//tbody/tr"));

            for (int j = 0; j < beneDetails.Count; j++)
            {
                if (j != 0)
                    beneDetails = beneClassElement.FindElements(By.XPath("//table//tbody/tr"));

                IList<IWebElement> beneInfo = new List<IWebElement>();
                beneInfo = beneDetails[j].FindElements(By.XPath("./td"));

                string actualEntityType = NYLDSelenium.GetAttribute("Bene Entity", beneInfo[2]).Replace(" ", "").ToLower();

                if (actualEntityType == filterInformation.ToLower())
                {
                    if (action.ToLower() == "deletebene")
                    {
                        editStatus = DeleteBeneficiary(args, beneInfo[4], beneClass, filterInformation.ToLower(), beneDetails.Count, j);
                        if (editStatus == "Success")
                        {
                            DistributeBeneShare(beneClass);
                        }
                        break;
                    }
                    else if (action.ToLower() == "changeshare")
                    {
                        editStatus = ChangeShare(beneInfo[3], beneClass, filterInformation);
                        break;
                    }
                    else if (action.ToLower() == "changeclass")
                    {
                        ChangeClass(beneInfo[0], beneClass);
                        break;
                    }
                }
                else
                {
                    if (filterInformation.ToLower() == "person" && (actualEntityType != "estate" && actualEntityType != "trust" && actualEntityType != "funeralhome" && actualEntityType != "organization"))
                    {
                        if (action.ToLower() == "deletebene")
                        {
                            editStatus = DeleteBeneficiary(args, beneInfo[4], beneClass, filterInformation, beneDetails.Count, j);
                            if (editStatus == "Success")
                            {
                                DistributeBeneShare(beneClass);
                            }
                            break;
                        }
                        else if (action.ToLower() == "changeshare")
                        {
                            editStatus = ChangeShare(beneInfo[3], beneClass, filterInformation);
                            break;
                        }
                        else if (action.ToLower() == "changeclass")
                        {
                            ChangeClass(beneInfo[0], beneClass);
                            break;
                        }
                    }
                }
            }

            return editStatus;
        }

        /// <summary>
        /// Method to change the bene class
        /// </summary>
        /// <param name="element"></param>
        /// <param name="beneClass"></param>
        public void ChangeClass(IWebElement element, int beneClass)
        {
            Actions act = new Actions(driver);
            IWebElement toElement = null;
            int toClass = 0;

            if (beneClass == 1)
                toClass = 2;
            else if (beneClass == 2)
                toClass = 3;
            else if (beneClass == 3)
                toClass = 1;

            //Drag and Drop the bene to a different class
            toElement = BeneficiaryDistribution[toClass - 1].FindElement(By.XPath(".//table/tbody/tr"));
            act.DragAndDrop(element, toElement).Build().Perform();

            //Update shares
            IWebElement distributeEvenly = null;
            IWebElement distributeEvenlyToClass = null;
            string xpath = "//table[@id='bene-class-" + beneClass + "']//a[contains(@href, 'Distribution')]";
            string xpath2 = "//table[@id='bene-class-" + toClass + "']//a[contains(@href, 'Distribution')]";

            Thread.Sleep(100);
            //Distrbute evenly link
            distributeEvenly = NYLDSelenium.GetWE(xpath);
            NYLDSelenium.Click("Distribute share evenly bene", distributeEvenly, true, "always");


            distributeEvenlyToClass = NYLDSelenium.GetWE(xpath2);
            NYLDSelenium.Click("Distribute share evenly to Class", distributeEvenlyToClass, true, "always");

            //Review and confirm
            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-60);
            NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);

            //Click on Update
            if (NYLDSelenium.ElemExist("Update", Update, false, "no", "no"))
                NYLDSelenium.Click("Update", Update, true, "always");
        }

        /// <summary>
        /// Method to delete a beneficiary
        /// </summary>
        /// <param name="element"></param>
        /// <param name="beneClass"></param>
        public string DeleteBeneficiary(string args, IWebElement element, int beneClass, string relationShip, int beneCount, int currentIndex)
        {
            // Delete bene
            IWebElement beneDeleteElement = null;
            string editStatus = "Success";
            if (relationShip == "FuneralHome" || relationShip == "Trust")
            {
                beneDeleteElement = element.FindElement(By.XPath("./i"));
            }
            else
            {
                beneDeleteElement = element.FindElement(By.XPath("./a"));
            }

            NYLDSelenium.Click("Delete link of Bene", beneDeleteElement, true, "always", "yes");

            if (relationShip == "FuneralHome" || relationShip == "Trust")
            {
                editStatus = "NoEdit";
                NYLDSelenium.VerifyText("No Delete action message", "This beneficiary cannot be deleted online.", NYLDSelenium.GetAttribute("No Delete message", beneDeleteElement, "data-original-title"));

                // Cancel
                NYLDSelenium.Click("Cancel", Cancel);
                NYLDSelenium.PageLoad("My Beneficiaries", BeneficiaryPage);
            }
            else
            {
                editStatus = VerifyDeleteBenePopUpMessage(args, beneClass, beneCount, currentIndex);
            }
            return editStatus;
        }

        public string VerifyDeleteBenePopUpMessage(string args, int beneClass, int beneCount, int currentIndex)
        {
            string expectedBeneClassName = "";
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            string editStatus = "Success";
            string expectedmsg = "";
            string[] getOptions = args.Split('-');
            string action = getOptions[1].Trim();
            // Verify Delete bene pop up
            string beneClassification = "BN" + beneClass;
            expectedBeneClassName = CF.ExpectedBeneClassName(beneClassification).ToLower();
            if (NYLDSelenium.ElemExist("Delete bene confirmation", DeleteBeneMessage, false, "yes", "yes"))
            {
                string deleteMessage = NYLDSelenium.GetAttribute("Delete bene Message", DeleteBeneMessage);

                if (currentIndex == beneCount - 1)
                {
                    expectedmsg = testData.GetContent("DeleteBeneficiaryLast").Replace("{BeneClass}", expectedBeneClassName);
                    // Last beneficiary
                    if (deleteMessage.StartsWith(expectedmsg) || deleteMessage.Contains(expectedmsg))
                    {
                        NYLDSelenium.VerifyText("Delete bene confirmation", expectedmsg, deleteMessage, "always");
                        NYLDSelenium.ElemExist("Delete Bene confirmation - Add a new Beneficiary", AddNewBeneButton);
                        if (action == "AddNewBene")
                        {
                            NYLDSelenium.Click("Delete Bene confirmation - Add new beneficiary", AddNewBeneButton);
                        }
                        else
                        {
                            if (NYLDSelenium.ElemExist("Delete Bene confirmation - cancel", CancelDeleteButton))
                            {
                                NYLDSelenium.Click("Delete Bene confirmation - cancel", CancelDeleteButton);
                            }
                        }
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("Unexpected delete confirmation message", deleteMessage, "FAIL");
                        editStatus = "UnabletoDelete";
                    }
                }
                else
                {
                    // Not the last beneficiary
                    expectedmsg = testData.GetContent("DeleteBeneficiary").ToString();
                    if (deleteMessage.Contains(expectedmsg))
                    {
                        NYLDSelenium.VerifyText("Delete bene confirmation", expectedmsg, deleteMessage, "always");
                        if (NYLDSelenium.ElemExist("Delete Bene confirmation - cancel", CancelDeleteButton))
                        {
                            if (NYLDSelenium.ElemExist("Delete confirm", DeleteButton, false, "no", "no"))
                            {
                                NYLDSelenium.Click("Delete confirm", DeleteButton);
                            }
                        }
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("Unexpected delete confirmation message", deleteMessage, "FAIL");
                        editStatus = "UnabletoDelete";
                    }
                }
            }
            else
            {
                NYLDSelenium.ReportStepResult("Delete bene confirmation popup not found", "###############", "FAIL");
                editStatus = "UnabletoDelete";
            }
            return editStatus;
        }

        public void DistributeBeneShare(int beneClass)
        {
            // Re-arrange shares and Click on update
            IWebElement distributeEvenly = null;
            string xpath = "//table[@id='bene-class-" + beneClass + "']//a[contains(@href, 'Distribution')]";
            // Distribute evenly link
            distributeEvenly = NYLDSelenium.GetWE(xpath);
            Thread.Sleep(100);
            NYLDSelenium.Click("Distribute share bene evenly", distributeEvenly, true, "always" );

            // Click on Update
            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-60);
            // Review and confirm
            NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);
            // Update
            if (NYLDSelenium.ElemExist("Update", Update))
            {
                NYLDSelenium.Click("Update", Update);
            }
        }

        /// <summary>
        /// Method to update share for a bene
        /// </summary>
        /// <param name="element"></param>
        /// <param name="beneClass"></param>
        public string ChangeShare(IWebElement element, int beneClass, string relationship)
        {
            ///Delete bene
            string editStatus = "Success";
            IWebElement beneShareElement = element.FindElement(By.XPath(".//input"));
            if (relationship == "Trust")
            {
                editStatus = "NoEdit";

                NYLDSelenium.VerifyText("Share Edit Status", "true", NYLDSelenium.GetAttribute("Share field Enabled", beneShareElement, "disabled"));
                if (NYLDSelenium.ElemExist("Cancel", Cancel, false, "no", "no"))
                    NYLDSelenium.Click("Cancel", Cancel);
                NYLDSelenium.PageLoad("My Beneficiaries", BeneficiaryPage);
            }
            else
            {
                Random random = new Random();
                string share1 = random.Next(20, 60).ToString();

                NYLDSelenium.Clear("Share 1", beneShareElement);
                NYLDSelenium.SendKeys("Update share 1", beneShareElement, share1);

                //Find number of benes in section
                IList<IWebElement> numberofRows = BeneficiaryDistribution[beneClass - 1].FindElements(By.XPath(".//table//tbody/tr"));

                //Update the second share value o balance the share total
                for (int i = 0; i < numberofRows.Count; i++)
                {
                    IList<IWebElement> beneInfo = numberofRows[i].FindElements(By.XPath("./td"));
                    if (beneInfo.Count != 1)
                    {
                        beneShareElement = beneInfo[3].FindElement(By.XPath(".//input"));
                        string share = NYLDSelenium.GetAttribute("Share", beneShareElement, "value");
                        if (share.Trim() != share1)
                        {
                            string share2 = (100 - Convert.ToInt16(share1)).ToString();
                            //NYLDSelenium.ScrollToView(BeneficiaryClasses[beneClass - 1]);
                            NYLDSelenium.Clear("Share 2", beneShareElement);
                            NYLDSelenium.SendKeys("Update share 2", beneShareElement, share2);
                            break;
                        }
                    }
                }
                //Click on Update
                CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-60);

                if (NYLDSelenium.ElemExist("Review and Confirm", ReviewAndConfirm, false, "no", "no"))
                    NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);
                if (NYLDSelenium.ElemExist("Update", Update, false, "no", "no"))
                    NYLDSelenium.Click("Update", Update);
            }

            return editStatus;
        }

        /// <summary>
        /// Method to validate share total
        /// </summary>
        /// <param name="args"></param>
        public void ValidateShareToTal(string args)
        {
            IWebElement beneShareElement = null;
            IWebElement beneShareTotalError = null;
            string[] shareValues = { "100", "500", "50" };
            string errorMessage = "";

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Share Total Message" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            try
            {
                Thread.Sleep(200);
                // NYLDSelenium.ScrollToView(EditDistributionLink[0], true);
                //Click on edit Distribution link
                NYLDSelenium.Click("Edit Distribuion", EditDistributionLink[0], true);


                NYLDSelenium.PageLoad("Edit Distribuion", EditBeneDistributionHeader);

                beneShareElement = BeneficiaryDistribution[0].FindElement(By.XPath("//table//tbody/tr[1]/td[4]//input"));

                for (int i = 0; i < shareValues.Count(); i++)
                {
                    if (NYLDSelenium.ElemExist("Share Values", beneShareElement, false, "no", "no", "no"))
                    {
                        NYLDSelenium.Clear("Clear share value", beneShareElement);
                        NYLDSelenium.SendKeys("Udpate share value", beneShareElement, "100");

                        beneShareTotalError = BeneficiaryDistribution[0].FindElement(By.XPath("//tr[@class='distribution-error']//label[@class='distribution-error-message']"));

                        if (i != 2)
                            errorMessage = "Shares must add up to 100%";

                        NYLDSelenium.VerifyText("Share total error message", errorMessage, NYLDSelenium.GetAttribute("Error Message", beneShareTotalError));
                    }
                }
            }
            catch (Exception e)
            {
                NYLDSelenium.ReportStepResult("Verify Share Total", "Failed to verify the share total", "Fail", "always", "yes");
                throw e;
            }

        }

        /// <summary>
        /// Method to find and edit the required beneficary based on test paramenters from Data sheet
        /// </summary>
        /// <param name="args"></param>
        public string EditBeneficiary(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Edit Beneficiary" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            string[] getOptions = args.Split('-');
            string actualEntityType = "";
            string actualBeneName = "";
            string editStatus = "Success";
            int beneClass;
            IWebElement beneClassElement = null;
            IWebElement editElement = null;
            IList<IWebElement> beneDetails = new List<IWebElement>();
            bool beneFound = false;
            bool irb = false;
            bool updateDistribution = false;
            string entity = "Person";

            string type = getOptions[0].Trim();
            string field = getOptions[1];
            string filterInformation = "";

            if (getOptions.Count() > 2)
                filterInformation = getOptions[2].Trim();

            //Get the class of Beneficiary to be edited
            Thread.Sleep(200);
            NYLDSelenium.PageLoad("My Beneficiaries", BeneficiaryPage);
            beneClass = Convert.ToInt16(type.Substring(type.Length - 1));

            //Find Expected Bene class to be edited and verify if it is in UI          
            if (beneClass > BeneficiaryClasses.Count)
            {
                NYLDSelenium.ReportStepResult("Bene count mismatch found", "Bene of class " + beneClass + " is found in DB but displayed in My Beneficiaries screen", "Fail");
            }
            else
                beneClassElement = BeneficiaryClasses[beneClass - 1];

            //Find the bene to be edited when mutiple benes of same class is displayed with filter information            
            if (filterInformation != "")
            {
                beneDetails = beneClassElement.FindElements(By.XPath("./following-sibling::div[1]//table//tbody/tr"));

                //Bene Class wise details verification
                for (int j = 0; j <= beneDetails.Count - 1; j++)
                {
                    irb = false;
                    if (j != 0)
                        beneDetails = BeneficiaryClasses[beneClass - 1].FindElements(By.XPath("./following-sibling::div[1]//table//tbody/tr"));
                    if (!beneFound)
                    {
                        IList<IWebElement> beneInfo = new List<IWebElement>();
                        beneInfo = beneDetails[j].FindElements(By.XPath("./td"));

                        actualEntityType = NYLDSelenium.GetAttribute("Bene Entity", beneInfo[2]).Trim();
                        try
                        {
                            editElement = beneInfo[0].FindElement(By.XPath("./a"));
                        }
                        catch
                        {
                            editElement = beneInfo[0].FindElement(By.XPath("./i"));
                            irb = true;
                        }
                        //get the bene details - ex: Firstname and lastname
                        beneInfo = beneDetails[j].FindElements(By.XPath("./td"));
                        actualBeneName = NYLDSelenium.GetAttribute("Bene Name", beneInfo[1]).Trim();
                        Console.WriteLine("Bene Name: " + actualBeneName);
                        //Click on Edit link of bene an check for filter condition                    
                        switch (filterInformation.ToLower())
                        {
                            case "noaddress":
                                NYLDSelenium.Click("Edit link of Bene " + (j + 1), editElement);
                                NYLDSelenium.PageLoad("Edit", EditBeneficiariesHeader);
                                NYLDSelenium.VerifyText("Edit Bene header", "Edit " + actualBeneName, NYLDSelenium.GetAttribute("Edit Bene header", EditBeneficiariesHeader));

                                if (NYLDSelenium.GetAttribute("Address line 1", AddresLine1, "value") == "")
                                    beneFound = true;
                                break;

                            case "nophone":
                                NYLDSelenium.Click("Edit link of Bene " + (j + 1), editElement);
                                NYLDSelenium.PageLoad("Edit", EditBeneficiariesHeader);
                                NYLDSelenium.VerifyText("Edit Bene header", "Edit " + actualBeneName, NYLDSelenium.GetAttribute("Edit Bene header", EditBeneficiariesHeader));
                                if (NYLDSelenium.GetAttribute("Phone", PhoneNumber) == "")
                                    beneFound = true;
                                break;

                            case "noperstirpes":
                                NYLDSelenium.Click("Edit link of Bene " + (j + 1), editElement);
                                NYLDSelenium.PageLoad("Edit", EditBeneficiariesHeader);
                                NYLDSelenium.VerifyText("Edit Bene header", "Edit " + actualBeneName, NYLDSelenium.GetAttribute("Edit Bene header", EditBeneficiariesHeader));
                                try
                                {
                                    string noneOptionSet = NoneInput.GetAttribute("checked");
                                    if ((noneOptionSet == "true"))
                                    {
                                        beneFound = true;
                                    }
                                }
                                catch
                                {
                                    beneFound = false;
                                }
                                break;

                            case "perstirpes":
                                NYLDSelenium.Click("Edit link of Bene " + (j + 1), editElement);
                                Thread.Sleep(300);
                                NYLDSelenium.PageLoad("Edit", EditBeneficiariesHeader);
                                NYLDSelenium.VerifyText("Edit Bene header", "Edit " + actualBeneName, NYLDSelenium.GetAttribute("Edit Bene header", EditBeneficiariesHeader));
                                try
                                {
                                    string perStirpesOptionSet = PerStirpesInput.GetAttribute("checked");
                                    if ((perStirpesOptionSet == "true"))
                                    {
                                        beneFound = true;
                                    }
                                }
                                catch
                                {
                                    beneFound = false;
                                }
                                break;

                            default:
                                if (field == "ChangeShare" || field == "DeleteBene" || field == "ChangeClass")
                                    updateDistribution = true;
                                else
                                {
                                    if (actualEntityType.Replace(" ", "") == filterInformation)
                                    {

                                        NYLDSelenium.Click("Edit link of Bene " + (j + 1), editElement);
                                        beneFound = true;
                                    }
                                    else
                                    {
                                        if (filterInformation == "Person" && (actualEntityType != "Estate" && actualEntityType != "Trust" && actualEntityType != "Funeral Home" && actualEntityType != "Organization"))
                                        {

                                            NYLDSelenium.Click("Edit link of Bene " + (j + 1), editElement);
                                            beneFound = true;
                                        }
                                    }
                                }
                                break;
                        }

                        if (irb)
                            j = j + 1;

                        if (beneFound)
                        {
                            if (actualEntityType == "Estate" || actualEntityType == "Trust" || actualEntityType == "Funeral Home" || actualEntityType == "Organization")
                                entity = actualEntityType.Trim();

                            break;
                        }
                        else if (!updateDistribution)
                        {
                            if (NYLDSelenium.ElemExist("Edit Page", EditBeneficiariesHeader, false, "no", "no"))
                            {
                                //If the Survey window pops up
                                Thread.Sleep(300);
                                NYLDDigital.SkipSurveyPopUp(StartSurvey, 30, false);

                                //Center of the screen of the element
                                // NYLDSelenium.ScrollToView(BackToManageBeneficiariesLink, true);
                                Thread.Sleep(150);

                                //double times check Survey pop up
                                NYLDDigital.SkipSurveyPopUp(StartSurvey, 30, false);

                                //Back to beneficiaries
                                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                                js.ExecuteScript("window.scrollBy(0,-600);");
                                Thread.Sleep(100);
                                if (NYLDSelenium.ElemExist("Back to beneficiaries", BackToManageBeneficiariesLink, false, "no", "no"))
                                    NYLDSelenium.Click("Back to beneficiaries", BackToManageBeneficiariesLink);

                                NYLDSelenium.PageLoad("My Beneficiaries", BeneficiaryPage);
                            }
                        }
                        else if (field == "ChangeShare" || field == "DeleteBene" || field == "ChangeClass")
                            break;
                    }
                }

                if (!beneFound && !updateDistribution && !irb)
                    NYLDSelenium.ReportStepResult("Could not find Beneficiary to edit", "Beneficiary with mentioned criteria could not be found in the beneficiary page, Criteria: " + filterInformation, "Fail", "always", "yes");
            }
            else if (BeneficiaryClasses.Count == 1)
            {
                beneDetails = beneClassElement.FindElements(By.XPath("./following-sibling::div[1]//table//tbody/tr"));

                IList<IWebElement> beneInfo = new List<IWebElement>();
                beneInfo = beneDetails[0].FindElements(By.XPath("./td"));

                NYLDSelenium.Click("Edit link of Bene 1", beneInfo[0]);
                NYLDSelenium.PageLoad("Edit", EditBeneficiariesHeader);
                NYLDSelenium.VerifyText("Edit Bene header", "Edit " + actualBeneName, NYLDSelenium.GetAttribute("Edit Bene header", EditBeneficiariesHeader));
            }
            else
            {
                NYLDSelenium.ReportStepResult("Multiple beneficiaries displayed", "Please provide information to select bene", "Fail", "always", "yes");
            }

            if (irb)
                editStatus = VerifyIRBInformation(editElement);
            else if (beneFound)
                editStatus = EditBeneficiaryDetails(entity + "|" + field, actualBeneName, beneClass);
            else if (updateDistribution)
                editStatus = UpdateDistribution(args);

            return editStatus;
        }

        /// <summary>
        /// Method to edit a Beneficiary
        /// </summary>
        /// <param name="args"></param>
        public string EditBeneficiaryDetails(string args, string editBeneName, int beneClass)
        {
            string entity = args.Split('|')[0].Trim();
            string[] testInput = args.Split('|')[1].Split('>');
            string state = "";
            string country = "";
            string editStatus = "Success";
            string firstName = "";
            string lastName = "";
            string middleName = "";
            string suffix = "";
            string companyName = "";
            string ssn = "";
            string[] name;
            TestData testData = new TestData();
            LSPDatabase database = new LSPDatabase(driver, data);

            database.QueryAssociatedPolicies("Beneficiaries");
            database.QueryPolicyDetails();
            database.GetBeneInfo();
            if (CSWData.BeneInfo[beneClass - 1][2] == "IRB")
                beneClass++;
            if (CSWData.BeneInfo[beneClass - 1][0].Contains("/"))
            {
                name = CSWData.BeneInfo[beneClass - 1][0].Split('/');
                lastName = name.Length > 0 ? name[0] : string.Empty;
                firstName = name.Length > 1 ? name[1] : string.Empty;
                middleName = name.Length > 2 ? name[2] : string.Empty;
                suffix = name.Length > 3 ? name[3] : string.Empty;
            }

            companyName = CSWData.BeneInfo[beneClass - 1][0];
            ssn = CSWData.BeneInfo[beneClass - 1][12].Substring(CSWData.BeneInfo[beneClass - 1][12].Length - 4);

            // Assign the split parts to respective variables
            if (CSWData.BeneInfo[beneClass - 1][0].Contains("/"))
                ssn = CSWData.BeneInfo[beneClass - 1][12].Substring(CSWData.BeneInfo[beneClass - 1][12].Length - 4);
            //Need to add which edit link to Click on depending on test scenario 

            //Page Load
            NYLDSelenium.PageLoad("Edit Beneficiaries", EditBeneficiariesHeader, "no", "no", true);
            NYLDSelenium.VerifyText("Edit Bene header", "Edit " + editBeneName, NYLDSelenium.GetAttribute("Edit Bene header", EditBeneficiariesHeader));
            //Entity selected
            //NYLDSelenium.VerifyText("Entity Selected", testData.GetContent(entity), NYLDSelenium.GetAttribute("Entity Selected", BeneficiaryEntity_Page2));
            //NYLDSelenium.ScrollToView(EditBeneficiariesHeader, true);
            IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver;
            switch (testInput[0].Trim())
            {
                //Edit page  First name, Last name and SSN No longer Editable Its grayed out
                case "EditName":
                    VerifyEditPage(entity);
                    if (NYLDSelenium.ElemExist("Bene First name", FirstNameReadOnly, false, "no", "yes", "yes"))
                        NYLDSelenium.VerifyText("Bene First name", firstName, NYLDSelenium.GetAttribute("bene First name ", FirstName, "value"));
                    else
                        NYLDSelenium.ReportStepResult("First name field edit status is true", "Please verify the screenshot", "fail", "yes");
                    if (NYLDSelenium.ElemExist("Bene Last name", lastNameReadOnly, false, "no", "yes", "yes"))
                        NYLDSelenium.VerifyText("Bene Last name", lastName, NYLDSelenium.GetAttribute("bene Last name ", LastName, "value"));
                    else
                        NYLDSelenium.ReportStepResult("last name field edit status is true", "Please verify the screenshot", "fail", "yes");
                    break;

                case "EditCompany":
                    VerifyEditPage(entity);
                    NYLDSelenium.Clear("Clear CompanyName", CompanyName);
                    companyName = "AutoEditing Company LLC";
                    NYLDSelenium.SendKeys("Bene CompanyName", CompanyName, companyName);
                    break;

                case "EditTIN":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,+100);");
                    if (NYLDSelenium.ElemNotExist("Bene TIN", TaxID, false, "no", "no"))
                    {
                        NYLDSelenium.ReportStepResult("TIN field can be editable", "adding TIN", "INFO", "yes");
                        NYLDSelenium.Clear("TIN", TaxID);
                        NYLDSelenium.SendKeys("TIN", TaxID, "246808642");
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("TIN field cannot be edited", "Verifying the TIN value", "INFO", "yes");
                        NYLDSelenium.VerifyText("Bene TIN ", ssn, NYLDSelenium.GetAttribute("bene TIN ", TaxID));
                    }
                    break;

                case "EditSSN":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,+100);");
                    if (NYLDSelenium.ElemNotExist("Bene SSN", SocialSecurityEditPage, false, "no", "no"))
                    {
                        NYLDSelenium.ReportStepResult("SSN field can be editable", "adding ssn", "INFO", "yes");
                        NYLDSelenium.Clear("SSN", SocialSecurity);
                        NYLDSelenium.SendKeys("SSN", SocialSecurity, "246808642");
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("SSN field cannot be edited", "Verifying the SSN value", "INFO", "yes");
                        NYLDSelenium.VerifyText("Bene SSN ", ssn, NYLDSelenium.GetAttribute("bene SSN", SocialSecurityEditPage));
                    }
                    break;

                case "EditDOB":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,+100);");
                    NYLDSelenium.Clear("DOB", DateOfBirth);
                    NYLDSelenium.SendKeys("DOB", DateOfBirth, "01/01/1950");
                    break;

                case "AddAddress":
                    VerifyEditPage(entity);
                    NYLDSelenium.Clear("Clear Address Line 1", AddresLine1);
                    NYLDSelenium.SendKeys("Add Bene Address Line 1", AddresLine1, "Test Add Address Line 1");
                    NYLDSelenium.Clear("Clear Address Line 2", AddressLine2);
                    NYLDSelenium.SendKeys("Add Bene Address Line 2", AddressLine2, "Test Add Address Line 2");
                    NYLDSelenium.Clear("Clear city", City);
                    NYLDSelenium.SendKeys("Add Bene City", City, "Test Add City");
                    NYLDSelenium.ReportStepResult("Select Country: " + testInput[1].Trim(), "Select Country", "INFO", "no");
                    country = CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", testInput[1].Trim()));

                    //Update country specific fields
                    if (testInput[1].Trim() == "US")
                    {
                        state = testData.GetMappedValue("State", "MI");
                        NYLDSelenium.SelectList("Add Bene State", State, state, "bytext");
                        NYLDSelenium.Clear("Clear Zip", Zip);
                        NYLDSelenium.SendKeys("Add Bene Zip", Zip, "33045");
                    }
                    else if (testInput[1].Trim() == "CA")
                    {
                        state = testData.GetMappedValue("State", "AB");
                        NYLDSelenium.SelectList("Add Bene Province", Province, state, "bytext");
                        NYLDSelenium.Clear("Clear postal Code", PostalCode);
                        NYLDSelenium.SendKeys("Add Bene Postal Code", PostalCode, "A9A 9A9");
                    }
                    break;

                case "AddPhone":
                    VerifyEditPage(entity);
                    NYLDSelenium.Clear("Clear Phone Number", PhoneNumber);
                    NYLDSelenium.SendKeys("Add Bene Phone Number", PhoneNumber, "(200) 123-1234");
                    break;

                case "AddAddressPhone":
                    VerifyEditPage(entity);
                    //NYLDSelenium.ScrollToView(AddresLine1, true);
                    NYLDSelenium.Clear("Clear Address Line 1", AddresLine1);
                    NYLDSelenium.SendKeys("Add Bene Address Line 1", AddresLine1, "Test Add Address Line 1");
                    NYLDSelenium.Clear("Clear Address Line 2", AddressLine2);
                    NYLDSelenium.SendKeys("Add Bene Address Line 2", AddressLine2, "Test Add Address Line 2");
                    NYLDSelenium.Clear("Clear city", City);
                    NYLDSelenium.SendKeys("Add Bene City", City, "Test Add City");

                    NYLDSelenium.ReportStepResult("Select Country: US", "Select Country", "INFO", "no");
                    country = CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", testInput[1].Trim()));

                    NYLDSelenium.SelectList("Update Country", Country, country, "bytext");

                    //Update country specific fields
                    if (testInput[1].Trim() == "US")
                    {
                        // NYLDSelenium.ScrollToView(State, true);
                        state = testData.GetMappedValue("State", "MI");
                        NYLDSelenium.SelectList("Add Bene State", State, state, "bytext");
                        NYLDSelenium.Clear("Clear Zip", Zip);
                        NYLDSelenium.SendKeys("Add Bene Zip", Zip, "33045");
                    }
                    else if (testInput[1].Trim() == "CA")
                    {
                        // NYLDSelenium.ScrollToView(State, true);
                        state = testData.GetMappedValue("State", "AB");
                        NYLDSelenium.SelectList("Add Bene Province", Province, state, "bytext");
                        NYLDSelenium.Clear("Clear postal Code", PostalCode);
                        NYLDSelenium.SendKeys("Add Bene Postal Code", PostalCode, "A9A 9A9");
                    }

                    //Phone
                    //NYLDSelenium.ScrollToView(PhoneNumber, true);
                    NYLDSelenium.Clear("Clear Phone Number", PhoneNumber);
                    NYLDSelenium.SendKeys("Add Bene Phone Number", PhoneNumber, "(200) 123-1234");
                    break;

                case "EditAddress":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,-300);");
                    NYLDSelenium.Clear("Clear Addr Line 1", AddresLine1);
                    NYLDSelenium.SendKeys("Bene Addr Line 1", AddresLine1, "Test Address Line 1");
                    NYLDSelenium.Clear("Clear Addr Line 2", AddressLine2);
                    NYLDSelenium.SendKeys("Bene Addr Line 2", AddressLine2, "Test Address Line 2");
                    NYLDSelenium.Clear("Clear city", City);
                    NYLDSelenium.SendKeys("Bene City", City, "Test City");

                    NYLDSelenium.ReportStepResult("Select Country: " + args, "Select Country", "INFO", "no");
                    country = CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", testInput[1].Trim()));

                    NYLDSelenium.SelectList("Update Country", Country, country, "bytext");

                    //Update country specific fields
                    if (testInput[1].Trim() == "US")
                    {
                        // NYLDSelenium.ScrollToView(State, true);
                        state = testData.GetMappedValue("State", "MI");
                        NYLDSelenium.SelectList("Update State", State, state, "bytext");
                        NYLDSelenium.Clear("Clear Zip", Zip);
                        NYLDSelenium.SendKeys("Update payor Zip", Zip, "33045");
                    }
                    else if (testInput[1].Trim() == "CA")
                    {
                        // NYLDSelenium.ScrollToView(State, true);
                        state = testData.GetMappedValue("State", "AB");
                        NYLDSelenium.SelectList("Update State", Province, state, "bytext");
                        NYLDSelenium.Clear("Clear postal Code", PostalCode);
                        NYLDSelenium.SendKeys("Update payor Zip", PostalCode, "A9A 9A9");
                    }
                    break;

                case "EditPhone":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,-100);");
                    if (NYLDSelenium.ElemExist("PhoneNumber", PhoneNumber, false, "no", "no"))
                    {
                        NYLDSelenium.Clear("Clear PhoneNumber", PhoneNumber);
                        NYLDSelenium.SendKeys("Bene PhoneNumber", PhoneNumber, "(200) 123-1234");
                    }
                    break;

                case "EditAddressPhone":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,-300);");
                    NYLDSelenium.Clear("Clear Addr Line 1", AddresLine1);
                    NYLDSelenium.SendKeys("Bene Addr Line 1", AddresLine1, "Test Address Line 1");
                    NYLDSelenium.Clear("Clear Addr Line 2", AddressLine2);
                    NYLDSelenium.SendKeys("Bene Addr Line 2", AddressLine2, "Test Address Line 2");
                    NYLDSelenium.Clear("Clear city", City);
                    NYLDSelenium.SendKeys("Bene City", City, "Test City");

                    NYLDSelenium.ReportStepResult("Select Country: " + args, "Select Country", "INFO", "no");
                    country = CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", testInput[1].Trim()));

                    NYLDSelenium.SelectList("Update Country", Country, country, "bytext");

                    //Update country specific fields
                    if (testInput[1].Trim() == "US")
                    {
                        state = testData.GetMappedValue("State", "MI");
                        NYLDSelenium.SelectList("Update State", State, state, "bytext");
                        NYLDSelenium.Clear("Clear Zip", Zip);
                        NYLDSelenium.SendKeys("Update Zip", Zip, "33045");
                    }
                    else if (testInput[1].Trim() == "CA")
                    {
                        state = testData.GetMappedValue("State", "AB");
                        NYLDSelenium.SelectList("Update State", Province, state, "bytext");
                        NYLDSelenium.Clear("Clear Code", PostalCode);
                        NYLDSelenium.SendKeys("Update Zip", PostalCode, "A9A 9A9");
                    }

                    //Phone
                    // NYLDSelenium.ScrollToView(PhoneNumber, true);
                    js3.ExecuteScript("window.scrollBy(0,-100);");
                    if (NYLDSelenium.ElemExist("PhoneNumber", PhoneNumber, false, "no", "no"))
                    {
                        NYLDSelenium.Clear("Clear PhoneNumber", PhoneNumber);
                        NYLDSelenium.SendKeys("Bene PhoneNumber", PhoneNumber, "(200) 123-1234");
                    }
                    break;

                case "ChangeRelationship":
                    VerifyEditPage(entity);
                    // NYLDSelenium.ScrollToView(RelationshipDropdown, true);
                    if (entity != "Person")
                    {
                        editStatus = "NoEdit";
                        NYLDSelenium.ElemNotExist("Relationship", RelationshipDropdown);
                    }
                    else
                        NYLDSelenium.SelectList("Relationship", RelationshipDropdown, "Friend", "bytext");
                    break;

                case "ChangeClass":
                    VerifyDistributionPage();
                    break;

                case "PerStirpes":
                    VerifyEditPage(entity);
                    NYLDSelenium.Click("Per Stirpes", PerStirpeslabel);
                    break;

                case "EditEmail":
                    VerifyEditPage(entity);
                    js3.ExecuteScript("window.scrollBy(0,-200);");
                    if (NYLDSelenium.ElemExist("Email address", Email, false, "no", "no"))
                    {
                        NYLDSelenium.Clear("Clear Email address", Email);
                        Random rnd = new Random();
                        int rval = rnd.Next(1, 10);
                        string email = "AUTBeneTest" + rval + DateTime.Now.ToString("HHmmss") + "@" + "automation.com";
                        NYLDSelenium.SendKeys("Bene Email address", Email, email);
                    }
                    break;
            }

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollBy(0,-600);");
            Thread.Sleep(150);
            //Due to some situations if data is  empty forcefully filling this data
            if (NYLDSelenium.ElemExist("FirstName", FirstName, false, "no", "no", "yes"))
            {
                NYLDSelenium.VerifyText("FirstName", firstName, FirstName.GetAttribute("value"));
            }
            if (NYLDSelenium.ElemExist("LastName", LastName, false, "no", "no"))
            {
                NYLDSelenium.VerifyText("LastName", lastName, LastName.GetAttribute("value"));
            }
            if (NYLDSelenium.ElemExist("CompanyName", CompanyName, false, "no", "no"))
            {
                NYLDSelenium.VerifyText("CompanyName", companyName, CompanyName.GetAttribute("value"));
            }
            if (NYLDSelenium.ElemExist("SSN", SocialSecurityHeader, false, "no", "no"))
            {
                NYLDSelenium.VerifyText("Bene SSN", ssn, NYLDSelenium.GetAttribute("bene First name ", SocialSecurityEditPage));
            }
            if (NYLDSelenium.ElemExist("Relationship", RelationshipDropdown, false, "no", "no"))
            {
                NYLDSelenium.SelectList("Relationship", RelationshipDropdown, "Friend", "bytext");
            }
            if (NYLDSelenium.ElemExist("Addr Line 1", AddresLine1, false, "no", "no"))
            {
                NYLDSelenium.Clear("Addr Line 1", AddresLine1);
                NYLDSelenium.SendKeys("Bene Addr Line 1", AddresLine1, "Test Address Line 1");
            }
            if (NYLDSelenium.ElemExist("Bene Addr Line 2", AddressLine2, false, "no", "no"))
            {
                NYLDSelenium.Clear("Addr Line 2", AddressLine2);
                NYLDSelenium.SendKeys("Bene Addr Line 2", AddressLine2, "Test Address Line 2");
            }
            if (NYLDSelenium.ElemExist("PhoneNumber", PhoneNumber, false, "no", "no"))
            {
                NYLDSelenium.Clear("PhoneNumber", PhoneNumber);
                NYLDSelenium.SendKeys("Bene PhoneNumber", PhoneNumber, "(200) 123-1234");
            }

            //Click on Update
            if (editStatus == "NoEdit")
            {
                if (NYLDSelenium.ElemExist("Cancel", Cancel, false, "no", "no", "yes"))
                    NYLDSelenium.Click("Cancel", Cancel);
                NYLDSelenium.PageLoad("My Beneficiaries", BeneficiaryPage);
            }
            else
            {
                CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-30);
                if (NYLDSelenium.ElemExist("Review and Confirm", ReviewAndConfirm, false, "no", "no", "yes"))
                    NYLDSelenium.Click("Review and Confirm", ReviewAndConfirm);

                if (NYLDSelenium.ElemExist("Update", Update, false, "no", "no", "yes"))
                    NYLDSelenium.Click("Update", Update);
            }

            return editStatus;
        }

        /// <summary>
        /// Method to verify IRB locked information
        /// </summary>
        /// <param name="irbElement"></param>
        public string VerifyIRBInformation(IWebElement irbElement)
        {
            string editStatus = "NoEdit";

            //Verify IRB Text
            NYLDSelenium.Click("IRB Edit element", irbElement);
            NYLDSelenium.VerifyText("IRB Edit info", "This beneficiary cannot be edited online.", NYLDSelenium.GetAttribute("IRB Edit element", irbElement, "data-original-title"));

            //Report edit could not be performed
            NYLDSelenium.ReportStepResult("Edit action could not be performed as Beneficiary is an IRB", "IRB Beneficiaries could not be edited", "INFO", "always");

            return editStatus;
        }

        /// <summary>
        /// Method to verify thank you screen after successful Add or Edit action
        /// </summary>
        /// <param name="args"></param>
        /// <summary>
        /// Method to verify thank you screen after successful Add or Edit action
        /// </summary>
        /// <param name="args"></param>
        public void VerifyThankYouPage(string args)
        {
            string action = string.IsNullOrEmpty(args) ? "Add" : args;
            string greeting = $"Thank you, {data[KeyRepository.FirstName]}";
            string thankYouHeader = action == "Edit" || action == "EditDistribution"
                ? $"{greeting}. Your beneficiary information has been updated."
                : $"{greeting}. Your beneficiary has been added.";

            NYLDSelenium.ReportStepResult($"<h3 style=\"color:Blue\">Verify {action} Beneficiary Thank you page</h3>", "<h3 style=\"color:Blue\">###########</h3>", "INFO", "no");

            // Verify Change Payor Thank you screen
            NYLDSelenium.PageLoad("Beneficiary Thank You", ThankYouHeader);

            // If the Survey window pops up
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            // Scroll to the top of the page
            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollBy(0,-300);");

            // Verify the success message displayed on the Thank you screen
            NYLDSelenium.VerifyText("Submit successful message", thankYouHeader, ThankYouHeader.Text);
            
        }

        /// <summary>
        /// Verify Add Bene Page 1
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPage1(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Page 1" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            string[] entity = { "Person", "Business", "Estate", "Trust", "Funeral" };
            string[] entity_nofuneral = { "Person", "Business", "Estate", "Trust" };
            string[] type = { "Class 1", "Class 2", "Estate", "Class 3" };
            string[] expectedEntityLabels = { "Name Person/Individual (spouse, sibling, child, etc.)", "Company/Organization Name (business, charity, etc.)", "Estate", "Trust", "Funeral Home" };
            string[] expectedEntityLabels_nofuneral = { "Name Person/Individual (spouse, sibling, child, etc.)", "Company/Organization Name (business, charity, etc.)", "Estate", "Trust" };

            string[] expectedTypeLabels = { "BN1", "BN2", "BN3" };

            CommonFunctions commonFunctions = new CommonFunctions(data);
            TestData tesData = new TestData();

            if (args == "FuneralHome")
            {
                //Click on Add Beneficiary link
                NYLDSelenium.Click("Add Beneficiary", AddBeneficiaryLink);
                //Page Load
                NYLDSelenium.PageLoad("Add Beneficiary", AddBeneficiaryPage);
            }
            //Verify Bene Entities displayed

            for (var i = 0; i < EntityTypeLabels.Count; i++)
            {
                if (args == "FuneralHome")
                {
                    NYLDSelenium.VerifyText(
                        "Entity type - " + entity[i],
                        expectedEntityLabels_nofuneral[i],
                        commonFunctions.FormatString(NYLDSelenium.GetAttribute("Entity ", EntityTypeLabels[i])).Replace("Cancel", "").Trim(), "always");
                    NYLDSelenium.ElemNotExist("Funeral Home Entity", FuneralEntity, true, "no", "always");
                }

                else
                    NYLDSelenium.VerifyText("Entity type - " + entity[i],
                                            expectedEntityLabels[i],
                                            commonFunctions.FormatString(NYLDSelenium.GetAttribute("Entity", EntityTypeLabels[i])).Replace("Cancel", "").Trim(), "always");
            }
            //Verify Bene class displayed
            for (int i = 0; i < BeneficiaryTypeLabels.Count; i++)
            {
                NYLDSelenium.VerifyText("Beneficiary type - " + type[i], tesData.GetContent(expectedTypeLabels[i]), commonFunctions.FormatString(NYLDSelenium.GetAttribute("Entity", BeneficiaryTypeLabels[i])), "always");
            }
        }

        /// <summary>
        /// Fill Add Bene Page 1
        /// </summary>
        /// <param name="args"></param>
        public void FillPage1(string args)
        {
            Thread.Sleep(1000);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Fill Page 1" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            TestData testData = new TestData();

            string[] options = args.Split('-');
            string expectedEntityType = testData.GetContent(options[0].Trim());
            int expectedBeneficiaryType = Convert.ToInt16(options[1].Substring(options[1].Length - 1).Trim());

            //Select enity type            
            foreach (IWebElement entity in EntityTypeLabels)
            {
                if (NYLDSelenium.GetAttribute("Entity", entity).Trim().Contains(expectedEntityType))
                {
                    if (expectedEntityType == "Funeral Home" || expectedEntityType == "Trust")
                    {
                        IWebElement element = entity.FindElement(By.XPath("./strong"));
                        NYLDSelenium.Click("Select a beneficiary entity type", element, true, "always", "always");
                    }
                    else
                        NYLDSelenium.Click("Select a beneficiary entity type", entity, true, "always", "always");
                    break;
                }
            }

            //Select Beneficiary class
            NYLDSelenium.Click("Select Beneficiary class entity", BeneficiaryTypeLabels[expectedBeneficiaryType - 1], true, "always", "always");


            //Click Continue
            NYLDSelenium.Click("Continue", Continue);

            Thread.Sleep(2000);
        }

        /// <summary>
        /// Verify Add Bene Page 2
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPage2(string args)
        {
            Thread.Sleep(1000);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Page 2" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            string entity = args.Split('-')[0].Trim();
            string type = args.Split('-')[1].Trim();

            TestData testData = new TestData();
            CommonFunctions commonFunctions = new CommonFunctions(data);

            NYLDSelenium.AddHeader("Verify Add bene page for Contract Number " + data[KeyRepository.PolicyNumber], "SubHeader");

            //Contract Number
            NYLDSelenium.VerifyText("Contract Number", data[KeyRepository.PolicyNumber], NYLDSelenium.GetAttribute("Contract Number", ContractNumber_Page2));

            //Entity selected
            if (NYLDSelenium.ElemExist("Type", BeneficiaryEntity_Page2, false, "no", "no"))
                NYLDSelenium.VerifyText("Beneficiary Type", testData.GetContent(entity), NYLDSelenium.GetAttribute("Beneficiary Type", BeneficiaryEntity_Page2).Replace("Cancel", "").Trim(), "always", "yes");
            else
                NYLDSelenium.ReportStepResult("Beneficiary Type does not exist ", "Beneficiary type is not displayed", "Fail");

            //Class selected
            NYLDSelenium.VerifyText("Beneficiary Class", testData.GetContent(type), commonFunctions.FormatString(NYLDSelenium.GetAttribute("Beneficiary Class", BeneficiaryType_Page2)), "always");

            if (entity != "FuneralHome" && entity != "Trust")
            {
                //Form Content
                if (entity == "Person")
                {
                    NYLDSelenium.ElemExist("FirstName", FirstName);
                    NYLDSelenium.ElemExist("LastName", LastName);
                    NYLDSelenium.ElemExist("Relationship", RelationshipDropdown);
                    NYLDSelenium.ElemExist("DOB", DateOfBirth);
                    NYLDSelenium.ElemExist("SSN", SocialSecurityHeader);

                    //Per stirpes and None option
                    NYLDSelenium.ElemExist("Per Stirpes", PerStirpeslabel);
                    NYLDSelenium.ElemExist("None", NoneLabel);
                }
                else if (entity == "Business")
                {
                    NYLDSelenium.ElemExist("Company", CompanyName);
                    NYLDSelenium.ElemExist("Tax ID", TaxID);
                }


                NYLDSelenium.ElemExist("Address Line 1", AddresLine1);
                NYLDSelenium.ElemExist("Address Line 2", AddressLine2);
                NYLDSelenium.ElemExist("City", City);

                SelectElement select = new SelectElement(Country);

                string country = select.SelectedOption.Text;
                if (country.Contains("United"))
                {
                    NYLDSelenium.ElemExist("State", State);
                    NYLDSelenium.ElemExist("Zip", Zip);
                }
                else
                {
                    NYLDSelenium.ElemExist("Province", Province);
                    NYLDSelenium.ElemExist("Postal code", PostalCode);
                }
                NYLDSelenium.ElemExist("Country", Country);
            }
            else
            {
                //Funeral home
                NYLDSelenium.VerifyText(entity + " - information text", testData.GetContent("FuneralHomeText"), commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " info text", FuneralHomeText[0])), "always");
                NYLDSelenium.VerifyText(entity + " - Beneform Header", "Beneficiary Form", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " bene form header", FuneralHomeText[1])), "always");
                NYLDSelenium.VerifyText(entity + " - Beneform download text", "Please download, print, and complete this form.", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " bene form download text", FuneralHomeText[2])), "always");
                NYLDSelenium.VerifyText(entity + " - Beneform download link", "Beneficiary form", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " bene form download link", FuneralHomeText[3])), "always");

                if (entity == "FuneralHome")
                {
                    NYLDSelenium.VerifyText(entity + " - Aggrement Header", "Pre-need Agreement:", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " Aggrement Header", FuneralHomeText[4])), "always");
                    NYLDSelenium.VerifyText(entity + " - Aggrement text", testData.GetContent("FuneralHomeAggreement"), commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " Aggrement text", FuneralHomeText[5])), "always");
                    NYLDSelenium.VerifyText(entity + " - Mail header", "Complete and mail forms to:", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " Mail header", FuneralHomeText[6])), "always");
                    NYLDSelenium.VerifyText(entity + " - Mail text", testData.GetContent("FuneralHomeAddress"), commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " Mail", FuneralHomeText[7])), "always");
                }
                else
                {
                    NYLDSelenium.VerifyText(entity + " - TrustForm Header", "Statement of Trust Form", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " bene form header", FuneralHomeText[4])), "always");
                    NYLDSelenium.VerifyText(entity + " - Trustform download text", testData.GetContent("TrustFormText"), commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " bene form download text", FuneralHomeText[5])), "always");
                    NYLDSelenium.VerifyText(entity + " - Trustform download link", "Trust form", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " bene form download link", FuneralHomeText[6])), "always");
                    NYLDSelenium.VerifyText(entity + " - Mail header", "Complete and mail forms to:", commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " Mail header", FuneralHomeText[7])), "always");
                    NYLDSelenium.VerifyText(entity + " - Mail text", testData.GetContent("FuneralHomeAddress"), commonFunctions.FormatString(NYLDSelenium.GetAttribute(entity + " Mail", FuneralHomeText[8])), "always");
                }


            }

        }

        /// <summary>
        /// Verify Add Bene Page 3
        /// </summary>
        /// <param name="country"></param>
        public void FillPage2(string country, string beneClass, string type = "", bool perStirpes = false)
        {
            TestData testData = new TestData();
            Thread.Sleep(1000);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Fill Page 2" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "yes");

            string entity = NYLDSelenium.GetAttribute("Entity Selected", BeneficiaryEntity_Page2).Replace("Cancel", "").Trim();
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            LoginPage login = new LoginPage(driver, data);
            //Page 2
            string pFN = "TestFirstName";
            string pLN = "TestLastName";
            string company = "TestCompanyName";
            string relationShip = "Spouse";
            string pPN = "(200) 123-1234";
            string pAL1 = "219 E Huron St";
            string pAL2 = "";
            string pCY = "Ann Arbor";
            string pCN;
            string pST;
            string pZP;
            string StatenZip;
            string state;
            string name = "";
            // CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", login.CloseMockBanner, false, "no", "no"))
                NYLDSelenium.Click("Mock banner", login.CloseMockBanner);

            //Scroll to beginning of page
            //NYLDSelenium.ScrollToView(ContractNumber_Page2);
            //Clear and update Non Country specific fields
            if (entity.Contains("Person"))
            {
                NYLDSelenium.Clear("Clear FirstName", FirstName);
                NYLDSelenium.SendKeys("Bene FirstName", FirstName, pFN);
                NYLDSelenium.Clear("Clear LastName", LastName);
                NYLDSelenium.SendKeys("Bene Last Name", LastName, pLN);
                NYLDSelenium.SendKeys("SSN", SocialSecurity, "123456789");
                NYLDSelenium.SelectList("Relationship", RelationshipDropdown, relationShip, "bytext");

                name = pFN + " " + pLN;
            }

            if (entity.Contains("Company"))
            {
                NYLDSelenium.Clear("Clear CompanyName", CompanyName);
                NYLDSelenium.SendKeys("Bene CompanyName", CompanyName, company);
                NYLDSelenium.SendKeys("SSN", TaxID, "123456789");

                name = company;
            }


            NYLDSelenium.Clear("Clear PhoneNumber", PhoneNumber);
            NYLDSelenium.SendKeys("Bene PhoneNumber", PhoneNumber, pPN);
            NYLDSelenium.Clear("Clear Addr Line 1", AddresLine1);
            NYLDSelenium.SendKeys("Bene Addr Line 1", AddresLine1, pAL1);
            NYLDSelenium.Clear("Clear Addr Line 2", AddressLine2);
            NYLDSelenium.SendKeys("Bene Addr Line 2", AddressLine2, pAL2);
            NYLDSelenium.Clear("Clear city", City);
            NYLDSelenium.SendKeys("Bene City", City, pCY);

            NYLDSelenium.ReportStepResult("Select Country: " + country, "Select Country", "INFO", "no");
            pCN = CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", country.Trim()));

            //Update country specific fields
            if (country.Trim() == "US")
            {
                state = testData.GetMappedValue("State", "MI");
                pST = "MI";
                pZP = "48103";
                StatenZip = pST + " " + pZP;

                NYLDSelenium.SelectList("Update payor State", State, state, "bytext");
                NYLDSelenium.Clear("Clear Zip", Zip);
                NYLDSelenium.SendKeys("Update payor Zip", Zip, pZP);
            }
            else if (country.Trim() == "CA")
            {
                state = testData.GetMappedValue("State", "AB");
                pST = "AB";
                pZP = "A9A 9A9";
                StatenZip = pST + " " + pZP;

                NYLDSelenium.SelectList("Update payor State", Province, state, "bytext");
                NYLDSelenium.Clear("Clear postal Code", PostalCode);
                NYLDSelenium.SendKeys("Update payor Zip", PostalCode, pZP);
            }
            else
            {
                pCN = country.Trim() + " - " + pCN;
                pST = "";
                pZP = "";
                StatenZip = "";
            }

            //Select per stirpes if requested
            if (perStirpes && (NYLDSelenium.ElemExist("Per Stirpes", PerStirpeslabel, false, "no", "no")))
                NYLDSelenium.Click("Per Stirpes", PerStirpeslabel);

            //Click on continue button
            if (NYLDSelenium.ElemExist("Submit", Continue, false, "no", "no"))
                NYLDSelenium.Click("Submit", Continue);


            //Store updated values    
            CSWData.TempVal = name + ":" + pPN + ":" + pAL1 + " " + pCY + "," + " " + StatenZip + ":" + pCN;

            //COnfirm address
            if (country == "US")
                changePayor.UpdateSelectAddress("US,Entered");

            //Save Bene edetails Added
            newBeneAdded.Add(pFN + " " + pLN);
            newBeneAdded.Add(type);
            newBeneAdded.Add(beneClass);
            newBeneAdded.Add(relationShip);
        }

        /// <summary>
        /// Verify Add Bene Page 3
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPage3(string args)
        {
            Thread.Sleep(1000);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Page 3" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "yes");

            int beneClass = 1;
            string classToBeAdded = args.Split('-')[1];
            IWebElement beneClassTable = null;
            IList<IWebElement> beneClassTableRows = new List<IWebElement>(); ;
            List<List<string>> currentBeneList = new List<List<string>>();
            LSPDatabase database = new LSPDatabase(driver, data);

            //Get Bene Info            
            database.GetBeneInfo();
            Thread.Sleep(300);
            //Page load
            NYLDSelenium.PageLoad("Add Bene Page 3", BenePage3);

            //Verify Bene table
            currentBeneList = CSWData.BeneInfo.ToList();
            currentBeneList.Add(newBeneAdded);

            //Get Class number
            beneClass = Convert.ToInt16(classToBeAdded.Substring(classToBeAdded.Length - 1));
            beneClassTable = NYLDSelenium.GetWE("//table[@id='bene-class-" + beneClass + "']//tbody");
            beneClassTableRows = beneClassTable.FindElements(By.XPath("./tr"));

            //Verify Bene table
            for (int i = 0; i < currentBeneList.Count; i++)
            {

                if (currentBeneList[i][2].Trim() == classToBeAdded)
                {
                    //Format Name as displayed in UI
                    string fullname;
                    string[] name;

                    if (currentBeneList[i][0].Contains("/"))
                    {
                        name = currentBeneList[i][0].Split('/');

                        if (name.Length > 2)
                        {

                            if (name[2].Trim() == "")
                            {
                                fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim() + " " + name[4].Trim();
                            }
                            else
                            {
                                fullname = name[3].Trim() + " " + name[1].Trim() + " " + name[2].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim() + " " + name[4].Trim();
                            }
                        }
                        else
                            fullname = name[1].Trim() + " " + name[0].Replace(",", "").Replace("Per Stirpes", "").Trim();


                        if (currentBeneList[i][15] == "Trust")
                            fullname = "Trust of " + fullname;

                        if (currentBeneList[i][15] == "Estate")
                            fullname = name[0].Replace(",", "").Replace("Per Stirpes", "");
                    }
                    else if (currentBeneList[i].Count > 4)
                    {
                        fullname = currentBeneList[i][0].Replace(",", "").Replace("Per Stirpes", "").Trim();


                        try

                        {
                            if (currentBeneList[i][15] != null)
                            {
                                if (currentBeneList[i][15] == "Estate")
                                    fullname = "Estate";
                            }

                        }

                        catch
                        {
                            fullname = currentBeneList[i][0].Trim();
                        }
                    }

                    else
                    {
                        fullname = currentBeneList[i][0].Trim();
                    }

                    //loop through and verifyif bene is displayed
                    for (int j = 0; j < beneClassTableRows.Count; j++)
                    {
                        IList<IWebElement> beneInfo = new List<IWebElement>();
                        string relationShip = currentBeneList[i][3].Trim();

                        if (currentBeneList[i].Count > 4)
                        {
                            if (currentBeneList[i].Count > 15)
                                relationShip = currentBeneList[i][15].Trim();
                            else
                                relationShip = currentBeneList[i][7].Trim();
                        }

                        beneInfo = beneClassTableRows[j].FindElements(By.XPath("./td"));
                        if (fullname.Trim() == beneInfo[0].Text.Trim())
                        {
                            NYLDSelenium.VerifyText("Beneficiary Name" + i, fullname.Trim(), beneInfo[0].Text.Trim());
                            NYLDSelenium.VerifyText("Beneficiary Relationship" + i, relationShip.Trim(), beneInfo[1].Text.Trim());
                            break;
                        }
                    }
                }

            }
        }

        /// <summary>
        /// Fill Add Bene Page 3
        /// </summary>
        /// <param name="args"></param>
        public void FillPage3(string args)
        {
            Thread.Sleep(1000);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Fill Page 3" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            IWebElement distributeEvenly = null;
            string classToBeAdded = args.Split('-')[1];
            string xpath = "//table[@id='bene-class-" + classToBeAdded.Substring(classToBeAdded.Length - 1) + "']//a[contains(@href, 'Distribution')]";

            //Page load
            NYLDSelenium.PageLoad("Bene Page 3", BenePage3);

            //Distrbute evenly link
            distributeEvenly = NYLDSelenium.GetWE(xpath);
            NYLDSelenium.Click("Distribute share evenly", distributeEvenly, true, "always");

            //Review and Confirm select
            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-50);
            if (NYLDSelenium.ElemExist("Select Review and confirm", ReviewAndConfirm, false, "no", "no"))
                NYLDSelenium.Click("Select Review and confirm", ReviewAndConfirm);

            //Click on Continue button
            if (NYLDSelenium.ElemExist("Submit", Continue, false, "no", "no"))
                NYLDSelenium.Click("Submit", Continue);
        }

        /// <summary>
        /// Verify common elements in Edit Beneficiaries page
        /// </summary>
        public void VerifyEditPage(string entity)
        {
            //Form Content
            NYLDSelenium.ElemExist("Address Line 1", AddresLine1);
            NYLDSelenium.ElemExist("Address Line 2", AddressLine2);

            SelectElement select = new SelectElement(Country);

            string country = select.SelectedOption.Text;
            if (country.Contains("United"))
            {
                NYLDSelenium.ElemExist("State", State);
                NYLDSelenium.ElemExist("Zip", Zip);
            }
            else
            {
                NYLDSelenium.ElemExist("Province", Province);
                NYLDSelenium.ElemExist("Postal code", PostalCode);
            }

            NYLDSelenium.ElemExist("City", City);
            NYLDSelenium.ElemExist("Country", Country);

            //Buttons bottom of page
            NYLDSelenium.ElemExist("Review and Confirm", ReviewAndConfirm);
            NYLDSelenium.ElemExist("Cancel Button", Cancel);
            NYLDSelenium.ElemExist("Update Button", Update);

            //NYLDSelenium.ScrollToView( EditBeneficiariesHeader);

            //Verifying and updating page depending on Beneficiary type
            switch (entity)
            {
                case "Person":
                    //Form Content
                    NYLDSelenium.ElemExist("FirstName", FirstName);
                    NYLDSelenium.ElemExist("LastName", LastName);
                    NYLDSelenium.ElemExist("SSN", SocialSecurityEdit);
                    NYLDSelenium.ElemExist("Relationship", RelationshipDropdown);
                    NYLDSelenium.ElemExist("DOB", DateOfBirth);

                    //Per stirpes and None option
                    NYLDSelenium.ElemExist("Per Stirpes", PerStirpeslabel);
                    NYLDSelenium.ElemExist("None", NoneLabel);
                    break;

                case "Organization":
                    //Form Content
                    NYLDSelenium.ElemExist("Company Name", Company);
                    NYLDSelenium.ElemExist("Tax ID Number", TaxID);
                    NYLDSelenium.ElemExist("Phone Number", PhoneNumber);
                    break;

                case "Estate":
                    //Form Content
                    NYLDSelenium.ElemExist("SSN", SocialSecurityEdit);
                    NYLDSelenium.ElemExist("Phone Number", PhoneNumber);
                    break;
            }
        }

        public void VerifyDistributionPage()
        {
            NYLDSelenium.Click("Edit Distribution", EditDistributionLink[0], true, "always", "yes");

            NYLDSelenium.PageLoad("Edit Bene Distribution Header", EditBeneDistributionHeader);

            for (int i = 1; i < 4; i++)
            {
                IWebElement BeneClassHeader = driver.FindElement(By.XPath("//span[contains(text(),'" + i + "')]"));
                IWebElement DistributeEvenly = driver.FindElement(By.XPath("//*[@id='bene-class-" + i + "']//a[contains(@href, 'Distribution')]"));
                IWebElement ReorderTableHeader = driver.FindElement(By.XPath("//table[@id='bene-class-" + i + "']//th[contains(text(),'Reorder')]"));
                IWebElement BeneficiaryTableHeader = driver.FindElement(By.XPath("//table[@id='bene-class-" + i + "']//th[contains(text(),'Beneficiary')]"));
                IWebElement RelationshipTableHeader = driver.FindElement(By.XPath("//table[@id='bene-class-" + i + "']//th[contains(text(),'Relationship')]"));
                IWebElement ShareTableHeader = driver.FindElement(By.XPath("//table[@id='bene-class-" + i + "']//th[contains(text(),'Share')]"));
                IWebElement DeleteTableHeader = driver.FindElement(By.XPath("//table[@id='bene-class-" + i + "']//th[contains(text(),'Delete')]"));

                NYLDSelenium.ElemExist("Bene Class Header", BeneClassHeader);
                NYLDSelenium.ElemExist("Distribute Evenly Button", DistributeEvenly);
                NYLDSelenium.ElemExist("Reorder Table Header", ReorderTableHeader);
                NYLDSelenium.ElemExist("Beneficiary Table Header", BeneficiaryTableHeader);
                NYLDSelenium.ElemExist("Relationship Table Header", RelationshipTableHeader);
                NYLDSelenium.ElemExist("Share Table Header", ShareTableHeader);
                NYLDSelenium.ElemExist("Delete Table Header", DeleteTableHeader);
            }

            //Need to add: Bene Names, Percentage, Delete button page objects

            NYLDSelenium.ElemExist("Review and Confirm Header", ReviewAndConfirmHeader);
            NYLDSelenium.ElemExist("Review and Confirm Button", ReviewAndConfirm);
            NYLDSelenium.ElemExist("Cancel Button", Cancel);
            NYLDSelenium.ElemExist("Update Button", Update);

            //This is after Delete button is Clicked for a bene
            //NYLDSelenium.ElemExist("Delete Bene Message", DeleteBeneMessage, 1);
            //NYLDSelenium.ElemExist("Cancel Delete Button", CancelDeleteButton, 1);
            //NYLDSelenium.ElemExist("Delete Bene Button", DeleteButton, 1);
        }

        public void VerifyPreventBeneChangeGrief()
        {
            TestData testData = new TestData();

            NYLDSelenium.PageLoad("Manage Beneficiary Header", BeneficiaryPage);

            NYLDSelenium.VerifyText("Prevent Bene Change Subheader", testData.GetContent("ShareTotal"), NYLDSelenium.GetAttribute("Prevent Bene Change Subheader", PreventBeneChangeSubheader));

            NYLDSelenium.VerifyText("Grief Message for Prevent Bene Change", testData.GetContent("PreventBeneChangeGrief"), PreventBeneChangeMessage.Text.Replace("\r", "").Replace("\n", ""), "yes");
        }

        public void VerifyNoBeneGriefMsg()
        {
            TestData testData = new TestData();

            NYLDSelenium.PageLoad("Manage Beneficiary Header", BeneficiaryPage);

            NYLDSelenium.VerifyText("Grief Message for No Beneficiaries", "No beneficiaries are listed for this contract.", NYLDSelenium.GetAttribute("No Beneficiaries Subheader", NoBeneMessage));
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyChangePayorfields                                                                     ///////////
        ////// Description:  Field validation for change payor page                                              ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void EnterBeneficiaryInfo(string args)
        {           
            NYLDSelenium.AddHeader("Verify Beneficiary Page field", "mainheader");
            TestData testData = new TestData();
            LoginPage login = new LoginPage(driver, data);

            //Click on Add Beneficiary link
            if (NYLDSelenium.ElemExist("Add Beneficiary Link", AddBeneficiaryLink, false, "no", "no"))
                NYLDSelenium.Click("Add Beneficiary Link", AddBeneficiaryLink);

            //Page Load
            NYLDSelenium.PageLoad("Add Beneficiary", AddBeneficiaryPage);

            //Page 1            
            FillPage1(args + "-BN1");

            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", login.CloseMockBanner, false, "no", "no", "no", 30))
                NYLDSelenium.Click("Mock banner", login.CloseMockBanner);
        }
    }
}
