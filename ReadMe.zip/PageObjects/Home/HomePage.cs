﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using System.Threading;
using CSW.PageObjects.Login;

namespace CSW.PageObjects.Home
{
    class HomePage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;
        public HomePage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@class = 'standard-modal-close modal-dialog-close']")]
        public IWebElement NoPolicyClosePP { get; set; }

        //[FindsBy(How = How.XPath, Using = "//a[contains(@class, 'nav-link dropdown-toggle') and contains(@data-ea-cta-link,'Account Panel')]")]
        [FindsBy(How = How.XPath, Using = "//a[contains(@class, 'nav-link dropdown-toggle') and @id='account-panel-id']")]
        public IWebElement MyAccountDropDown { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='navbarSupportedContent']//h4")]//strong[text()='Coverage']/../..
        public IWebElement WelcomeUser { get; set; }

        [FindsBy(How = How.XPath, Using = "//strong[text()='Coverage']/../..")]
        public IWebElement CoverageHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//strong[text()='Payments']/../..")]
        public IWebElement PaymentHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//strong[text()='Profile']/../..")]
        public IWebElement ProfileHeader { get; set; } 

        [FindsBy(How = How.XPath, Using = "(//a[contains(@href, 'Coverage') and  contains(text(), 'View coverage details')])[1]")]
        public IWebElement SummaryPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Welcome to the Customer Service Center!')]")]
        public IWebElement LoginPageHeader { get; set; }       

        [FindsBy(How = How.Id, Using = "P6BWWR9LQB-firefly-button")]
        public IWebElement SupportButton { get; set; }
     
        [FindsBy(How = How.XPath, Using = "(//p[text()='Co-Browse session code:']/../following::span/p)[1]")]
        public IWebElement CoBrowserSessionCode { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='disclaimer-checkbox']")]
        public IWebElement CoBrowserDisclaimerCheckbox { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='dialog disclaimer']")]
        public IWebElement CoBrowserDisclaimer { get; set; }

        //Agree
        [FindsBy(How = How.XPath, Using = "//button[@type='button' and contains(text(), 'Agree')]")]
        public IWebElement CoBrowserAgreeBtn { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        /// <summary>
        /// Method to Navigate to different tabs from home screen
        /// </summary>
        /// <param name="args"></param>
        public void NavigateToPage(string args)
        {
            Thread.Sleep(500);

            NYLDDigital.SkipSurveyPopUp(StartSurvey, 15, false);

            //Open Account panel
            if (NYLDSelenium.GetAttribute("Account Panel", MyAccountDropDown, "aria-expanded", false, "no", "no") != "true")
                NYLDSelenium.Click("My Coverage", MyAccountDropDown);
            Thread.Sleep(1000);
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 15, false);
            Thread.Sleep(1000);
            //Navigate to the required tab
            NYLDSelenium.Click(args + " tab", NYLDSelenium.GetWE("//a[contains(@data-ea-zone, 'Account') and contains(text(), '" + args + "')]"));

            Thread.Sleep(1000);
        }

        public void VerifyCoBrowseSession()
        {
            LoginPage LP = new LoginPage(driver, data);
            try
            {
                string actualResult;
                //Verify Login Page is loaded
                NYLDSelenium.PageLoad("Login", LoginPageHeader);
                Thread.Sleep(5000);
                //Cookies preferance popup
                NYLDDigital.AcceptCookiesPreferences();
                Thread.Sleep(1000);

                //Switch to iframe
                NYLDSelenium.GetWE("//iframe[@id='P6BWWR9LQB-firefly']");
                driver.SwitchTo().Frame("P6BWWR9LQB-firefly");
              
                //Click Support Button
                NYLDSelenium.Click("Support", SupportButton);

                driver.SwitchTo().DefaultContent();

                Thread.Sleep(5000);
                //Switch to iframe
                driver.SwitchTo().Frame("P6BWWR9LQB-widget-frame");

                NYLDSelenium.PageLoad("Support Co-browser", CoBrowserDisclaimer);

                //if (CSWData.Environment == "Stage")
                //{
                NYLDSelenium.Click("CoBrowser Disclaimer Checkbox", CoBrowserDisclaimerCheckbox);
                NYLDSelenium.Click("Agree", CoBrowserAgreeBtn);
                //Get the Session ID
                //string cobrowseSessionCode = CoBrowserSessionCode.GetAttribute("text");
                string cobrowseSessionCode = NYLDSelenium.GetAttribute("Cobrowse Session", CoBrowserSessionCode);

                //Check the length of the string
                if (cobrowseSessionCode.Length > 0)
                {
                    actualResult = "CoBrowse Session Code is displayed as " + cobrowseSessionCode;
                    NYLDSelenium.ReportStepResult("Verify if CoBrowse Session Code exists", actualResult, "Pass");
                }
                else
                {
                    actualResult = "CoBrowse Session Code is empty";
                    //Report the result
                    NYLDSelenium.ReportStepResult("Verify if CoBrowse Session Code exists", actualResult, "Fail");
                }

                driver.SwitchTo().DefaultContent();
            }
            catch
            {
                NYLDSelenium.ReportStepResult("CoBrowser popup is not display in the homepage screen.", "Please check report to automation team. Here is the exception: CoBrowser popup is not display in the homepage screen.", "FAIL", "always", "yes");
            }

        }
        /// <summary>
        /// Method to check all My acount banner content
        /// </summary>
        /// <param name="args"></param>
        public void VerifyMyAccountBanner(string args)
        {
            IList<IWebElement> links = new List<IWebElement>();
            IWebElement[] headerElements = { CoverageHeader, PaymentHeader, ProfileHeader};
            string[] coverageLinks = {KeyRepository.CoveragePage, KeyRepository.BeneficiaryPage, KeyRepository.InsuredPage };
            string[] paymentLinks = { KeyRepository.OneTimePaymentPage, KeyRepository.PaymentPage, KeyRepository.PayorPage };
            string[] profileLinks = { KeyRepository.ContactInfoPage, KeyRepository.AccountInfoPage, KeyRepository.LogoutPage };

            //Open Account panel
            if (NYLDSelenium.GetAttribute("Account Panel",MyAccountDropDown, "aria-expanded",false, "no", "no") != "true")
                NYLDSelenium.Click("My Coverage", MyAccountDropDown);

            //Welcome User
            NYLDSelenium.VerifyText("Welcome Header", "Welcome " + "AAll", WelcomeUser.Text.Trim());

            //Welcome Text

            //Verify Header and Links
            for(int i=0; i<3; i++)
            {
                string header = "";
                string[] linkNames = null;

                switch(i)
                {
                    case 0:
                        header = "Coverage Section";
                        linkNames = coverageLinks;
                        break;

                    case 1:
                        header = "Payment Section";
                        linkNames = paymentLinks;
                        break;

                    case 2:
                        header = "Profile Section";
                        linkNames = profileLinks;
                        break;
                }

                NYLDSelenium.ElemExist(header, headerElements[i]);

                links = headerElements[i].FindElements(By.XPath(".//li/a"));

                int j = 0;
                foreach(IWebElement we in links)
                {
                    if (j > linkNames.Count() - 1)
                        NYLDSelenium.ReportStepResult("New link displayed in Account panel", "New link '"+ NYLDSelenium.GetAttribute(we.ToString(), we).Trim() + "' displayed in My accout panel", "Fail", "yes");
                    else
                        NYLDSelenium.VerifyText(we.ToString(), linkNames[j], NYLDSelenium.GetAttribute(we.ToString(), we).Trim());
                    j++;
                }
            }               
        }
    }
}
