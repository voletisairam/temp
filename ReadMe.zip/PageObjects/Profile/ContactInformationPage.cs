﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using CSW.Common.DataBase;
using System.Text.RegularExpressions;
using CSW.PageObjects.Login;
using CSW.Common.Email;
using CSW.Common.Excel;
using CSW.Common.Database;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace CSW.PageObjects.Profile
{
    class ContactInfomationPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ContactInfomationPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////
        /////////    Contact Information Page Section    /////////
        //////////////////////////////////////////////////////////

        //Contract information page
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Contact information')]")]
        public IWebElement ContactInfoPageTitle { get; set; }

        //Account information page
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Account information')]")]
        public IWebElement AccountInfoPageTitle { get; set; }

        //Contract Owner section
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Contract Owner')]")]
        public IWebElement ContractOwner { get; set; }

        //Address section Header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Update your address')]")]
        public IWebElement AddressHeader { get; set; }

        //Phone Number section header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Update your primary phone')]")]
        public IWebElement PhoneHeader { get; set; }

        //Owner Country
        [FindsBy(How = How.XPath, Using = "//*[@id='Country']")]
        public IWebElement Country { get; set; }

        //Owner Address line 1
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress1']")]
        public IWebElement AddressLine1 { get; set; }

        //Owner Address line 1 pop up message
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress1-error']")]
        public IWebElement AddressLine1Popup { get; set; }

        //Owner Address line 2
        [FindsBy(How = How.XPath, Using = "//*[@id='txtAddress2']")]
        public IWebElement AddressLine2 { get; set; }

        //Owner city
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCity']")]
        public IWebElement City { get; set; }

        //owner city pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtCity-error']")]
        public IWebElement CityPopup { get; set; }

        //Owner State
        [FindsBy(How = How.XPath, Using = "//*[@id='State']")]
        public IWebElement State { get; set; }

        //Owner Zip
        [FindsBy(How = How.XPath, Using = "//*[@id='txtZip']")]
        public IWebElement Zip { get; set; }

        //owner Zip pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtZip-error']")]
        public IWebElement ZipPopup { get; set; }

        //Owner Province
        [FindsBy(How = How.XPath, Using = "//*[@id='Province']")]
        public IWebElement Province { get; set; }

        //Owner PostalCode
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPostalCode']")]
        public IWebElement PostalCode { get; set; }

        //owner Postalcode pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPostalCode-error']")]
        public IWebElement PostalCodePopup { get; set; }

        //Save Address
        [FindsBy(How = How.XPath, Using = "//form[@id='change-address-form']//button[@type='submit']")]
        public IWebElement SaveAddress { get; set; }

        //Save Phone
        [FindsBy(How = How.XPath, Using = "//form[@id='change-phone-form']//button[@type='submit']")]
        public IWebElement SavePhone { get; set; }

        //Owner phone 
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPhoneNumber']")]
        public IWebElement PhoneNumber { get; set; }

        //Owner phone number pop up message
        [FindsBy(How = How.XPath, Using = "//*[@id='txtPhoneNumber-error']")]
        public IWebElement PhoneErrorTxt { get; set; }

        //Update your mobile number section text
        [FindsBy(How = How.XPath, Using = "//h1[contains(@class,'h2') and contains(text(),'Update your mobile phone')]")]
        public IWebElement MobileUpdateSubHeading { get; set; }

        //Current mobile number
        [FindsBy(How = How.XPath, Using = "//*[@id='change-mobile-form']/strong")]
        public IWebElement CurrentMobileNumber { get; set; }        

        //Profile mobile number for profile security
        [FindsBy(How = How.XPath, Using = "//*[@id='txtMobileNumber']")]
        public IWebElement MobileNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtMobileNumber-error']")]
        public IWebElement MobileErrorTxt { get; set; }

        //Profile mobile number for profile security
        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmMobileNumber']")]
        public IWebElement ConfirmMobileNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmMobileNumber-error']")]
        public IWebElement ConfirmMobileErrorTxt { get; set; }

        //Save Phone
        [FindsBy(How = How.XPath, Using = "//form[@id='change-mobile-form']//button[@type='submit']")]
        public IWebElement Savemobile { get; set; }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Verify your identity')]")]
        public IWebElement IdentityPageHeading { get; set; }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Verify your identity')]//following::p")]
        public IWebElement IdentitySubTitleTxt { get; set; }

        //Heading
        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Enter the code sent to your')]")]
        public IWebElement PageHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'txtOtp']")]
        public IWebElement Otp { get; set; }

        //General Continue Button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(), 'Continue')]")]
        public IWebElement ContinueBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='confirm-otp-form']//div//p[contains(text(),'This code expires')]")]
        public IWebElement resendOtpTxt { get; set; }

        /////////////////////////////////////////////////////////
        /////////    Additional Address Page Section    /////////
        /////////////////////////////////////////////////////////

        //Suggested address Page
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Please confirm address')]")]
        public IWebElement ConfirmAddressHeader { get; set; }

        //Confirm address full table
        [FindsBy(How = How.XPath, Using = "//*[@id='cleanse-address-form']/div[1]")]
        public IWebElement ConfirmAddressTable { get; set; }

        //Suggested USPS address header
        [FindsBy(How = How.XPath, Using = "//*[@id='cleanse-address-form']/div[1]/div[1]/p")]
        public IWebElement SuggestedAddressHeader { get; set; }

        //Suggested Address
        [FindsBy(How = How.XPath, Using = "//*[@id='cleanse-address-form']/div[1]/div[1]/div/label")]
        public IWebElement SuggestedAddress { get; set; }

        //Entered address Header
        [FindsBy(How = How.XPath, Using = "//*[@id='cleanse-address-form']/div[1]/div[2]/p")]
        public IWebElement EnteredAddressHeader { get; set; }

        //Entered Address
        [FindsBy(How = How.XPath, Using = "//*[@id='cleanse-address-form']/div[1]/div[2]/div/label")]
        public IWebElement EnteredAddress { get; set; }

        //Suggested address select Radio button
        [FindsBy(How = How.XPath, Using = "//*[@id='suggested-address']")]
        public IWebElement SuggestedAddressRadioBtn { get; set; }

        //Entered address select Radio button
        [FindsBy(How = How.XPath, Using = "//*[@id='entered-address']")]
        public IWebElement EnteredAddressRadioBtn { get; set; }

        //Address Confirm button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Confirm')]")]
        public IWebElement ConfirmAddressButton { get; set; }

        /////////////////////////////////////////////////////////////
        /////////    Select Additional Contracts Section    /////////
        /////////////////////////////////////////////////////////////

        //Select Additional contracts header
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Select additional contracts')]")]
        public IWebElement SelectAddlContractsHeader { get; set; }

        //Select Additional contracts sub header
        //[FindsBy(How = How.XPath, Using = "")]
        //public IWebElement SelectAddContractsSubHeader { get; set; }

        //Policy select table
        [FindsBy(How = How.XPath, Using = "//*[@id='select-policies-form']")]
        public IWebElement PolicySelectTable { get; set; }

        //Select All Contracts checkbox
        [FindsBy(How = How.XPath, Using = "//*[@id='selectAll']")]
        public IWebElement SelectAllContractsBox { get; set; }

        //Select All Contracts text
        [FindsBy(How = How.XPath, Using = "//*[@id='select-policies-form']/div[1]/label")]
        public IWebElement SelectAllContractsText { get; set; }

        //Policy select submit button
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Save')]")]
        public IWebElement PolicySelectSave { get; set; }

        //Select All Contracts text
        [FindsBy(How = How.XPath, Using = "//small[@class='float-right text-center']")]
        public IWebElement CloseMockBanner { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='select-policies-form']/div[3]/div/span[text()='There was an error when updating your contact information.']")]
        public IWebElement ErrorMessage { get; set; }

        ////////////////////////////////////////////////
        /////////    Thank You Page Section    /////////
        ////////////////////////////////////////////////

        //Thank you Page
        [FindsBy(How = How.XPath, Using = "//*[@class='bg-white p-3 p-md-5 shadow']")]
        public IWebElement ThankYouPage { get; set; }

        //Policy select Thank You header
        //[FindsBy(How = How.XPath, Using = "")]
        //public IWebElement ThankYouHeader { get; set; }

        //Policy select Thank You Message
        [FindsBy(How = How.XPath, Using = "//*[@class='text-dk-palm']")]
        public IWebElement ThankYouMessage { get; set; }

        //Return to home page
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Back')]")]
        public IWebElement BackButton { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Methods      //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: contactInfoFormVal                                                                          ///////////
        ////// Description:  Get field validation message for contact information fields                         ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void ContactInfoFormVal(string fldName, out IWebElement fieldName, out IWebElement fieldPopUp, out IWebElement Submit, out string blankmsg, out string message, out int maxlength, out string data, out bool list, out bool submit, out bool phone)
        {
            list = false;
            submit = false;
            phone = false;

            switch (fldName)
            {
                case "Phone":
                    fieldName = PhoneNumber;
                    fieldPopUp = PhoneErrorTxt;
                    blankmsg = "This number is not in the correct format.";
                    message = "This number is not in the correct format.";
                    maxlength = 12;
                    data = ";BLNK|1234";
                    phone = true;
                    Submit = SavePhone;
                    break;

                case "Mobile":
                    fieldName = MobileNumber;
                    fieldPopUp = MobileErrorTxt;
                    blankmsg = "Please enter a valid mobile number.";
                    message = "Please enter a valid mobile number.";
                    maxlength = 12;
                    data = ";BLNK|1234";
                    phone = true;
                    Submit = SavePhone;
                    break;

                case "AddressLine1":
                    fieldName = AddressLine1;
                    fieldPopUp = AddressLine1Popup;
                    blankmsg = "Please specify first line of address.";
                    message = "Invalid characters found in address.";
                    maxlength = 30;
                    Submit = SaveAddress;
                    data = "SPC|1043 O'Niel Street|123-34 Main St|43 St,Mark Place|45 Dr.Higgins Road|#142 Richmond Avenue|%43 Lowell Ave|542 Run Dr&|(|)|_|43 Henderson St+|001 Richmond Place?;BLNK|<|>|653 US 19!|1/2 Bruce B Downs Road|^43 Dale Mabry Hwy|67~ WoodBridge|822 T@rrid Ave|1040 Florida Av$|342 L*cas St";
                    break;

                case "City":
                    fieldName = City;
                    fieldPopUp = CityPopup;
                    blankmsg = "Please specify city.";
                    message = "This is an invalid city name.";
                    maxlength = 20;
                    Submit = SaveAddress;
                    data = "New York|St.Pete|Jai-Alai;BLNK|Tampa!|B@ston|#Washington|Baltimor$|Denve%|Mt^Rushmore|Ft&Worth|Mi*mi|(|)|_|Mobile+|<|>|Atlanta?|/|Panama,City|Grand'Am";
                    break;

                case "Zip":
                    fieldName = Zip;
                    fieldPopUp = ZipPopup;
                    blankmsg = "Please specify Zip Code.";
                    message = "The specified Zip Code is invalid.";
                    maxlength = 10;
                    data = ";123A|124";
                    Submit = SaveAddress;
                    submit = true;
                    break;

                case "PostalCode":
                    fieldName = PostalCode;
                    fieldPopUp = PostalCodePopup;
                    blankmsg = "Please specify Postal Code.";
                    message = "The specified Postal Code is invalid.";
                    maxlength = 0;
                    data = ";34567|A2124";
                    Submit = SaveAddress;
                    submit = true;
                    break;

                default:
                    fieldName = PhoneNumber;
                    fieldPopUp = PhoneErrorTxt;
                    blankmsg = "Please enter a phone number.";
                    message = "This number is not in the correct format.";
                    maxlength = 12;
                    data = "BLNK;888-888-8";
                    Submit = SaveAddress;
                    break;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyContactInfomation                                                                     ///////////
        ////// Description:  verify contact information details                                                  ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyContactInfomation()
        {
            TestData testData = new TestData();
            LSPDatabase DB = new LSPDatabase(driver, data);
            string[] policyList = { };

            NYLDSelenium.AddHeader("Verify Contact Information page", "SubHeader");
            //verify page info is displayed
            NYLDSelenium.ElemExist("Contact Information", ContactInfoPageTitle);
            NYLDSelenium.PageLoad("Contact Information", ContactInfoPageTitle);
            string polnum = data[KeyRepository.PolicyNumber];
            DB.QueryAssociatedPolicies();

            //Get viper policies string
            if (CSWData.VIPERPolicies != null)
                //viper policy list
                policyList = CSWData.VIPERPolicies.Split(';');

            if ((data[KeyRepository.ContractCount] == "Multi") && (policyList.Length <= 1))
                //Stop Test from further progress if Test data is not Multi contract
                NYLDSelenium.ReportStepResult("Multi contract", "User does not have Multiple VIPER policies, data sheet needs to be udpated with valid Policy number", "FAIL", "no", "yes");
            else if ((data[KeyRepository.ContractCount] == "Single") && (policyList.Length > 1))
                //Stop Test from further progress if Test data is not Single contract
                NYLDSelenium.ReportStepResult("Single contract", "User has Multiple VIPER policies, data sheet needs to be udpated with valid Policy number", "FAIL", "no", "yes");

            //verify page info is displayed
           NYLDSelenium.PageLoad("Contact Information", ContactInfoPageTitle);

            data[KeyRepository.PolicyNumber] = polnum;
            DB.QueryPolicyDetails();

            string Ownersection = NYLDSelenium.GetAttribute("Owner", ContractOwner);
            //string[] Ownersplit = Ownersection.Split(':');
            //string Ownername = Ownersplit[1].Trim();

            //string[] Ownersplit = Ownersection.Split(' ');
            IWebElement test = NYLDSelenium.GetWE("//*[@class='alert alert-info mb-2 p-2 fs-mask']");
            string Ownername = NYLDSelenium.GetAttribute("Owner Name", test);
            Ownername = Ownername.Split('\r')[1];
            Ownername = Ownername.Split('\n')[1];

            //verify owner name
            NYLDSelenium.VerifyText("Owner Name", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], Ownername);

            //Verify Address section Header and sub header
            NYLDSelenium.VerifyText("Address section Header", "Update your address", NYLDSelenium.GetAttribute("Address Header", AddressHeader));
            NYLDSelenium.VerifyText("Phone Number section Header", "Update your primary phone", NYLDSelenium.GetAttribute("Phone Number Header", PhoneHeader));

            //verify Address setion
            NYLDSelenium.VerifySelectedItem("Country", Country, testData.GetMappedValue("Country", data[KeyRepository.Country]), "bytext");
            NYLDSelenium.VerifyText("Address Line 1", data[KeyRepository.AddressLine1].Trim(), NYLDSelenium.GetAttribute("Address Line 1", AddressLine1, "value"));
            NYLDSelenium.VerifyText("Address Line 2", data[KeyRepository.AddressLine2].Trim(), NYLDSelenium.GetAttribute("Address Line 2", AddressLine2, "value"));
            NYLDSelenium.VerifyText("City", data[KeyRepository.City].Trim(), NYLDSelenium.GetAttribute("City", City, "value"));
            NYLDSelenium.ElemExist("Save Address", SaveAddress, false, "no", "no", "yes");

            if (data[KeyRepository.Country] == "US")
            {
                NYLDSelenium.VerifySelectedItem("State", State, testData.GetMappedValue("State", data[KeyRepository.State]), "bytext");
                string zipExpected = data[KeyRepository.Zip].Trim();
                string zipActual = NYLDSelenium.GetAttribute("Zip", Zip, "value");
                if (zipExpected.Contains("-"))
                {
                    if (!zipActual.Contains("-"))
                        zipExpected = zipExpected.Split('-')[0].Trim();
                }
                NYLDSelenium.VerifyText("Zip", zipExpected, zipActual);
            }
            else if (data[KeyRepository.Country] == "CA")
            {
                NYLDSelenium.VerifySelectedItem("Province", Province, data[KeyRepository.State], "bytext"); ;
                NYLDSelenium.VerifyText("Postal Code", data[KeyRepository.Zip].Trim(), NYLDSelenium.GetAttribute("PostalCode", PostalCode, "value"));
            }
            else
            {
                NYLDSelenium.ElemNotExist("State", State, false, "no", "no", "yes");
                NYLDSelenium.ElemNotExist("Zip", Zip, false, "no", "no", "yes");
                NYLDSelenium.ElemNotExist("Province", Province, false, "no", "no", "yes");
                NYLDSelenium.ElemNotExist("Postal Code", PostalCode, false, "no", "no", "yes");
            }

            //verify Phone Number section fields availability
            NYLDSelenium.VerifyText("Phone Number", data[KeyRepository.Phone].Trim().Replace(" ", ""), NYLDSelenium.GetAttribute("Phone Number", PhoneNumber, "value").Replace("-", "").Replace(" ", "").Replace("(", "").Replace(")", ""));
            NYLDSelenium.ElemExist("Phone Number", SavePhone, false, "no", "no", "yes");

            NYLDSelenium.AddHeader("Contact information page verification success", "Success");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: UpdateContactInformation                                                                    ///////////
        ////// Description:  Update contact information fields based on parameters                               ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void UpdateContactInformation(string Section)
        {
            NYLDSelenium.AddHeader("Update contact information form", "SubHeader");
            TestData testData = new TestData();

            //verify contact information page availability
           NYLDSelenium.PageLoad("Contact Information", ContactInfoPageTitle);

            //Section split
            string[] getoption = Section.Split(',');

            //Ger Owner name
            //string Ownersection = NYLDSelenium.GetAttribute("Contract Owner", ContractOwner);
            //string[] Ownersplit = Ownersection.Split(' ');
            //string Ownername = Ownersplit[1].Trim();

            IWebElement test = NYLDSelenium.GetWE("//*[@class='alert alert-info mb-2 p-2 fs-mask']");
            string Ownername = NYLDSelenium.GetAttribute("Owner Name", test);
            Ownername = Ownername.Split('\r')[1];
            Ownername = Ownername.Split('\n')[1];

            //Address
            string addressline1 = "";
            string addressline2 = "";
            string city = "";
            string state = "";
            string fullState = "";
            string zip = "";
            string countryCode = "";

            //Phone Number
            string phone = testData.GetInputData("Phone");

            //Update Address information
            if (getoption[0].Trim() == "Address")
            {
                countryCode = getoption[1].Trim();

                int addressLine2Index = 0;

                //Get the Address
                string[] fullAddress = testData.GetInputData(countryCode).Split(',');

                //Set the Address Line 2 Index
                if (((countryCode == "US") || (countryCode == "CN")) && (fullAddress.Length == 5))
                    addressLine2Index++;
                else if (fullAddress.Length == 3)
                    addressLine2Index++;

                //Address Line 1
                addressline1 = fullAddress[0].Trim();

                //Address Line 2
                if (addressLine2Index == 1)
                    addressline2 = fullAddress[1].Trim();

                //City
                city = fullAddress[1 + addressLine2Index].Trim();

                //State and Zip
                if ((countryCode == "US") || (countryCode == "CN"))
                {
                    state = fullAddress[2 + addressLine2Index].Trim();
                    fullState = testData.GetMappedValue("State", state);
                    zip = fullAddress[3 + addressLine2Index].Trim();
                }

                //Full Country name
                string fullCountry = testData.GetMappedValue("Country", countryCode);

                //NYLDSelenium.ScrollToView(AddressLine1);
                NYLDSelenium.Clear("Clear Address Line 1", AddressLine1);
                NYLDSelenium.SendKeys("Update Owner Address Line 1", AddressLine1, addressline1);
                NYLDSelenium.Clear("Clear Address Line 2", AddressLine2);
                NYLDSelenium.SendKeys("Update Owner Address Line 2", AddressLine2, addressline2);
                NYLDSelenium.Clear("Clear city", City);
                NYLDSelenium.SendKeys("Update Owner City", City, city);

                //Enter Non Country specific fields     
                if (countryCode != "US")
                {
                    NYLDSelenium.SelectList("Updating Country", Country, fullCountry, "bytext");
                }

                //Update country specific fields for the US
                if (countryCode == "US")
                {
                    NYLDSelenium.SelectList("Update Owner State", State, fullState, "bytext");
                    NYLDSelenium.Clear("Clear Zip", Zip);
                    NYLDSelenium.SendKeys("Update Owner Zip", Zip, zip);
                }
                else if (countryCode == "CN")
                {
                    NYLDSelenium.SelectList("Update Owner Province", Province, fullState, "bytext");
                    NYLDSelenium.Clear("Clear PostalCode", PostalCode);
                    NYLDSelenium.SendKeys("Update Owner Postal Code", PostalCode, zip);
                }

                //Save Address
                BtnClick("Save Address", SaveAddress, "//form[@id='change-address-form']//button[@type='submit']", data);

                CSWData.EventTriggerTime = DateTime.Now;
                CSWData.EventTriggerTime.AddSeconds(-100);
            }
            //Update Phone number information
            else if(getoption[0].Trim() == "ProfileMobile")
            {
                string mobile = testData.GetInputData("ProfileMobileNumber");
                NYLDSelenium.Clear("Clear mobile Number", MobileNumber);
                NYLDSelenium.Clear("Clear confirm mobile Number", ConfirmMobileNumber);

                //Send phone number one digit at a time
                for (int i = 0; i < mobile.Length; i++)
                {
                    char[] singlePhone = mobile.ToCharArray();

                    try
                    {
                        MobileNumber.SendKeys(singlePhone[i].ToString());

                        if (i == phone.Length - 1)
                            NYLDSelenium.ReportStepResult("Enter data in Phone number field", phone, "PASS");
                    }
                    catch
                    {
                        NYLDSelenium.ReportStepResult("Enter data in Phone number field", phone, "FAIL");
                    }
                }

                //Send phone number one digit at a time
                for (int i = 0; i < mobile.Length; i++)
                {
                    char[] singlePhone = mobile.ToCharArray();

                    try
                    {
                        ConfirmMobileNumber.SendKeys(singlePhone[i].ToString());

                        if (i == phone.Length - 1)
                            NYLDSelenium.ReportStepResult("Enter data in Mobile number field", phone, "PASS");
                    }
                    catch
                    {
                        NYLDSelenium.ReportStepResult("Enter data in Mobile number field", phone, "FAIL");
                    }
                }

                NYLDSelenium.Click("Mobile Number Update submit", Savemobile);

            }
            else
            {
                CSWData.EventTriggerTime = DateTime.Now;
                NYLDSelenium.Clear("Clear Phone Number", PhoneNumber);

                //Send phone number one digit at a time
                for (int i = 0; i < phone.Length; i++)
                {
                    char[] singlePhone = phone.ToCharArray();

                    try
                    {
                        PhoneNumber.SendKeys(singlePhone[i].ToString());

                        if (i == phone.Length - 1)
                            NYLDSelenium.ReportStepResult("Enter data in Phone number field", phone, "PASS");
                    }
                    catch
                    {
                        NYLDSelenium.ReportStepResult("Enter data in Phone number field", phone, "FAIL");
                    }
                }

                NYLDSelenium.Click("Phone Number Update submit", SavePhone);

                //set trigger time                
                CSWData.EventTriggerTime.AddSeconds(-100);
            }

            //assign temval with udpated information
            if (addressline2 != "")
                data[KeyRepository.TempValue] = Ownername + ":" + phone + ":" + addressline1 + " " + addressline2 + ", " + city + ", " + state + " " + zip + ":" + countryCode;
            else if (state != "")
                data[KeyRepository.TempValue] = Ownername + ":" + phone + ":" + addressline1 + " " + city + ", " + state + " " + zip + ":" + countryCode;
            else
                data[KeyRepository.TempValue] = Ownername + ":" + phone + ":" + addressline1 + " " + city + ":" + countryCode;

            if (getoption[0].Trim() == "Address" && getoption[1].Trim() == "US")
            {
                if (NYLDSelenium.ElemExist("Confirm Address page", ConfirmAddressTable, false, "no", "no"))
                {
                    VerifyConfirmAddress();
                    UpdateConfirmAddress(getoption[2].Trim());
                }
                else
                    NYLDSelenium.ReportStepResult("Confirm Address page not found", "Confirm Address page did not load and address was not selected", "FAIL");
            }

            NYLDSelenium.AddHeader("Update Contact information fields success", "Success");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyConfirmAddress                                                                        ///////////
        ////// Description:  Verify confirm address page                                                         ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyConfirmAddress()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Confirm address page of Contact Information" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Header is displayed
            NYLDSelenium.VerifyText("Confirm Address Header", "Please confirm address", NYLDSelenium.GetAttribute("Confirm addrress header", ConfirmAddressHeader));

            //Verify Suggested address Header
            NYLDSelenium.VerifyText("Suggested Address Header", "Suggested U.S. Postal Service address", NYLDSelenium.GetAttribute("Suggested Address Header", SuggestedAddressHeader));

            //Verify Entered address Header
            NYLDSelenium.VerifyText("Entered Address Header", "Use address entered", NYLDSelenium.GetAttribute("Entered Address Header", EnteredAddressHeader));
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: UpdateConfirmAddress                                                                        ///////////
        ////// Description:  Update confirm address page                                                         ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateConfirmAddress(string option)
        {
            string selectedAddress;
            string[] updatedInfo;
            NYLDSelenium.AddHeader("Confirm address page verification", "SubHeader");

            //Select Suggested or entered address as mentioned in args
            if (option == "Suggested")
            {
                //NYLDSelenium.selectRadioBtn("Suggested option", CPsuggAddrRadioBtn, "SuggestedPostalAddress");
                if (!(SuggestedAddressRadioBtn.Selected))
                    NYLDSelenium.Click("Select Suggested Radio", SuggestedAddress);

                selectedAddress = NYLDSelenium.GetAttribute("Suggested Address", SuggestedAddress);
                selectedAddress = selectedAddress.Replace(System.Environment.NewLine, " ");
            }
            else
            {
                //NYLDSelenium.selectRadioBtn("Entered option", CPenteredAddrRadioBtn, "EnteredAddress");
                NYLDSelenium.Click("Select Entered Radio", EnteredAddress);

                selectedAddress = NYLDSelenium.GetAttribute("Entered Address", EnteredAddress);
                selectedAddress = selectedAddress.Replace(System.Environment.NewLine, " ");
            }

            if (CSWData.TempVal != null)
            {
                //Owner information
                updatedInfo = data[KeyRepository.TempValue].Split(':');

                data[KeyRepository.TempValue] = updatedInfo[0] + ":" + updatedInfo[1] + ":" + selectedAddress + ":" + updatedInfo[3];

                //Click on Confirm 
                NYLDSelenium.Click("Confirm Address", ConfirmAddressButton);
            }
            else
            {
                //Click on SaveAddress 
                NYLDSelenium.Click("Confirm Address", ConfirmAddressButton);
            }

            NYLDSelenium.AddHeader("Confirm address page verification and update success", "Success");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifySelectAddlContracts                                                                   ///////////
        ////// Description:  Verify policies displayed in the selct additional contracts page                    ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifySelectAddlContracts()
        {
            NYLDSelenium.AddHeader("Select Additional contracts", "SubHeader");

            //If the Survey window pops up
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            //Verify Page load
            NYLDSelenium.PageLoad("Select Policy", SelectAddlContractsHeader);

            List<string> ContNumlist = new List<string>();
            List<string> allContNumlist = new List<string>();
            StringBuilder allContNumString = new StringBuilder();
            IList<IWebElement> policyRow = driver.FindElements(By.XPath("//*[contains(@id,'_PlanName')]"));

            //viper policy list
            string[] viperPolicyList = CSWData.VIPERPolicies.Split(';');
            string[] associatedPolicyList = CSWData.AssociatedPolicies.Split(';');

            IWebElement test = NYLDSelenium.GetWE("//*[@class='alert alert-info mb-2 p-2 fs-mask']");
            string Ownername = NYLDSelenium.GetAttribute("Owner Name", test);
            Ownername = Ownername.Split('\r')[1];
            Ownername = Ownername.Split('\n')[1];


            //verify owner name              
            NYLDSelenium.VerifyText("Owner Name", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], Ownername);

            //Verify Additional Contracts header and sub header
            NYLDSelenium.VerifyText("Additional contracts header", "Select additional contracts", NYLDSelenium.GetAttribute("Additional Contracts Header", SelectAddlContractsHeader));
            //NYLDSelenium.VerifyText("Additional contracts Sub header", "To apply this address change to additional contracts, please select from the list below.", NYLDSelenium.GetAttribute("Addntl Contracts Sub header", SelectAddContractsSubHeader));

            //Compare the count
            if ((policyRow.Count()) != (associatedPolicyList.Count()))
                NYLDSelenium.ReportStepResult("VIPER policy count", "Policy count [" + policyRow.Count() + "] displayed in the UI does not match with the count of VIPER policies [" + associatedPolicyList.Count() + "] in system", "FAIL", "Yes", "no");

            IWebElement primaryPolicySelection = driver.FindElement(By.XPath("//*[@id='Policies_0__Selected']"));

            //Checks if the primary policy check box is selected
            if (primaryPolicySelection.Selected)
                NYLDSelenium.ReportStepResult("First Contract displayed", "First Contract displayed in Policy selection table is already selected", "PASS", "Yes", "No");
            else
                NYLDSelenium.ReportStepResult("First Contract displayed", "First Contract displayed in Policy selection table is not selected", "FAIL", "Yes", "No");


            //Verify if expected policy number (from database) is displayed in the UI
            for (int j = 0; j <= (associatedPolicyList.Count() - 1); j++)//**starts from zero
            {
                string expectedPolicyNumber = associatedPolicyList[j];

                //Loop through all the policies in the UI
                for (int i = 0; i <= (policyRow.Count() - 1); i++)
                {
                    string actualPlanName = driver.FindElement(By.XPath("//*[@id='Policies_" + i + "__PlanName']")).GetAttribute("value");
                    string actualPolicyNumber = driver.FindElement(By.XPath("//*[@id='Policies_" + i + "__PolicyNumber']")).GetAttribute("value");

                    //Verify if expected policy number from database is displayed
                    if (expectedPolicyNumber == actualPolicyNumber)
                    {
                        //Add Step to verify Phone Number
                        break;
                    }
                    else
                    {
                        //If expected policy number is not found, report failure
                        if (i == (policyRow.Count() - 1))
                            NYLDSelenium.ReportStepResult("Verify if " + expectedPolicyNumber + " is displayed in additional contracts page", expectedPolicyNumber + " is not displayed", "FAIL", "no", "no");
                    }
                }
            }

            //Verify if actual policy number from UI exists in database --------NEEDS MORE WORK
            for (int i = 0; i <= (policyRow.Count() - 1); i++)
            {
                string actualPlanName = driver.FindElement(By.XPath("//*[@id='Policies_" + i + "__PlanName']")).GetAttribute("value");
                string actualPolicyNumber = driver.FindElement(By.XPath("//*[@id='Policies_" + i + "__PolicyNumber']")).GetAttribute("value");

                for (int j = 0; j <= (associatedPolicyList.Count() - 1); j++)//**starts from zero
                {
                    string expectedPolicyNumber = associatedPolicyList[j];

                    //Verify if actual policy number exists in the database
                    if (actualPolicyNumber == expectedPolicyNumber)
                    {
                        break;
                    }
                    else
                    {
                        //If expected policy number is not found, report failure
                        if (j == (associatedPolicyList.Count() - 1))
                            NYLDSelenium.ReportStepResult("Verify if " + actualPolicyNumber + " displayed in Select Additional Contracts page is a VIPER Policy", actualPolicyNumber + " is not a VIPER Policy", "FAIL", "no", "no");
                    }
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: UpdateSelectAddlContracts                                                                   ///////////
        ////// Description:  Select policies displayed in the selct additional contracts page                    ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateSelectAddlContracts(string args)
        {
            string[] getOption = args.Split(',');
            CSWData.AssociatedPolicies = "";

            IList<IWebElement> policyRow = driver.FindElements(By.XPath("//*[contains(@id,'_PlanName')]"));
            NYLDSelenium.AddHeader("Additional Contracts page verification", "SubHeader");
            //Select the contracts(Make a note of contracts selected)
            int j = 0;
            bool numofPolicy;
            if (getOption[1].Trim() != "All")
            {
                numofPolicy = int.TryParse(getOption[1].Trim(), out j);

                if (!(numofPolicy))
                    NYLDSelenium.ReportStepResult("Date Sheet update: Number of Contracts to be selected", "Data sheet needs to be updated with proper integer value as the second argument", "FAIL", "no", "Yes");
                else if (j > (policyRow.Count()))
                    NYLDSelenium.ReportStepResult("Date Sheet update: Number of Contracts to be selected", "Specified number of contracts [" + j + "] to be selected in Data sheet is more than the actual number of contracts displayed [" + policyRow.Count() + "]", "FAIL", "no", "Yes");
                else
                {
                    for (int i = 1; i <= j; i++)
                    {
                        //Get the check box web element to be selected and the policy number which is selected
                        string actualPlanName = driver.FindElement(By.XPath("//*[@id='Policies_" + (i - 1) + "__PlanName']")).GetAttribute("value");
                        string actualPolicyNumber = driver.FindElement(By.XPath("//*[@id='Policies_" + (i - 1) + "__PolicyNumber']")).GetAttribute("value");
                        IWebElement policyCheckBox = driver.FindElement(By.XPath("//*[@id='Policies_" + (i - 1) + "__Selected']"));
                        IWebElement policyCheckText = driver.FindElement(By.XPath("//*[@id='select-policies-form']/div[2]/div[" + i + "]/div[1]/div/label"));

                        //select the check box
                        if (i > 1)
                            NYLDSelenium.Click(actualPlanName + " - " + actualPolicyNumber, policyCheckText);//**Click to be used insted of selct check box                         

                        if (CSWData.AssociatedPolicies == "")
                        {
                            CSWData.AssociatedPolicies = actualPolicyNumber;
                        }
                        else
                        {
                            CSWData.AssociatedPolicies = CSWData.AssociatedPolicies + ";" + actualPolicyNumber;
                        }

                    }

                }

            }
            else
            {
                //select All policy check box
                numofPolicy = true;
                NYLDSelenium.Click("Select All Contracts Box", SelectAllContractsText); //------Currently Clicking the text instead of checkbox

                CSWData.AssociatedPolicies = CSWData.VIPERPolicies;
            }

            //Click on Save button
            NYLDSelenium.Click("Policy Select Save", PolicySelectSave);
            NYLDSelenium.AddHeader("Additional Contracts page verification Success", "Success");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyGriefContactInfoPage                                                                  ///////////
        ////// Description:  Verify grief message displayed in contact information screen                        ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyGriefContactInfoPage()
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            TestData testData = new TestData();
            NYLDSelenium.AddHeader("Verify Grief Message for contact information", "Success");

            //verify contact info page
            NYLDSelenium.PageLoad("Contact Information", ContactInfoPageTitle);

            //verify Owner name is displayed
            NYLDSelenium.ElemExist("Contract Owner", ContractOwner, false, "no", "no", "yes");

            //verify owner secion
            DB.QueryPolicyDetails();
            string Ownersection = NYLDSelenium.GetAttribute("Contract Owner", ContractOwner);
            string[] Ownersplit = Ownersection.Split(':');
            string Ownername = Ownersplit[1].Trim();

            //Verify owner name
            NYLDSelenium.VerifyText("Contract Owner Name", "Contract Owner" + " " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], Ownername);

            //verify address header
            NYLDSelenium.ElemExist("Address Header", AddressHeader, false, "no", "no", "yes");

            //Verify Address
            NYLDSelenium.VerifyText("Address Line 1", data[KeyRepository.AddressLine1], NYLDSelenium.GetAttribute("Address Line 1", AddressLine1, "value"));
            NYLDSelenium.VerifyText("Address Line 2", data[KeyRepository.AddressLine2], NYLDSelenium.GetAttribute("Address Line 2", AddressLine2, "value"));
            NYLDSelenium.VerifyText("City", data[KeyRepository.City], NYLDSelenium.GetAttribute("City", City, "value"));
            NYLDSelenium.VerifySelectedItem("Country", Country, testData.GetMappedValue("Country", data[KeyRepository.Country]), "bytext");

            if (data[KeyRepository.Country] == "US")
            {
                NYLDSelenium.VerifySelectedItem("State", State, testData.GetMappedValue("State", data[KeyRepository.State]), "bytext");
                NYLDSelenium.VerifyText("Zip", data[KeyRepository.Zip], NYLDSelenium.GetAttribute("Zip", Zip, "value"));
            }
            else if (data[KeyRepository.Country] == "CA")
            {
                NYLDSelenium.VerifySelectedItem("Province", Province, testData.GetMappedValue("Province", data[KeyRepository.State]), "bytext");
                NYLDSelenium.VerifyText("Postal Code", data[KeyRepository.Zip], NYLDSelenium.GetAttribute("PostalCode", PostalCode, "value"));
            }
            else
            {
                NYLDSelenium.ElemNotExist("State", State, false, "no", "no", "yes");
                NYLDSelenium.ElemNotExist("Zip", Zip, false, "no", "no", "yes");
                NYLDSelenium.ElemNotExist("Province", Province, false, "no", "no", "yes");
                NYLDSelenium.ElemNotExist("Postal Code", PostalCode, false, "no", "no", "yes");
            }

            //verify submit button is not available
            NYLDSelenium.ElemNotExist("Save Address", SaveAddress, false, "no", "no", "yes");

            //verify phone section header
            NYLDSelenium.ElemExist("Phone Number Header", PhoneHeader, false, "no", "no", "yes");

            //verify Phone number
            string phone = NYLDSelenium.GetAttribute("Phone Number", PhoneNumber, "value").Replace("-", "");
            NYLDSelenium.VerifyText("Phone Number", data[KeyRepository.Phone], phone);

            //verify submit button is not available
            NYLDSelenium.ElemNotExist("Save Phone", SavePhone, false, "no", "no", "yes");
            NYLDSelenium.AddHeader("Contact info page grief message verification done", "Success");
        }

        public void VerifyGriefSelectAddlContracts(string args)
        {
            NYLDSelenium.ElemExist("Error Message displayed for Snowbird Contract", ErrorMessage);

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyThankYou                                                                              ///////////
        ////// Description:  Verify thank you page details displayed for contact information                     ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyThankYou(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            MIDatabase midb = new MIDatabase(data);

            string[] getOption = args.Split(',');
            string[] updatedData = { };
            //string[] contNumbers;
            EmailVerification OE = new EmailVerification(driver, data);

            NYLDSelenium.AddHeader("Verify Thank You page for update", "Success");

            //Verify if Thank You Page is loaded
            NYLDSelenium.PageLoad("Thank You", ThankYouPage);

            //Verify Header
            //NYLDSelenium.VerifyText("Thank You", "Thank You", NYLDSelenium.GetAttribute("Thank you header", ThankYouHeader));

            //Verify Thank You message
            NYLDSelenium.VerifyText("Thank You message", "You have successfully updated your contact information.", NYLDSelenium.GetAttribute("Thank You message", ThankYouMessage));

            updatedData = data[KeyRepository.TempValue].Split(':');
            string[] ContractsList = CSWData.AssociatedPolicies.Split(';');

            //verify Details updated for every contract number
            for (int i = 0; i <= (ContractsList.Count() - 1); i++)
            {
                string address;
                string city;
                string country;
                string stateandzip;
                string actualAddress;
                string policyNumber = ContractsList[i].Split(' ').Last();
                data[KeyRepository.PolicyNumber] = policyNumber;
                DB.QueryPolicyDetails();
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "############################ Select "+i+" Contract #############################"+ "</h3>", "<h3 style=\"color:Blue\">" + "###############################" + "</h3>", "INFO", "no");
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify updated owner information for policy number: " + policyNumber + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                if (getOption[0].Trim() != "Phone")
                {
                    //Expected Address
                    string expectedAddress = updatedData[2] + ", " + updatedData[3];

                    //Country name
                    country = data[KeyRepository.Country];

                    //Number of Address lines 
                    if (data[KeyRepository.AddressLine2] == "")
                        address = data[KeyRepository.AddressLine1];
                    else
                        address = data[KeyRepository.AddressLine1].Trim() + " " + data[KeyRepository.AddressLine2].Trim();

                    //City
                    city = data[KeyRepository.City];

                    //Zip code
                    if ((country == "US" || country == "CN"))
                        stateandzip = data[KeyRepository.State] + " " + data[KeyRepository.Zip];
                    else
                        stateandzip = "";

                    //Full Actual Address
                    if (stateandzip != "")
                        actualAddress = address + " " + data[KeyRepository.City] + ", " + stateandzip + ", " + country;
                    else
                        actualAddress = address + " " + data[KeyRepository.City] + ", " + country;

                    //Verify owner name
                    NYLDSelenium.VerifyText("Confirm Owner Name", updatedData[0], data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName]);

                    //Verify owmer address
                    NYLDSelenium.VerifyText("Confirm Owner Address", expectedAddress, actualAddress);

                    //Query LSP Notes
                    DB.QueryLSPNotes("ContactInfo-UpdateAddress");

                    //Verify Activity Table
                    midb.VerifyActivityTable("Update Address");

                    NYLDSelenium.AddHeader("Update Owner information process successful", "Success");

                }
                //verify Updated values of Phone Number
                else
                {
                    //verify owner name
                    NYLDSelenium.VerifyText("Confirm Owner Name", updatedData[0].Trim(), data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName]);

                    //verify Phone number
                    NYLDSelenium.VerifyText("Confirm Phone Number", updatedData[1], data[KeyRepository.Phone]);

                    //Query LSP Notes
                    DB.QueryLSPNotes("ContactInfo-UpdatePhone");

                    //Verify Activity Table
                    midb.VerifyActivityTable("Update Phone");
                    NYLDSelenium.AddHeader("Update Owner information process successful", "Success");
                    
                }
            }

            //If the Survey window pops up
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 30, false);
            Thread.Sleep(1000);

            //temp fix need to handle in Framework
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(BackButton));
            //Click on Back
            NYLDSelenium.Click("Back Button", BackButton, true);

            //Verify Contact Information page load
            NYLDSelenium.PageLoad("Contact Information", ContactInfoPageTitle);

            //Verify Email
            if (getOption[0].Trim() == "Phone")
                OE.VerifyEmailInbox("Contact Information Update Phone Confirmation");
            else
                OE.VerifyEmailInbox("Contact Information Update Address Confirmation");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: ClearValueforPhone                                                                          ///////////
        ////// Description:  Clear phone field value while field validation                                      ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public string ClearValueforPhone()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            string xpath = "//*[@id='editPhoneForm']/p[1]/input[contains(@id, 'PhoneNumber')]";
            IWebElement element = driver.FindElement(By.XPath("//*[@id='editPhoneForm']/p[1]/input[contains(@id, 'PhoneNumber')]"));
            IWebElement element1 = driver.FindElement(By.XPath("//*[@id='editAddressForm']/input[contains(@id, 'PhoneNumber')]"));
            js.ExecuteScript("arguments[0].setAttribute('value', '')", element);
            js.ExecuteScript("arguments[0].setAttribute('value', '')", element1);

            return xpath;
        }       

        public void BtnClick(string display, IWebElement elemetdata, string element, Dictionary<string, string> data)
        {
            try
            {
                // NYLDSelenium.ScrollToView(elemetdata, true);
                NYLDSelenium.Click(display, elemetdata, true);
            }
            catch
            {
                try
                {
                    driver.FindElement(By.XPath(element)).Click();
                }
                catch
                {
                    CommonFunctions cf = new CommonFunctions(data);
                    cf.MovetoElement(element, driver);
                }
            }
        }

        public void VerifyIdentity(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your identity" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Confirm Your Account Heading
            NYLDSelenium.PageLoad("OTP Confirmation", IdentityPageHeading);
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            NYLDSelenium.VerifyText("Identity verification content : ", CF.FormatString(testData.GetContent("IdentityMsg").ToString().Trim()), CF.FormatString(NYLDSelenium.GetAttribute("Identity verification content: ", IdentitySubTitleTxt)), "always", "always");
            NYLDSelenium.VerifyText("your identity resend code content", "This code expires in 15 minutes. If you do not receive the code, you can request a new code.".Trim(), NYLDSelenium.GetAttribute("your identity resend code content ", resendOtpTxt, "text").Trim());
            //Verify One Time Fields
            NYLDSelenium.ElemExist("OTP", Otp);

            NYLDSelenium.SendKeys("OTP", Otp, "999999");
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Entered Pin Code" + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "Pass");

            //Click Continue
            NYLDSelenium.Click("Continue", ContinueBtn);
        }

        public void VerifyMobileUpdateThankYou(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Thank You page for update mobile number" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify if Thank You Page is loaded
            NYLDSelenium.PageLoad("Thank You", ThankYouPage);

            //Verify Thank You message
            NYLDSelenium.VerifyText("Thank You message", "You have successfully updated your mobile.", NYLDSelenium.GetAttribute("Thank You message", ThankYouMessage));
        }

        public void VerifyMobileForProtectProfile(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify profile mobile number on update your mobile phone section" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            //Contact info update profile mobile phone section 
            NYLDSelenium.ElemNotExist("Update your mobile Phone", MobileUpdateSubHeading, false, "no", "yes", "yes");
            if(args == "NoMobile")
                NYLDSelenium.VerifyText("Phone Number", "No mobile phone added", NYLDSelenium.GetAttribute("Phone Number", CurrentMobileNumber), "always", "always");
            else
                NYLDSelenium.VerifyText("Mobile Phone was added to your profile : ", Regex.Replace(data[KeyRepository.ProfilePhone], @"[^0-9]", ""), NYLDSelenium.GetAttribute("Phone Number", CurrentMobileNumber), "always", "always");

            if (args == "UpdateSame")
            {
                NYLDSelenium.Clear("Clear mobile Number", MobileNumber);
                NYLDSelenium.Clear("Clear confirm mobile Number", MobileNumber);

                MobileNumber.SendKeys(NYLDSelenium.GetAttribute("Phone Number", CurrentMobileNumber).ToString());                
                ConfirmMobileNumber.SendKeys(NYLDSelenium.GetAttribute("Phone Number", CurrentMobileNumber).ToString());
                NYLDSelenium.Click("Mobile Number Update submit", Savemobile);
            }

        }
    }
}