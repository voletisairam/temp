﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using CSW.Common.DataBase;
using System.Threading;
using System.Text.RegularExpressions;
using CSW.PageObjects.Login;
using CSW.Common.Email;
using CSW.Common.Excel;
using OpenQA.Selenium.Support.UI;
using CSW.Drivers;
using SeleniumExtras.WaitHelpers;

namespace CSW.PageObjects.Profile
{
    class AccountInformationPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public AccountInformationPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////
        /////////    Account Information Page Section    /////////
        //////////////////////////////////////////////////////////

        //Contract Owner
        [FindsBy(How = How.XPath, Using = "//p[contains(text(),'Contract owner: ')]")]
        public IWebElement ContractOwner { get; set; }

        //Account Information
        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Account information')]")]
        public IWebElement AccountInfoPageTitle { get; set; }
        
        //Back to Dashboard link
        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Back to dashboard')]")]
        public IWebElement BackToDashboard { get; set; } //Currently does not work on UI

        /////////////////////////////////////////////////
        /////////    Update Username Section    /////////
        /////////////////////////////////////////////////

        //Update your username header
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Update your username')]")]
        public IWebElement UpdateUsernameHeader { get; set; }

        //Username header
        [FindsBy(How = How.XPath, Using = "//form[@id='change-username-form']//div[1]//div[1]//label[1]")]
        public IWebElement UsernameHeader { get; set; }

        //Current Username
        [FindsBy(How = How.XPath, Using = "//*[@id='change-username-form']/div[1]/div/strong")]
        public IWebElement CurrentUsername { get; set; }

        //New Username Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblUsername']")]
        public IWebElement NewUsernameHeader { get; set; }

        //New Username
        [FindsBy(How = How.XPath, Using = "//*[@id='txtUsername']")]
        public IWebElement NewUsername { get; set; }

        //New Username Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtUsername-error']")]
        public IWebElement NewUsernamePopUp { get; set; }

        //Username already taken Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='change-username-form']/div[2]/div/span")]
        public IWebElement UsernameExistsPopUp { get; set; }

        //Save updated Username 
        [FindsBy(How = How.XPath, Using = "//*[@id='change-username-form']/div[3]/div/div/button")]
        public IWebElement SaveUsername { get; set; }

        //////////////////////////////////////////////
        /////////    Update Email Section    /////////
        //////////////////////////////////////////////

        //Update Email Header
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Update your email address')]")]
        public IWebElement UpdateEmailHeader { get; set; }

        //Current Email Header
        [FindsBy(How = How.XPath, Using = "//*[@id='change-email-form']/div[1]/div/label")]
        public IWebElement CurrentEmailHeader { get; set; }

        //Current Email
        [FindsBy(How = How.XPath, Using = "//*[@id='change-email-form']/div[1]/div/strong")]
        public IWebElement CurrentEmail { get; set; }

        //New Email Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblEmail']")]
        public IWebElement NewEmailHeader { get; set; }       

        //New Email
        [FindsBy(How = How.XPath, Using = "//*[@id='txtEmail']")]
        public IWebElement NewEmail { get; set; }

        //New Email Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtEmail-error']")]
        public IWebElement NewEmailPopUp { get; set; } 
        
        //New Email Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='change-email-form']/div[2]/div[1]/span")]
        public IWebElement EmailExistsPopUp { get; set; }        

        //Confirm Email Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblConfirmEmail']")]
        public IWebElement ConfirmEmailHeader { get; set; }

        //Confirm Email
        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmEmail']")]
        public IWebElement ConfirmEmail { get; set; }

        //Confirm Email Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='txtConfirmEmail-error']")]
        public IWebElement ConfirmEmailPopUp { get; set; }

        //Save Email Button
        [FindsBy(How = How.XPath, Using = "//*[@id='change-email-form']/div[3]/div/div/button")]
        public IWebElement SaveEmail { get; set; }

        /////////////////////////////////////////////////
        /////////    Update Password Section    /////////
        /////////////////////////////////////////////////
        
        //Update Password Header
        [FindsBy(How = How.XPath, Using = "//h1[contains(text(),'Update your password')]")]
        public IWebElement UpdatePasswordHeader { get; set; }

        //Current Password Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblCurrentPassword']")]
        public IWebElement CurrentPasswordHeader { get; set; }

        //Current Password
        [FindsBy(How = How.XPath, Using = "//*[@id='CurrentPassword']")]
        public IWebElement CurrentPassword { get; set; }

        //Current Password Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='CurrentPassword-error']")]
        public IWebElement CurrentPasswordPopUp { get; set; }

        //Show Current Password 
        [FindsBy(How = How.XPath, Using = "//input[@id='CurrentPassword']/following-sibling::div/button[text()='Show']")]
        public IWebElement ShowCurrentPassword { get; set; }
        
        //Show Current Password  for Motest
        [FindsBy(How = How.XPath, Using = "//input[@id='CurrentPassword']/following-sibling::div/button[text()='Show']")]
        public IWebElement ShowCurrentPasswordMotest { get; set; }

        //New Password Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblPassword']")]
        public IWebElement NewPasswordHeader { get; set; }

        //New Password
        [FindsBy(How = How.XPath, Using = "//*[@id='Password']")]
        public IWebElement NewPassword { get; set; }

        //New Password Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='Password-error']")]
        public IWebElement NewPasswordPopUp { get; set; }
        
        //Show New Password
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']/following-sibling::div/button[text()='Show']")]
        public IWebElement ShowNewPassword { get; set; }

        //Confirm Password Header
        [FindsBy(How = How.XPath, Using = "//*[@id='lblConfirmPassword']")]
        public IWebElement ConfirmPasswordHeader { get; set; }

        //Confirm Password
        [FindsBy(How = How.XPath, Using = "//*[@id='ConfirmPassword']")]
        public IWebElement ConfirmPassword { get; set; }

        //Confirm Password Pop up
        [FindsBy(How = How.XPath, Using = "//*[@id='ConfirmPassword-error']")]
        public IWebElement ConfirmPasswordPopUp { get; set; }

        //Show Confirm Password
        [FindsBy(How = How.XPath, Using = "//input[@id='ConfirmPassword']/following-sibling::div/button[text()='Show']")]
        public IWebElement ShowConfirmPassword { get; set; }

        //Save Password Button
        [FindsBy(How = How.XPath, Using = "//*[@id='change-password-form']/div[3]/div/div/button")]
        public IWebElement SavePassword { get; set; }

       
        //New Email Pop up
        [FindsBy(How = How.XPath, Using = " //*[@id='change-password-form']/div[2]/div[1]/span")]
        public IWebElement PasswordExistsPopUp { get; set; }

        ////////////////////////////////////////////////
        /////////    Thank You Page Section    /////////
        ////////////////////////////////////////////////

        //Thank you Page
        [FindsBy(How = How.XPath, Using = "//*[@class='bg-white p-3 p-md-5 shadow']")]
        public IWebElement ThankYouPage { get; set; }

        //Policy select Thank You header
        //[FindsBy(How = How.XPath, Using = "")]
        //public IWebElement ThankYouHeader { get; set; }

        //Policy select Thank You Message
        [FindsBy(How = How.XPath, Using = "//*[@class='text-dk-palm']")]
        public IWebElement ThankYouMessage { get; set; }

        //Return to home page
        [FindsBy(How = How.XPath, Using = "//button[contains(text(),'Back')]")]
        public IWebElement BackButton { get; set; }        

        ///Survey Popup
        string StartSurvey = "//button[contains(text(),'Start Survey')]";
        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: LoginDetailsFormVal                                                                        ////////////
        ////// Description: Get field validation message for the Login details page                             ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //public void LoginDetailsFormVal(string fldName, out IWebElement fieldName, out IWebElement fieldPopUp, out string blankmsg, out string message, out int maxlength, out string data, out bool list, out bool submit, out bool phone)
        //{
        //    list = false;
        //    submit = false;
        //    phone = false;

        //    switch (fldName.Trim())
        //    {
        //        case "UserName":
        //            fieldName = NewUsername;
        //            fieldPopUp = NewUsernamePopUp;
        //            blankmsg = "Please enter your username.";
        //            message = "Username must be at least 5 characters and can include a combination of letters, numbers and symbols.";
        //            maxlength = 50;
        //            data = ";SPC|BLNK|test!|test#|$test|%test|te^st|t&est|ttsst*|t(est|test)|t+est|tes<t|tes>tt|t?estt|test";
        //            submit = true;
        //            break;

        //        case "Email":
        //            fieldName = NewEmail;
        //            fieldPopUp = NewEmailPopUp;
        //            blankmsg = "Must enter an email address.";
        //            message = "Email must be a correct email format.";
        //            maxlength = 50;
        //            data = ";SPC|BLNK|test.com|test@|test@.1|tes!t@t.com|tes#t@t.com|tes$t@t.com|tes%t@t.com|tes^t@t.com|tes&t@t.com|tes*t@t.com|tes+t@t.com|tes<t@t.com|tes>t@t.com|tes?t@t.com|tes/t@t.com";
        //            submit = true;
        //            break;


        //        case "Password":
        //            fieldName = NewPassword;
        //            fieldPopUp = NewPasswordPopUp;
        //            blankmsg = "Please enter your password.";
        //            message = "Passwords must contain:\r\n● 1 lowercase letter\r\n● 1 uppercase letter\r\n● 1 number\r\n● 1 special character(!@#$%^&*).\r\n● At least 8 characters";
        //            maxlength = 20;
        //            data = ";BLNK|test!1234|test#1234|$test1234|%test1234|te^st1234|12t&est34|ttsst*1234|1234t(est|1234test)|12t34+est|te1234s<t|te1234s>tt|t?1234estt|t/112233tesstt|12345678|abcdefgh";
        //            submit = true;
        //            break;

        //        default:
        //            fieldName = NewUsername;
        //            fieldPopUp = NewUsernamePopUp;
        //            blankmsg = "Please enter a phone number";
        //            message = "This number is not in the correct format.";
        //            maxlength = 12;
        //            data = ";BLNK|1234";
        //            phone = true;
        //            break;
        //    }
        //}

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyLoginDetailsFields                                                                   ////////////
        ////// Description: Verify login details page fields                                                    ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        //public void VerifyLoginDetailsFields(string args)
        //{
        //    //Contact Information page field validation
        //    CommonFunctions cf = new CommonFunctions();
        //    ChangePayor CP = new ChangePayor(driver);

        //    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify login details page field validation " + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

        //    LoginDetailsFormVal(args.Trim(), out IWebElement fieldName, out IWebElement fieldPopUp, out string blankmsg, out string message, out int maxlength, out string data, out bool list, out bool submit, out bool phone);

        //    switch (args.Trim())
        //    {
        //        case "UserName":
        //            cf.Verifyfields(args.Trim(), fieldName, fieldPopUp, SaveUsername, blankmsg, message, maxlength, data, list, submit);
        //            string Username = "t_test-@t.12" + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
        //            CSWData.eventTriggertime = DateTime.Now;
        //            NYLDSelenium.Clear("UserName", fieldName);
        //            NYLDSelenium.SendKeys("Enter Username", fieldName, Username);
        //            CSWData.userName = Username;
        //            NYLDSelenium.Click("Submit New user name ", SaveUsername);
        //            CP.WaitForUpdate(CP.Updateinprogress);
        //            CSWData.tempval = "username";
        //            break;

        //        case "Password":
        //            cf.Verifyfields(args.Trim(), fieldName, fieldPopUp, SavePassword, blankmsg, message, maxlength, data, list, submit);
        //            CSWData.eventTriggertime = DateTime.Now;
        //            fieldName.SendKeys(Keys.Tab);
        //            NYLDSelenium.SendKeys("Enter Current password", CurrentPassword, CSWData.password);
        //            NYLDSelenium.Clear("Password", fieldName);
        //            NYLDSelenium.SendKeys("Enter New password", fieldName, "A1b2c3d4*");
        //            NYLDSelenium.SendKeys("Enter confirm password", ConfirmPassword, "A1b2c3d4*");
        //            CSWData.password = "A1b2c3d4*";
        //            NYLDSelenium.Click("Submit Password ", SavePassword);
        //            CP.WaitForUpdate(CP.Updateinprogress);
        //            CSWData.tempval = "password";
        //            break;

        //        case "Email":
        //            cf.Verifyfields(args.Trim(), fieldName, fieldPopUp, SaveEmail, blankmsg, message, maxlength, data, list, submit);
        //            string EmailID = "test_auto-" + DateTime.Now.Second.ToString() + "1@testemail.com";
        //            CSWData.eventTriggertime = DateTime.Now;
        //            NYLDSelenium.Clear("Email", fieldName);
        //            NYLDSelenium.SendKeys("Enter New Email", fieldName, EmailID);
        //            NYLDSelenium.SendKeys("Enter confirm Email", ConfirmEmail, EmailID);
        //            CSWData.eMailID = EmailID;
        //            NYLDSelenium.Click("Submit Email ", SaveEmail);
        //            CP.WaitForUpdate(CP.Updateinprogress);
        //            CSWData.tempval = "email";
        //            break;

        //        default:
        //            break;
        //    }
        //}

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyLoginDetailsPage                                                                     ////////////
        ////// Description: Verify login details page fields availability and options                           ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void VerifyAccountInformation()
        {

            NYLDSelenium.AddHeader("Verify Account Information page", "SubHeader");
            NYLDSelenium.PageLoad("Account Information", AccountInfoPageTitle);

            string Ownersection = NYLDSelenium.GetAttribute("Contract Owner", ContractOwner);
            string[] Ownersplit = Ownersection.Split(':');
            string Ownername = Ownersplit[1].Trim();

            //verify owner name
            NYLDSelenium.VerifyText("Owner Name", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName], Ownername);
            
            //verify header
            NYLDSelenium.VerifyText("Account Information page header", "Account information", NYLDSelenium.GetAttribute("Account Information header", AccountInfoPageTitle));

            //verify username section
            NYLDSelenium.VerifyText("Update Username header", "Update your username", NYLDSelenium.GetAttribute("Update Username header", UpdateUsernameHeader));
            NYLDSelenium.VerifyText("Username header", "Username", NYLDSelenium.GetAttribute("Username header", UsernameHeader));
            NYLDSelenium.VerifyText("Username", data[KeyRepository.UserName], NYLDSelenium.GetAttribute("Current Username", CurrentUsername),"always");
            NYLDSelenium.VerifyText("New Username header", "New username", NYLDSelenium.GetAttribute("New Username header", NewUsernameHeader));

            NYLDSelenium.ElemExist("Username input field", NewUsername, false, "no", "no");
            NYLDSelenium.ElemExist("Save Username Button", SaveUsername, false, "no", "no");

            //verify email section
            NYLDSelenium.VerifyText("Update Email header", "Update your email address", NYLDSelenium.GetAttribute("Update Email header", UpdateEmailHeader));
            NYLDSelenium.VerifyText("Current Email header", "Current email address", NYLDSelenium.GetAttribute("Current Email header", CurrentEmailHeader));
            NYLDSelenium.VerifyText("Current Email", data[KeyRepository.EmailId].ToLower(), NYLDSelenium.GetAttribute("Current Email", CurrentEmail).ToLower(), "always");
            NYLDSelenium.VerifyText("New Email header", "New email address", NYLDSelenium.GetAttribute("New Email header", NewEmailHeader));
            NYLDSelenium.VerifyText("Confirm Email header", "Confirm new email address", NYLDSelenium.GetAttribute("Confirm New Email header", ConfirmEmailHeader));

            NYLDSelenium.ElemExist("New Email input field", NewEmail,false, "no", "no" );
            NYLDSelenium.ElemExist("Confirm Email input field", ConfirmEmail,false, "no", "no" );
            NYLDSelenium.ElemExist("Save Email Button", SaveEmail,false, "no", "no" );

            //verify password section
            NYLDSelenium.VerifyText("Update Password header", "Update your password", NYLDSelenium.GetAttribute("Update password header", UpdatePasswordHeader));
            NYLDSelenium.VerifyText("Current Password header", "Enter your current password to make changes", NYLDSelenium.GetAttribute("Current Password header", CurrentPasswordHeader));
            NYLDSelenium.VerifyText("New Password header", "New password", NYLDSelenium.GetAttribute("New Password header", NewPasswordHeader));
            NYLDSelenium.VerifyText("Confirm New Password header", "Confirm new password", NYLDSelenium.GetAttribute("Confirm New Password header", ConfirmPasswordHeader));

            if (Environment.UserName.ToLower().Contains("motest"))
                ShowCurrentPassword = ShowCurrentPasswordMotest;

            NYLDSelenium.ElemExist("Current password input field", CurrentPassword,false, "no", "no" );
            NYLDSelenium.ElemExist("Show Current password button", ShowCurrentPassword,false, "no", "no" );
            NYLDSelenium.ElemExist("New password input field", NewPassword,false, "no", "no" );
            NYLDSelenium.ElemExist("Show New password button", ShowNewPassword,false, "no", "no" );
            NYLDSelenium.ElemExist("Confirm password input field", ConfirmPassword,false, "no", "no" );
            NYLDSelenium.ElemExist("Show Confirm password button", ShowConfirmPassword,false, "no", "no" );
            NYLDSelenium.ElemExist("Save Password button", SavePassword,false, "no", "no" );

            NYLDSelenium.AddHeader("Account information fields success", "SubHeader");
            }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: UpdateAccountInformation                                                                   ////////////
        ////// Description: Update login options for the user from login details page                           ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void UpdateAccountInformation(string args)
        {
            LSPDatabase LSP = new LSPDatabase(driver, data);
            NYLDSelenium.AddHeader("Update " + args + " field values in Account Information page", "SubHeader");
            NYLDSelenium.PageLoad("Account Information", AccountInfoPageTitle);

            //update user detail
            switch (args)
            {
                case "Username":
                    NYLDSelenium.Clear("Clear Username", NewUsername);
                    NYLDSelenium.SendKeys("New Uername",  NewUsername,data[KeyRepository.UserName]);
                    NYLDSelenium.Click("Save-Username", SaveUsername);
                    break;

                case "Email":
                    NYLDSelenium.Clear("Clear text in New Email field", NewEmail);
                    NYLDSelenium.Clear("Clear text in Confirm Email field", ConfirmEmail);
                    NYLDSelenium.SendKeys("New Email field", NewEmail, data[KeyRepository.EmailId].Replace("'",""));
                    NYLDSelenium.SendKeys("Confirm Email field", ConfirmEmail, data[KeyRepository.EmailId].Replace("'",""));
                    NYLDSelenium.Click("Save-Email", SaveEmail);

                    //To skip the OTP verification
                    if (!NYLDSelenium.ElemExist("Email Exist PopUp", EmailExistsPopUp, false, "no", "no", "no"))
                    {
                        string actualemail = data[KeyRepository.EmailId];
                        Thread.Sleep(30);
                        UserRegistrationDriver registration = new UserRegistrationDriver(driver, data);
                        registration.OneTimeVerificationPage(false);
                        Thread.Sleep(60000); // adding sleep to wait for email verification to recevie the valid OTP after a minute
                        LSP.VerifyPolicyDetails("Email");
                    }
                    break;

                case "Password":
                    //change case of new password as per the args
                    NYLDSelenium.Clear("Clearing Old password field", CurrentPassword);
                    NYLDSelenium.Clear("Clearing New password field", NewPassword);
                    NYLDSelenium.Clear("Clearing Confirm password field", ConfirmPassword);
                    NYLDSelenium.SendKeys("Enter Current password", CurrentPassword,data[KeyRepository.PrevPassword]);
                    NYLDSelenium.SendKeys("New password field", NewPassword, data[KeyRepository.Password]);
                    NYLDSelenium.SendKeys("Confirm password field", ConfirmPassword, data[KeyRepository.Password]);
                    NYLDSelenium.Click("Save-password", SavePassword);
                    break;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyThankYouPage                                                                         ////////////
        ////// Description: Verify thank you page displayed after the different log in details options update   ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
        public void VerifyThankYou(string option)
        {
            CSWData.TempVal = option;
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Thank you page for " + option.Trim() + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");


            //Verify if Thank You Page is loaded
            NYLDSelenium.PageLoad("Thank You", ThankYouPage);

            //If the Survey window pops up
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 30, false);

            string startpoint = "";
            //Verify Thank you message
            if (option.ToLower() == "email")
            {
                option = "email";
                startpoint = "Your";
            }
            else
            {
                option = "profile";
                startpoint = "You";
            }

            NYLDSelenium.VerifyText("Thank You message", startpoint+" have successfully updated your " + option.ToLower().Trim()+".", NYLDSelenium.GetAttribute("Thank You message", ThankYouMessage),"awlays","always");
            Thread.Sleep(1000);
            if (NYLDSelenium.ElemExist("Back button", BackButton, false, "no", "no"))
            {
                //temp fix need to handle in Framework
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementToBeClickable(BackButton));
                NYLDSelenium.Click("Back button", BackButton, true);
            }

            //Verify Contact Information page load
           NYLDSelenium.PageLoad("Account Information", AccountInfoPageTitle,"no", "no",false);
        }


        /// <summary>
        /// Method helps to verify Grif message based on arg type
        /// </summary>
        /// <param name="args"></param>
        public void VerifyAccountInformationErrorMessage(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify " + args + " Account Information Grif Message Popup" + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            switch (args)
            {
                case "Username":
                        NYLDSelenium.VerifyText("Verify Username validation message", "This username already exists.", NYLDSelenium.GetAttribute("Username validation message", UsernameExistsPopUp),"always","always");
                        NYLDSelenium.Clear("Clearing Username field", NewUsername);
                    break;

                case "Email":
                        NYLDSelenium.VerifyText("Verify email field validation message", "This email account already exists, please enter a different account.", NYLDSelenium.GetAttribute("Email field validation message", EmailExistsPopUp), "always", "always");
                        NYLDSelenium.Clear("Clearing New Email field", NewEmail);
                        NYLDSelenium.Clear("Clearing Confirm Email field", ConfirmEmail);
                    break;

                case "Password": 
                    NYLDSelenium.VerifyText("Verify Password field validation message", "The password entered does not meet our password rules. Please try with a different password.", NYLDSelenium.GetAttribute("Password field validation message", PasswordExistsPopUp), "always", "always");
                    NYLDSelenium.Clear("Clearing New Password field", NewPassword);
                    NYLDSelenium.Clear("Clearing Confirm password field", ConfirmPassword);
                    break;
            }
        }
    }
}
