﻿using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Coverage;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using PasswordEncryptDecrpt;
using SeleniumExtras.PageObjects;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Threading;

namespace CSW.PageObjects.Profile
{
    class PaperlessSettingsPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public PaperlessSettingsPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(),'Paperless settings')]")]
        public IWebElement PreferenceManagementPageTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Welcome to paperless!')]")]
        public IWebElement WelcometoPageTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'basic-content text-steel')]/p")]
        public IWebElement Paperlesstext { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='custom-control custom-switch paperless']")]
        public IWebElement PaperlessDocumentOptOut { get; set; }

        [FindsBy(How = How.XPath, Using = "(//input[@type='checkbox' and @checked='checked']")]
        public IWebElement PaperlessDocumentOptOutChecked { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[@class='custom-control custom-switch paperless']/input[1]")]
        public IWebElement PaperlessDocumentSet { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[ @class='text-box textarea pb-4 pre-scrollable']")]
        public IWebElement PaperlessInvoiceDocument { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/p[contains(text(),'Invoices')]")]
        public IWebElement InvoiceHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@data-sc-field-key='835DAE2A38764CB2A1167AF1300EE37E' and @style = 'display: block;']")]
        public IWebElement PaperlessSetON { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@data-sc-field-key='835DAE2A38764CB2A1167AF1300EE37E' and @style = 'display: none;']")]
        public IWebElement PaperlessSetOFF { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[@data-sc-field-name='ConsentCheckbox']")]
        public IWebElement PaperlessSettingsConfirmation { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='submit']")]
        public IWebElement SavePreference { get; set; }

        //UserName
        [FindsBy(How = How.Id, Using = "txtUsername")]
        public IWebElement UserName { get; set; }
        //Password
        [FindsBy(How = How.Id, Using = "Password")]
        public IWebElement Password { get; set; }
        //Confirm Password
        [FindsBy(How = How.Id, Using = "ConfirmPassword")]
        public IWebElement ConfirmPassword { get; set; }
        //Show Button
        [FindsBy(How = How.XPath, Using = "//button[text()='Log in']")]
        public IWebElement login { get; set; }


        /// <summary>
        ///New User Thankyou page
        /// </summary>
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Thanks for signing up to paperless!')]")]
        public IWebElement ThankyouPageheader { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='text-left text-steel text-sans-serif' or @class='text-left text-steel']/p[1]")]
        public IWebElement ActualThankyouPageContent1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='text-left text-steel text-sans-serif' or @class='text-left text-steel']/p[2]")]
        public IWebElement ActualThankyouPageContent2 { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        /// <summary>
        /// Update Thankyou page
        /// </summary>
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Your preferences have been updated')]")]
        public IWebElement PreferenceUpdateThankyouPageheader { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='text-left text-steel text-sans-serif'  or @class='text-left text-steel']/p[1]")]
        public IWebElement PreferenceUpdateThankyouPageContent { get; set; }

        public string Iwantto = "//*[@class='list-unstyled mb-4']/li/a";

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'No changes have been made')]")]
        public IWebElement PaperlessSettingsNoChange { get; set; }

        /// <summary>
        /// Method to Verify the PreferenceMangementPage Info
        /// this method is to Verify the elements / expected content / text are present in UI or not
        /// </summary>
        public void VerifyPaperlessSettingsInfo(string args)
        {
                CommonFunctions CF = new CommonFunctions(data);
                ManagePaymentsPage MP = new ManagePaymentsPage(driver, data);

                NYLDSelenium.AddHeader("Verify Paperless settings page", "SubHeader");
                //Verify the Preference Mangement page is loaded
                NYLDSelenium.PageLoad("Paperless settings", PreferenceManagementPageTitle, "always", "no");
                //Verify the Preference Mangement Welcome titile text is present in UI or not
                NYLDSelenium.VerifyText("Paperless settings Welcome Title", "Welcome to paperless!", NYLDSelenium.GetAttribute("Welcome Title", WelcometoPageTitle, "text"));

                //Get the Preference header context from Testdata sheet
                string expectedheadertext = new TestData().GetContent("PreferenceHeader");
                //Verify the Preference Mangement  header text
                NYLDSelenium.VerifyText("Paperless Header text", expectedheadertext, NYLDSelenium.GetAttribute("Paperless Header text", Paperlesstext, "text"));
                //Verify the Preference Mangement Go paperless for all document// types  element is avaible or not

                bool isreturn = NYLDSelenium.ElemExist("Go paperless for all document types available", PaperlessDocumentOptOut);
                Console.WriteLine("Go paperless for all document types available " + args, isreturn);

                //Verify the Invoices section is present or not
                NYLDSelenium.ElemExist("Invoices", InvoiceHeader, false, "no", "yes");

                #region  //Verify Contract Owner details &&  //Verify Insured details 

                //Verify Contract Owner details            

                CF.GetOwnerandInsuredDetails(MP.ContractOwner, MP.ContractInsured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName);

                //Verify Owner details 
                NYLDSelenium.VerifyText("Contract Owner", ExpOwnerNameandAddr.Trim(), ActualOwnerNameandAddr); //TODO: Why we commented these?

                //Verify Insured details
                NYLDSelenium.VerifyText("Insured Name", ExpectedInsuredName, ActualInsuredName);


                //Verify I Want to Links
                CF.ValidateIWantToLinks("PaperlessSettings Page", Iwantto);
            #endregion

            NYLDSelenium.AddHeader("Verify Paperless settings", "Success");
            }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SelectPreferenceOption                                                                 ///////////
        ////// Description:  method helps to set the paperless settings on / update the paperless settings  ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void PaperlessSettingsOption(string args)
        {
            NYLDSelenium.AddHeader("Choose Paperless settings for - " + args, "SubHeader");

            //User paperless document settings is set to OptIn /Optout
            string customswitch = "//*[@class='custom-control custom-switch paperless']/input[1]/following-sibling::label";
            CommonFunctions cf = new CommonFunctions(data);
            cf.MovetoElement(customswitch, driver);

            //Verify the Hidden invoices is present or not
            NYLDSelenium.ElemExist("Hidden Invoices Discloser Visibility", PaperlessSetON, false, "Yes", "yes");

            //User paperless document settings  set to OptIn /Optout confirmation 
            string ConsentCheckbox = "//*[@data-sc-field-name='ConsentCheckbox']";
            cf.MovetoElement(ConsentCheckbox, driver);
            //User paperless document settings  set to OptIn /Optout Save settings 
            NYLDSelenium.Click("'On' Confirm my settings", SavePreference);

            //Verify the paperless settings is set to be OptIn /Optout sucessfuly
            NYLDSelenium.AddHeader("Paperless Settings Option display and Configuration settings as expected", "SubHeader");
        }


            /// <summary>
            /// VerifyPaperlessStatus
            /// </summary>
            /// <param name="args"></param>
            public void VerifyPaperlessStatusInfo(string args)
        {
                LoginPage lp = new LoginPage(driver, data);
                HomePage home = new HomePage(driver, data);
                lp.Login();
                //naviage to the Preference Management Page 
                home.NavigateToPage(KeyRepository.PaperlessSettingsInfoPage);
                PaperlessSettingsOption(args); 
                Thread.Sleep(1000);
                home.NavigateToPage(KeyRepository.LogoutPage);
                System.IO.File.WriteAllText(Properties.Settings.Default.LogFile, string.Empty);
                NYLDSelenium.ReportStepResult("Launch " + data[KeyRepository.Browser]+ " browser", "Launch " + data[KeyRepository.Browser] + " browser", "PASS", "no", "no");
                NYLDSelenium.ReportStepResult("Navigate to " + data[KeyRepository.URL],"Navigate to " + data[KeyRepository.URL], "PASS", "always", "no");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaperlessSignUpThankYouPage                                                                 ///////////
        ////// Description:  SignUp the Paperless settings- Thank you page                                       ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyPaperlessSignUpThankYouPage()
        {
            NYLDSelenium.AddHeader("Verify Paperless settings OptIn Thankyou page", "SubHeader");
            //verify if Survey popup occurs to skip it
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            //Verify the Thankyou page loaded and verify the text
            IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-600);");
            Thread.Sleep(1000);
            NYLDSelenium.PageLoad("Paperless settings Thank you page", ThankyouPageheader);
            //Verify the Paperless settings Information at line 1
            NYLDSelenium.VerifyText("Paperless settings Information1", new TestData().GetContent("Thankyoupage1"), NYLDSelenium.GetAttribute("Paperless settings Info", ActualThankyouPageContent1, "text"), "yes");
            //Verify the Paperless settings Information at line 2
            NYLDSelenium.VerifyText("Paperless settings Information2", new TestData().GetContent("Thankyoupage"), NYLDSelenium.GetAttribute("Paperless settings Info", ActualThankyouPageContent2, "text"), "yes");

            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-90);

            //Verify the Papereless Settings Optin sucessfully or not
            NYLDSelenium.AddHeader("Verify Paperless settings OptIn Thankyou page", "Success");
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaperlessOptOutThankYouPage                                                                 ///////////
        ////// Description:  Update the Paperless settings- Thank you page                                       ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyPaperlessOptOutThankYouPage()
        {
            NYLDSelenium.AddHeader("Verify Paperless settings OptOut Thankyou page", "SubHeader");
            //to skip the survery popup occurs in middle of test execution
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            //Verify Preference Management Thankyou page is loaded
            NYLDSelenium.PageLoad("Paperless settings OptOut Thank you page", PreferenceUpdateThankyouPageheader);
            //Verify Preference Management Thankyou page confirmation message and verify text
            NYLDSelenium.VerifyText("Paperless settings OptOut welcome header", new TestData().GetContent("UpdateThankyoupage"), NYLDSelenium.GetAttribute("Welcome Thank you Page", PreferenceUpdateThankyouPageContent, "text"));

            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-90);
            NYLDSelenium.AddHeader("Verify Paperless settings OptOut Thankyou page", "Success");            
        }

        public void PaperlessSettingOptIn(string args= "OptIn")
        {
            try
            {
                HomePage home = new HomePage(driver, data);
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Choose Paperless settings for - " + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                //Enter User Name and Password  
                NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
                NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);

                //Click Submit Button
                NYLDSelenium.Click("login", login, true);

                //naviage to the Preference Management Page 
                home.NavigateToPage(KeyRepository.PaperlessSettingsInfoPage);

                if (NYLDSelenium.ElemExist("paperlessalreayon", PaperlessSetON, false, "no", "no", "no", 10))
                {
                    NYLDSelenium.Click("'On' for Go Paperless for all document type available toggle", PaperlessDocumentSet, true);
                    NYLDSelenium.Click("'On' for Go Paperless for all document type available toggle", PaperlessDocumentSet, true);
                }
                else
                NYLDSelenium.Click("'On' for Go Paperless for all document type available toggle", PaperlessDocumentSet, true);

                //User paperless document settings  set to OptIn /Optout confirmation 
                NYLDSelenium.Click("'On' Check box for Customer consent & disclore", PaperlessSettingsConfirmation, true);
                //User paperless document settings  set to OptIn /Optout Save settings 
                NYLDSelenium.Click("'On' Confirm my settings", SavePreference);

            }
            catch
            {

            }
        }

        public bool IsLinkWorking(string url, string text)
        {
            //RestServices webService = new RestServices(driver, data);
            //return webService.GetRequestAPI(url);

            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                       | SecurityProtocolType.Tls11
                       | SecurityProtocolType.Tls12
                       | SecurityProtocolType.Ssl3;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                // new HttpBasicAuthenticator(Properties.Settings.Default.MuleServiceUserName, PasswordDecrypter.Decrypt(Properties.Settings.Default.MuleServicePassword))
                //You can set some parameters in the "request" object...
                request.UseDefaultCredentials = true;
                request.PreAuthenticate = true;
                request.Credentials = new NetworkCredential(Properties.Settings.Default.MuleServiceUserName, PasswordDecrypter.Decrypt(Properties.Settings.Default.MuleServicePassword));
                request.AllowAutoRedirect = true;

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {

                    // Releases the resources of the response.
                    response.Close();
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                NYLDSelenium.ReportStepResult("Paperless Settings--Quick Link", "Paperless Settings--Quick Link :" + text + " is not working", "FAIL", "always");
                //TODO: Check for the right exception here
                return false;
            }
        }


    }
}
