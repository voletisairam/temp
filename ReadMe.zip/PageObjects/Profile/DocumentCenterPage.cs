﻿using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;


namespace CSW.PageObjects.Profile
{
    class DocumentCenterPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public DocumentCenterPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        // Contract Information
        [FindsBy(How = How.XPath, Using = "//h3[contains(text(),'Document Center')]")]
        public IWebElement DoumentCenterPageTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'View up to 1 year of available documents digitally.')]")]
        public IWebElement DocumentCenterPageSubtext { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Choose a contract number:')]")]
        public IWebElement ContractHeader { get; set; }

        //Choose a contract number dropdown 
        [FindsBy(How = How.XPath, Using = "//*[@id='policy-toggle']")]
        public IWebElement ContractNumberDropdown { get; set; }


        // Date table Header
        [FindsBy(How = How.XPath, Using = "//*[@id='docCenterTable']/thead/tr/th[1]")]
        public IWebElement ContractDateHeader { get; set; }

        // Document Name table Header
        [FindsBy(How = How.XPath, Using = "//*[@id='docCenterTable']/thead/tr/th[2]")]
        public IWebElement ContractDocumentNameHeader { get; set; }

        // Category table Header
        [FindsBy(How = How.XPath, Using = "//*[@id='docCenterTable']/thead/tr/th[3]")]
        public IWebElement ContractCategoryHeader { get; set; }

        // Download Premium Invoice
        [FindsBy(How = How.XPath, Using = "//*[@id='docCenterTable']/tbody/tr[1]/td[2]/a")]
        public IWebElement PremiumInvoiceDownload { get; set; }

        // No data in the table
        [FindsBy(How = How.XPath, Using = "//th[contains(text(),'Date')]")]
        public IWebElement NodataDocumentCenterTable { get; set; }

        // Contract Owner Information
        [FindsBy(How = How.XPath, Using = "//*[@id='docCenterTable']/tbody/tr/td")]
        public IWebElement OwnerFullName { get; set; }


        ///////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////   Methods   ///////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////


        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyDocument                                                                  /////////
        ////// Description: Verify documents presence and sortability of the table headers           //////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifyDocument()
        {
            //Verify Page load
            NYLDSelenium.PageLoad("Document Center", DoumentCenterPageTitle);

            // Verify essential page elements
            bool isTitleDisplayed = NYLDSelenium.VerifyText("Document Center Title", "Document Center", NYLDSelenium.GetAttribute("Document Center title verification", DoumentCenterPageTitle),"always");
            bool isSubtextDisplayed = NYLDSelenium.VerifyText("SubText verification", "View up to 1 year of available documents digitally.", NYLDSelenium.GetAttribute("SubText verification", DocumentCenterPageSubtext), "always");          
            if (!isTitleDisplayed || !isSubtextDisplayed)
            {
                NYLDSelenium.ReportStepResult("Essential Elements Verification", "Essential Document Center elements are not displayed as expected.", "Fail");
            }
            else
            {
                // Check for the "no documents" message
                bool noDocumentsDisplayed = NYLDSelenium.ElemExist("Date", NodataDocumentCenterTable);
                if (!noDocumentsDisplayed)
                {
                    NYLDSelenium.ReportStepResult("No Document Message Displayed", "No documents available message displayed successfully.", "Fail");
                }
                else
                {
                    // If documents are present, verify sortability of table headers
                    bool headersSortable = CheckIfElementIsSortable(ContractDateHeader) &&
                                           CheckIfElementIsSortable(ContractDocumentNameHeader) &&
                                           CheckIfElementIsSortable(ContractCategoryHeader);

                    if (headersSortable)
                    {
                        NYLDSelenium.ReportStepResult("Invoices Displayed", "Invoices displayed successfully.", "Pass");
                        NYLDSelenium.ReportStepResult("Headers Sortability Verification", "All specified headers are sortable.", "Pass");                     
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("Headers Sortability Verification", "One or more headers are not sortable as expected.", "Fail");
                    }
                }
            }
        }

        private bool CheckIfElementIsSortable(IWebElement element)
        {
            string classAttribute = element.GetAttribute("class");
            return classAttribute != null && classAttribute.Contains("sorting");
        }

    }
}