﻿using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.PageObjects.Coverage;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Threading;

namespace CSW.PageObjects.Profile
{
    class PreferenceManagementPage
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public  PreferenceManagementPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Paperless settings')]")]
        public IWebElement PreferenceManagementPageTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Welcome to paperless!')]")]
        public IWebElement WelcometoPageTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='basic-content text-steel']/p")]
        public IWebElement Paperlesstext { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[ @class='custom-control-label'])[1]")]
        public IWebElement PaperlessDocumentSet { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[ @class='text-box textarea pb-4 pre-scrollable'])")]
        public IWebElement PaperlessInvoiceDocument { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Invoices')]")]
        public IWebElement InvoiceHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id ='invoices' and @class='fal fa-lg fa-check-square']")]
        public IWebElement PaperlessSetON { get; set; }
        [FindsBy(How = How.XPath, Using = "//*[@id ='invoices' and @class='fal fa-lg fa-square']")]
        public IWebElement PaperlessSetOFF { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id ='invoices' and @class='fal fa-square fa-lg']")]
        public IWebElement PaperlessSetOFF2 { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[@class='custom-control-label'])[2]")]
        public IWebElement PaperlessSettingsConfirmation { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='submit']")]
        public IWebElement SavePreference { get; set; }


        /// <summary>
        ///New User Thankyou page
        /// </summary>
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Thanks for signing up to paperless!')]")]
        public IWebElement ThankyouPageheader { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='text-left text-steel text-sans-serif' or @class='text-left text-steel']/p[1]")]
        public IWebElement ActualThankyouPageContent1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='text-left text-steel text-sans-serif' or @class='text-left text-steel']/p[2]")]
        public IWebElement ActualThankyouPageContent2 { get; set; }

        /// <summary>
        /// Update Thankyou page
        /// </summary>
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Your preferences have been updated')]")]
        public IWebElement PreferenceUpdateThankyouPageheader { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='text-left text-steel text-sans-serif'  or @class='text-left text-steel']/p[1]")]
        public IWebElement PreferenceUpdateThankyouPageContent { get; set; }

        //Start Survey button
        private string StartSurvey = "//button[contains(text(),'Start Survey')]";

        /// <summary>
        /// Method to Verify the PreferenceMangementPage Info
        /// this method is to Verify the elements / expected content / text are present in UI or not
        /// </summary>
        public void VerifyPreferenceManagementInfo(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            ManagePaymentsPage MP = new ManagePaymentsPage(driver, data);

            NYLDSelenium.AddHeader("Verify Paperless settings page", "SubHeader");
            //Get the Preference header context from Testdata sheet
            string expectedheadertext = new TestData().GetContent("PreferenceHeader");

            //Verify the Preference Mangement page is loaded
            NYLDSelenium.PageLoad("Paperless settings", PreferenceManagementPageTitle);
            IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-600);");
            //Verify the Preference Mangement Welcome titile text is present in UI or not
            NYLDSelenium.VerifyText("Paperless settings Welcome Title", "Welcome to paperless!", NYLDSelenium.GetAttribute("Welcome Title", WelcometoPageTitle, "text"), "always");
            //Verify the Preference Mangement Go paperless for all document// types  element is avaible or not
            NYLDSelenium.ElemExist("Go paperless for all document types available", PaperlessDocumentSet,false,"no", "always");
            //Verify the Preference Mangement  header text
            NYLDSelenium.VerifyText("Paperless Header text", expectedheadertext, NYLDSelenium.GetAttribute("Paperless Header text", Paperlesstext, "text"), "always");
            //Verify the Invoices section is present or not
            NYLDSelenium.ElemExist("Invoices", InvoiceHeader, false, "no", "yes");
            //Verify the Invoice Paperless document 
            NYLDSelenium.ElemExist("Paperless Invoice Document", PaperlessInvoiceDocument, false, "no", "always");

            //Verify if New user is set to be OptIn ///Verify if exisitng user is already set to be update -OptOut
            if (args== "Opt-In")
            NYLDSelenium.ElemExist("Paperless Settings default set to off", PaperlessSetOFF2, false, "no", "always");
            else
             NYLDSelenium.ElemExist("Paperless Settings is already Opt", PaperlessSetON, false, "no", "always");

            //Verify the paperless settings confirmation element is present or not
            NYLDSelenium.ElemExist("Paperless settings confirmation", PaperlessSettingsConfirmation, false, "no", "always");
            //Verify the paperless settings is to be save
            NYLDSelenium.ElemExist("Save Paperless Settings", SavePreference, false, "no", "always");
            NYLDSelenium.AddHeader("Paperless settings page verification success", "Success");

            #region  //Verify Contract Owner details &&  //Verify Insured details 

            //Verify Contract Owner details         

            NYLDSelenium.AddHeader("\"Owner and Insured Name\"", "SubHeader");
            CF.GetOwnerandInsuredDetails(MP.ContractOwner, MP.ContractInsured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName);

            //Verify Owner details 
            NYLDSelenium.VerifyText("Contract Owner", ExpOwnerNameandAddr.Trim(), ActualOwnerNameandAddr,"yes"); //TODO: Why we commented these?

            //Verify Insured details
            NYLDSelenium.VerifyText("Insured Name", ExpectedInsuredName, ActualInsuredName,"yes");
            NYLDSelenium.AddHeader("Verify Owner and Insured name of contract - " + data[KeyRepository.PolicyNumber], "Success");
            
            #endregion
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SelectPreferenceOption                                                                 ///////////
        ////// Description:  method helps to set the paperless settings on / update the paperless settings  ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void PreferenceOption(string args)
        {
            NYLDSelenium.AddHeader("Welcome to Paperless settings", "SubHeader");
            //Verify the Prefrence Management Page Title is displayed
            //NYLDSelenium.PageLoad("Preference Management", PreferenceManagementPageTitle);
            //User paperless document settings is set to OptIn /Optout
            NYLDSelenium.Click("Paperless Document Configuration is Set for " + args, PaperlessDocumentSet,true);
            //User paperless document settings  set to OptIn /Optout confirmation 
            NYLDSelenium.Click("Paperless settings confirmation", PaperlessSettingsConfirmation,true);
            //User paperless document settings  set to OptIn /Optout Save settings 
            NYLDSelenium.Click("Save Paperless Settings", SavePreference);

            //Verify the paperless settings is set to be OptIn /Optout sucessfuly
            NYLDSelenium.AddHeader("Paperless settings  - Paperless document " + args + " Configuration settings success" + data[KeyRepository.PolicyNumber], "Success");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaperlessSignUpThankYouPage                                                                 ///////////
        ////// Description:  SignUp the Paperless settings- Thank you page                                       ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyPaperlessSignUpThankYouPage()
        {
            NYLDSelenium.AddHeader("Verify Paperless settings OptIn Thankyou page", "SubHeader");
            //verify if Survey popup occurs to skip it
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            //Verify the Thankyou page loaded and verify the text
            IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-600);");
            Thread.Sleep(1000);
            NYLDSelenium.PageLoad("Paperless settings Thank you page", ThankyouPageheader);
            //Verify the Paperless settings Information at line 1
            NYLDSelenium.VerifyText("Paperless settings Information1",new TestData().GetContent("Thankyoupage1"), NYLDSelenium.GetAttribute("Paperless settings Info", ActualThankyouPageContent1, "text"),"yes");
            //Verify the Paperless settings Information at line 2
            NYLDSelenium.VerifyText("Paperless settings Information2", new TestData().GetContent("Thankyoupage"), NYLDSelenium.GetAttribute("Paperless settings Info", ActualThankyouPageContent2, "text"),"yes");

            NYLDSelenium.AddHeader("Verify Paperless settings OptIn Thankyou page", "Success");
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyPaperlessOptOutThankYouPage                                                                 ///////////
        ////// Description:  Update the Paperless settings- Thank you page                                       ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void VerifyPaperlessOptOutThankYouPage()
        {
            NYLDSelenium.AddHeader("Verify Paperless settings OptOut Thankyou page", "SubHeader");
            //to skip the survery popup occurs in middle of test execution
            NYLDDigital.SkipSurveyPopUp(StartSurvey, 60, false);

            //Verify Preference Management Thankyou page is loaded
            NYLDSelenium.PageLoad("Paperless settings OptOut Thank you page", PreferenceUpdateThankyouPageheader);
            //Verify Preference Management Thankyou page confirmation message and verify text
            NYLDSelenium.VerifyText("Paperless settings OptOut welcome header", new TestData().GetContent("UpdateThankyoupage"), NYLDSelenium.GetAttribute("Welcome Thank you Page", PreferenceUpdateThankyouPageContent, "text"));
            NYLDSelenium.AddHeader("Verify Paperless settings OptIn Thankyou page", "Success");
        }

    }
}
