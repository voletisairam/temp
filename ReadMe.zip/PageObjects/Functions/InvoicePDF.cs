﻿using Spire.Pdf;
using System.Collections.Generic;
using System.IO;
using System.Text;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using CSW.Common.Others;
using CSW.Common.DataBase;
using CSW.PageObjects.Payments;
using OpenQA.Selenium.Interactions;

namespace CSW.PageObjects.Functions
{
    class InvoicePDF
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public InvoicePDF(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
           
        }

        // Define the PDF download path dynamically based on the user's environment
        public static string PDFPath = @"C:\Users\" + Environment.UserName + @"\Downloads";

        ///////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////// Page Objects //////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////


        // Download Premium Invoice
        [FindsBy(How = How.XPath, Using = "//*[@id='docCenterTable']/tbody/tr[1]/td[2]/a")]
        public IWebElement DownloadLink { get; set; }

        ///////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////   Methods   ///////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////


        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: DownloadAndValidatePDF                                                           /////////
        ////// Description: Download And Validate PDF                                                //////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DownloadAndValidatePDF()
        {
            Actions action = new Actions(driver);

            NYLDSelenium.Click("Premium Notice", DownloadLink);
            System.Threading.Thread.Sleep(2000);
            NYLDSelenium.ReportStepResult("Downloading invoice", "Invoice is downloading", "Pass");
            // Switch to the new window that opens for the PDF download
            string originalWindow = driver.CurrentWindowHandle;
            //string downloadedFile = WaitForFileDownload();
            foreach (var windowHandle in driver.WindowHandles)
            {
                if (windowHandle != originalWindow)
                {
                    driver.SwitchTo().Window(windowHandle);
                    // Download the document
                    action.SendKeys(Keys.Control + "s").Perform();
                    System.Threading.Thread.Sleep(2000);
                    NYLDSelenium.ReportStepResult("Downloading invoice", "Invoice is downloading", "Pass", "Always");
                    WaitForFileDownload();

                    // Validate the content of the downloaded PDF
                    ValidatePDFContentFromText(WaitForFileDownload());
            
                    driver.Close(); // Close the new window
                    driver.SwitchTo().Window(originalWindow); // Switch back to the original window
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: WaitForFileDownload                                                               /////////
        ////// Description: Method to wait for file to download                                       //////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////

        private string WaitForFileDownload()
        {
            string targetDirectory = PDFPath;
            string newestFile = null;
            DateTime lastWritten = DateTime.MinValue;
            int timeout = 10000;  // 10 seconds
            var sw = System.Diagnostics.Stopwatch.StartNew();

            while (sw.ElapsedMilliseconds < timeout)
            {
                var files = Directory.GetFiles(targetDirectory, "*.pdf"); // Assuming the file is a PDF
                foreach (var file in files)
                {
                    DateTime lastWriteTime = File.GetLastWriteTime(file);
                    if (lastWriteTime > lastWritten)
                    {
                        lastWritten = lastWriteTime;
                        newestFile = file;
                    }
                }

                if (newestFile != null)
                    return newestFile;

                System.Threading.Thread.Sleep(500);  // Check every 500 milliseconds
            }

            return null;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: ValidatePDFContentFromText                                                         /////////
        ////// Description: Method to validate PDF Content From Text                                  //////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ValidatePDFContentFromText(string downloadedFile)
        {
            string extractedText = ExtractTextFromPDF(downloadedFile);
            if (string.IsNullOrEmpty(extractedText))
            {
                NYLDSelenium.ReportStepResult("PDF extraction verification", "Failed to extract text from PDF.", "Fail");
                return;
            }

            NYLDSelenium.ReportStepResult("Extract text from PDF successfully.", "It extracts text from PDF.", "Pass");


            // Database and data operations
            LSPDatabase DB = new LSPDatabase(driver, data);
            DB.QueryPolicyNumber();  // This method is expected to populate data with the Policy Number

            if (!data.TryGetValue(KeyRepository.PolicyNumber, out string policyNumber))
            {
                NYLDSelenium.ReportStepResult("Policy Number Fetch", "Failed to fetch policy number from DB.", "Fail");
                return;  // Stop further execution if policy number is not available
            }
            NYLDSelenium.ReportStepResult("Policy Number Fetch", "Able to fetch policy number from DB.", "Pass");
            ValidateField("Contract Number:", extractedText);
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: ExtractTextFromPDF                                                                 /////////
        ////// Description: Method to extract text from PDF                                           //////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private string ExtractTextFromPDF(string downloadedFile)
        {
            StringBuilder content = new StringBuilder();
            using (PdfDocument document = new PdfDocument())
            {
                document.LoadFromFile(downloadedFile);
                foreach (PdfPageBase page in document.Pages)
                {
                    content.Append(page.ExtractText());
                }
            }
            return content.ToString();
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: ValidateField                                                                      /////////
        ////// Description: Method to Validate Field                                                  //////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ValidateField(string key, string pdfText)
        {
            if (!data.TryGetValue(key, out string expectedValue))
            {
                NYLDSelenium.ReportStepResult($"Data key not found: {key}", "Data Key not found.", "Fail");
                return;
            }

            if (pdfText.Contains(expectedValue))
            {
                NYLDSelenium.ReportStepResult($"{key} matches expected value.", "It matches expected value.", "Pass");
            }
            else
            {
                NYLDSelenium.ReportStepResult($"{key} does not match expected value. Expected: {expectedValue}", "Does not match expected value.", "Fail");
            }
        }
    }
}
