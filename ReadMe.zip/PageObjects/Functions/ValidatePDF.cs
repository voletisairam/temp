﻿using NYLDWebAutomationFramework;
using Spire.Pdf;
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using CSW.Common.Excel;
using CSW.Common.Others;
using System.Collections.Generic;
using OpenQA.Selenium;

using iText.Kernel.Pdf;
using iText.Forms;
using System.Net;
using SeleniumExtras.PageObjects;
using System.Threading;

namespace CSW.PageObjects.Functions
{
    class ValidatePDF
    {
        //TODO: Can you move validate PDF to Common. Create a folder as needed
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ValidatePDF(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        public static string[] ReadContent { get; set; }
        public static string FilePDF { get; set; }
        public static string ControlNo;
        public static string PDFPATH = @"C:\Users\" + Environment.UserName + @"\Downloads";
        public static string[] healthQuestResp = null;
        public static int pdfcounter;

        public void VerifyPDFCFormContent(string args = "")
        {
            TestData testdata = new TestData();
            NYLDSelenium.AddHeader("Verify PDF Generated for the Esig Submission ", "SubHeader");
            Thread.Sleep(2000);
            string fileName ="";


            //Verify PDF
            if (args == "Riders")
            {
                ExecuteValidationMethod("Riders");
                fileName = @"\NYLApplication.pdf";
            }
            else
            {
                VerifyExchangePDF();
                ExecuteValidationMethod("Exchange");
                fileName = @"\ExchangeApp.pdf";
            }

            //Create the daily folder name.
            string folderName = CommonFunctions.PathPDFCreation(Properties.Settings.Default.RootDirectory + Properties.Settings.Default.PDFPath);

            //Save the file
            string SourceApplicationPDF = PDFPATH + fileName;
            string DestinationApplicationPDF = folderName + fileName.Replace(".pdf","").Replace("NYLApplication","RiderApp") +"_" + data[KeyRepository.ControlNumber] + ".pdf";            
            NYLDGeneric.CopyFile(SourceApplicationPDF, DestinationApplicationPDF);

            NYLDSelenium.AddHeader("Verify PDF Generated for the Esig Submission ", "Success");
        }


        public void VerifyContractViewPDFFormContent(string args = "")
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify PDF Generated for the Esig Submission" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            int startCounter = GetSettor.failCounter;
            PDFTextExtract();
        }
        public void SavePDFFileMethod(string fileName)
        {
            try

            {

                //Create a WebClient object

                WebClient webClient = new WebClient();
                //Security Credentials
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls | SecurityProtocolType.Ssl3;
              
                Spire.Pdf.PdfDocument document = new Spire.Pdf.PdfDocument();

                //Download data from URL and save as memory stream
                using (MemoryStream ms = new MemoryStream(webClient.DownloadData(driver.Url)))
                {
                    //Load the stream
                    document.LoadFromStream(ms);
                }

                //Save to PDF file
                document.SaveToFile(fileName, FileFormat.PDF);
            }
            catch
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Red\">" + "Verify PDF Generated is not save" + "</h3>", "<h3 style=\"color:Red\">" + "###########" + "</h3>", "FAIL","always","yes");
            }
        }
        public void ExecuteValidationMethod(string ActExchange)
        {
            string fieldName = null;
            string leftBoundary = null;
            string rightBoundary = null;
            string extractedText = null;
            pdfcounter = GetSettor.failCounter;

            Console.WriteLine("pdfcounter starting:" + pdfcounter);
            //data[KeyRepository.TemplateType] = "3111-01-VT";
            //data[KeyRepository.HQAnswers] = "No|No|No|No|No|No|No";
            //data[KeyRepository.Member] = "Yes";
            //data[KeyRepository.Height] = @"5'9""";
            //data[KeyRepository.Weight] = "130";
            //data[KeyRepository.Age] = "60";
            //healthQuestResp = data[KeyRepository.HQAnswers].Split('|');

            StringBuilder textContent = new StringBuilder();
            textContent.Append(Extract_Text(ActExchange,data));

            string content = textContent.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "").Replace(@"_", "");

            //Reading PDF Boundaries 
            int row = 2;
            if (ActExchange == "Riders")
                data[KeyRepository.TemplateType] = "3628-00-NAT";
            NYLDSelenium.AddHeader("Verify the content of PDF ", "SubHeader");
            TestData testData = new TestData();
            do
            {
                string ch = data[KeyRepository.TemplateType];
                string ch2 = testData.PDFConfigSheet(row, 1);
                if (ch2.Trim() == ch.Trim())
                {
                    fieldName = testData.PDFConfigSheet(row, 2);

                    //if (fieldName != "Health Questions" && fieldName != "Email")
                    //{
                        leftBoundary = testData.PDFConfigSheet(row, 3);
                        rightBoundary = testData.PDFConfigSheet(row, 4);

                        //Validate if the text index have 1 or 2
                        string index = "first";
                        if (fieldName.Contains("MVF"))
                            index = "last";
                        if ((fieldName != "Health Questions Comments") || (fieldName != "CA Residents"))
                        {
                            //extract the text using boundaries
                            extractedText = GetMidString(leftBoundary, rightBoundary, content, fieldName, index);

                            //junk charecters//
                            extractedText = RemoveJunkText(extractedText, testData.PDFConfigSheet(row, 5), data);
                        }
                        else
                            extractedText = content;

                        Console.WriteLine(GetSettor.failCounter);
                        //text validation field wise //
                        switch (fieldName)
                        {

                            case "Disclaimer":

                                string PDFDisclaimer = testData.PDFConfigSheet(11, 7);
                                PDFDisclaimer = PDFDisclaimer.Replace("\n", "").Replace(" ", "");

                                //extractedText = Regex.Replace(extractedText, "Send no            money now.", "X                                                                                                        /     /");
                                extractedText = GetMidString(testData.PDFConfigSheet(row, 3), testData.GetPDFContent(row, 4), content, fieldName);
                                extractedText = extractedText.Trim();

                                extractedText = extractedText.Trim().Replace(" ", "");

                                NYLDSelenium.VerifyText("Esig PDF: CA Residents", PDFDisclaimer, extractedText.Trim());

                                break;

                            case "FirstName":
                            NYLDSelenium.VerifyText("Esig PDF: First Name Validation", FirstCharString(data[KeyRepository.FirstName].Trim()).ToLower(), extractedText.ToLower().Trim());
                                    break;

                            case "LastName":
                                NYLDSelenium.VerifyText("Esig PDF: Last Name Validation", FirstCharString(data[KeyRepository.LastName].Trim()).ToLower(), extractedText.ToLower().Trim());
                                break;
                            case "Address":
                                NYLDSelenium.VerifyText("Esig PDF: Address Validation", data[KeyRepository.AddressLine1].Trim().ToLower(), extractedText.Replace("Address:", "").Trim().ToLower());
                                break;
                            case "City":
                                if (data[KeyRepository.Product].Contains("PL"))
                                {
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.State], "");
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.Zip], "");
                                }
                                else
                                    NYLDSelenium.VerifyText("Esig PDF: City Validation", FirstCharString(data[KeyRepository.City]), extractedText.Trim());
                                break;
                            case "State":
                                if (data[KeyRepository.Product].Contains("PL"))
                                {
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.City], "");
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.Zip], "");
                                }
                                else
                                {
                                    extractedText = Regex.Replace(extractedText, "Zip:", "").Replace(data[KeyRepository.Zip], "");
                                    NYLDSelenium.VerifyText("Esig PDF: State Validation", data[KeyRepository.State], extractedText.Trim());
                                }
                                break;
                            case "Zip":
                                if (data[KeyRepository.Product].Contains("PL"))
                                {
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.City], "");
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.State], "");
                                }
                                else
                                {
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.State], "");
                                    extractedText = extractedText.Trim();
                                    var actual = data[KeyRepository.Zip].Trim();
                                    NYLDSelenium.VerifyText("Esig PDF: ZIP Validation", actual, extractedText);
                                }
                                break;
                        case "Email":
                            NYLDSelenium.VerifyText("Esig PDF: Email Validation", data[KeyRepository.EmailId].ToLower(), extractedText.ToLower().Replace(data[KeyRepository.AddressLine1].ToLower(),"").Replace("address:","").Trim().ToLower());
                            break;
                        case "SSN":
                                extractedText = Regex.Replace(extractedText, @" ", "").Replace("-", "");
                                NYLDSelenium.VerifyText("Esig PDF: SSN Validation", data[KeyRepository.SSN].Trim(), extractedText.Trim());
                                break;

                            case "Phone Number":
                                if (data[KeyRepository.Product].Contains("PL"))
                                {
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.City], "");
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.State], "");
                                    extractedText = Regex.Replace(extractedText, data[KeyRepository.Zip], "");
                                }

                                extractedText = Regex.Replace(extractedText, @"[ ]+", "").Replace(@"-", "").Trim();
                                //var phone = data[KeyRepository.PhoneNumber].Trim();
                                //NYLDSelenium.VerifyText("Esig PDF: Phone Number Validation", phone, extractedText);

                                break;
                            case "Control Number":
                                if (extractedText != "")
                                {
                                    ControlNo = extractedText;
                                    data[KeyRepository.ControlNumber] = ControlNo.Trim();
                                    NYLDSelenium.ReportStepResult("Esig PDF: Control Number Validation", "Control Number from PDF is: " + extractedText, "PASS", "no");

                                    leftBoundary = data[KeyRepository.TemplateFormId];
                                    rightBoundary = "107";
                                    extractedText = GetMidString(leftBoundary, rightBoundary, content, fieldName, index);

                                    //junk charecters//
                                    extractedText = RemoveJunkText(extractedText, testData.PDFConfigSheet(row, 5), data);
                                    if (extractedText != "")
                                        data.Add(KeyRepository.ControlNumber, extractedText);
                                }
                                break;
                            case "Product Type":
                                string ProdName = "";
                                switch (data[KeyRepository.Product])
                                {
                                    case "LBT":
                                        ProdName = "Level Benefit Term Life";
                                        break;
                                    case "PL":
                                        ProdName = "Permanent Life";
                                        break;
                                    case "GAL":
                                        ProdName = "Guaranteed Acceptance Life";
                                        break;
                                }

                                if (extractedText.Trim().Contains(ProdName))
                                    NYLDSelenium.ReportStepResult("Esig PDF: Product Type Validation", "Product Type from PDF is: " + extractedText, "PASS", "no");
                                break;

                            case "PDF Version":
                                extractedText = Regex.Replace(extractedText, FirstCharString(data[KeyRepository.FirstName]), "").Replace(FirstCharString(data[KeyRepository.LastName]), "").Replace(@"[ ]+", " ");

                                // extractedText = Regex.Replace(extractedText, data[KeyRepository.RoutingNumber], "");
                                // NYLDSelenium.VerifyText("Esig PDF Version: ", data[KeyRepository.PDFVersion], extractedText.Trim());

                                break;

                            case "Read & Sign text":
                                string fullName1 = null; string fullName2 = null; string dt = null; string mnt = null; string yr = null;
                                mnt = DateTime.Today.Month.ToString();
                                dt = DateTime.Today.Day.ToString();
                                yr = DateTime.Today.Year.ToString();

                                fullName1 = FirstCharString(data[KeyRepository.FirstName]) + " " + FirstCharString(data[KeyRepository.LastName]);
                                fullName2 = FirstCharString(data[KeyRepository.FirstName]) + " " + data[KeyRepository.MiddleName] + " " + FirstCharString(data[KeyRepository.LastName]);
                                extractedText = leftBoundary + " " + extractedText + "" + rightBoundary;
                                extractedText = Regex.Replace(extractedText, fullName1, "").Replace(fullName2, "");
                                extractedText = Regex.Replace(extractedText, @"[ ]+", " ").Replace("[S]+", " ").Replace(".", "").Replace("\r", "").Replace("\n", " ").Replace("“", "").Replace(" ", "").Replace(".", "").Trim();

                                var expectedText = data[KeyRepository.Read_SignDisclaimer].Replace("[S]+", " ").Replace(".", "").Replace("\r", "").Replace("\n", " ").Replace("“", "").Replace(" ", "").Replace(".", "").Trim();
                                #region --Read & Sign text
                                //string[] readandSignWords = ReadContent;                             
                                NYLDSelenium.VerifyText("Esig PDF: Read And Sign Text Validation", expectedText, extractedText);

                                #endregion
                                break;
                            case "Health Questions":
                                string[] HealthQuesAns_Split = data[KeyRepository.HQAnswers].Split('|');
                                break;
                            case "Risk Conditions":                               
                                extractedText = Regex.Replace(extractedText, @"[ ]+", " ").Replace(".", "");
                                break;
                            case "Health Questions Comments":
                                int sizeHealthResp = healthQuestResp.Length;
                                break;
                            case "TemplateType":
                                NYLDSelenium.VerifyText("Esig PDF: templateType Type validation", data[KeyRepository.TemplateType], extractedText.Trim());
                                break;
                        }
                        //pdfcounters = GetSettor.failCounter;
                        //Console.WriteLine("pdfcounter FieldName with fail counter inside:" + fieldName + "|" + pdfcounters);
                    //}
                }

                row = row + 1;

            } while (testData.GetPDFContent(row, 1) != "");
            NYLDSelenium.AddHeader("Verify the content of PDF ", "Success");

        }



        public void PDFTextExtract()
        {
            int pagecount;
            bool filefound = true;
            string PdfLocation = PDFPATH + @"\ViewContract.pdf", txtfilename = "ConvertedLTCPdfToText";
            string fileNames = @"\WelcomeLetter";            
            NYLDGeneric.DeleteFiles(PDFPATH, "ViewContract.pdf");
            SavePDFFileMethod(PdfLocation);

            //Verify if File Exists in specified location
            while (!File.Exists(PdfLocation))
            {
                System.Threading.Thread.Sleep(1000);
            }

            //Check if PDF is downloaded
            if (filefound)
                goto FileFound;

            else
                NYLDSelenium.ReportStepResult("Verify the content of " + PdfLocation + " form", PdfLocation + " did not successfully downloaded", "FAIL", "no", "no");


            FileFound:
            Spire.Pdf.PdfDocument document = new Spire.Pdf.PdfDocument(PdfLocation);
            StringBuilder content = new StringBuilder();

            //Get the page count of PDF
            pagecount = document.Pages.Count;
            Console.WriteLine("Number of pages in PDF is" + pagecount);

            //Extract text from PDF pages
            for (int i = 0; i < pagecount; i++)
            {
                content.Append(document.Pages[i].ExtractText());
            }

            string fileName = PDFPATH + @"\ConvertedLTCPdfToText.txt";

            File.WriteAllText(fileName, content.ToString());
            StreamReader sr = new StreamReader(fileName);
            StringBuilder sb = new StringBuilder();
            document.Dispose();

            while (!sr.EndOfStream)
            {
                sb.Append((char)sr.Read());
            }
            sr.Close();

            //Path to move the files
            string destfile = CommonFunctions.PathPDFCreation(Properties.Settings.Default.RootDirectory + Properties.Settings.Default.PDFPath) +@"\"+ txtfilename + "-" + DateTime.Now.ToFileTime() + ".txt";
            string destfilePath = CommonFunctions.PathPDFCreation(Properties.Settings.Default.RootDirectory + Properties.Settings.Default.PDFPath);

            //Comparing the content of the PDF with .txt file
            Directory.CreateDirectory(destfilePath);

            //Save the file
            string SourceApplicationPDF = PdfLocation;
            string DestinationApplicationPDF = destfilePath + fileNames + "-" + DateTime.Now.ToFileTime() + ".pdf";
            NYLDGeneric.CopyFile(SourceApplicationPDF, DestinationApplicationPDF);
            NYLDGeneric.MoveFile(fileName, destfile);

            string expformcontent = File.ReadAllText(destfile);

            //Verify the content of the PDF from the text file with the expected content
            if (expformcontent != content.ToString())
            {
                Console.WriteLine("################################## NOT MATCHED ##################################");
                NYLDSelenium.ReportStepResult("Verify the content of " + txtfilename + " ", "Content of the " + txtfilename + " form is changed. Reference path." + destfile + "", "FAIL", "no", "no");

            }
            else
            {
                Console.WriteLine("################################## MATCHED ##################################");
                NYLDSelenium.ReportStepResult("Verify the content of " + txtfilename + " form", "Content of the " + txtfilename + " form is as expected. Reference path." + destfile + "", "PASS", "no", "no");

            }

            if (content.ToString().Contains(data[KeyRepository.PolicyNumber]))
                NYLDSelenium.ReportStepResult("Verify the content of " + txtfilename + " form", "Content of the " + txtfilename + " form is as expected. Reference path." + destfile + "", "PASS", "no", "no");
            else
                NYLDSelenium.ReportStepResult("Verify the content of " + txtfilename + " ", "Content of the " + txtfilename + " form is changed. Reference path." + destfile + "", "FAIL", "no", "no");
            NYLDGeneric.DeleteFiles(PDFPATH, "ViewContract.pdf");
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: GetMidString                                                                                    //
        ////// Description: Ged mid string using start and ending string                                             //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        static String GetMidString(String startString, String endString, String sourceString, string fieldName, string index = "start")
        {

            String midString = "";

            try
            {

                if (endString.Equals("End of File"))
                {
                    sourceString = sourceString + " End of File";
                }

                if (index == "last")
                {
                    midString = (sourceString.Substring(sourceString.LastIndexOf(startString) + startString.Length, sourceString.LastIndexOf(endString) - sourceString.LastIndexOf(startString) - startString.Length)).Trim();
                }

                    else
                    {
                        int first = sourceString.IndexOf(startString) + startString.Length;
                        int second = sourceString.IndexOf(endString) - sourceString.IndexOf(startString);
                        int third = second - startString.Length;
                        midString = sourceString.Substring(first, third).Trim();
                    }

            }
            catch
            {
                NYLDSelenium.ReportStepResult("Could not fetch content for Field Name: " + fieldName, "<p> Incorrect boundaries for field Name: " + fieldName + " </p>" + " <p> Left Boundary: " + startString + " </p>" + " <p> Right Boundary: " + endString, "Fail", "yes", "yes");
            }
            return midString;
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: removeJunkText                                                                                  //
        ////// Description: removes junk text                                                                        //
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public string RemoveJunkText(string extractedText, string junktext, Dictionary<string, string> entryData)
        {
            string[] tobeReplaced = null;
            string finalRpl = null;

            if (junktext.Contains("|"))
            {
                tobeReplaced = junktext.Split('|');

                for (int i = 0; i < tobeReplaced.Length; i++)
                {
                    if (tobeReplaced[i].Contains("MSDData"))
                    {
                        finalRpl = tobeReplaced[i].Split('.')[1];

                        switch (finalRpl)
                        {
                            case "FirstName":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.FirstName], "");
                                break;
                            case "LastName":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.LastName], "");
                                break;
                            case "City":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.City], "");
                                break;
                            case "Address":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.AddressLine1], "");
                                break;
                            case "State":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.State], "");
                                break;
                            case "SSN":
                                extractedText = extractedText.Replace(@"    ", "").Replace(@"   ", "").Replace(@"  ", "");
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.SSN], "");
                                break;
                            case "Zip":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.Zip], "");
                                break;
                            case "Email":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.EmailId], "");
                                break;
                            case "RoutingNum":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.RoutingNumber], "");
                                break;
                            case "AccountNum":
                                extractedText = Regex.Replace(extractedText, data[KeyRepository.AccountNumber], "");
                                break;
                        }
                    }
                    else
                        extractedText = Regex.Replace(extractedText, @tobeReplaced[i], "");
                }
            }
            else
                extractedText = Regex.Replace(extractedText, @junktext, "");

            return extractedText;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: Extract_Text                                                                                    //
        ////// Description: Extract text/content of PDF that has been download after ESIG submission to text file    //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        static StringBuilder Extract_Text(string Formtype,Dictionary<string, string> testdata)
        {
            Spire.Pdf.PdfDocument document = new Spire.Pdf.PdfDocument();
            string filename = "";string loadfilename = "";

            //Set the file type and to load the pdf content into text file
            if (Formtype == "Riders")
            {
                filename = @"\NYLApplication.pdf";
                loadfilename = @"\NYLApplicationTOText.txt";
            }
            else
            {
                filename = @"\ExchangeApp.pdf";
                loadfilename = @"\ExchangeAppTOText.txt";
            }

            while (!File.Exists(PDFPATH + filename))
            {
                System.Threading.Thread.Sleep(1000);
            }
            
            document.LoadFromFile(PDFPATH + filename);

            StringBuilder content = new StringBuilder();
            content.Append(document.Pages[0].ExtractText());
          
            string fileName = PDFPATH + loadfilename;

            File.WriteAllText(fileName, content.ToString());
            StreamReader f = new StreamReader(fileName);
            StringBuilder sb = new StringBuilder();
            document.Dispose();
            while (!f.EndOfStream)
            {
                sb.Append((char)f.Read());
            }
            f.Close();

            return sb;
        }

        /// <summary>
        /// Method to verify the PDF form conent for exchanges
        /// </summary>
        public void VerifyExchangePDF()
        {
            Dictionary<string, string> pdfFormData = new Dictionary<string, string>();

            pdfFormData = GetExchangePDFFormValues();

            NYLDSelenium.VerifyText(KeyRepository.FirstName, data[KeyRepository.FirstName], pdfFormData[KeyRepository.FirstName]);
            NYLDSelenium.VerifyText(KeyRepository.LastName, data[KeyRepository.LastName], pdfFormData[KeyRepository.LastName]);
            NYLDSelenium.VerifyText(KeyRepository.MiddleName, data[KeyRepository.MiddleName], pdfFormData[KeyRepository.MiddleName]);
            NYLDSelenium.VerifyText(KeyRepository.AddressLine1, data[KeyRepository.AddressLine1], pdfFormData[KeyRepository.AddressLine1]);
            NYLDSelenium.VerifyText(KeyRepository.City, data[KeyRepository.City], pdfFormData[KeyRepository.City]);
            NYLDSelenium.VerifyText(KeyRepository.State, data[KeyRepository.State], pdfFormData[KeyRepository.State]);
            NYLDSelenium.VerifyText(KeyRepository.Zip, data[KeyRepository.Zip], pdfFormData[KeyRepository.Zip]);
            NYLDSelenium.VerifyText(KeyRepository.CoverageAmount, data[KeyRepository.CoverageAmount], pdfFormData[KeyRepository.CoverageAmount]);
            string premium = data[KeyRepository.Premium].Replace("for just", "").Replace("per month", "").Replace("$", "").Trim();
            premium = premium.Replace("Keep the same amount of coverage you currently have.\r\n0,000\r\n", "").Trim();
            data[KeyRepository.Premium] = premium;
           // NYLDSelenium.VerifyText(KeyRepository.Premium, data[KeyRepository.Premium], pdfFormData[KeyRepository.Premium]);
            NYLDSelenium.VerifyText(KeyRepository.CurrentPaymentFrequency, data[KeyRepository.CurrentPaymentFrequency], pdfFormData[KeyRepository.CurrentPaymentFrequency].Substring(0,1));
            
        }

        /// <summary>
        /// Method to fetch PDF form values for exchanges
        /// </summary>
        public Dictionary<string, string> GetExchangePDFFormValues()
        {
            Dictionary<string, string> formData = new Dictionary<string, string>();
            PdfReader reader = new PdfReader(PDFPATH + @"\ExchangeApp.pdf");
            iText.Kernel.Pdf.PdfDocument document = new iText.Kernel.Pdf.PdfDocument(reader);
            PdfAcroForm acroForm = PdfAcroForm.GetAcroForm(document, true);
            var fields = acroForm.GetFormFields();

            //Save values in the dictionary
            formData.Add(KeyRepository.FirstName, fields["First Name"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.LastName, fields["Last Name"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.MiddleName, fields["Middle Name"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.AddressLine1, fields["Address"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.City, fields["City"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.State, fields["State"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.Zip, fields["Zip"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.CoverageAmount, fields["New Coverage Amount"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.Premium, fields["New Premium"].GetValue().ToString().Trim());
            formData.Add(KeyRepository.CurrentPaymentFrequency, fields["Payment Mode"].GetValue().ToString().Trim());

            return formData;  
                        
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: DeleteAllFiles                                                                                  //
        ////// Description: delete all files from Downloads folder                                                   //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void DeleteAllFiles()
        {
            String filePath = PDFPATH;

            string[] fileEntries = Directory.GetFiles(filePath);
            foreach (string fileName in fileEntries)
            {
                if (fileName.Contains("ExchangeApp.pdf") || fileName.Contains("NYLApplication.pdf") || fileName.Contains("PDFConvertedTOText.txt"))
                {
                    File.Delete(fileName);
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: FirstCharString                                                                                 //
        ////// Description: Convert firstchar of a string to upper case                                              //
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public static string FirstCharString(string s)
        {
            if (s == null)
                return s;

            string[] words = s.Split(' ');

            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length == 0)
                    continue;

                Char firstChar = Char.ToUpper(words[i][0]);
                string rest = "";
                if (words[i].Length > 1)
                    rest = words[i].Substring(1).ToLower();

                words[i] = firstChar + rest;
            }

            return string.Join(" ", words);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getControlNumber                                                                                //
        ////// Description: get Control Number from PDF that has been download after ESIG submission                 //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //public void GetControlNumber()
        //{
        //    StringBuilder textContent = new StringBuilder();
        //    textContent.Append(Extract_Text(data));

        //    string content = textContent.ToString().Replace("\n", "").Replace("\r", "").Replace("\t", "").Replace(@"_", "");

        //    string leftboundary = null;
        //    string rightboundary = null;
        //    //   ControlNo = GetMidString("I’m already an AARP member.", "full year of membership.", content);
        //    if (data[KeyRepository.TemplateType] == "")
        //    {
        //        switch (data[KeyRepository.Product])
        //        {
        //            case "LBT":
        //            case "PL":
        //            case "LB10":
        //                if (data[KeyRepository.Result].Trim() == "Happy Path")
        //                {
        //                    leftboundary = "5505 West Cypress";
        //                    rightboundary = "Tampa, FL 33607-1707";
        //                }
        //                else
        //                {
        //                    leftboundary = "I understand I will be billed $16.00 for a";
        //                    rightboundary = "full year of membership.";
        //                }
        //                break;

        //            case "PL10":
        //                //case "PL":
        //                leftboundary = "I understand I will be billed $16.00 for a";
        //                rightboundary = "full year of membership.";
        //                break;

        //            case "GAL":
        //                leftboundary = "I understand I will be billed $16.00 for a";
        //                rightboundary = "full year of membership.";
        //                break;
        //        }
        //    }
        //    else
        //    {
        //        string boundary = new TestDataSheet().GetBoundary("Contract Number", data);
        //        leftboundary = boundary.Split('|')[0];
        //        rightboundary = boundary.Split('|')[1];
        //    }

        //    ContractNo = GetMidString(leftboundary, rightboundary, content, "Contract Number").Replace("\n", " ").Replace("\t", "").Replace("\r", ""); //ControlNo = GetMidString("I understand I will be billed $16.00 for a", "full year of membership.", content).Replace("\n", " ").Replace("\t", "").Replace("\r", "");

        //    ContractNo = Regex.Replace(ContractNo, "[k]+", "");
        //    ContractNo = Regex.Replace(ContractNo, @"\$", "");
        //    ContractNo = Regex.Replace(ContractNo, "\0", "");

        //    if (ContractNo.Contains("3285498147"))
        //        ContractNo = Regex.Replace(ContractNo, "3285498147", "");

        //    if (!ContractNo.Trim().Equals(""))
        //    {

        //        //I dont know if it will be needed for CMS RIder......To save this value in data.
        //        data[KeyRepository.ControlNumber] = ContractNo.Trim();
        //    }
        //    else
        //        NYLDSelenium.ReportStepResult("Get the Control Number from the Esig PDF application", "Couldnt get the control number from the Esig PDF application.", "FAIL");

        //}
    }
}
