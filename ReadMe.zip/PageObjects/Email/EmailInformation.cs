﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.PageObjects.Email
{
    class EmailInformation
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public EmailInformation(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////
        ///

        
        public class Email
        {
            public string id { get; set; }
            public string subject { get; set; }
            public string conversationId { get; set; }
            public bool hasAttachments { get; set; }
            public EmailHeaders emailHeaders { get; set; }
        }


        public class From
        {
            public string name { get; set; }
            public string address { get; set; }
        }

        public class To
        {
            public string name { get; set; }
            public string address { get; set; }
        }



        public class EmailHeaders
        {
            public string parentFolderId { get; set; }
            public string conversationId { get; set; }
            public bool isReadReceiptRequested { get; set; }
            public bool isRead { get; set; }
            public bool isDraft { get; set; }
            public string webLink { get; set; }
            public string inferenceClassification { get; set; }
            public DateTime sentDateTime { get; set; }
            public DateTime receivedDateTime { get; set; }
            public string importance { get; set; }
            public From from { get; set; }
            public List<To> to { get; set; }
            public List<object> cc { get; set; }
            public string BodyPreview { get; set; }
        }

        public class EmailList
        {
            public string context { get; set; }
            public List<Email> emails { get; set; }
        }

        public class IndividualEmailInfo
        {
            public string context { get; set; }
            public string subject { get; set; }
            public string id { get; set; }
            public string flagStatus { get; set; }
            public EmailHeaders emailHeaders { get; set; }
            public string body { get; set; }
            public string contentType { get; set; }
        }



    }
}
