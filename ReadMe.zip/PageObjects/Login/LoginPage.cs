﻿
namespace CSW.PageObjects.Login
{
    using System.Collections.Generic;
    using OpenQA.Selenium;
    using SeleniumExtras.PageObjects;
    using CSW.Common.Others;
    using NYLDWebAutomationFramework;
    using System.Threading;
    using CSW.Common.Services;
    using System;
    using CSW.Common.DataBase;
    using OpenQA.Selenium.Chrome;
    using CSW.Common.Excel;
    using CSW.Drivers;
    using System.Linq;
    using CSW.PageObjects.Home;
    using System.Web.UI.WebControls;
    using CSW.PageObjects.NewRegistration;

    class LoginPage : WebBrowser
    {
        public new  IWebDriver driver;
        public Dictionary<string, string> data;


        public LoginPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //LoginLink
        [FindsBy(How = How.Id, Using = "login-page-login-link")]
        public IWebElement LoginLink { get; set; }

        //UserName
        [FindsBy(How = How.XPath, Using = "//input[@id='txtUsername']")]
        public IWebElement UserName { get; set; }

        //UserName PopUp
        [FindsBy(How = How.XPath, Using = "//input[@id='txtUsername']/following-sibling::span[@class='field-validation-error']")]
        public IWebElement UserNamePopUp { get; set; }

        //Password
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']")]
        public IWebElement Password { get; set; }

        //Password PopUp
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']/following-sibling::span[@class='field-validation-error']")]
        public IWebElement PasswordPopUp { get; set; }

        //Correct field
        [FindsBy(How = How.XPath, Using = "(//span[@class='field-validation-error']/p)[1]")]
        public IWebElement CorrectFieldMessage { get; set; }

        //Create an Account Button
        [FindsBy(How = How.XPath, Using = "//*[@id='login-form']//following::div/a/u[contains(text(),'Forgot username?')]")]
        public IWebElement ForgotUsernamelnk { get; set; }

        //Create an Account Button
        [FindsBy(How = How.XPath, Using = "//*[@id='login-form']//following::div/a/u[contains(text(),'Forgot password?')]")]
        public IWebElement ForgotPasswordlnk { get; set; }

        //Forgot UserName and Password
        [FindsBy(How = How.XPath, Using = "//*[@id='resetPswdLink']/span")]
        public IWebElement ForgotUserNamePwd { get; set; }

        //Login
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Log')]")]
        public IWebElement LoginButton { get; set; }

        //Login
        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Please call New York Life')]")]
        public IWebElement ServerError { get; set; }

        [FindsBy(How = How.XPath, Using = "(//*[contains(text(),'The information provided does not match our records.')])[1]")]
        public IWebElement LoginError { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'unable to')]")]
        public IWebElement unabletoverifyError { get; set; }        

        //Account Verification page
        [FindsBy(How = How.XPath, Using = "(//*[contains(@class,'logo-title') and contains(text(),'Account Verification')])")]
        public IWebElement AccountVerificationTxt { get; set; }

        //SMS Device type page
        [FindsBy(How = How.XPath, Using = "//*[contains(@class,'verification-option-container')]")]
        public IWebElement devicetyperadio { get; set; }

        //verification input field
        [FindsBy(How = How.XPath, Using = "//*[@id='field_verification_code']")]
        public IWebElement AccountVerificationInput { get; set; }

        //Account Verification page
        [FindsBy(How = How.XPath, Using = "//*[contains(@class,'verification-option-container')]")]
        public IWebElement AccountVerificationSendToTxt { get; set; }

        //verification input field
        [FindsBy(How = How.XPath, Using = "(//button[@type='submit' and contains(text(), 'Continue')])")]
        public IWebElement AccountVerificationSendToSelection { get; set; }

        //Account Verification page submit button
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Submit')]")]
        public IWebElement SubmitButton { get; set; }

        //Remember Me
        [FindsBy(How = How.XPath, Using = "//input[@name = 'RememberMe'][1]")]
        public IWebElement RememberMe { get; set; }

        //Create an Account link
        [FindsBy(How = How.XPath, Using = "//*[@id='login-form-container']/p/a[text()='Create your account']")]
        public IWebElement CreateAnAccountLink { get; set; }

        //Create an Account Button
        [FindsBy(How = How.XPath, Using = "//form[@id='login-form']/a[contains(text(),'Create')]")]
        public IWebElement CreateAnAccountButton { get; set; }        

        [FindsBy(How = How.XPath, Using = "//*[@id='LoginDisplay']/div[@id='loginHeading']//div[@class='loginHeaderFont'] | //*[@id='cswm-login-form']")]
        public IWebElement LoginHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[text()='Log In'] | //*[@id='cswm-login-form']")]
        public IWebElement LoginHeaderExistingUser { get; set; }

        [FindsBy(How = How.XPath, Using = "//form[@id='login-form']")]
        public IWebElement LoginHeaderNewUser { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='onetrust-banner-sdk']/div[@aria-label='Cookie Preferences']")]
        public IWebElement CookiesPreferencesbanner{ get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@id='onetrust-accept-btn-handler']")]
        public IWebElement AcceptCookiesPreferences { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='-aarp-mock-footer'][contains(@style,'display: block')]")]
        public IWebElement CloseMockFooter { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'Click to close')]")]
        public IWebElement CloseMockBanner { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class, 'ui-progressbar')]")]
        public IWebElement UiInProgress { get; set; }

        [FindsBy(How = How.Id, Using = "header-welcome")]
        public IWebElement HomePageHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='col csw-form-margin']/h2")]
        public IWebElement SuccessNewPwd { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='col csw-form-margin']/p")]
        public IWebElement MsgNewPwd { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@class, 'nav-link dropdown-toggle') and @id='account-panel-id']")]
        public IWebElement BtnGoMyacct { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@class='img - fluid']")]
        public IWebElement AARPLogo { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='navbarSupportedContent']/ul/li[5]/a")]
        public IWebElement LoginHomeLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='login-form-container']/h1")]
        public IWebElement LoginFormHeader { get; set; }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Please Call')]/following-sibling::p[1]")]
        public IWebElement SuspendUserMessage { get; set; }


        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Please Call')]")]
        public IWebElement PleaseCallNYL { get; set; }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////// Footer Links                   /////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////////

        [FindsBy(How = How.XPath, Using = "(//a[contains(.,'Frequently Asked Questions')])[2]")]
        public IWebElement FAQs { get; set; }

        [FindsBy(How = How.XPath, Using = "(//a[contains(text(), 'One-Time Payment')])[1]")]
        public IWebElement PayAsGuest { get; set; }

        // Profile
        [FindsBy(How = How.XPath, Using = "//ul[@class = 'd-none d-md-block footer-links']//li[contains(.,'Create An Account')]/a")]
        public IWebElement CreateAccount { get; set; }

        // Forms
        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Claim Form')]")]
        public IWebElement ClaimForm { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Nursing Home Premium Waiver Form')]")]
        public IWebElement NursingHomePremForm { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,' Collateral Assignment Form')]")]
        public IWebElement CollateralAsignForm { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Owner Change Form')]")]
        public IWebElement ChangeOwnerForm { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Payor Change Form')]")]
        public IWebElement ChangePayorForm { get; set; }

        ////////////////////////////////// Banner  /////////   - Banner is removed; As per Kelly instead using Account FAQ PO going forward - 2/6/2017 = Raj

        [FindsBy(How = How.XPath, Using = "//*[@id='alert']/div[3]/a[1][contains(.,'create an account')]")]
        public IWebElement BannerCreateAccount { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='alert']/div[3]/a[2][contains(.,'managing beneficiaries online')]")]
        public IWebElement BannerManageBenes { get; set; }

        /////////////////////////////// Account FAQ //////////////

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'How do I create an account?')]")]
        public IWebElement HowDoICreateAccount { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'How do I change my Beneficiaries?')]")]
        public IWebElement HowDoIChangeBenes { get; set; }

        ////////////// Home Page ////////////////////

        //No Valid policy display pop up
        [FindsBy(How = How.Id, Using = "modal-dialog")]
        public IWebElement NoValidPolicyPopUp { get; set; }

        //No Valid policy text in Home Line 1
        [FindsBy(How = How.XPath, Using = "//*[@id='modal - dialog']/div[contains((Classname text(), 'modal-dialog-content'))]/p[1]/strong")]
        public IWebElement NoValidPolicyMsgLine1 { get; set; }

        //No Valid policy text in Home Line 2
        [FindsBy(How = How.XPath, Using = "//*[@id='modal - dialog']/div[contains((Classname text(), 'modal-dialog-content'))]/p[2][contains(Classname text(), 'errorTextDefaultFont')]")]
        public IWebElement NoValidPolicyMsgLine2 { get; set; }

        //No Valid policy text in Home Contac No.
        [FindsBy(How = How.XPath, Using = "//*[@id='modal - dialog']/div[contains(Classname text(), 'modal-dialog-content')]/div[contains(Classname text(), 'errorContactPhoneNumber')]")]
        public IWebElement NoValidPolicyMsgPhone { get; set; }

        //No Valid policy text in Home Availability time
        [FindsBy(How = How.XPath, Using = "//*[@id='modal - dialog']/div[contains(Classname text(), 'modal-dialog-content')]/div[2]")]
        public IWebElement NoValidPolicyMsgTime { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='modal - dialog']/div[contains((Classname text(), 'modal-dialog-header'))]/button")]
        public IWebElement NoValidPolicyClosebyCross { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class = 'standard-modal-close modal-dialog-close']")]
        public IWebElement NoPolicyClosePP { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//button[text()='Show']")]
        public IWebElement LoginShowBtn { get; set; }

        //Download Forms Text 
        [FindsBy(How = How.XPath, Using = "//li[contains(.,'Download Forms')]")]
        public IWebElement DownloadFormsSection { get; set; }

        //Download Forms Text 
        [FindsBy(How = How.XPath, Using = "//li[contains(.,'Questions?')]")]
        public IWebElement QuestionsSection { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(.,'Need help creating an account')]/span")]
        public IWebElement VideoLinkBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id = 'videoModal']//iframe[@class = 'embed-responsive-item']")]
        public IWebElement VideoLocator { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id = 'videoModal']//button[@class = 'close']")]
        public IWebElement CloseVideo { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@href ='/Account/Login' and text()='Continue']")]
        public IWebElement AccountConfirmationContinue { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(),'Welcom to the Customer Service Center!')]")]
        public IWebElement LoginPageHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(),'Make a one-time payment')]")]
        public IWebElement OneTimePaymentLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='txtUsername-error']")]
        public IWebElement EmptyUsername { get; set; }

        // [FindsBy(How = How.XPath, Using = "//h2[@class='h1 text-steel']/following-sibling::p[1]")]
        [FindsBy(How = How.XPath, Using = "//h2[@class='h1 text-steel']/parent::div")]        
        public IWebElement LoginGriefMsg { get; set; }

        //////////////Go Paperless Pop up ////////////////////

        [FindsBy(How = How.XPath, Using = "//*[@id=\"offermodalLabel\"]/span[contains(text(),'Go Paperless!')]")]
        public IWebElement GoPaperlessBannerHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id=\"offermodal\"]/div/div/div[1]/button/span/i")]
        public IWebElement GoPaperlessBannerXBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Access Denied')]")]
        public IWebElement AccessDeniedPage { get; set; }

        /// <summary>
        /// Login page load
        /// </summary>
        public void LoginPageLoad()
        {
            do
            {
                Thread.Sleep(6000);
            } while (NYLDSelenium.ElemExist("UI Load in progress", UiInProgress));
        }

        /// <summary>
        /// Method to login to the CSW application
        /// </summary>
        /// <param name="args"></param>
        public void Login(string args = "")
        {
            string msg = "";
            if (data[KeyRepository.SubFuntionality].Contains("Reset"))
                msg = "Reset login page";
            if (data[KeyRepository.SubFuntionality].Contains("Registration"))
                msg = "Registration login page";
            else
                msg = "login page";

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + msg + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Stage Workaround            
            //IWebElement loginHeader = LoginHeaderNewUser;
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);

            if (args == "ConfirmAccount")
                NYLDSelenium.Click("Account confirmation continue", AccountConfirmationContinue);
            Thread.Sleep(100);
            //Verify Page load
            NYLDSelenium.PageLoad("CSW Login", LoginHeaderNewUser);

            //Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);
            bool MockServicesEnabled = NYLDDigital.CheckMockServices();
            if(!MockServicesEnabled)
            {
                NYLDSelenium.ReportStepResult("Mock Services are not enabled", "Please reach out Automation team", "Fail", "always","yes");
            }
            //CLose Mock banner
            if (NYLDSelenium.ElemExist("Mock banner", CloseMockBanner, false, "no", "no", "no",30))
            NYLDSelenium.Click("Mock banner", CloseMockBanner);
            Thread.Sleep(1000);
            //Enter User Name and Password  

            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);

            // Show Button validation
            new CommonFunctions(data).ShowValidation("Login");

            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            //Check Remember Me
            if (args == "RememberMe")
            {
                NYLDSelenium.ReportStepResult("Remember me to uncheck", "INFO", "no");
                //NYLDSelenium.Click("Remember Me", RememberMe);
                js.ExecuteScript("document.getElementById('RememberMe').Click();");
            }
            else if (args == "NoRememberMe")
            {
                if (RememberMe.Selected)
                {
                    NYLDSelenium.ReportStepResult("Remember me to uncheck", "INFO", "no");
                    js.ExecuteScript("document.getElementById('RememberMe').Click();");
                }
                else
                    NYLDSelenium.ReportStepResult("Verify if Remember Me is checked", "Remember me is not selected.", "FAIL");
            }


            //Click Submit Button
            NYLDSelenium.Click("Login Button", LoginButton);
            Thread.Sleep(2000);
            GetinHomePage(args);
            if (data[KeyRepository.UserName] != "NOPolicyAsso" && !driver.Url.Contains("FailedViperStatusCheck") &&  args != "CyberFraudProtection" && args != "Rider" && args != "Exchange" && data[KeyRepository.ContractType] != "NoAssociatedPolicyContract" && (data[KeyRepository.ContractType] == "NonViperContract") &&  (data[KeyRepository.ContractType] != "NonViperContract365Days"))
            {
                HomePage homePage = new HomePage(driver, data);
                //Verify Page Load

                //Click on My account drop down and verify user name
                if (NYLDSelenium.GetAttribute("Account Panel", homePage.MyAccountDropDown, "aria-expanded") != "true")
                    NYLDSelenium.Click("My Account", homePage.MyAccountDropDown);
                Thread.Sleep(1000);
                var firstname = homePage.WelcomeUser.Text.ToLower().Trim();
                Thread.Sleep(1000);
                //Verify if Welcome Header is populated correctly
                if (args != "Payments" && data[KeyRepository.ContractType] != "NoAssociatedPolicyContract")
                    NYLDSelenium.VerifyText("Welcome Header", "welcome, " + data[KeyRepository.FirstName].ToLower().Trim(), firstname);
                Thread.Sleep(1000);
                //Click to Close MyAccount
                if (NYLDSelenium.GetAttribute("Account Panel", homePage.MyAccountDropDown, "aria-expanded") == "true")
                    NYLDSelenium.Click("My Account", homePage.MyAccountDropDown);
            }
        }

        public bool CreateAccountLogin(int count)
        {
            UserRegistrationDriver user = new UserRegistrationDriver(driver, data);

            if (!driver.Url.ToLower().Contains("login"))
            {
                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                Thread.Sleep(3000);
            }
            //Verify Page load
            NYLDSelenium.PageLoad("CSW Login", LoginHeaderNewUser, "onerror", "onerror");
            if (count == 0)
            {
                NYLDDigital.AcceptCookiesPreferences();
                Thread.Sleep(1000);
                bool MockServicesEnabled = NYLDDigital.CheckMockServices();
                if (!MockServicesEnabled)
                {
                    NYLDSelenium.ReportStepResult("Mock Services are not enabled", "Please reach out Automation team", "Fail", "always", "yes");
                }
                //CLose Mock banner
                if (NYLDSelenium.ElemExist("Mock banner", CloseMockBanner, false, "no", "onerror", "onerror", 15))
                    NYLDSelenium.Click("Mock banner", CloseMockBanner, false, "onerror", "onerror");
                Thread.Sleep(1000);
            }
            //Enter User Name and Password
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName], false, "onerror", "onerror");
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password], false, "onerror", "onerror");
            //Click Submit Button
            NYLDSelenium.Click("Login Button", LoginButton, false, "onerror", "onerror");
            Thread.Sleep(2000);
            if(NYLDSelenium.ElemExist("unable to verify your account", LoginGriefMsg, false, "no", "no", "no", 15))
            {
                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                Thread.Sleep(3000);
                return false;
            }
            OneTimeVerificationPage verificationPage = new OneTimeVerificationPage(driver, data);
            verificationPage.FillOneTimeCodeForTestData("999999");
            return true;
        }

        public void GetinHomePage(String args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            if (data[KeyRepository.UserName] == "Nocontractexists")
            {
                //skip to login
            }
            else
            {                
                // Verify the Auth page to enter OTP
                if (NYLDSelenium.ElemExist("Authendication Page", AccountVerificationTxt, false, "yes", "yes", "no", 15))
                {
                    if (args == "SMSOTP")
                    {                      
                        if (NYLDSelenium.ElemExist("SMS Device", devicetyperadio))
                        {
                            NYLDSelenium.Click("on verification code Submit", AccountVerificationSendToSelection);
                        }
                    }
                        driver.FindElement(By.XPath("//*[@id='field_verification_code']")).SendKeys("999999");
                        NYLDSelenium.Click("on verification code Submit", SubmitButton);
                }

                if (NYLDSelenium.ElemExist("Login Error", LoginError, false, "no", "no", "no", 15) || NYLDSelenium.ElemExist("Server Error", ServerError, false, "no", "no", "no", 1))
                    NYLDSelenium.ReportStepResult("Verify if user able to login successfully", "User failed to login -Please check and report to automation team.", "Fail", "always", "yes");

            }
            // Verify Go Paperless Pop up window
            if (NYLDSelenium.ElemExist("Go Paperless Popup", GoPaperlessBannerHeader, false, "no", "no", "no", 15))
                GoPaperlessBannerXBtn.Click();
        }

        public void LoginPageGriefMsg(string args)
        {
            Thread.Sleep(5000);
            Console.WriteLine("arguments are :" + args);

            string action = "";
            string body;
            TestData testData = new TestData(); 
            NYLDSelenium.AddHeader("Login Page Grief Msg ", "SubHeader");
            switch (args)
            {
                case "VIPERGriefMsg":
                    action = "ViperMorethan1Year";
                    body = "ViperMorethan1Year";
                    break;
                case "DisabledUserMessage":
                    action = "DisabledUserMessage";
                    body = "DisabledUserMessage";
                    break;
                case "NoContractGriefMsg":
                    action = "ContractNotInforce";
                    body = "ContractNotInforce";
                    break;
                default:
                    action = "UnableToVerifyMessage";
                    body = "UnableToVerifyMessage";
                    break;
            }
            CommonFunctions CF = new CommonFunctions(data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Grief Message for: " + action + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            NYLDSelenium.VerifyText("your account login request", CF.FormatString(testData.GetContent(body)).Trim(), CF.FormatString(NYLDSelenium.GetAttribute("your account login request Grief page", LoginGriefMsg)).Trim(), "always", "always");

            NYLDSelenium.AddHeader("Grief message verification ", "Success");
        }

        /// <summary>
        /// Method to verify Existing Login Credentials of CSW application
        /// </summary>
        /// <param name="args"></param>
        public bool? VerifyLoginCreds(string args = "")
        {
            bool? loginWorks = null;

            //Verify Page load
            NYLDSelenium.PageLoad("Login", LoginHeaderNewUser);

            //Enter User Name and Password  
            NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);

            //Click Submit Button
            NYLDSelenium.Click("Login Button", LoginButton);
            // Verify the Auth page to enter OTP
            if (NYLDSelenium.ElemExist("Authendication Page", AccountVerificationTxt, false, "yes", "no", "no", 30))
            {
                NYLDSelenium.SendKeys("send wild card OTP", AccountVerificationInput, "999999");
                NYLDSelenium.Click("on verification code Submit", SubmitButton);
            }

            CSW.PageObjects.Home.HomePage homePage = new CSW.PageObjects.Home.HomePage(driver, data);
            if (NYLDSelenium.ElemExist("Home Page", homePage.MyAccountDropDown, false, "no", "no", "no", 30))
            {
                // Verify Go Paperless Pop up window
                if (NYLDSelenium.ElemExist("Go Paperless Popup", GoPaperlessBannerHeader, false, "no", "no", "no", 10))
                    GoPaperlessBannerXBtn.Click();
                homePage.NavigateToPage(KeyRepository.LogoutPage);

                loginWorks = true;
            }
            else if (NYLDSelenium.ElemExist("Login Error", LoginError, false, "no", "no", "no", 10))
                loginWorks = false;
            else if(NYLDSelenium.ElemExist("Server Error", ServerError, false, "no", "no", "no", 1))
                NYLDSelenium.ReportStepResult("Verify if user able to login successfully", "User failed to login -Please check and report to automation team.", "Fail", "always", "yes");
            else if (NYLDSelenium.ElemExist("Server Error", unabletoverifyError, false, "no", "no", "no", 1))
                NYLDSelenium.ReportStepResult("Verify if user able to login successfully", "User failed to login -Please check and report to automation team.", "Fail", "always", "yes");

            return loginWorks;
        }

        public void ClickCreateAccount(string reportstopfor)
        {
            if (reportstopfor == "useraccounts")
                GetSettor.ReportEvent = "no";

            if (reportstopfor != "useraccounts")
            {
                string msg = data[KeyRepository.SubFuntionality].Contains("Registration") ? "Registration Page" : "Login Page";
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + msg + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            }

            //Verify Page load
            NYLDSelenium.PageLoad("Create User Accounts Login Page", LoginHeaderNewUser);

            // Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);

            //CLose Mock banner
            var result = driver.FindElements(By.XPath("//div[@id='-aarp-mock-footer'][contains(@style,'display: block')]")).Count;
            if (result == 1)
                NYLDSelenium.Click("Mock banner", CloseMockBanner);
            Thread.Sleep(500);
            //TODO:Investigate why Create Account Link is failing as not visible.
            NYLDSelenium.Click("Create Account Button", CreateAnAccountButton);
        }

        /// <summary>
        /// Method to Suspedn a new user by incorret paswrod attempts
        /// </summary>
        /// <param name="args"></param>
        public void SuspendUser(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Suspend User" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            RestServices webService = new RestServices(data);
            HomePage home = new HomePage(driver, data);

            string body = "You have exceeded the maximum number of log in attempts.To unlock your account please reset your password now or call.For immediate assistance, please contact New York Life at(800) 865-7927Monday - Friday: 8 a.m. to 8 p.m. (ET)";

            //Navigate to URL            
            driver.Url = data[KeyRepository.URL];


            //Verify if it is login page.
            NYLDSelenium.PageLoad("Login", LoginHeaderNewUser);
            bool loopcontinue = false;
            //Enter incorrect Password for 5 times
            for (int i = 0; i <6; i++)
            {
                if (loopcontinue == true)
                    break;

                NYLDSelenium.Click("UserName", UserName);
                NYLDSelenium.Clear("User Name", UserName);
                NYLDSelenium.Clear("Password", Password);

                //Enter UserName 
                NYLDSelenium.SendKeys("User Name", UserName, data[KeyRepository.UserName]);

                //Enter Password              
                NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password] + i);

                //Click continue
                NYLDSelenium.Click("Login", LoginButton);

                Thread.Sleep(100);
                if (NYLDSelenium.ElemExist("Disable Error Message ", SuspendUserMessage, false, "no", "no", "no", 20))
                {
                    NYLDSelenium.ElemExist("Please Call New York Life ", PleaseCallNYL);
                    NYLDSelenium.ElemExist("Disable Error Message ", SuspendUserMessage);
                    IWebElement we = driver.FindElement(By.XPath("//h2[contains(text(), 'Please Call')]/.."));
                    string c = we.Text.Replace("\r", "").Replace("\n", "").Trim();
                    c = c.Replace("Please Call New York Life", "");
                    NYLDSelenium.VerifyText("Please Call NYL Body Message ", body, c.Replace("\r", "").Replace("\n", "").Trim());
                    loopcontinue = true;
                }
            }

            //Click on AARP Logo
            if (NYLDSelenium.ElemExist("LoginLink", LoginLink, false, "no", "no", "no"))
                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            else
                driver.Navigate().Refresh();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: navigateHome                                                                               ////////////
        ////// Description: Navigate to home screen by Clicking on logo                                         ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
        public void NavigateHome()
        {
            //Click AARP Logo
            if (NYLDSelenium.ElemExist("AARP Logo", AARPLogo, false, "no", "no", "no"))
                NYLDSelenium.Click("AARP Logo", AARPLogo);

            driver.Navigate().GoToUrl(data[KeyRepository.URL]);

            //Verify if it is login page
            NYLDSelenium.PageLoad("Home", LoginHomeLink);
            if (NYLDSelenium.ElemExist("Login Link on Home page", LoginHomeLink, false, "no", "no", "no"))
                NYLDSelenium.Click("LoginLink", LoginLink);

            if (!NYLDSelenium.ElemExist("Login Submit Button", LoginButton, false, "no", "no", "no"))
                NYLDSelenium.ReportStepResult("Verify if Login Page is displayed", "Login Page is not displayed", "FAIL");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: NavigateOneTimePayment                                                                     ////////////
        ////// Description: Navigate to One Time Payment                                                        ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void NavigateOneTimePayment(string args)
        {
            NYLDSelenium.PageLoad("Login", LoginPageHeader);

            NYLDSelenium.Click("One Time Payment Link", OneTimePaymentLink);
        }

        public void ClickCreateAccountForRegistration()
        {
            //Verify Page load
            NYLDSelenium.PageLoad("Login", LoginHeaderNewUser, "no", "no");

            //CLose Mock banner
            var result = driver.FindElements(By.XPath("//div[@id='-aarp-mock-footer'][contains(@style,'display: block')]")).Count;
            if (result == 1)
                NYLDSelenium.Click("Mock banner", CloseMockBanner, true, "no", "no");

            //TODO:Investigate why Create Account Link is failing as not visible.
            NYLDSelenium.Click("Create Account Button", CreateAnAccountButton, true, "no", "no");
        }

        public void VerifyLSPEmaildetails(string args)
        {
            LSPDatabase db = new LSPDatabase(driver, data);
            db.GetDataBaseValues("queryEmail");
            if (!db.queryResultList[0]["ELEMAL"].ToString().Trim().Contains(data[KeyRepository.EmailId]))
                NYLDSelenium.ReportStepResult("Verify if LSP EMailId is not match", "Verify if LSP EMailId :" + db.queryResultList[0]["ELEMAL"].ToString().Trim() + " is not match with expected:" + data[KeyRepository.EmailId], "FAIL");
            else
                NYLDSelenium.ReportStepResult("Verify if LSP EMailId is  match with records", "Verify if LSP EMailId :" + db.queryResultList[0]["ELEMAL"].ToString().Trim() + " is match with expected:" + data[KeyRepository.EmailId], "PASS");
        }

        public void ClickForgotUserName()
        {
            //Verify Page load
            NYLDSelenium.PageLoad("Login", LoginHeaderNewUser);
            // Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);
            //CLose Mock banner
            var result = driver.FindElements(By.XPath("//div[@id='-aarp-mock-footer'][contains(@style,'display: block')]")).Count;
            if (result == 1)
                NYLDSelenium.Click("Mock banner", CloseMockBanner);
        
            NYLDSelenium.Click("Forgot Username", ForgotUsernamelnk);
        }

        public void ClickForgotPassword()
        {
            //Verify Page load
            NYLDSelenium.PageLoad("Login", LoginHeaderNewUser);

            // Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);
            //CLose Mock banner
            var result = driver.FindElements(By.XPath("//div[@id='-aarp-mock-footer'][contains(@style,'display: block')]")).Count;
            if (result == 1)
                NYLDSelenium.Click("Mock banner", CloseMockBanner);
         
            NYLDSelenium.Click("Forgot Password", ForgotPasswordlnk);
        }


        public void BtnClick(string display, IWebElement elemetdata, string element, Dictionary<string, string> data)
        {
            //NYLDSelenium.ScrollToView(elemetdata, true);
            NYLDSelenium.Click(display, elemetdata, true);
        }
    }
}
