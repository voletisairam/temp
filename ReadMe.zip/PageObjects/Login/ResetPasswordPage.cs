﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Text;
using System.Threading.Tasks;
using CSW.Common.Others;
using CSW.Common.DataBase;
using CSW.Common.Email;
using NYLDWebAutomationFramework;
using System.Threading;
using CSW.PageObjects.Registration;
using CSW.Common.Services;
using CSW.PageObjects.Home;
using CSW.Common.Excel;
using CSW.PageObjects.NewRegistration;
using CSW.Drivers;

namespace CSW.PageObjects.Login
{
    class ResetPasswordPage
    {
        private static IWebDriver driver;
        private Dictionary<string, string> data;
        public static string[] pinCode = new string[6];

        public ResetPasswordPage(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 
        /// 
        /// </summary>
        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement LastName { get; set; }

        //Last Name
        [FindsBy(How = How.Id, Using = "txtDateOfBirth")]
        public IWebElement DOB { get; set; }

        //SSN
        [FindsBy(How = How.Id, Using = "LastFourSsn")]
        public IWebElement SSN { get; set; }


        [FindsBy(How = How.XPath, Using = "(//span[@class='field-validation-error'])[1]")]
        public IWebElement ErrorPopupMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='login-form']//following::div/a/u[contains(text(),'Forgot password?')]")]
        public IWebElement ForgotPasswordLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//form[@action='/Account/Reset']/ancestor::div[@class='row']//h2[contains(text(), 'Reset your password')]")]
        public IWebElement ResetPasswordHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//form[@action='/Account/Reset']/../h1[contains(text(), 'Enter the Email')]")]
        public IWebElement ResetPasswordInstructions { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtEmail']")]
        public IWebElement Email { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtEmail']/following-sibling::span")]
        public IWebElement EmailFieldValidationError { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Continue')]")]
        public IWebElement ResetContinue { get; set; }
        [FindsBy(How = How.XPath, Using = "//button[@type='submit' and contains(text(), 'Save')]")]
        public IWebElement ResetSave { get; set; }


        [FindsBy(How = How.XPath, Using = "//li[@class='nav-item']/a[@data-ea-cta-link='Log in']")]
        public IWebElement LoginButton { get; set; }        

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'request a new code')]")]
        public IWebElement ReSendCode { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id = 'newOTPreq']")]
        public IWebElement ReSendCodeMsgSuccess { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[text()= 'Submit'] | //button[@type= 'submit']")]
        public IWebElement Submit { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[text()='Verify your identity']")]
        public IWebElement VerificationTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//h1[contains(text(), 'Account verification')]/../p")]
        public IWebElement VerNotificationText1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//form[@action='/Account/Reset']/../h1")]
        public IWebElement VerPasswordInd { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@href='/Account/Reset']/..")]
        public IWebElement VerNotificationText2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id = 'txtOtp']")]
        public IWebElement Otp { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'Update your password')]")]
        public IWebElement NewPasswordPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(text(), 'almost there!')]")]
        public IWebElement NPInstructionsUI { get; set; }

        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Create your new password.')]")]
        public IWebElement ResetPageSubheader { get; set; }

        [FindsBy(How = How.XPath, Using = "//h4[contains(text(),'Update your password')]")]
        public IWebElement ResetPageheader { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(text(), 'Username')]/../strong")]
        public IWebElement NPUserNameUI { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='txtPassword']")]
        public IWebElement LabelPassword { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='txtConfirmPassword']")]
        public IWebElement LabelConfirmPassword { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='cswm-reset-form']/h2[text()='New Password']")]
        public IWebElement PMNewPasswordPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//h2[contains(text(), 'New Password')]/../p")]
        public IWebElement NPInstructionsUI_PM { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(text(), 'Username')]/../../dd")]
        public IWebElement NPUserNameUI_PM { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='Password']")]
        public IWebElement LabelPassword_PM { get; set; }

        [FindsBy(How = How.Id, Using = "Password")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Id, Using = "ConfirmPassword")]
        public IWebElement CurrentPassword { get; set; }

        [FindsBy(How = How.Id, Using = "NewPassword")]
        public IWebElement NewPassword { get; set; }

        [FindsBy(How = How.Id, Using = "PwdSubmit")]
        public IWebElement PwdSubmit { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[@for='ConfirmPassword']")]
        public IWebElement LabelConfirmPassword_PM { get; set; }

        [FindsBy(How = How.Id, Using = "ConfirmPassword")]
        public IWebElement ConfirmPassword { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='col csw-form-margin']")]
        public IWebElement SuccessNewPasswordScreen { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='col csw-form-margin']/h2")]
        public IWebElement LabelSuccess { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='col csw-form-margin']/p")]
        public IWebElement SuccessMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@data-valmsg-for='Otp']")]
        public IWebElement InvalidPINMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='ContinueButton' and contains(text(),'My account')]")]
        public IWebElement MyacctBtn { get; set; }

        //Password field pop up message
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']//following::span[1]/span")]
        public IWebElement PasswordFieldValidationPopUP { get; set; }

        //Confirm Password field pop up message
        [FindsBy(How = How.XPath, Using = "//input[@id='ConfirmPassword']//following::span[1]/span")]
        public IWebElement ConfirmPwDFieldValidationPopUP { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class= 'validation-summary-errors']")]
        public IWebElement SummaryPwDFieldValidationPopUP { get; set; }

        //Confirm Password User Name
        [FindsBy(How = How.XPath, Using = "//*[@id='reset3Form']/div[3] | //*[@class='form-group'][1]")]
        public IWebElement UsernameConfirmPwdPage { get; set; }

        //Email field pop up message
        [FindsBy(How = How.XPath, Using = "//*[@id='Email']/../span[contains(@class,'field-validation-error')]/span | //div[@class='form-group' and contains(., 'Email')]//*[@class='cswm-label-error']")]
        public IWebElement EmailFieldValidationPopUP { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='field-validation-error' and @data-valmsg-for='Otp']")]
        public IWebElement ErrormessagepopupForOTP { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//button[text()='Show']")]
        public IWebElement SSNShowBtn { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//input[@id='Password']/following-sibling::div/button[text()='Show']")]
        public IWebElement PwdShowBtn { get; set; }

        //Show Login Button 
        [FindsBy(How = How.XPath, Using = "//input[@id='ConfirmPassword']/following-sibling::div/button[text()='Show']")]
        public IWebElement ConfirmPwdShowBtn { get; set; }

        public string Errormessagecontent = "The information provided does not match our records.";

        public string ErrormessageOTPcontent = "You've entered an invalid code. Please enter the code from your email or click the link below to resend a new 6-digit code.";

        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////          Methods    ////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////


        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: requestPasswordOption                                                                       ////////////
        ////// Description: Reset password for the user                                                         ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         

        //TODO: Lets rename method relavently
        public void RequestResetPasswordPage(string args)
        {
            LoginPage LP = new LoginPage(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            VerifyYourDetailsPage verifyDetails = new VerifyYourDetailsPage(driver, data);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "ResetPassword Option - New Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Login Page    
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            NYLDSelenium.PageLoad("Login", LP.LoginHeaderNewUser);

            // Cookies preferance popup
            NYLDDigital.AcceptCookiesPreferences();
            Thread.Sleep(1000);
            //CLose Mock banner  
            //TODO: Ensure mock banner is closed at the beginning and remove all other places
            if (NYLDSelenium.ElemExist("Mock banner", LP.CloseMockBanner,false, "no", "no" ,"no"))
                NYLDSelenium.Click("Mock banner", LP.CloseMockBanner);

            //Click Forgot password link
            NYLDSelenium.Click("Forgot UserName or Password", ForgotPasswordLink);

            //Fill Owner Details
            verifyDetails.ForgotOwnerDetailsPage("");
        }

        /// <summary>
        /// Method helps to Reest password with Valid/Invalid/Resend/PinExpired
        /// </summary>
        /// <param name="action"></param>
        public void RequestPasswordOptions(string action = "")
        {
            //Verify Content
            TestData testData = new TestData();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verification - Reset Password for :"+ action + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
        

            if (action == "ResendCode")
            {
                NYLDSelenium.Click("Resend Code", ReSendCode);
                Thread.Sleep(10000);
                GetEnterPinCode("Valid");
            }
            else if (action == "ValidPIN")
            {
                Thread.Sleep(10000);
                GetEnterPinCode("Valid");
            }
            else if (action == "PinCodeExpired")
            {
                //Enter the One-Time code
                GetEnterPinCode("Valid");
                Thread.Sleep(900000);
            }
            else if (action == "Default")
            {
               GetEnterPinCode("Default");
            }
            else
            {
                GetEnterPinCode("Invalid");
            }
            NYLDSelenium.Click("Continue", ResetContinue,false,"always","always");

            //highlighted the continue button and not clicking- then reuse the below condition
            if (NYLDSelenium.ElemExist("Resend Code", ReSendCode,false,"no","no","no"))
                NYLDSelenium.Click("Continue", ResetContinue, false, "no", "no");
        }

        /// <summary>
        /// Method helps to get the pincode from email / defauly / invalid pin enters in otp
        /// </summary>
        /// <param name="option"></param>
        private void GetEnterPinCode(string option)
        {
            EmailVerification email = new EmailVerification(driver, data);
            NYLDSelenium.SendKeys("OTP", Otp, "999999",false,"no","no");
            NYLDSelenium.Clear("OTP", Otp);
            NYLDSelenium.Click("Activate OTP", Otp,false,"no","no");

            string invalidpin = ""
;            if (option == "Valid")
            {
                string oneTimeCode = null;
                oneTimeCode = email.GetOneTimeCodeFromValidEMail();NYLDSelenium.SendKeys("OTP", Otp, oneTimeCode);
            }
            else if (option == "Default")
            {
                NYLDSelenium.SendKeys("OTP", Otp, "999999");
            }
            else if (option == "Invalid")
            {
                //Enter the One-Time code
                invalidpin = CSWData.TempInvalidPIN;
                if (string.IsNullOrEmpty(invalidpin))
                    invalidpin = "123456";          
                
                NYLDSelenium.SendKeys("OTP", Otp, invalidpin); 
                NYLDSelenium.Click("Activate OTP", Otp, false, "no", "no");
            }
        }

        public void EnterNewPassword(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            Random random = new Random();
            string hp1 = random.Next(100, 9999).ToString();
           
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verification screen for Update Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            NYLDSelenium.PageLoad("Create your New Password screen", NewPasswordPage);

            //Verify Content            
            string npInstructionsText = testData.GetContent("ResetPassword - New Password Instructions").Replace("\r", "").Replace("\n", "").Trim();

            NYLDSelenium.VerifyText("Label New password", "New password", LabelPassword.Text, "yes");
            NYLDSelenium.VerifyText("Label Confirm new password", "Confirm new password", LabelConfirmPassword.Text, "yes");

            //Previous password storage in keyvalue
            data.TryGetValue(KeyRepository.PrevPassword, out string PrevPassword);
            if (!string.IsNullOrEmpty(PrevPassword))
                data[KeyRepository.PrevPassword] = string.Concat(",", data[KeyRepository.PrevPassword] + "," + data[KeyRepository.Password]);
            else
                data[KeyRepository.PrevPassword] = data[KeyRepository.Password];
           
            //Entering New Password and Confirm

            data[KeyRepository.Password] = "2W3e4r5t" + hp1+"*";
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Re-enter Password", ConfirmPassword, data[KeyRepository.Password]);

            // Show Button validation
            CF.ShowValidation("Password");

            NYLDSelenium.Click("Save", ResetSave);
        }

        public void VerifyPrevious10PasswordsGriefMessage(string args)
        {
          
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            string[] getpwds = null;

            getpwds= data[KeyRepository.PrevPassword].Split(',');
            //Verify Content            
            string npInstructionsText = testData.GetContent("ResetPassword - New Password Instructions").Replace("\r", "").Replace("\n", "").Trim();
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Previous Passwords GriefMessage" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            Console.WriteLine(getpwds);
            Thread.Sleep(1000);
            NYLDSelenium.VerifyText("Verification - New Password Instructions", npInstructionsText, NYLDSelenium.GetAttribute("New Password Instructions", NPInstructionsUI, "text").Replace("\r", "").Replace("\n", "").Trim());

           
                          
                //to check only tenth password cant accept , if other than 10th password it should display the new password screen
                //Previous password cant accept to reset - expecting a grif message
                if (!string.IsNullOrEmpty(data[KeyRepository.Password]))
                {
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Green\">" + "Verify Previous Password Couldnt accept to save:" + data[KeyRepository.Password] + "</h3>", "<h3 style=\"color:Green\">" + "###########" + "</h3>", "INFO", "no");
                    NYLDSelenium.Clear("Password", Password, 5);
                    NYLDSelenium.Clear("Re-enter Password", ConfirmPassword, 5);

                    NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);
                    NYLDSelenium.SendKeys("Re-enter Password", ConfirmPassword, data[KeyRepository.Password]);
                    NYLDSelenium.Click("Save", ResetSave, false, "always");
                    Thread.Sleep(3500);
                    NYLDSelenium.VerifyText("Verification -Previous password Enter", "The password entered does not meet length, complexity or history requirements.", NYLDSelenium.GetAttribute("Verification -Previous password Enter", ErrorPopupMessage, "text"),"always","always");
                }
            

            //continue the create a new password before to clean up the text box
            NYLDSelenium.Clear("Password", Password, 5);
            NYLDSelenium.Clear("ConfirmPassword", ConfirmPassword, 5);
        }
       
        public void EnterNewPassword_PM(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testData = new TestData();
            IWebElement ResetNewPasswordPage = null;
            Random random = new Random();
            string hp1 = random.Next(100, 999).ToString();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verification screen for New Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
           
            //Set the Page based on link generated by Profile Maintenance or user password reset
            if (args == "PM")
                ResetNewPasswordPage = PMNewPasswordPage;
            else
                ResetNewPasswordPage = NewPasswordPage;

            Thread.Sleep(5000);
            NYLDSelenium.PageLoad("New Password screen", ResetNewPasswordPage);

            //Verify Content            
            string npInstructionsText = (testData.GetContent("ResetPassword - PM New Password Instructions") + data[KeyRepository.UserName]).Replace("\r", "").Replace("\n", "").Trim();
            string npInstructionsUIText = (NPInstructionsUI_PM.Text + NPUserNameUI_PM.Text).Replace("\r", "").Replace("\n", "").Trim();
            NYLDSelenium.VerifyText("Verification - New Password Instructions", npInstructionsText, npInstructionsUIText, "yes");
            NYLDSelenium.VerifyText("Label Password", "Password", LabelPassword_PM.Text, "yes");
            NYLDSelenium.VerifyText("Label Re-enter Password", "Re-enter Password", LabelConfirmPassword_PM.Text, "yes");
            //CF.BlueBoxValidation("Questions?");

            //Entering New Password and Confirm
            data[KeyRepository.Password] = data[KeyRepository.Password] + hp1;
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Re-enter Password", ConfirmPassword, data[KeyRepository.Password]);

            // Show Button validation
            CF.ShowValidation("Password");

            NYLDSelenium.Click("Save", ResetSave);
        }


        //TODO: ActionVerb
        public void SuccessNewPassword(string args = "")
        {         
            HomePage homePage = new HomePage(driver, data);
            ForgotPage forgotpassword = new ForgotPage(driver, data);
            LoginDriver login = new LoginDriver(driver, data);
            if (args == "")
            {
                NYLDSelenium.PageLoad("Home", homePage.MyAccountDropDown);
            }
            else
            {
                forgotpassword.VerifyForgotPasswordResultPage();
              // login.Login("");
            }
        }



        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getPinFieldValidationMessages                                                              ////////////
        ////// Description: Get error validation messages for the fields                                        ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void GetPinFieldValidationMessages(string fldName, out IWebElement fieldName, out IWebElement fieldPopUp, out string blankmsg, out string message, out int maxlength, out string data)
        {
            switch (fldName)
            {
                case "Password":
                    fieldName = Password;
                    fieldPopUp = PasswordFieldValidationPopUP;
                    blankmsg = "Please enter your password.";
                    message = "";
                    maxlength = 17;
                    data = ";BLNK";
                    break;

                case "ConfirmPassword":
                    fieldName = ConfirmPassword;
                    fieldPopUp = ConfirmPwDFieldValidationPopUP;
                    blankmsg = "Must enter password.";
                    message = "Your passwords must match.";
                    maxlength = 17;
                    data = ";CHNG|BLNK";
                    break;

                default:
                    fieldName = ConfirmPassword;
                    fieldPopUp = ConfirmPwDFieldValidationPopUP;
                    blankmsg = "";
                    message = "";
                    maxlength = 17;
                    data = "";
                    break;
            }
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: verifyPasswordField                                                                         ////////////
        ////// Description: Password field validation                                                           ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void ValidatePasswordFields()
        {
            TestData testData = new TestData();
            string[] PasswordField = { "Password", "ConfirmPassword" };
            NYLDSelenium.AddHeader("Verify Password Field Test data Validation", "mainheader");
            NYLDSelenium.PageLoad("New Password screen", ConfirmPassword);

            Thread.Sleep(3000);
            NYLDSelenium.AddHeader("Verify Password Field Validation", "SubHeader");
            for (int i = 0; i < PasswordField.Count(); i++)
            {
                GetPinFieldValidationMessages(PasswordField[i], out IWebElement fieldName, out IWebElement fieldPopUp, out string blankmsg, out string message, out int maxlength, out string data);              
                string InvalidDataString = data.Split(';')[1];
                string[] InvalidData = InvalidDataString.Split('|');
                string expMessage;
                for (int j = 0; j < InvalidData.Count(); j++)
                {
                    NYLDSelenium.Clear("Password field", Password);
                    NYLDSelenium.Clear("Re-enter Password field", ConfirmPassword);
                    if (InvalidData[j] == "BLNK")
                    {
                        NYLDSelenium.SendKeys("Password", fieldName, "");
                        NYLDSelenium.SendKeys("Re-enter Password", ConfirmPassword, "");
                        expMessage = blankmsg;
                    }
                    else if (InvalidData[j] == "CHNG")
                    {
                        NYLDSelenium.SendKeys("Password", Password, "Test*Value*1");
                        NYLDSelenium.SendKeys("Re-enter Password", fieldName, "Value*Test*1");
                        expMessage = message;
                    }
                    else
                    {
                        expMessage = "";
                    }
                    NYLDSelenium.Click("Save", ResetSave);
                    string uiexpMessage = NYLDSelenium.GetAttribute("Get pop up Text", fieldPopUp).Replace("\r", "").Trim();
                    NYLDSelenium.VerifyText("Verify field validation pop up", expMessage.Trim(), uiexpMessage, "yes");
                }
            }
            NYLDSelenium.AddHeader("Verify Password Field Validation", "Success");

            NYLDSelenium.Clear("Password field", Password);
            NYLDSelenium.Clear("Re-enter Password field", ConfirmPassword);
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SetPasswordReset                                                                            ////////////
        ////// Description: Reset new password for the user                                                     ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public void SetPasswordReset(string args)
        {
            LoginPage LP = new LoginPage(driver, data);
            RestServices webServices = new RestServices(data);
            //ChangePayor CP = new ChangePayor(driver);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Complete Password Reset" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Verify Reset Password Page
            NYLDSelenium.PageLoad("Reset Password", ResetPasswordHeader);

            // Verify UserName
            NYLDSelenium.VerifyText("Actual UserName", data[KeyRepository.UserName], UsernameConfirmPwdPage.Text.Replace("Username:", "").Trim(), "yes");

            data[KeyRepository.Password] = data[KeyRepository.Password] + "*1";//*to be checked

            //Set Trigger Time
            CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-15);

            // Enter New Password
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);

            // Confirm New Password
            NYLDSelenium.SendKeys("Confirm password", ConfirmPassword, data[KeyRepository.Password]);

            //Click Submit
            NYLDSelenium.Click("Continue", Submit);
            //CP.WaitForUpdate(CP.Updateinprogress);

            EmailVerification OE = new EmailVerification(driver, data);
            OE.VerifyEmailInbox("Password Confirmation");

            if (args.Trim() != "SuspUser")
                NYLDSelenium.VerifyText("verify Bad password count", "0", webServices.SubmitRestCall("BadPasswordCount").Trim(), "yes");

            //Success page load
            NYLDSelenium.PageLoad("Success New Password", LP.SuccessNewPwd);

            // Verify Success Message
            NYLDSelenium.VerifyText("Message New Pwd", "Your password has been changed. You can now access your account.", LP.MsgNewPwd.Text.Trim(), "yes");

            NYLDSelenium.Click("Go to My Account", LP.BtnGoMyacct);

            //Verify home page load
            NYLDSelenium.PageLoad("Home", LP.HomePageHeader);
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: CyberFraudGenericMessage                                                                   ////////////
        ////// Description: Error message for reset password                                                    ////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void CyberFraudGenericMessage(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Grief Message" + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            Thread.Sleep(3000);
            NYLDSelenium.VerifyText("Verify cyber fraud message for Invalid Email", "The information provided does not match our records.", NYLDSelenium.GetAttribute("Invalid Email pop up message", EmailFieldValidationPopUP).Trim(), "yes");
        }
        
        public void ValidatePasswordComplexity(string args)
        {
            //Clicking on password show button to show password content
            NYLDSelenium.Click("Password Show", PwdShowBtn);
            NYLDSelenium.Click("Re-enter Password Show", ConfirmPwdShowBtn);

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Password Complexity Validation" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");


            string[] reqPwdText = { "Passwords must contain:", "1 lowercase letter", "1 uppercase letter", "1 number", "1 special character(!@#$%^&*)", "At least 8 characters" };
            string[] testInputs = { "PASSWORD*1", "password*1", "Password*", "Passw0rd", "Pasw0r*" };

            if (args != "test")
            {
                NYLDSelenium.Click("Password", Password);

                string expErrorClass = "cswm-pwd text-error";
                string expSuccessClass = "cswm-pwd text-success";

                //Validation default requirements
                NYLDSelenium.AddHeader("Password requirement " , "SubHeader");
                for (int i = 1; i < reqPwdText.Count(); i++)
                    NYLDSelenium.VerifyText("Text: " + i, reqPwdText[i - 1], NYLDSelenium.GetWE("//li[@class = 'cswm-pwd-complexity'][" + i + "]").Text);
                NYLDSelenium.AddHeader("Password requirement ", "Success");


                for (int i = 2; i <= reqPwdText.Count(); i++)
                {
                    NYLDSelenium.AddHeader("Missed requirement", "SubHeader");
                    NYLDSelenium.Clear("Password", Password);

                    NYLDSelenium.SendKeys("Password combination without: " + reqPwdText[i - 1], Password, testInputs[i - 2]);

                    NYLDSelenium.VerifyText("Requirement did not met", expErrorClass, NYLDSelenium.GetWE("//li[@class = 'cswm-pwd-complexity'][" + i + "]/span").GetAttribute("class").ToString());
                    NYLDSelenium.AddHeader("Missed requirement ", "Success");

                    NYLDSelenium.AddHeader("Success requirements", "SubHeader");
                    for (int j = 2; j <= reqPwdText.Count(); j++)
                    {
                        if (i != j)
                            NYLDSelenium.VerifyText("Requirement did met", expSuccessClass, NYLDSelenium.GetWE("//li[@class = 'cswm-pwd-complexity'][" + j + "]/span").GetAttribute("class").ToString());
                    }
                    NYLDSelenium.AddHeader("Success requirements", "Success");
                }
                NYLDSelenium.Clear("Password", Password);

            }
            else
            {
                string expRequirements = "Passwords must contain:\r\n● 1 lowercase letter\r\n● 1 uppercase letter\r\n● 1 number\r\n● 1 special character(!@#$%^&*).\r\n● At least 8 characters";
                //NYLDSelenium.ScrollToView(CurrentPassword);
                NYLDSelenium.SendKeys("Current Password", CurrentPassword, data[KeyRepository.Password]);


                for (int i = 2; i <= reqPwdText.Count(); i++)
                {
                    NYLDSelenium.Clear("New Password", NewPassword);

                    NYLDSelenium.AddHeader("Requirements Message", "SubHeader");
                    NYLDSelenium.SendKeys("Password combination without: " + reqPwdText[i - 1], NewPassword, testInputs[i - 2]);

                    NYLDSelenium.Click("Submit", PwdSubmit);

                    string actRequirements = NYLDSelenium.GetWE("//span[@for='NewPassword']").Text;

                    NYLDSelenium.VerifyText("Requirements for Password", expRequirements, actRequirements);
                    NYLDSelenium.AddHeader("Requirements Message", "Success");
                }

                NYLDSelenium.Clear("New Password", NewPassword);
                NYLDSelenium.Clear("Current Password", CurrentPassword);
            }

            //Clicking on password show button to hide password content
            NYLDSelenium.Click("Password Show", PwdShowBtn);
            NYLDSelenium.Click("Re-enter Password Show", ConfirmPwdShowBtn);
        }

            
        public void UpdateNewPassword()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verification screen for Update Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            NYLDSelenium.PageLoad("Update your password", ResetPageSubheader);
            Random random = new Random();
            string hp1 = random.Next(100, 9999).ToString();
            NYLDSelenium.VerifyText("Label Password", "New password", LabelPassword.Text);
            NYLDSelenium.VerifyText("Label Re-enter Password", "Confirm new password", LabelConfirmPassword.Text);

            //Entering New Password and Confirm
            data[KeyRepository.Password] = "2W3e4r5t" + hp1 + "*";
            NYLDSelenium.SendKeys("Password", Password, data[KeyRepository.Password]);
            NYLDSelenium.SendKeys("Re-enter Password", ConfirmPassword, data[KeyRepository.Password]);
            NYLDSelenium.Click("Save", ResetSave);
        }


        public void GetValidEmail()
        {
            TestData testData = new TestData();
            if (!new TestData().GetValidEmail(driver, data))
            {
                NYLDSelenium.ReportStepResult("Use Valid EMail for Registration /Reset Password", "Valid EMail is not available hence stoping the test execution. Report to devops automation team", "FAIL", "no", "yes");
            }
        }


        /// <summary>
        /// Method helps to verify Grief message- Owner Details page via Reset password
        /// </summary>
        /// <param name="args"></param>
        public void VerifyGriefMessage(string args)
        {
            TestData testData = new TestData();
          
            if (args == "PinCodeExpired")
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your identity - Grief Message PopUp for:" + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                NYLDSelenium.VerifyText("Verify OTP confirmaiton for PIN Code Expired after 10 Min", testData.GetContent("ResetPassword - Invalid PIN Msg").Trim(), NYLDSelenium.GetAttribute("Invalid PIN", InvalidPINMsg).Trim(),"always","always");
            }
            else if (!string.IsNullOrEmpty(args))
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your identity - Grief Message PopUp for:" + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                NYLDSelenium.VerifyText("Verify OTP confirmaiton ", ErrormessageOTPcontent.Replace("\r", "").Replace("\n", "").Trim(), NYLDSelenium.GetAttribute("Verify OTP Grief Message ", ErrormessagepopupForOTP, "text").Replace("\r", "").Replace("\n", "").Trim(), "always", "always");
            }  
            else
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify your identity - Grief Message PopUp for InvalidPIN" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                NYLDSelenium.VerifyText("Verify OTP confirmaiton for Invalid PIN", testData.GetContent("ResetPassword - Invalid PIN Msg").Trim(), NYLDSelenium.GetAttribute("Invalid PIN", InvalidPINMsg).Trim(), "always", "always");

            }
            //Adding delay here, because if there is another OTP atleast its need a delay to get the new OTP
            Thread.Sleep(90000);
        }


    }
}
