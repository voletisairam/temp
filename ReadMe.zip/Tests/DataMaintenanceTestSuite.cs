﻿
namespace CSW
{
    using System;
    using NUnit.Framework;
    using NYLDWebAutomationFramework;
    using CSW.Common.Excel;
    using System.Collections.Generic;
    using CSW.Common.Others;
    using CSW.Drivers;
    using OpenQA.Selenium;
    using System.Web.Services;
    using CSW.Common.DataBase;
    using CSW.Common.Services;
    using System.Diagnostics.Contracts;

    public class DataMaintenanceTestSuite : WebBrowser
    {
        public static Dictionary<string, string> data;
        public static DateTime date = new DateTime();
        public static string TestCaseIDInfo = "";
        TestSetUp testSet = new TestSetUp();

        //DataManagement - Create User Accounts / Exisitng Contracts Status / Exisitng User Accounts Status
        //Added the new testcase for making payments
        [Test, TestCaseSource("DataMaintenanceTestCasesList")]
        public void DataMaintenanceTestCases(string TestCaseID)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            data = testSet.InitializeTestData(TestCaseID);

            //Back up Application File and Exsisting User Account File
            string newUserAccountSheet = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.NewUserAccountSheet;
            string existingUserAccountSheet = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataPath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet;
            string destinationpath = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataRestore;
            NYLDGeneric.CopyFile(newUserAccountSheet, destinationpath + Properties.Settings.Default.NewUserAccountSheet, true);
            NYLDGeneric.CopyFile(existingUserAccountSheet, destinationpath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet, true);

            data[KeyRepository.Status] = "TestCaseID";
            //Create user accounts / Status of existing User Accounts / Status of Contracts
            switch (TestCaseID)
            {
                case "DM_Create_new_user_account":
                    new TestData().CreateNewUserAccounts(driver, data);
                    break;
                case "DM_Verify_contracts_status":
                   int count= new TestData().GetStatusOfTestContracts(driver, data);
                    if (count == 0)
                    {
                        NYLDSelenium.ReportStepResult("Verify Existing Contracts status , In **All Existing Contract** sheet the miss match status are highlited with colors", "Exisiting contract's status are same as expected", "PASS", "no");
                        data[KeyRepository.Status] = "Exisiting contract's status are same as expected";
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("Verify Existing Contracts status , In **All Existing Contract** sheet the miss match status are highlited with colors", "Miss Match Contracts Count :" + count, "INFO", "no", "no");
                        data[KeyRepository.Status] = "Miss Match Contracts Count :" + count;
                    }
                    break;
                case "DM_Verify_existing_user_accounts":
                    new TestData().VerifyExistingUserAccountsSheetCreds(driver, data);
                    break;
                case "DM_MakePayment":                   
                    new TestData().MakePayment(driver, data);
                    break;
                case "DM_UpdateValidEmail":
                    new TestData().UpdateValidEmailId(driver, data);
                    break;
                case "DM_PaperlessOptIn":
                    new TestData().PaperlessOptIn(driver, data);
                    break;
            }
        }


        [TearDown()]
        public void Dispose()
        {
            testSet.ResetData();
            //Relese com object
            TestData testData = new TestData();
            testData.ReleaseExcelObjects();
            //Close the browser
            Close();
            List<string> processes = new List<string> { "chromedriver", "chrome", "EXCEL", "Microsoft Excel" };
            NYLDGeneric.KillProcesses(processes);
            //Publish Test result and Test data info
            string[] resultData = new string[] { KeyRepository.Status };
            NYLDGeneric.PublishTestResult(data, resultData);
        }
            #region --Testscripts
            static readonly object[] DataMaintenanceTestCasesList =
        {
            new object[] {"DM_Create_new_user_account"},
            new object[] {"DM_Verify_contracts_status"},
            new object[] {"DM_Verify_existing_user_accounts"},
            new object[] {"DM_MakePayment" },
            new object[] {"DM_UpdateValidEmail" },
             new object[] { "DM_PaperlessOptIn" }
        };
        #endregion
    }
}
