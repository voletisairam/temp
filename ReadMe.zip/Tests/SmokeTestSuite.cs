﻿
namespace CSW
{
    using CSW.Common.Excel;
    using CSW.Common.Others;
    using NUnit.Framework;
    using NYLDWebAutomationFramework;
    using System.Collections.Generic;

    public class SmokeTestSuit : TestSetUp
    {
        TestSetUp testSet = new TestSetUp();
        [Test, TestCaseSource("SmokeTestCasesList")]
        public void SmokeTestCases(string TestCaseID)
        {           
            ExecuteTest(TestCaseID);
        }

        [TearDown()]
        public void Dispose()
        {
            ResetData();
            //Relese com object
            TestData testData = new TestData();
            testData.ReleaseExcelObjects();
            //Close the browser
            Close();
            List<string> processes = new List<string> { "chromedriver", "chrome", "EXCEL", "Microsoft Excel" };
            NYLDGeneric.KillProcesses(processes);
            //Publish Test result and Test data info
            string[] resultData = new string[] { KeyRepository.PolicyNumber, KeyRepository.UserName, KeyRepository.Password };
            NYLDGeneric.PublishTestResult(data, resultData);
        }
        #region --Testscripts
        static readonly object[] SmokeTestCasesList =
       {
                new object[] {"ST_Registration_01_QA1"},
              new object[] {"ST_ResetPassword_02_QA1"},
              new object[] {"ST_Beneficiaries_03_QA1"},
              new object[] {"ST_Details_04_QA1"},
              new object[] {"ST_EditInsured_05_QA1"},
              new object[] {"ST_OwnerAddress_06_QA1"},
              new object[] {"ST_ChangePayor_07_QA1"},
              new object[] {"ST_AutoPay-EFT_08_QA1"},
              new object[] {"ST_ManagePaymentsOverview_09_QA1"},
               new object[] {"ST_Dashboard_10_QA1"},
              new object[] {"ST_Registration_01_QA2"},
              new object[] {"ST_ResetPassword_02_QA2"},
              new object[] {"ST_Beneficiaries_03_QA2"},
              new object[] {"ST_Details_04_QA2"},
              new object[] {"ST_EditInsured_05_QA2"},
              new object[] {"ST_OwnerAddress_06_QA2"},
              new object[] {"ST_ChangePayor_07_QA2"},
              new object[] {"ST_AutoPay-EFT_08_QA2"},
              new object[] {"ST_ManagePaymentsOverview_09_QA2"},
               new object[] {"ST_Dashboard_10_QA2"},
              new object[] {"ST_Registration_01_QA3"},
              new object[] {"ST_ResetPassword_02_QA3"},
              new object[] {"ST_Beneficiaries_03_QA3"},
              new object[] {"ST_Details_04_QA3"},
              new object[] {"ST_EditInsured_05_QA3"},
              new object[] {"ST_OwnerAddress_06_QA3"},
              new object[] {"ST_ChangePayor_07_QA3"},
              new object[] {"ST_AutoPay-EFT_08_QA3"},
              new object[] {"ST_ManagePaymentsOverview_09_QA3"},
               new object[] {"ST_Dashboard_10_QA3"},
              new object[] {"ST_Registration_01_QA4"},
              new object[] {"ST_ResetPassword_02_QA4"},
              new object[] {"ST_Beneficiaries_03_QA4"},
              new object[] {"ST_Details_04_QA4"},
              new object[] {"ST_EditInsured_05_QA4"},
              new object[] {"ST_OwnerAddress_06_QA4"},
              new object[] {"ST_ChangePayor_07_QA4"},
              new object[] {"ST_AutoPay-EFT_08_QA4"},
              new object[] {"ST_ManagePaymentsOverview_09_QA4"},
               new object[] {"ST_Dashboard_10_QA4"},
              new object[] {"ST_Registration_01_Stage"},
              new object[] {"ST_ResetPassword_02_Stage"},
              new object[] {"ST_Beneficiaries_03_Stage"},
              new object[] {"ST_Details_04_Stage"},
              new object[] {"ST_EditInsured_05_Stage"},
              new object[] {"ST_OwnerAddress_06_Stage"},
              new object[] {"ST_ChangePayor_07_Stage"},
              new object[] {"ST_AutoPay-EFT_08_Stage"},
              new object[] { "ST_ManagePaymentsOverview_09_Stage" },
               new object[] {"ST_Dashboard_10_Stage"},
               new object[] {"ST_Registration_01_QA5"},
              new object[] {"ST_ResetPassword_02_QA5"},
              new object[] {"ST_Beneficiaries_03_QA5"},
              new object[] {"ST_Details_04_QA5"},
              new object[] {"ST_EditInsured_05_QA5"},
              new object[] {"ST_OwnerAddress_06_QA5"},
              new object[] {"ST_ChangePayor_07_QA5"},
              new object[] {"ST_AutoPay-EFT_08_QA5"},
              new object[] { "ST_ManagePaymentsOverview_09_QA5" },
               new object[] { "ST_Dashboard_10_QA5" }
        };
        #endregion
    }
}
