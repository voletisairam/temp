﻿
namespace CSW
{
    using CSW.Common.Excel;
    using CSW.Common.Others;
    using Microsoft.Office.Interop.Excel;
    using NUnit.Framework;
    using NYLDWebAutomationFramework;
    using OpenQA.Selenium;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class RegressionTestSuit : TestSetUp
    {
        TestSetUp testSet = new TestSetUp();

        //Constructor- initialization for TestSetUp Constructor - Keyword event count
        public RegressionTestSuit() : base()
        {
            
        }

        [Test, TestCaseSource("RegressionTestCasesList")]
        public void RegressionTestCases(string TestCaseID)
        {           
            ExecuteTest(TestCaseID);
            driver = testSet.driver;
        }

        //Core Regression
        [Test, TestCaseSource("CoreRegressionTestCasesList")]
        public void CoreRegressionTestCases(string TestCaseID)
        {
            ExecuteTest(TestCaseID);
            driver = testSet.driver;
        }

        [TearDown()]
        public void Dispose()
        {            
            ResetData();
            //Relese com object
            TestData testData = new TestData();
            testData.ReleaseExcelObjects();
            //Close the browser
            Close();
            List<string> processes = new List<string> { "chromedriver", "chrome", "EXCEL", "Microsoft Excel" };
            NYLDGeneric.KillProcesses(processes);
            //Publish Test result and Test data info
            string[] resultData = new string[] { KeyRepository.PolicyNumber, KeyRepository.UserName, KeyRepository.Password };
            NYLDGeneric.PublishTestResult(data, resultData);
        }

        #region --Testscripts
        static readonly object[] RegressionTestCasesList =
        {
                    new object[] {"Account_Cyber Fraud_01"},
                    new object[] {"Account_Cyber Fraud_02"},
                    new object[] {"Account_Cyber Fraud_03"},
                    new object[] {"Account_Cyber Fraud_04"},
                    new object[] {"Account_Cyber Fraud_05"},
                    new object[] {"Profile Maintenance_Reset Password_01"},
                    new object[] {"Profile Maintenance_Reset Password_02"},
                    new object[] {"Profile Maintenance_Complete Registration_03"},
                    new object[] {"Profile Maintenance_Contract Search_04"},
                    new object[] {"Profile Maintenance_Contract Search_05"},
                    new object[] {"Profile Maintenance_Contract Search_06"},
                    new object[] {"Profile Maintenance_Contract Search_07"},
                    new object[] {"Profile Maintenance_Contract Search_08"},
                    new object[] {"Profile Maintenance_Contract Search_09"},
                    new object[] {"Profile Maintenance_Contract Search_10"},
                    new object[] {"Profile Maintenance_Deactivate Account_11"},
                    new object[] {"Profile Maintenance_Deactivate Account_12"},
                    new object[] {"Profile Maintenance_Deactivate Account_13"},
                    new object[] {"Profile Maintenance_Deactivate Account_14"},
                    new object[] {"Account_Login_01"},
                    new object[] {"Account_Login_02"},
                    new object[] {"Account_Profile Updates_01"},
                    new object[] {"Account_Profile Updates_02"},
                    new object[] {"Account_Profile Updates_03"},
                    new object[] {"Account_Profile Updates_04" },
                    new object[] {"Account_Profile Updates_05" },
                    new object[] {"Account_Profile Updates_06" },
                    new object[] {"Account_Forgot Username_01"},
                    new object[] {"Account_Forgot Username_02"},
                    new object[] {"Account_Registration_01"},
                    new object[] {"Account_Registration_02"},
                    new object[] {"Account_Registration_03"},
                    new object[] {"Account_Registration_04"},
                    new object[] {"Account_Registration_05"},
                    new object[] {"Account_Registration_06"},
                    new object[] {"Account_Registration_07"},
                    new object[] {"Account_Registration_08"},
                    new object[] {"Account_Reset Password_01"},
                    new object[] {"Account_Reset Password_02"},
                    new object[] {"Account_Reset Password_03"},
                    new object[] {"Account_Reset Password_04"},
                    new object[] {"Account_Reset Password_05"},
                    new object[] {"Account_Reset Password_06"},
                    new object[] {"Account_Reset Password_07"},
                    new object[] {"Account_Reset Password_08"},
                    new object[]{"Account_Paperless Settings_01"},
                    new object[]{"Account_Paperless Settings_02"},
                    new object[] {"Coverage_Beneficiaries_01"},
                    new object[] {"Coverage_Beneficiaries_02"},
                    new object[] {"Coverage_Beneficiaries_03"},
                    new object[] {"Coverage_Beneficiaries_04"},
                    new object[] {"Coverage_Beneficiaries_05"},
                    new object[] {"Coverage_Beneficiaries_06"},
                    new object[] {"Coverage_Beneficiaries_07"},
                    new object[] {"Coverage_Beneficiaries_08"},
                    new object[] {"Coverage_Beneficiaries_09"},
                    new object[] {"Coverage_Beneficiaries_10"},
                    new object[] {"Coverage_Beneficiaries_11"},
                    new object[] {"Coverage_Beneficiaries_12"},
                    new object[] {"Coverage_Beneficiaries_13"},
                    new object[] {"Coverage_Beneficiaries_14"},
                    new object[] {"Coverage_Beneficiaries_15"},
                    new object[] {"Coverage_Beneficiaries_16"},
                    new object[] {"Coverage_Beneficiaries_17"},
                    new object[] {"Coverage_Beneficiaries_18"},
                    new object[] {"Coverage_Beneficiaries_19"},
                    new object[] {"Coverage_Beneficiaries_20"},
                    new object[] {"Coverage_Beneficiaries_21"},
                    new object[] {"Coverage_Beneficiaries_22"},
                    new object[] {"Coverage_Beneficiaries_23"},
                    new object[] {"Coverage_Beneficiaries_24"},
                    new object[] {"Coverage_Beneficiaries_25"},
                    new object[] {"Coverage_Beneficiaries_26"},
                    new object[] {"Coverage_Beneficiaries_27"},
                    new object[] {"Coverage_Beneficiaries_28"},
                    new object[] {"Coverage_Beneficiaries_29"},
                    new object[] {"Coverage_Beneficiaries_30"},
                    new object[] {"Coverage_Beneficiaries_31"},
                    new object[] {"Coverage_Beneficiaries_32"},
                    new object[] {"Coverage_Beneficiaries_33"},
                    new object[] {"Coverage_Dashboard Details_01"},
                    new object[] {"Coverage_Dashboard Details_02"},
                    new object[] {"Coverage_Dashboard Details_03"},
                    new object[] {"Coverage_Dashboard Details_04"},
                    new object[] {"Coverage_Dashboard Details_05"},
                    new object[] {"Coverage_Dashboard Details_06"},
                    new object[] {"Coverage_Dashboard Details_07"},
                    new object[] {"Coverage_Dashboard Details_08"},
                    new object[] {"Coverage_Dashboard Details_09"},
                    new object[] {"Coverage_Dashboard Details_10"},
                    new object[] {"Coverage_Dashboard Details_11"},
                    new object[] {"Coverage_Dashboard Details_12"},
                    new object[] {"Coverage_Dashboard Details_13"},
                    new object[] {"Coverage_Dashboard Details_14"},
                    new object[] {"Coverage_Dashboard Details_15"},
                    new object[] {"Coverage_Dashboard Details_16"},
                    new object[] {"Coverage_Dashboard Details_17"},
                    new object[] {"Coverage_Dashboard Details_18"},
                    new object[] {"Coverage_Dashboard Details_19"},
                    new object[] {"Coverage_Dashboard Details_20"},
                    new object[] {"Coverage_Dashboard Details_21"},
                    new object[] {"Coverage_Dashboard Details_22"},
                    new object[] {"Coverage_Dashboard Details_23"},
                    new object[] {"Coverage_Dashboard Details_24"},
                    new object[] {"Coverage_Dashboard Details_25"},
                    new object[] {"Coverage_Details_01"},
                    new object[] {"Coverage_Details_02"},
                    new object[] {"Coverage_Details_03"},
                    new object[] {"Coverage_Edit Insured_01"},
                    new object[] {"Coverage_Edit Insured_02"},
                    new object[] {"Coverage_Edit Insured_03"},
                    new object[] {"Coverage_Edit Insured_04"},
                    new object[] {"Coverage_Owner Address_01"},
                    new object[] {"Coverage_Owner Address_02"},
                    new object[] {"Coverage_Owner Address_03"},
                    new object[] {"Coverage_Owner Address_04"},
                    new object[] {"Coverage_Owner Address_05"},
                    new object[] {"Coverage_Owner Address_06"},
                    new object[] {"Coverage_Owner Phone_01"},
                    new object[] {"Coverage_Owner Phone_02"},
                    new object[] {"Coverage_Owner Phone_03"},
                    new object[] {"Coverage_Owner Phone_04"},
                    new object[] {"Payment_Auto Pay_01"},
                    new object[] {"Payment_Auto Pay_02"},
                    new object[] {"Payment_Auto Pay_03"},
                    new object[] {"Payment_Auto Pay_04"},
                    new object[] {"Payment_Auto Pay_05"},
                    new object[] {"Payment_Auto Pay_06"},
                    new object[] {"Payment_Auto Pay_07"},
                    new object[] {"Payment_Auto Pay_08"},
                    new object[] {"Payment_Change Payor_01"},
                    new object[] {"Payment_Change Payor_02"},
                    new object[] {"Payment_Change Payor_03"},
                    new object[] {"Payment_Change Payor_04"},
                    new object[] {"Payment_Change Payor_05"},
                    new object[] {"Payment_Manage Payments Overview_01"},
                    new object[] {"Payment_Manage Payments Overview_02"},
                    new object[] {"Payment_Manage Payments Overview_03"},
                    new object[] {"Payment_Manage Payments Overview_04"},
                    new object[] {"Payment_Manage Payments Overview_05"},
                    new object[] {"Payment_Manage Payments Overview_06"},
                    new object[] {"Payment_Manage Payments Overview_07"},
                    new object[] {"Payment_Manage Payments Overview_08"},
                    new object[] {"Payment_Manage Payments Overview_09"},
                    new object[] {"Payment_Manage Payments Overview_10"},
                    new object[] {"Payment_Manage Payments Overview_11"},
                    new object[] {"Payment_Manage Payments Overview_12"},
                    new object[] {"Payment_Manage Payments Overview_13"},
                    new object[] {"Payment_Manage Payments Overview_14"},
                    new object[] {"Payment_One Time Payment_01"},
                    new object[] {"Payment_One Time Payment_02"},
                    new object[] {"Payment_One Time Payment_03"},
                    new object[] {"Payment_One Time Payment_04"},
                     new object[] {"Payment_One Time Payment_05"},
                    new object[] {"Payment_Payment Frequency_01"},
                    new object[] {"Payment_Payment Frequency_02"},
                    new object[] {"Payment_Payment Frequency_03"},
                    new object[] {"Sitewide_Co-Browse_01"},
                     new object[] {"Term Rider_Findability_01"},
                     new object[] {"Term Rider_Email_02"},
                     new object[] {"Term Rider_FieldValidation_03"},
                     new object[] {"Exchange_Findability_01"},
                     new object[] {"Exchange_Email_02"},
                      new object[] {"SecureDoc_Upload_01"},
                      new object[] {"SecureDoc_Upload_02"},
                      new object[] {"SecureDoc_Upload_03"},
                      new object[] {"SecureDoc_Upload_04"},
                      new object[] {"SecureDoc_Upload_05"},
                      new object[] {"SecureDoc_Upload_06"},
                    new object[] {"Payment_Pay As Guest_01"},
                    new object[] {"Payment_Pay As Guest_02"},
                    new object[] {"Payment_Pay As Guest_03"},
                    new object[] {"Payment_Payment History_01"},
                    new object[] {"Payment_Payment History_02"},
                    new object[] {"Payment_Payment History_03"}

        };
        static readonly object[] CoreRegressionTestCasesList =
       {
            new object[] {"Account_Cyber Fraud_03"},
            new object[] {"Profile Maintenance_Contract Search_08"},
            new object[] {"Profile Maintenance_Deactivate Account_11"},
            new object[] {"Account_Profile Updates_01"},
            new object[] {"Account_Profile Updates_04"},
            new object[] {"Account_Registration_01"},
            new object[] {"Account_Registration_08"},
            new object[] {"Account_Reset Password_01"},
            new object[] {"Coverage_Beneficiaries_01"},
            new object[] {"Coverage_Beneficiaries_12"},
            new object[] {"Coverage_Beneficiaries_13"},
            new object[] {"Coverage_Beneficiaries_20"},
            new object[] {"Coverage_Beneficiaries_02"},
            new object[] {"Coverage_Dashboard Details_05"},
            new object[] {"Coverage_Dashboard Details_12"},
            new object[] {"Coverage_Dashboard Details_14"},
            new object[] {"Coverage_Dashboard Details_17"},
            new object[] {"Coverage_Dashboard Details_18"},
            new object[] {"Coverage_Dashboard Details_19"},
            new object[] {"Coverage_Dashboard Details_20"},
            new object[] {"Coverage_Dashboard Details_23"},
            new object[] {"Coverage_Dashboard Details_24"},
            new object[] {"Coverage_Dashboard Details_25"},
            new object[] {"Coverage_Details_03"},
            new object[] {"Coverage_Edit Insured_02"},
            new object[] {"Coverage_Owner Address_01"},
            new object[] {"Coverage_Owner Phone_02"},
            new object[] {"Payment_Auto Pay_01"},
            new object[] {"Payment_Auto Pay_03"},
            new object[] {"Payment_Auto Pay_13"},
            new object[] {"Payment_Change Payor_07"},
            new object[] {"Payment_Manage Payments Overview_10"},
            new object[] {"Payment_Manage Payments Overview_13"},
            new object[] {"Payment_One Time Payment_04"},
            new object[] {"Payment_Payment Frequency_03"},
            new object[] {"Sitewide_Co-Browse_01"},
            new object[] {"Term Rider_Findability_01"},
            new object[] {"Exchange_Findability_01"},
        };
        #endregion
    }
}
