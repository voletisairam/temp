﻿
namespace CSW
{
    using System;
    using NUnit.Framework;
    using NYLDWebAutomationFramework;
    using CSW.Common.Excel;
    using System.Collections.Generic;
    using CSW.Common.Others;
    using CSW.Drivers;
    using OpenQA.Selenium;
    using CSW.Common.DataBase;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Edge;
    using OpenQA.Selenium.Firefox;
    using System.IO;
    using CSW.Common.Services;

    public class TestSetUp : WebBrowser
    {
        public static Dictionary<string, string> data;
        public static DateTime date = new DateTime();
        _MainDriver requestFlow;        
        public new  IWebDriver driver;
        public static string TestCaseIDInfo = "";
        int expectedKeywordsCount;
        int actualKeywordsCount;

        public TestSetUp() {
            expectedKeywordsCount = 0;
            actualKeywordsCount = 0;
        }

        /// <summary>
        ///  Method to fetch the correponding Browser and get business flow 
        /// </summary>
        /// <param name="TestCaseID"></param>
        public Dictionary<string, string> InitializeTestData(string TestCaseID)
        {
            string testscenariossheet;
            List<string> processes = new List<string> { "EXCEL" };
            NYLDGeneric.KillProcesses(processes);
            TestCaseIDInfo = TestCaseID;
            GetSettor.projectName = "CSW";
            GetSettor.failCounter = 0;
            // Clear the Step.txt every test case
            FileInfo fileInfo = new FileInfo(GetSettor.StepsFile + "Steps.txt");
            if (fileInfo.Exists)
            {
                File.WriteAllText(GetSettor.StepsFile, string.Empty);
            }
            ////TestData Sheet            
            testscenariossheet = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.DataSheetPath + Properties.Settings.Default.DataSheet;

            System.IO.File.WriteAllText(Properties.Settings.Default.LogFile, string.Empty);
            //Get the business flow
            requestFlow = new _MainDriver();
            data = requestFlow.GetTestData(TestCaseID, testscenariossheet);
            driver = OpenBrowser(data[KeyRepository.Browser]);
            NavigateToUrl(data[KeyRepository.URL]);
                       
            data[KeyRepository.LSPDate] = NYLDDatabase.GetLSPDate();
            Console.WriteLine("LSP Date is : " + data[KeyRepository.LSPDate]);

            data.TryGetValue(KeyRepository.ContractType, out string policycondtion);
            if (string.IsNullOrEmpty(policycondtion))
                data[KeyRepository.ContractType] = "continueflow";

            return data;
        }
      
        /// <summary>
        /// ExecuteTest method help us to find the Prerequisite conditions as per testcase
        /// Validate the business requiremnt by passing the TestCaseID Parameter
        /// </summary>
        /// <param name="TestCaseID"></param>
        public void ExecuteTest(string TestCaseID)
        {
            string sBusinessFlow;
            string[] aBusinessEvents;

            //Call TestSetup to launch browser and get the data type and business flow
            data = InitializeTestData(TestCaseID);
            //Set Prerequiste
            TestPreRequisites testRequiste = new TestPreRequisites(driver, data);
            testRequiste.SetPrerequisite("");

            //Read the business Flow and execute test cases     
            sBusinessFlow = data[KeyRepository.BusinessFlow];
            aBusinessEvents = sBusinessFlow.Split('|');
            expectedKeywordsCount = aBusinessEvents.Length;


            foreach (String BEvent in aBusinessEvents)
            {
                    Console.WriteLine("Business Event Name is :  " + BEvent.Trim());
                    requestFlow.ExecuteMethod(BEvent.Trim(), driver, data);
                    Console.WriteLine(GetSettor.failCounter);
                    actualKeywordsCount++;
            }

        }

        /// <summary>
        /// RestData method helps us to change the exisiting contracts execute flag status as Yes/No
        /// </summary>
        public void ResetData()
        {
            string sPostBusinessFlow;
            string[] aPostBusinessEvents;
            string eventnamefail = "";

            if (data != null)
            {
                //Post Prerequist
                //Read the PostTest DataReset Flow and execute test cases     
                try
                {

                    data.TryGetValue(KeyRepository.PostTestDataReset, out string PostTestDataResetvalue);
                    if (!string.IsNullOrEmpty(PostTestDataResetvalue))
                    {
                        sPostBusinessFlow = data[KeyRepository.PostTestDataReset];
                        aPostBusinessEvents = sPostBusinessFlow.Split('|');
                        ////Reset Emailid - in Exisitng Useraccount to reusable emailid
                        if ((data[KeyRepository.SubFuntionality].Contains("Registration") || data[KeyRepository.SubFuntionality].Contains("Reset")) && sPostBusinessFlow.Contains("Update_AccountInfo_EmailId"))
                        {
                            new TestData().UpdateValidEmailId(driver, data);
                        }
                        else
                        {
                            NYLDSelenium.ReportStepResult("<h3 style=\"color:Purple\">" + "Postrequisite" + "</h3>", "Using this valid Contract number: " + data[KeyRepository.PolicyNumber] + " for this testcase", "Info", "always", "no");

                            foreach (string PostBEvent in aPostBusinessEvents)
                            {
                                Console.WriteLine("Post Business Event Name is :  " + PostBEvent.Trim());
                                requestFlow.ExecuteMethod(PostBEvent.Trim(), driver, data);
                                eventnamefail = PostBEvent.Trim();
                            }
                        }
                    }
                }
                catch
                {
                    //nothing to do
                }


                //Release the hard coded test data lock
                if (data[KeyRepository.ContractSource] == "ExistingUserAccountsSheet")
                    new TestData().GetExistingUserAccountsSheetData(data, "Release");


                //Release the test data lock
                if (data[KeyRepository.ContractSource] != "ExistingUserAccountsSheet")
                    new TestData().ReleaseUserAccounts(driver, data);
            }

        }          
            
    }
}
