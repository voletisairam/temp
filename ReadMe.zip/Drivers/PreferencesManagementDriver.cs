﻿using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Profile;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;

namespace CSW.Drivers
{
    class PreferencesManagementDriver
    {

        private IWebDriver driver;
        private Dictionary<string, string> data;

        public PreferencesManagementDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //////////////////////////////////////////////////////////
        /////////    Preference Management Page Section    /////////
        //////////////////////////////////////////////////////////

        /// <summary>
        /// Method helps to view the Preference Management page header /text content / buttons etc
        /// </summary>
        /// <param name="args"></param>
        public void ViewPreferenceManagementPage(string args)
        {
            PreferenceManagementPage preference = new PreferenceManagementPage(driver, data);
            HomePage home = new HomePage(driver, data);
            
            //naviage to the Preference Management Page 
            home.NavigateToPage(KeyRepository.PreferenceManagementInfoPage);
            //Verify the paperless Management of elments /text/values to be verify
            preference.VerifyPreferenceManagementInfo(args);
        }

        /// <summary>
        /// Method helps to user Optin paperless settings
        /// </summary>
        /// <param name="args"></param>
        public void OptInPaperlessPreference(string args)
        {
            PreferenceManagementPage preference = new PreferenceManagementPage(driver, data);
            preference.PreferenceOption(args);
        }

        /// <summary>
        /// Method helps tp update the paperless settings and its set as OptOut
        /// </summary>
        /// <param name="args"></param>
        public void OptOutPaperlessPreference(string args)
        {
            PreferenceManagementPage preference = new PreferenceManagementPage(driver, data);
            preference.PreferenceOption(args);
        }

        /// <summary>
        /// Method helps to Verify Thank You page for user OptIn sucessfuly
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaperlessOptInThankYouPage(string args)
        {
            PreferenceManagementPage preference = new PreferenceManagementPage(driver, data);
            preference.VerifyPaperlessSignUpThankYouPage();
        }

        /// <summary>
        ///  Method helps to Verify Thank You page for user user updated sucessfuly as OptOut
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaperlessOptOutThankYouPage(string args)
        {
            PreferenceManagementPage preference = new PreferenceManagementPage(driver, data);
            preference.VerifyPaperlessOptOutThankYouPage();
        }

        /// <summary>
        /// Method helps to validate the Confirmation email is expected or not
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaperlessSuccessEmail(string args)
        {
            EmailVerification email = new EmailVerification(driver, data);
            email.GetEmailsList("Paperless Settings Confirmation");
        }

        /// <summary>
        /// method helps to verify the record entry is present in db or not
        /// </summary>
        /// <param name="args"></param>
        public void VerifyOptInDataBaseEntry(string args)
        {
            LSPDatabase db = new LSPDatabase(driver, data);
            //Build the query              
            db.QueryPreferenceManagementEntry("Opt-In");
        }
        /// <summary>
        /// Method helps to verify the record is present in db or not
        /// </summary>
        /// <param name="args"></param>
        public void VerifyOptOutDataBaseEntry(string args)
        {
            LSPDatabase db = new LSPDatabase(driver, data);
            db.QueryPreferenceManagementEntry("Opt-Out");
        }
    }

}
