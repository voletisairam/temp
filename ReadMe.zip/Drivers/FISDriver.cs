﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.Others;
using CSW.PageObjects.External_Applications;
using NYLDWebAutomationFramework;
using System.Collections.Generic;

namespace CSW.Drivers
{
    class FISDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public FISDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method helps to verify the FIS page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyFISDetails(string args)
        {
            FISPage fisPage = new FISPage(driver, data);
            fisPage.NavigateToUserInformation();

            if (args=="Email")
                fisPage.VerifyEmailAddress();

            //After succesfull landing to FIS page need to Redirect to existing URL
            NYLDSelenium.NavigateToUrl(data[KeyRepository.URL]);
        }

        /// <summary>
        /// Method helps to navigate the FIS and verify the   //Contact Information section //Payment ifnromation etc
        /// </summary>
        /// <param name="args"></param>
        public void VerifyFISPage(string args)
        {
            FISPage fisPage = new FISPage(driver, data);

            fisPage.VerifyFISPage(args);

            NYLDSelenium.NavigateToUrl(data[KeyRepository.URL]);
        }

        /// <summary>
        /// Method to verify LSP Data Mismatch
        /// </summary>
        /// <param name="args"></param>
        public void VerifyLSPErrorMessage(string args)
        {
            FISPage fisPage = new FISPage(driver, data);

            fisPage.VerifyLSPErrorMessage(args);

            NYLDSelenium.NavigateToUrl(data[KeyRepository.URL]);
        }
    }
}
