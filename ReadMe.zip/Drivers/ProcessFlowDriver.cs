﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using CSW.PageObjects.Registration;
using CSW.PageObjects.Login;
using CSW.Common.Services;
using CSW.PageObjects.External_Applications;
using CSW.PageObjects.Home;


namespace CSW.Drivers
{
    class ProcessFlowDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ProcessFlowDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        public void VerifyProcessFlowTask(string args)
        {
            string changeType = args.Split(',')[0];
            string changeDetails = args.Split(',')[1];

            CSW.PageObjects.External_Applications.ProcessFlow pf = new CSW.PageObjects.External_Applications.ProcessFlow(driver, data);
         
            pf.VerifyProcessFlowEntry("EditInsured", CSWData.TempVal);
        }
    }
}
