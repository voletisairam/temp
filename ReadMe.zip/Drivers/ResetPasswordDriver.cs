﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using CSW.PageObjects.Coverage;
using CSW.PageObjects.NewRegistration;
using System.Threading;

namespace CSW.Drivers
{
    class ResetPasswordDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ResetPasswordDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }
           

        /// <summary>
        /// Method to validate complete reset password scenarios
        /// </summary>
        /// <param name="args"></param>
        public void ResetPassword(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);
            VerifyYourDetailsPage verifyDetails = new VerifyYourDetailsPage(driver, data);
            UserRegistrationDriver userRegistration = new UserRegistrationDriver(driver, data);
            OneTimeVerificationPage verificationPage = new OneTimeVerificationPage(driver, data);
            IList<string> options = new List<string>();

            string[] getOptions = args.Split(',');
            options = getOptions.ToList();

            //  //Request Password option
            if (args == "")
            {
                resetPassword.RequestResetPasswordPage("");
                verificationPage.VerifyOneTimeVerificationPage();
                resetPassword.RequestPasswordOptions("Default"); Thread.Sleep(2000);
                resetPassword.EnterNewPassword("");
                resetPassword.SuccessNewPassword("Default");

            }
            else
            {
                if (options.Count == 1)
                    options.Add("");

                //1st argument
                switch (options[0])
                {
                    case "FillOwnerDetailsPage":
                    case "ValidEmail":
                        userRegistration.OwnerDetailsPage(args);
                        verifyDetails.FillOwnerdetails(args);
                        break;
                    case "OTPPage":
                        verificationPage.VerifyOneTimeVerificationPage();
                        break;
                    case "SMSOTPPage":
                        verificationPage.VerifyOneTimeVerificationSMSPage();
                        break;
                    case "EnterOTP":
                        resetPassword.RequestPasswordOptions("ValidPIN");
                        break;
                    case "PinCodeExpired":
                    case "WaitforOTPtoExpire":
                        resetPassword.RequestPasswordOptions("PinCodeExpired");
                        break;
                    case "VerifyGriefMessage":
                        resetPassword.VerifyGriefMessage(options[1]);
                        break;
                    case "InvalidPIN":
                    case "ValidPIN":
                    case "ResendCode":
                        resetPassword.RequestPasswordOptions(options[1]);
                        break;
                    case "Default":
                        resetPassword.RequestPasswordOptions("Default");
                        break;
                }

                if (options[0] != "VerifyGriefMessage")
                {
                    //2nd argument
                    switch (options[1])
                    {
                        case "InvalidPIN":
                        case "ValidPIN":
                        case "ResendCode":
                            resetPassword.RequestPasswordOptions(options[1]);
                            break;
                        case "PwdComplexity":
                            resetPassword.RequestPasswordOptions("Default");
                            resetPassword.ValidatePasswordComplexity("");
                            break;
                        case "Default":
                            resetPassword.RequestPasswordOptions("Default");
                            break;
                    }
                }
            }
        }        
    }
}
