﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using CSW.PageObjects.Coverage;
using CSW.PageObjects.NewRegistration;
using System.Threading;
using CSW.Common.Database;

namespace CSW.Drivers
{
    class HomeDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public HomeDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method to navigate to different tabs from home screen
        /// </summary>
        /// <param name="args"></param>
        public void Navigate(string args)
        {
            HomePage home = new HomePage(driver, data);

            //home.NavigateToPage(args.Trim());
            home.VerifyMyAccountBanner("");
        }

        //TODO: Why login is here?


        /// <summary>
        /// Method to Login to application
        /// </summary>
        /// <param name="args"></param>
        public void Login(string args)
        {
            PageObjects.Login.LoginPage login = new PageObjects.Login.LoginPage(driver, data);

            login.Login(args.Trim());
        }

        /// <summary>
        /// Method to Logout of the application
        /// </summary>
        /// <param name="args"></param>
        public void Logout(string args)
        {
            HomePage home = new HomePage(driver, data);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Logout" + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            home.NavigateToPage(KeyRepository.LogoutPage);
        }

        /// <summary>
        /// Method helps to forgot Username
        /// </summary>
        /// <param name="args"></param>
        public void ForgotUsername(string args)
        {
            ForgotPage forgotusername = new ForgotPage(driver, data);
            forgotusername.VerifyForgotUsername(args);
        }

        /// <summary>
        /// Method helps to Get the forgotpassword
        /// </summary>
        /// <param name="args"></param>
        public void ForgotPassword(string args)
        {
            ForgotPage forgotpassword = new ForgotPage(driver, data);
            forgotpassword.VerifyForgotPassword(args);
        }

        /// <summary>
        /// Method to validate reset password scenarios
        /// </summary>
        /// <param name="args"></param>
        public void ResetPasswordOption(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);

            resetPassword.RequestResetPasswordPage(args);
        }

        /// <summary>
        /// Method to validate reset password scenarios
        /// </summary>
        /// <param name="args"></param>
        public void CyberFraudGenericMessage(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);

            resetPassword.CyberFraudGenericMessage(args);
        }

        /// <summary>
        /// Method to validate contract details displayed in MY coverage screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDashboardPage(string args)
        {
            SummaryPage summaryPage = new SummaryPage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            //Query Associated policies and sort the policy list
            DB.QueryAssociatedPolicies("SummaryPage");
            CF.SortContracts(CSWData.AssociatedPolicies);
            DB.QueryAssociatedPolicies();

            if (args != "Grief")
                summaryPage.VerifySummaryPage(args);
        }

        /// <summary>
        /// Method to validate contract Info displayed in MY coverage screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDashboardPageInfo(string args)
        {
            SummaryPage summaryPage = new SummaryPage(driver, data);
            summaryPage.VerifySummaryPageInfo(args);
        }

        /// <summary>
        /// Method to validate AARP Memebr Elligiblity Info displayed in MY coverage screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifySummaryPageContractElligible(string args)
        {
            SummaryPage summaryPage = new SummaryPage(driver, data);
            if (args != "Grief")
                summaryPage.VerifySummaryPageContractElligible(args);
        }

        /// <summary>
        /// Method to Verify dashboard sort order for policies listed
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDashboardSortOrder(string args)
        {
            SummaryPage summaryPage = new SummaryPage(driver, data);
            summaryPage.Verify25Multis(args);

        }

        /// <summary>
        /// Method to validate details screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDetailsPage(string args)
        {
            DetailsPage detailsPage = new DetailsPage(driver, data);

            detailsPage.VerifyDetailsPage(args);
        }

        /// <summary>
        /// Method to validate Request types Duplicate, Cash and Fax
        /// </summary>
        /// <param name="args"></param>
        public void VerifyRequestType(string args)
        {
            DetailsPage detailsPage = new DetailsPage(driver, data);

            detailsPage.VerifyRequestType(args);
        }

        public void VerifyCoBrowse(string args)
        {
            HomePage home = new HomePage(driver, data);

            home.VerifyCoBrowseSession();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        public void GetValidEmail(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);

            resetPassword.GetValidEmail();
        }

        /// <summary>
        /// Method helps to verify previous ten password verify with grief message
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPrevious10PasswordsGriefMessage(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);

            resetPassword.VerifyPrevious10PasswordsGriefMessage(args);
        }

         /// <summary>
         /// Navigate to Dashboard page
         /// </summary>
        public void NavigateDashboardPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            home.NavigateToPage(KeyRepository.CoveragePage);
        }

        /// <summary>
        /// Method to Navigate Payment History Page from MyAccount
        /// </summary>
        /// <param name="args"></param>
        public void NavigatePaymentHistoryPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            home.NavigateToPage(KeyRepository.PaymentHistory);
        }

        /// <summary>
        /// Method to click Payment History link
        /// </summary>
        /// <param name="args"></param>
        public void ClickPaymentHistoryLink(string args)
        {
            DetailsPage page = new DetailsPage(driver, data);
            page.ClickPaymentHistory();
        }

        /// <summary>
        /// Method to Navigate  My Beneficiaries Page from MyAccount
        /// </summary>
        /// <param name="args"></param>
        public void NavigateBeneficiariesPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            home.NavigateToPage(KeyRepository.BeneficiaryPage);
        }

    }
}

  