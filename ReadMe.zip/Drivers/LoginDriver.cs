﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using CSW.PageObjects.Registration;
using CSW.PageObjects.Login;
using CSW.Common.Services;
using CSW.PageObjects.Profile;

namespace CSW.Drivers
{
    class LoginDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public LoginDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //TODO: Is there anything we can set the logic here?

        public void Login(string args)
        {
            LoginPage login = new LoginPage(driver, data);
            login.Login(args);
        }
        /// <summary>
        /// NonViper-LoginError_Morethan1YearUserAccount
        /// </summary>
        /// <param name="args"></param>
        public void VerifyLoginPageGrief(string args)
        {
            LoginPage login = new LoginPage(driver, data);
            login.LoginPageGriefMsg(args);
        }

        public void ReturnHome(string args)
        {
            LoginPage login = new LoginPage(driver, data);
            login.NavigateHome();
        }

        /// <summary>
        /// Apply CyberFraud flag by using the 128-Restservice
        /// Validate the record in entry table and should not be in history table
        /// </summary>
        /// <param name="args"></param>
        public void ApplyCyberFraudFlag(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            RestServices webService = new RestServices(data);
            string result = "";

            DB.QueryCyberFraudDetails("ApplyCyberFraudProtection");

            //Calling 186 service to set the flag
            for (int i = 1; i <= 4; i++)
            {
                result = webService.SubmitRestCall("ApplyCyberFraudProtection", "10");
                if (result.Contains("was successful"))
                    break;
            }
            //verify policy entery in cyber fraud entry table
            DB.QueryCyberFraudFlagAlerts("ApplyCyberFraudProtection");

            //verify policy entry in cyber fraud history table
            DB.QueryCyberFraudFlagHistory("ApplyCyberFraudProtection");

            //Verify LSP Notes
            DB.QueryLSPNotes("ApplyCyberFraudProtection".Trim(), "");

            //Verify Reset Password Email 
            CSWData.TempVal = "";
            if (args.Trim() == "ApplyCyberFraudProtection")
                CSWData.TempVal = "CSW cyberfraud record inserted for UC 00" + data[KeyRepository.UclientIdOfPolicy] + ".";

            CSWData.TempVal = "";
        }

        /// <summary>
        /// Remove CyberFraud flag by using the 128-Restservice
        /// Validate the record should not in entry table and be in history table
        /// </summary>
        /// <param name="args"></param>
        public void RemoveCyberFraudFlag(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            RestServices webService = new RestServices(data);
            string result = "";

            DB.QueryCyberFraudDetails("RemoveCyberFraudProtection");

            //Calling 186 service to remove the flag
            for (int i = 1; i <= 4; i++)
            {
                result = webService.SubmitRestCall("RemoveCyberFraudProtection", "10");
                if (result.Contains("was successful"))
                    break;
            }
            //verify policy entery in cyber fraud entry table
            DB.QueryCyberFraudFlagAlerts("RemoveCyberFraudProtection");

            //verify policy entry in cyber fraud history table
            DB.QueryCyberFraudFlagHistory("RemoveCyberFraudProtection");

            //Verify LSP Notes
            DB.QueryLSPNotes("RemoveCyberFraudProtection".Trim(), "");

            //Verify Reset Password Email 
            CSWData.TempVal = "";
            if (args.Trim() == "RemoveCyberFraudProtection")
                CSWData.TempVal = "CSW cyberfraud record removed for UC 00" + data[KeyRepository.UclientIdOfPolicy] + ".";

            CSWData.TempVal = "";
        }
    }
}

