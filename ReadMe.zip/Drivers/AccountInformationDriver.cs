﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using CSW.PageObjects.Registration;
using CSW.PageObjects.Login;
using CSW.Common.Services;
using CSW.PageObjects.Profile;
using CSW.PageObjects.Home;
using System.Threading;

namespace CSW.Drivers
{
    class AccountInformationDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public AccountInformationDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method helps to Verify Account Informaiton
        /// </summary>
        /// <param name="args"></param>
        public void VerifyAccountInformationPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            AccountInformationPage account = new AccountInformationPage(driver, data);
            home.NavigateToPage(KeyRepository.AccountInfoPage);
            account.VerifyAccountInformation();
        }

        /// <summary>
        /// Method helps to update the Account Information
        /// </summary>
        /// <param name="args"></param>
        public void UpdateAccountInformationPage(string args)
        {
            Thread.Sleep(400);
            HomePage home = new HomePage(driver, data);
            AccountInformationPage account = new AccountInformationPage(driver, data); 
            home.NavigateToPage(KeyRepository.AccountInfoPage); 
            account.UpdateAccountInformation(args.Trim());
        }

        /// <summary>
        /// Method helps to verify the error message popup
        /// </summary>
        /// <param name="args"></param>
        public void VerifyAccountInformationGriefMessage(string args)
        {
            AccountInformationPage account = new AccountInformationPage(driver, data);
            account.VerifyAccountInformationErrorMessage(args.Trim());
        }

        /// <summary>
        /// Method helps to Verify the Account Information thank you page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyAccountInfornamtionThankYouPage(string args)
        {
            AccountInformationPage account = new AccountInformationPage(driver, data);
            account.VerifyThankYou(args.Trim());
        }
    }
}
