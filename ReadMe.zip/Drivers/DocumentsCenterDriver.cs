﻿
using System.Collections.Generic;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.Others;
using CSW.PageObjects.Profile;
using CSW.PageObjects.Home;

namespace CSW.Drivers
{
    class DocumentsCenterDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public DocumentsCenterDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Verifies the Document Center page by checking for the presence of key elements and document sortability.
        /// </summary>
        public void VerifyDocumentCenter(string arg)
        {
            HomePage home = new HomePage(driver, data);
            DocumentCenterPage documentCenterPage = new DocumentCenterPage(driver, data);
            CommonFunctions commonFunctions = new CommonFunctions(data);

            // Navigate to Document Center  
            home.NavigateToPage(KeyRepository.DocumentsInfoPage);

            // Verify contract owner information that is on the side window of the page
            ///commonFunctions.VerifyContractOwnerInfo();

            // Perform the verification of the Document Center Content Page
            documentCenterPage.VerifyDocument();
        }
    }
}