﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using CSW.Common.Services;
using CSW.PageObjects.Login;
using CSW.PageObjects.Home;
using System.Threading;
using Microsoft.Office.Interop.Excel;
using System.IO;
using CSW.PageObjects.External_Applications;
using CSW.PageObjects.NewRegistration;
using System.Web.Services;
using CSW.PageObjects.Profile;

namespace CSW.Drivers
{
    class TestPreRequisites
    {

        private IWebDriver driver;
        private Dictionary<string, string> data;

        public TestPreRequisites(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method to process test prequisites for the test case
        /// </summary>
        /// <param name="args"></param>
        public void SetPrerequisite(string args)
        {
            LSPDatabase lspDatabase = new LSPDatabase(driver, data);

            string[] options = data[KeyRepository.ContractSource].Trim().Split(':');
            string typeofData = options[0];
            string filterCriteria = "";

            if (options.Count() > 1)
                filterCriteria = options[1];

            //Set up Test prequisites
            switch (typeofData)
            {
                case "NewUserAccountsSheet":
                    GetNewUserAccountsSheet(filterCriteria);
                    break;

                case "DataMine":
                    CreateTestRequiste_DataMine("");
                    break;

                case "ExistingUserAccountsSheet":
                    GetPreSetContractDetails("");
                    break;
                case "":
                    data[KeyRepository.UserName] = "";
                    data[KeyRepository.Password] = "";
                    break;
            }
        }

        /// <summary>
        /// Method to fetch the new contract details from App entry and create test prerequsite
        /// </summary>
        /// <param name="args"></param>
        public void GetNewUserAccountsSheet(string args)
        {
            TestData testData = new TestData();
            LSPDatabase lspDatabase = new LSPDatabase(driver, data);
            string[] options = new string[] { };
            options = data[KeyRepository.PreTestDataSet].Split(':');

            try
            {
                if (string.IsNullOrEmpty(args))
                {
                    testData.GetContractData(driver, data);
                }
                else
                {
                    testData.GetContractData(driver, data, args.Trim());
                }

                // Set User Status
                SetUserStatus("");

                if (data[KeyRepository.PreTestDataSet].Contains("Benes") && !(options.Length > 1))
                {
                    NYLDSelenium.ReportStepResult("PreRequisite Testdata Set column is not in expected format", "Update PreRequisite Testdata Set column in required format", "FAIL", "always", "yes");
                }

                if (data[KeyRepository.PreTestDataSet].Contains("Benes"))
                {
                    AddBenes(data[KeyRepository.PreTestDataSet].Split(':')[1].Trim());
                }

                if (data[KeyRepository.PreTestDataSet].Contains("Payment"))
                {
                    SetPaymentInformation(data[KeyRepository.PreTestDataSet].Split(':')[1].Trim());
                }
            }
            catch (Exception ex)
            {
                NYLDSelenium.ReportStepResult("An error occurred while processing the test data", "Please reach out to automation team", "FAIL", "always", "yes");
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }

        /// <summary>
        /// Method to fetch pre set policy login details from data sheet
        /// </summary>
        /// <param name="args"></param>
        public void GetPreSetContractDetails(string args)
        {
            TestData testData = new TestData();
            LSPDatabase lspDatabase = new LSPDatabase(driver, data);
            PaperlessSettingsDriver paperlessSettingsDriver = new PaperlessSettingsDriver(driver, data);

            //testData.GetStaticContractData(data);
            testData.GetExistingUserAccountsSheetData(data);

            //verify the Pre requist  
            if (data[KeyRepository.PreTestDataSet].Contains("Payment"))
            {
                if (data[KeyRepository.PreTestDataSet].Split(':')[1].Trim() == "VerifyExistingEFT")
                {
                    //To check the associated policies and verify the EFT status
                    string[] policyList = { };
                    RestServices webServices = new RestServices(data);
                    lspDatabase.QueryAssociatedPolicies();
                    string EFTstatus = "";

                    if (CSWData.AssociatedPolicies != null)
                        policyList = CSWData.AssociatedPolicies.Split(';');
                    int counter = 0;
                    //To verify the each contract EFT status
                    for (int j = 0; j <= (policyList.Count() - 1); j++)
                    {
                        string[] phrasePolicy = policyList[j].Split(' ');
                        string PolicyNumber = phrasePolicy.Last();
                        data[KeyRepository.PolicyNumber] = PolicyNumber;
                        EFTstatus = webServices.SubmitRestCall("CheckEFTElig");                      
                        if(EFTstatus == "Existing EFT")
                        {
                            counter++;
                            break;
                        }
                        NYLDSelenium.ReportStepResult("Verify ExistingEFT Eligibility", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                        if (EFTstatus == "No Existing EFT")
                        {                            
                            EFTstatus = webServices.SubmitRestCall("AddEFT");

                            NYLDSelenium.ReportStepResult("Adding EFT", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                            EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                            NYLDSelenium.ReportStepResult("Verify ExistingEFT Eligibility after adding EFT", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                            if (EFTstatus == "Existing EFT")
                            {
                                counter++;
                                break;
                            }
                        }
                    }
                    if (counter == 0)
                    {
                        NYLDSelenium.ReportStepResult("Verify if no EFT set up is available", "System could not verify Current EFT status for this account " + data[KeyRepository.UserName], "fail", "no", "yes");
                    }
                }
                else
                    SetPaymentInformation(data[KeyRepository.PreTestDataSet].Split(':')[1].Trim());
            }

            //Adding benes
            if (data[KeyRepository.PreTestDataSet].Contains("Benes"))
            {
                string policyItem = "1";
                string[] policy = null;
                string[] requestType = null;
                string[] beneinfo = data[KeyRepository.PreTestDataSet].Split(',');

                if (beneinfo.Length > 0)
                {
                    requestType = beneinfo[0].Split(':');
                    if (requestType.Length > 1)
                    {
                        string policyinfo = requestType[1].Trim();
                        if (policyinfo.Contains("MultiPolicy"))
                        {
                            policy = policyinfo.Split('-');
                            if (policy.Length > 0)
                            {
                                policyItem = policy[0].Trim();
                            }
                        }
                    }
                }

                if (policy != null && policy.Length > 0 && policy[1].Trim().Contains("MultiPolicy"))
                {
                    string[] policyList = { };
                    RestServices webServices = new RestServices(data);
                    lspDatabase.QueryAssociatedPolicies();

                    if (CSWData.AssociatedPolicies != null)
                        policyList = CSWData.AssociatedPolicies.Split(';');
                    int counter = 0;
                    for (int j = 0; j <= (policyList.Count() - 1); j++)
                    {
                        string[] phrasePolicy = policyList[j].Split(' ');
                        string PolicyNumber = phrasePolicy.Last();
                        data[KeyRepository.PolicyNumber] = PolicyNumber;
                        if ((Convert.ToInt32(policyItem) - 1) == j)
                        {
                            string beneargs = requestType[1].Split(';')[1].Trim() + "," + beneinfo[1];
                            AddBenes(beneargs);
                            counter++;
                        }
                    }
                    if (counter == 0)
                    {
                        NYLDSelenium.ReportStepResult("Verify if beneficiaries for " + data[KeyRepository.PolicyNumber] + "added successfully.", "System could not add the beneficiaried to " + data[KeyRepository.PolicyNumber], "fail", "no", "yes");
                    }
                }
                else
                    SetPaymentInformation(data[KeyRepository.PreTestDataSet].Split(':')[1].Trim());
            }

            if (data[KeyRepository.PreTestDataSet] == "PaperlessContract")
            {

                if(!paperlessSettingsDriver.VerifyPaperlessStatus())
                {
                    PaperlessSettingsPage ps = new PaperlessSettingsPage(driver, data);
                    ps.VerifyPaperlessSettingsInfo(args);
                }
            }

            // Verify Death Claim policy - If PreTestDataSet is DeathClaim:VerifyEntryExists
            if (data[KeyRepository.PreTestDataSet].Equals("DeathClaimContractExists"))
            {
                //To check the associated policies
                string[] policyList = { };
                lspDatabase.QueryAssociatedPolicies();

                if (CSWData.DeathClaimPolicies)
                    NYLDSelenium.ReportStepResult("Verify Death Claim Policy exists in " + data[KeyRepository.ContractType], " Death Claim Policy exists for this account", "PASS", "no");
                else
                {
                    NYLDSelenium.ReportStepResult("Verify Death Claim Policy exists in" + data[KeyRepository.ContractType], " Death Claim Policy not exists for this account", "FAIL", "no", "YES");                    
                }
                CSWData.DeathClaimPolicies = false;
            }

            //Query policy number is provided in ExistingUserAccountsSheet Spreadsheet
            if (data[KeyRepository.PolicyNumber] != "")
                lspDatabase.QueryPolicyDetails();
        }

        /// <summary>
        /// Method to Datamine and find a contract that meets test requisites
        /// </summary>
        /// <param name="args"></param>
        public void CreateTestRequiste_DataMine(string args)
        {
            LSPDatabase lspDatabase = new LSPDatabase(driver, data);

            var temp = lspDatabase.DataMine_New(data[KeyRepository.PreTestDataSet]);

            if (data[KeyRepository.PreTestDataSet] == "RiderContract" || data[KeyRepository.PreTestDataSet] == "Exchange")
                GetValidRecord(false, temp);
        }

        /// <summary>
        /// Method to fetch the GetValid Record from congtrol number
        /// </summary>
        /// <param name="deactivate"></param>
        /// <param name="tempdata"></param>
        public void GetValidRecord(bool deactivate, List<string> tempdata)
        {
            ProfileMaintenance PF = new ProfileMaintenance(driver, data);
            LSPDatabase LSP = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            RestServices restService = new RestServices(data);
            TestData testData = new TestData();
            data[KeyRepository.AuthToken] = restService.SubmitRestCall("GenerateOAuthToken");
            int i = 0;
            foreach (string record in tempdata)
            {
                i = i + 1;
                data[KeyRepository.PolicyNumber] = record;

                if (data[KeyRepository.ContractType] == "Exchange")
                    restService.GetOffersAPI("Exchange");
                else
                    restService.GetOffersAPI("Rider");

                if (data[KeyRepository.RiderFlag] == "True")
                {
                    LoginPage LP = new LoginPage(driver, data);

                    //Check if contract is registered
                    //PF.LaunchPF("");
                    //userStatus = PF.GetUserStatusRiderAndExchanges("");
                    //PF.ClosePF();

                    //Local
                    if (testData.ValidContract(driver, data, "RiderExchange"))
                    {
                        UserRegistrationDriver RegPage = new UserRegistrationDriver(driver, data);
                        ForgotPage forgot = new ForgotPage(driver, data);
                        LSP.QueryPolicyDetails();

                        //Already CLientInUse Contract try to get Username and password
                        if (driver.Url.Contains("Invalid?Reason"))
                        {
                            //To get the username and password -due to reusable user accounts which are having offers.
                            bool status = forgot.getusernameandpassword(data[KeyRepository.PolicyNumber], false);
                            if (status == false)
                            {
                                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                                continue;
                            }
                        }//If contract is not register then try to register
                        else
                        {
                            RegPage.RegisterUser("");
                            if (driver.Url.Contains("Invalid?Reason"))
                            {
                                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                                continue;
                            }
                        }
                        break;
                    }
                    else
                        continue;
                }
                else
                {
                    Console.WriteLine("The policy status is: " + data[KeyRepository.PolicyStatus]);
                }
                if (i == 100)
                {
                    NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the record that meets the Test criteria: " + data[KeyRepository.ContractType] + "<br>GetOffersAPI:<br>" + data[KeyRepository.RiderFlag], "FAIL", "always", "yes");
                    break;
                }
            }

            if (i == 0)
                NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the record that meets the Test criteria: " + data[KeyRepository.ContractType] + "<br>GetOffersAPI:<br>", "FAIL", "always", "yes");
        }

        public void SetUserStatus(string args)
        {

            LoginPage login = new LoginPage(driver, data);
            HomePage home = new HomePage(driver, data);

            //Set up test requisite
            switch (data[KeyRepository.UserAccountStatus])
            {                
                case "SetValidEmail":
                    if (!new TestData().GetValidEmail(driver, data))
                    {
                        NYLDSelenium.ReportStepResult("Use Valid EMail for Registration", "All valid email are taken, not able to proceed the steps. Please report to DevOps Automation Team", "FAIL", "no", "yes");
                    }

                    break;
            }

            //Logout if already logged in
            if (NYLDSelenium.ElemExist("My Account", home.MyAccountDropDown, false, "no", "no", "always",30))
                home.NavigateToPage(KeyRepository.LogoutPage);

            //Load Application after test setup
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: checkUserStatus                                                                              //////////
        ////// Description:  Check user status in profile maintenace and compare with expected status            ///////////

        public void CheckUserStatus(string expStatus)
        {
            RestServices webServices = new RestServices(data);

            string actstatus = webServices.SubmitRestCall("ProfileStatus");
            if (expStatus == actstatus)
                NYLDSelenium.ReportStepResult("Verify if User Status is " + expStatus, "User status is " + expStatus, "PASS", "no");
            else
                NYLDSelenium.ReportStepResult("Verify if User Status is " + expStatus, "User status is " + actstatus + " instead of " + expStatus, "FAIL", "no");
        }
        /// <summary>
        /// Method to Add Bene based on parameters passed
        /// </summary>
        /// <param name="benetypes"></param>
        public void AddBenes(string benetypes)
        {
            string[] eachBene;
            string[] eachBeneSplit;
            string BeneCount;
            string BeneClass;
            string BeneType;
            string addparam;
            string relparam;
            string requeststring = "";

            CommonFunctions CF = new CommonFunctions(data);
            RestServices webServices = new RestServices(data);

            //Get each bene info
            eachBene = benetypes.Split(',');
            for (int i = 0; i < eachBene.Length; i++)
            {
                //Each Bene
                eachBeneSplit = eachBene[i].Split('-');

                //Get No.of Benes to be created
                BeneCount = eachBeneSplit[0];
                BeneClass = eachBeneSplit[1];
                BeneType = eachBeneSplit[2];

                for (int k = 0; k < Convert.ToInt32(BeneCount); k++)
                {
                    if (eachBeneSplit.Length == 3)
                        addparam = "";
                    else
                        addparam = "|" + eachBeneSplit[3];

                    switch (eachBeneSplit[2])
                    {
                        case "Person":
                            relparam = CF.RandData("Relation", k);
                            break;

                        default:
                            relparam = eachBeneSplit[2];
                            break;
                    }
                    requeststring = requeststring + eachBeneSplit[2] + "|" + eachBeneSplit[1] + "|" + "100.00" + "|" + relparam + addparam + ";";

                }
            }

            Console.WriteLine(requeststring);


            //Each Bene
            requeststring = requeststring.Trim(';');
            string test = webServices.SubmitRestCall("AddBenefeciary", "10", requeststring);
            if (!test.Contains("successful"))
            {
                test = webServices.SubmitRestCall("AddBenefeciary", "10", requeststring);
                if (string.IsNullOrEmpty(test))
                {
                    //string filePath = CSW.Properties.Settings.Default.BeneXML + "\\" + data[KeyRepository.TestID] + "_" + DateTime.Now.Date.ToString("MMddyyy") + "_" + DateTime.Now.Second + ".txt";
                    //if (File.Exists(filePath))
                    //    File.Delete(filePath);
                    //File.Create(filePath).Close();
                    //File.WriteAllText(filePath, CSWData.XML);
                    NYLDSelenium.ReportStepResult("Could not Add Bene as a Test Prequisite ", "Add Bene Service Response: " + test, "fail", "no", "yes");
                }
            }

            NYLDSelenium.ReportStepResult("Add Bene Service Response: " + test, "Add Bene Service Response: " + test, "info", "no");
            Console.WriteLine(test);
        }

        /// <summary>
        /// Method to set the payment information for the test data
        /// </summary>
        /// <param name="args"></param>
        public void SetPaymentInformation(string args)
        {
            string[] getOption = { };
            string[] getOption2 = { };
            string EFTAction;
            string PayFreqOpt = "";
            string CurrentPayFreq = "";
            string PendingPayment = "";

            RestServices webServices = new RestServices(data);

            if (args.Contains(","))
            {
                getOption = args.Split(',');

                EFTAction = getOption[0].Trim();
                PendingPayment = getOption[1];
                if (getOption.Length > 2)
                    PayFreqOpt = getOption[2].Trim();

                if (PayFreqOpt.Contains("-"))
                {
                    getOption2 = PayFreqOpt.Split('-');

                    PayFreqOpt = getOption2[0].Trim();
                    CurrentPayFreq = getOption2[1].Trim();
                }
            }
            else
                EFTAction = args.Trim();

            string EFTstatus = "";
            switch (EFTAction)
            {
                case "DeleteEFT":
                    // always the first contract going to be a EFT contract in multi contract
                    data[KeyRepository.PolicyNumber] = CSWData.AssociatedPolicies.Split(';')[0];
                    EFTstatus = webServices.SubmitRestCall("DeleteEFT");
                    break;
                case "ExistingEFT":
                case "QuarterlyEFT":
                    //Check if EFT is Set
                    for (int i = 1; i <= 2; i++)
                    {
                        EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                        NYLDSelenium.ReportStepResult("Verify ExistingEFT Eligibility", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                        if (EFTstatus != "Existing EFT")
                        {
                            //Add EFT
                            if (EFTAction == "QuarterlyEFT")
                                EFTstatus = webServices.SubmitRestCall("AddEFT", "10", "Quarterly");
                            else
                                EFTstatus = webServices.SubmitRestCall("AddEFT");

                            NYLDSelenium.ReportStepResult("Adding EFT", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                            EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                            NYLDSelenium.ReportStepResult("Verify ExistingEFT Eligibility after adding EFT", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                        }
                    }
                    
                    if (string.IsNullOrEmpty(EFTstatus) || EFTstatus != "Existing EFT")
                    {
                        NYLDSelenium.ReportStepResult("Verify if no EFT set up is available", "System could not verify Current EFT status for the Policy " + data[KeyRepository.PolicyNumber] + " the return value obtained for the policy is " + EFTstatus, "FAIL", "yes");
                    }
                    break;
                case "VerifyExistingEFT":
                    EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                    if (webServices.SubmitRestCall("CheckEFTElig") != "Existing EFT")
                    {
                        NYLDSelenium.ReportStepResult("Verify if no EFT set up is available", "System could not verify Current EFT status for the Policy " + data[KeyRepository.PolicyNumber] + " the return value obtained for the policy is " + EFTstatus, "FAIL", "yes");
                    }
                    break;

                case "NewEFT":
                    //Check if EFT is Set
                    //EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                    //Add EFT
                    if (EFTAction == "QuarterlyEFT")
                        EFTstatus = webServices.SubmitRestCall("AddEFT", "10", "Quarterly");
                    else
                        EFTstatus = webServices.SubmitRestCall("AddEFT");
                    break;
                case "NoExistingEFT":

                    //call a webservice to Delete a EFTCheckEligEFT
                    EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                    NYLDSelenium.ReportStepResult("Verify NoExistingEFT Eligibility", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                    //Delete EFT and check if EFT Eligibility is No Existing EFT
                    if (EFTstatus == "Existing EFT" || data[KeyRepository.ContractType].Contains("SingleQElig"))
                    {
                        EFTstatus = webServices.SubmitRestCall("DeleteEFT");
                        NYLDSelenium.ReportStepResult("Deleting EFT", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                        EFTstatus = webServices.SubmitRestCall("CheckEFTElig");
                        NYLDSelenium.ReportStepResult("Verify NoExistingEFT Eligibility after deleting EFT", "Verification for policy " + data[KeyRepository.PolicyNumber] + " the return the eligibility status as, " + EFTstatus, "INFO", "no");
                    }

                    if (EFTstatus != "No Existing EFT")
                    {
                        NYLDSelenium.ReportStepResult("Prequisite:Ensure contract does not have EFT setup", "The contract " + data[KeyRepository.PolicyNumber] + " is in " + EFTstatus, "FAIL", "no", "yes");
                    }
                    else if (EFTstatus == "Not Eligible")
                    {
                        NYLDSelenium.ReportStepResult("Prequisite:Ensure contract is not EFT Eligible", "The contract " + data[KeyRepository.PolicyNumber] + " is in " + EFTstatus, "FAIL", "no", "yes");
                    }
                    break;

                case "QuarterlyElig":
                    LSPDatabase lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryPaymentDetails();
                    lspDatabase.QueryQuarterlyPaymntElig();

                    if (!(CSWData.QuarterlyEligibility))
                        NYLDSelenium.ReportStepResult("Verify Quarterly pay frequency eligiblity", "Test data criteria Not met as Quarterly pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    break;
                case "PaymentModeElig":
                    lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryPolicyDetails();
                    lspDatabase.QueryPaymentDetails();
                    EFTstatus = webServices.SubmitRestCall("PaymentModeElig");
                    if (EFTstatus != "Eligible")
                    {
                        NYLDSelenium.AddHeader("<h3 style=\"color:Purple\">" + "Prerequisite - Verify Pay frequency is Eligible for " + EFTAction + " </h3>" + "<h3 style=\"color:Purple\">" + "###########" + "</h3>", "Success");
                        NYLDSelenium.ReportStepResult("Verify Pay frequency is Eligible", "Test data criteria Not met as pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    }
                    break;
                case "QMPayFreqElig":
                    lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryPolicyDetails();
                    lspDatabase.QueryPaymentDetails();
                    EFTstatus = webServices.SubmitRestCall("QMPayFreqElig");
                    if (EFTstatus != "Eligible")
                    {
                        NYLDSelenium.AddHeader("<h3 style=\"color:Purple\">" + "Prerequisite - Verify Pay frequency is Eligible for " + EFTAction + " </h3>" + "<h3 style=\"color:Purple\">" + "###########" + "</h3>", "Success");
                        NYLDSelenium.ReportStepResult("Verify Pay frequency is Eligible", "Test data criteria Not met as pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    }
                    break;

                case "MQPayFreqElig":
                    lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryPolicyDetails();
                    lspDatabase.QueryPaymentDetails();
                    EFTstatus = webServices.SubmitRestCall("MQPayFreqElig");
                    if (EFTstatus != "Eligible")
                    {
                        NYLDSelenium.AddHeader("<h3 style=\"color:Purple\">" + "Prerequisite - Verify Pay frequency is Eligible for " + EFTAction + " </h3>" +"<h3 style=\"color:Purple\">" + "###########" + "</h3>", "Success");
                        NYLDSelenium.ReportStepResult("Verify Pay frequency is Eligible", "Test data criteria Not met as pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    }
                    break;
                case "PayFrequencyMToQ":
                    //Check if EFT is Set ON 
                    lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryPolicyDetails();
                    lspDatabase.QueryPaymentDetails();
                    //Change  Payment frequency Monthly to Quartely
                    if (webServices.SubmitRestCall("CheckEFTElig") != "Existing EFT")
                    {
                        EFTstatus = webServices.SubmitRestCall("MQPayFreqElig");
                        if (EFTstatus != "Eligible")
                        {
                            NYLDSelenium.AddHeader("<h3 style=\"color:Purple\">" + "Prerequisite - Verify Pay frequency is Eligible" + " </h3>" + "<h3 style=\"color:Purple\">" + "PayFrequencyMToQ" + "</h3>", "Success");
                            NYLDSelenium.ReportStepResult("Verify Pay frequency is Eligible for MToQ", "Test data criteria Not met as pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                        }
                        else
                            EFTstatus = webServices.SubmitRestCall("UpdatePartyPayFrequency", desc:"Quarterly");
                    }
                    else 
                        NYLDSelenium.ReportStepResult("Verify Test data criteria is Not met please re execute this test case", "Test data criteria is Not met as Quarterly pay frequency eligility due to Exsitng AutoPay is On for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    break;
                case "PayFrequencyQToM":
                    //Check if EFT is Set ON 
                    lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryPolicyDetails();
                    lspDatabase.QueryPaymentDetails();
                    //Change  Payment frequency Quaterly to Monthly
                    if (webServices.SubmitRestCall("CheckEFTElig") != "Existing EFT")
                    {
                        EFTstatus = webServices.SubmitRestCall("QMPayFreqElig");
                        if (EFTstatus != "Eligible")
                        {
                            NYLDSelenium.AddHeader("<h3 style=\"color:Purple\">" + "Prerequisite - Verify Pay frequency is Eligible" + " </h3>"+"<h3 style=\"color:Purple\">" + "PayFrequencyQToM" + "</h3>", "Success");
                            NYLDSelenium.ReportStepResult("Verify Pay frequency is Eligible for QToM", "Test data criteria Not met as pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                        }
                        else
                            webServices.SubmitRestCall("UpdatePartyPayFrequency", desc:"Monthly");
                    }
                    else
                        NYLDSelenium.ReportStepResult("Verify Test data criteria is Not met please re execute this test case", "Test data criteria is Not met as Monthly pay frequency eligility due to Exsitng AutoPay is On for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    break;
                default:
                    break;
            }

            switch (PayFreqOpt)
            {
                case "QuarterlyElig":
                    LSPDatabase lspDatabase = new LSPDatabase(driver, data);
                    lspDatabase.QueryAssociatedPolicies();
                    lspDatabase.QueryPaymentDetails();
                    lspDatabase.QueryQuarterlyPaymntElig();

                    if (!(CSWData.QuarterlyEligibility))
                        NYLDSelenium.ReportStepResult("Verify Quarterly pay frequency eligiblity", "Test data criteria is not met as Quarterly pay frequency eligility is not found for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");

                    if (CurrentPayFreq != "")
                    {
                        if (CurrentPayFreq == "Monthly")
                        {
                            data[KeyRepository.CurrentPaymentFrequency] = "M";
                            if (!(data[KeyRepository.CurrentPaymentFrequency] == "M"))
                                NYLDSelenium.ReportStepResult("Verify current pay frequency meets test prerequisite", "Test data criteria is not met as the current pay frequency is not " + CurrentPayFreq + " for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");

                        }
                        else if (CurrentPayFreq == "Quarterly")
                        {
                            data[KeyRepository.CurrentPaymentFrequency] = "Q";
                            if (!(data[KeyRepository.CurrentPaymentFrequency] == "Q"))
                                NYLDSelenium.ReportStepResult("Verify current pay frequency meets test prerequisite", "Test data criteria is not met as the current pay frequency is not " + CurrentPayFreq + " for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                        }
                    }
                    //call webservice to check Quarterly eligiblity

                    break;

                case "Quarterly":
                    //call webservice to update current pay frequency to quarterly
                    break;

                default:
                    break;

            }
            switch (PendingPayment)
            {
                case "PendingPayment":
                    LSPDatabase DB = new LSPDatabase(driver, data);
                    EFTstatus = webServices.SubmitRestCall("AddOneTimePayment");
                    driver.Navigate().Refresh();
                    if (!(DB.PendingPayment()))
                        NYLDSelenium.ReportStepResult("Verify if Pending payment exists for the contract", "Pending payment does not exist for the policy: " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");
                    break;

                default:
                    break;
            }
            driver.Navigate().Refresh();
            if (string.IsNullOrEmpty(EFTstatus) && !args.Contains("QuarterlyElig") && !args.Contains("QuarterlyElig") && !args.Contains("Quarterly"))
                NYLDSelenium.ReportStepResult("Verify API-Web Services are up and running or not", "Verify API-Web Services are up and running Verify or not , for the policy:  " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");

        }

        /// <summary>
        ///  Method to Add one time payment for the existing contract
        /// </summary>
        /// <param name="args"></param>
        public void MakePayment(string args)
        {
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            testRequsite.SetPaymentInformation("NoExistingEFT,None,PendingPayment");
        }

        /// <summary>
        /// Method to introduce change in policy information to create expected test scenario
        /// </summary>
        /// <param name="type"></param>
        public void SetValue(string args)
        {
            CommonFunctions CF = new CommonFunctions(data);
            Random random = new Random();
            IList<string> options = new List<string>();
            string[] getOptions = args.Split(',');
            options = getOptions.ToList();
            string hp2 = "";
            hp2 = random.Next(201, 1500).ToString();

            switch (options[0].Trim())
            {
                case "UserName":
                    CSWData.TempUserName = data[KeyRepository.UserName];
                    if (options.Count > 1)
                    {
                        if (options[1].Trim() == "ExistingUserName")
                            data[KeyRepository.UserName] = "13Bene";
                        else if (options[1].Trim() == "UniqUserName")
                            CF.getUserName();
                        NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.UserName], "INFO", "no");
                    }
                    break;
                case "ExistingEmail":
                    CSWData.TempEmail = data[KeyRepository.EmailId];
                    data[KeyRepository.EmailId] = "naresh_konjeti@newyorklife.com";
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.EmailId], "INFO", "no");
                    break;
                case "Password":
                    CSWData.TempPassword = data[KeyRepository.Password];
                    data[KeyRepository.PrevPassword] = data[KeyRepository.Password];
                    if (options.Count > 1)
                    {
                        if (options[1].Trim() == "NewPassword")
                        {
                            data[KeyRepository.Password] = ("AUT" + data[KeyRepository.FirstName] + data[KeyRepository.SSN].Substring(3, 5) + hp2).Trim().ToString();
                            string Lower1 = data[KeyRepository.Password].Substring(0, 5).ToLower();
                            string Upper1 = data[KeyRepository.Password].Substring(5).ToUpper();
                            data[KeyRepository.Password] = Lower1 + Upper1 + "@123*";

                            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.Password], "INFO", "no");
                        }
                        else if (options[1].Trim() == "ExistingPassword")
                        {
                            data[KeyRepository.PrevPassword] = data[KeyRepository.Password];

                            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.PrevPassword], "INFO", "no");
                        }
                    }
                    break;
                case "ExistingUsername":
                    CSWData.TempUserName = data[KeyRepository.UserName];
                    data[KeyRepository.UserName] = "13Bene";
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.UserName], "INFO", "no");

                    break;
                case "UniqUser":
                    CSWData.TempUserName = data[KeyRepository.UserName];
                    data[KeyRepository.UserName] = ("AUT" + data[KeyRepository.FirstName] + data[KeyRepository.SSN].Substring(3, 5) + DateTime.Now.ToString("yyyyMMddHHmmss")).Trim().ToString();
                    break;

                case "ExistingUserAndEmail":
                    CSWData.TempUserName = data[KeyRepository.UserName] + ":" + data[KeyRepository.EmailId];
                    data[KeyRepository.UserName] = "MultiStatus01";
                    data[KeyRepository.EmailId] = "multi40@email.com";
                    break;

                case "InvalidLastName":
                    CSWData.TempVal = data[KeyRepository.LastName];
                    data[KeyRepository.LastName] = "12345";
                    break;

                case "ExpiredToken":
                    CSWData.TempVal = data[KeyRepository.TokenWaitTime];
                    data[KeyRepository.TokenWaitTime] = "Expired";
                    break;

                case "prtlastname":
                    CSWData.TempVal = data[KeyRepository.LastName];
                    data[KeyRepository.LastName] = data[KeyRepository.LastName].Substring(0, data[KeyRepository.LastName].Length - 3);
                    break;
                case "Email":
                    if (options.Count > 1)
                    {
                        if (options[1].Trim() == "NewEmail")
                            data[KeyRepository.EmailId] = "AUTtest" + DateTime.Now.ToString("MMddyyyyhhmmss") + hp2 + "@" + "automation.com";
                        else if (options[1].Trim() == "ValidEmail")
                            data[KeyRepository.EmailId] = CSWData.TempEmail;
                        else if (options[1].Trim() == "ExistingEmail")
                            CSWData.TempEmail = data[KeyRepository.EmailId];
                    }
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.EmailId], "INFO", "no");
                    CSWData.TempEmail = data[KeyRepository.EmailId];
                    break;
                case "NewEmail":
                    hp2 = random.Next(201, 500).ToString();
                    data[KeyRepository.EmailId] = "AUTtest" + DateTime.Now.ToString("MMddyyyyhhmmss") + hp2 + "@" + "automation.com";
                    data[KeyRepository.EmailIdSet] = data[KeyRepository.EmailId];
                    NYLDSelenium.ReportStepResult("Email set for :" + args.Trim(), data[KeyRepository.EmailIdSet], "INFO", "no");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :NewEmail" + "</h3>", data[KeyRepository.EmailId], "INFO", "no");
                    break;
                case "InvalidEmail":
                    CSWData.TempEmail = data[KeyRepository.EmailId];
                    string[] email1 = "InvalidEmail@NotValid.com".Split('@');
                    data[KeyRepository.UserName] = data[KeyRepository.UserName] + DateTime.Now.Second + DateTime.Now.Minute;
                    data[KeyRepository.EmailId] = email1[0] + DateTime.Now.Second + "#" + email1[1];
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :InvalidEmail" + "</h3>", data[KeyRepository.EmailId], "INFO", "no");
                    break;
                case "ValidEmail":
                    data[KeyRepository.EmailId] = CSWData.TempEmail;
                    break;

                case "noexistcontract":
                    data[KeyRepository.PolicyNumber] = "A99998400";
                    break;

                case "invalidcontract1":
                    data[KeyRepository.PolicyNumber] = "5a6#7^8>/";
                    break;
                case "invalidcontract2":
                    data[KeyRepository.PolicyNumber] = "A1234";
                    break;
                case "invalidcontract3":
                    data[KeyRepository.PolicyNumber] = "2abcd";
                    break;

                case "lcasePassword":
                    data[KeyRepository.Password] = data[KeyRepository.Password].ToLower();
                    break;

                case "ucasePassword":
                    data[KeyRepository.Password] = data[KeyRepository.Password].ToUpper();
                    break;

                case "mcasePassword":
                    string Lower = data[KeyRepository.Password].Substring(0, 6).ToLower();
                    string Upper = data[KeyRepository.Password].Substring(6).ToUpper();
                    data[KeyRepository.Password] = Lower + Upper;
                    break;
                case "LastName":
                    if (options[1] != "valid")
                    {
                        NYLDSelenium.ReportStepResult("Update for :" + options[0].Trim(), "and value to change  " + options[1].Trim(), "INFO", "no");
                        CSWData.TempLastName = data[KeyRepository.LastName];
                        data[KeyRepository.LastName] = options[1].ToString();
                    }
                    if (options[1] == "valid")
                        data[KeyRepository.LastName] = CSWData.TempLastName;
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.LastName], "INFO", "no");
                    break;
                case "SSN":
                    if (options[1] != "valid")
                    {
                        NYLDSelenium.ReportStepResult("Update for :" + options[0].Trim(), "and value to change  " + options[1].Trim(), "INFO", "no");
                        CSWData.TempSSN = data[KeyRepository.SSN];
                        data[KeyRepository.SSN] = options[1].ToString();
                    }
                    if (options[1] == "valid")
                        data[KeyRepository.SSN] = CSWData.TempSSN;
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.SSN], "INFO", "no");
                    break;
                case "DOB":

                    if (options[1] != "valid")
                    {
                        NYLDSelenium.ReportStepResult("Update for :" + options[0].Trim(), "and value to change  " + options[1].Trim(), "INFO", "no");
                        CSWData.TempDOB = data[KeyRepository.DOB];
                        data[KeyRepository.DOB] = options[1].ToString();
                    }
                    if (options[1] == "valid")
                        data[KeyRepository.DOB] = CSWData.TempDOB;
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", data[KeyRepository.DOB], "INFO", "no");
                    break;

                case "firstuserdetails":
                    CSWData.TempVal = data[KeyRepository.UserName] + ";" + data[KeyRepository.PolicyNumber] + ";" + data[KeyRepository.EmailId];
                    break;
                case "PIN":
                    NYLDSelenium.ReportStepResult("Update for Invalid PIN", "and value to change " + options[1].Trim(), "INFO", "no");
                    CSWData.TempInvalidPIN = options[1].ToString();
                    break;
                case "PendingPayment":
                    LSPDatabase DB = new LSPDatabase(driver, data);
                    RestServices webServices = new RestServices(data);
                    webServices.SubmitRestCall("AddOneTimePayment");
                    if (!(DB.PendingPayment()))
                        NYLDSelenium.ReportStepResult("Verify if Pending payment exists for the contract", "Pending payment does not exist for the policy: " + data[KeyRepository.PolicyNumber], "FAIL", "always", "yes");
                    break;
                case "NewSignUpAutoPay":
                case "MonthlyAutoPay":
                    SetPaymentInformation("NewEFT");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", "New SignUp AutoPay for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    break;
                case "DeleteExistingAutoPay":
                    SetPaymentInformation("DeleteEFT");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", "Delete AutoPay for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    break;
                case "QuarterlyAutoPay":
                    SetPaymentInformation("QuarterlyEFT");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", "Delete AutoPay for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    break;
                case "PayFrequencyQToM":
                    SetPaymentInformation("PayFrequencyQToM");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", "Pay Frequency Change from Quaterly to Monthly for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    break;
                case "PayFrequencyMToQ":
                    SetPaymentInformation("PayFrequencyMToQ");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", "Pay Frequency Change from Quaterly to Monthly for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    break;
                case "PaymentModeElig":
                    SetPaymentInformation("PaymentModeElig");
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "SetValue for :" + args.Trim() + "</h3>", "Pay Frequency Eligible check Monthly and Quaterly is present for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    break;
            }
        }

        /// <summary>
        /// Method helps to Add Monthly autoPay /delete autoPay/add to Quaterly autoPay
        /// </summary>
        /// <param name="args"></param>
        public void ResetValue(string args)
        {
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            IList<string> options = new List<string>();
            string[] getOptions = args.Split(',');
            options = getOptions.ToList();
            switch (options[0].Trim())
            {
                case "DeleteExisitngAutoPay":
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Reset Value for :" + args.Trim() + "</h3>", "Delete Existing AutoPay for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    SetPaymentInformation("DeleteEFT"); break;
                case "PayFrequencyQToM":
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Reset Value for :" + args.Trim() + "</h3>", "Pay Frequency Change from Quaterly to Monthly for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    SetPaymentInformation("PayFrequencyQToM"); break;
                case "PayFrequencyMToQ":
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Reset Value for :" + args.Trim() + "</h3>", "Pay Frequency Change from Monthly to Quaterly for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    SetPaymentInformation("PayFrequencyMToQ"); break;
                case "PaymentModeElig":
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Reset Value for :" + args.Trim() + "</h3>", "Pay Frequency Eligible check Monthly and Quaterly is present for this contract number " + data[KeyRepository.PolicyNumber], "INFO", "no");
                    SetPaymentInformation("PaymentModeElig"); break;

            }
            driver.Navigate().Refresh();
        }

        public void UpdateMCUSR4(string args)
        {
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            LSPDatabase ls = new LSPDatabase(driver, data);
            IList<string> options = new List<string>();
            string[] getOptions = args.Split(',');
            options = getOptions.ToList();
            switch (options[0].Trim())
            {
                case "DeathContractAlreadyUsed":
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Update Value for :" + args.Trim() + "</h3>", "Update the MCUSR4 Table" + data[KeyRepository.PolicyNumber], "INFO", "no");                   
                    ls.GetDataBaseValues("DeathContractAlreadyUsed");
                    break;
            }
        }

    }
}
    