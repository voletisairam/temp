﻿using CSW.PageObjects.Functions;
using System.Collections.Generic;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace CSW.Drivers
{
    class InvoicePDFDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public InvoicePDFDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


            /// <summary>
            /// Method to verify the invoice Downloaded in the document 
            /// </summary>
            /// <param name="args">Type of invoice to verify, e.g., "Premium Notice"</param>
            public void VerifyInvoice(string args)
        {
            // Instantiate the handler with the required parameters
            InvoicePDF pdfHandler = new InvoicePDF(driver, data);

            // Download and validate the invoice if the condition matches

            if (args == "PremiumNotice")
                pdfHandler.DownloadAndValidatePDF();
      
        }
    }
}
