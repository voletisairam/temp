﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Payments;
using CSW.PageObjects.Profile;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System.Linq;

namespace CSW.Drivers
{
    class ChangePayorDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ChangePayorDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        /// <summary>
        /// Method to verify change payor page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyChangePayorPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            DB.QueryAssociatedPolicies("Beneficiaries");  
            home.NavigateToPage(KeyRepository.PayorPage);
            changePayor.VerifyChangePayorInfo();
        }


        /// <summary>
        /// Method to update change payor with new values
        /// </summary>
        /// <param name="args"></param>
        public void UpdateChangePayor(string args)
        {
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            //Update change payor
            changePayor.UpdateChangePayor(args.Trim());
        }


        /// <summary>
        /// Method to verify change payor thank you page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyChangePayorThankYouPage(string args)
        {
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            changePayor.VerifyChangePayorThankYouPage(args);
        }

        /// <summary>
        /// Method helps to verify Verify ChangePayor USPSAddress ValidationPage
        /// </summary>
        /// <param name="args"></param>
        public void VerifyUSPSAddressValidationPage(string args)
        {
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            changePayor.VerifyChangePayorUSPSAddressValidationPage(args);
        }

        /// <summary>
        /// Method helps to suggest the SelectAddress
        /// </summary>
        /// <param name="args"></param>
        public void UpdateSelectAddress(string args)
        {
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            changePayor.UpdateSelectAddress(args);
        }

        /// <summary>
        /// Method to verify change payor result screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyChangePayorGriefMsg(string args)
        {
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            changePayor.VerifyChangePayorEditInsuredGriefMsg("Change Payor");
        }

        /// <summary>
        /// Method to verify change payor page
        /// </summary>
        /// <param name="args"></param>
        public void ChangePayorPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            DB.QueryAssociatedPolicies("Beneficiaries");
            home.NavigateToPage(KeyRepository.PayorPage);
            changePayor.ChangePayorChangeCountry(args);
        }

    }
}
