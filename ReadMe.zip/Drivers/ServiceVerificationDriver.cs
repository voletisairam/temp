﻿using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.NewRegistration;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CSW.PageObjects.Email.EmailInformation;

namespace CSW.Drivers
{
     class ServiceVerificationDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ServiceVerificationDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }
        /// <summary>
        /// Method to verify Service 
        /// </summary>
        public void VerifyService(string args)
        {
            RestServices restCall = new RestServices(data);
            LSPDatabase ld = new LSPDatabase(driver, data);
            string value;
            switch (args.Trim())
            {
                case "ProfileMobileNumber":
                    ld.GetClientId();
                    data[KeyRepository.AuthToken] = restCall.SubmitRestCall("GenerateOAuthToken");
                    restCall.SubmitOAuth2RestCall("SearchUser", "nylid");
                    value = restCall.SubmitOAuth2RestCall("DeviceInfo", "phoneNumber");
                    ProtectProfilePage pp = new ProtectProfilePage(driver, data);
                    pp.VerifyProfilePhonenumber(value);
                    break;

            }

        }
     }
}
