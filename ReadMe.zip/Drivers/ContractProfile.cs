﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using NYLDDotNetFramework;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.External_Applications;

namespace CSW.Drivers
{
    class ContractProfile
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ContractProfile(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        /// <summary>
        /// Metho to deactivate user profile actions
        /// </summary>
        /// <param name="args"></param>

        public void DeactivateUser(string args)
        {
            ProfileMaintenance profileMaintenance = new ProfileMaintenance(driver, data);

            profileMaintenance.DeactivateUser("");
        }
    }
}
