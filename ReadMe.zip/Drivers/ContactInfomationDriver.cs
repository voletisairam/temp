﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using CSW.PageObjects.Registration;
using CSW.PageObjects.Login;
using CSW.Common.Services;
using CSW.PageObjects.Profile;
using CSW.PageObjects.Home;

namespace CSW.Drivers
{
    class ContactInfomationDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ContactInfomationDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        public void ContactInformationPage(string args)
        {
            ContactInfomationPage contact = new ContactInfomationPage(driver, data);
            HomePage home = new HomePage(driver, data);

            string[] options = args.Split('-');
            switch (options[0].Trim())
            {
                case "Verify":
                    home.NavigateToPage(KeyRepository.ContactInfoPage);
                    contact.VerifyContactInfomation();
                    break;

                case "Update":
                    contact.UpdateContactInformation(options[1].Trim());
                    break;

                case "OTP":
                    contact.VerifyIdentity(args);
                    break;

                case "UpdateProfileMobile":
                    home.NavigateToPage(KeyRepository.ContactInfoPage);
                    contact.VerifyMobileForProtectProfile(options[1].Trim());
                    break;
            }
        }

        public void GriefContactInformationPage(string args)
        {
            ContactInfomationPage contact = new ContactInfomationPage(driver, data);
            HomePage home = new HomePage(driver, data);

            home.NavigateToPage(KeyRepository.ContactInfoPage);

            string[] options = args.Split('-');
            switch (options[0].Trim())
            {
                case "Verify":
                    contact.VerifyGriefContactInfoPage();
                    break;
            }
        }

        public void VerifyGriefMessage(string args)
        {
            ContactInfomationPage contact = new ContactInfomationPage(driver, data);
            RegistrationGrief griefMsg = new RegistrationGrief(driver, data);
            HomePage home = new HomePage(driver, data);


            switch (args)
            {
                case "Snowbird":
                    griefMsg.VerifyRegGriefMsg(args);
                    break;
            }
        }

        public void ConfirmAddressPage(string args)
        {
            ContactInfomationPage contact = new ContactInfomationPage(driver, data);

            string[] options = args.Split('-');
            switch (options[0].Trim())
            {
                case "Verify":
                    contact.VerifyConfirmAddress();
                    break;

                case "Update":
                    contact.UpdateConfirmAddress(options[1].Trim());
                    break;
            }
        }

        public void SelectAddlContractsPage(string args)
        {
            ContactInfomationPage contact = new ContactInfomationPage(driver, data);

            string[] options = args.Split('-');
            switch (options[0].Trim())
            {
                case "Verify":
                    contact.VerifySelectAddlContracts();
                    break;

                case "Update":
                    contact.UpdateSelectAddlContracts(options[1].Trim());
                    break;
            }
        }

        public void VerifyThankYouPage(string args)
        {
            IList<string> options = new List<string>();
            string[] getOptions = args.Split(',');
            options = getOptions.ToList();
            ContactInfomationPage contact = new ContactInfomationPage(driver, data);
            switch (options[0].Trim())
            {
                case "ProfileMobile":
                    contact.VerifyMobileUpdateThankYou(args);
                    break;
                default:
                    contact.VerifyThankYou(args);
                    break;
            }
           
        }
    }
}
