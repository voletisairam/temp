﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumExtras.PageObjects;
using OpenQA.Selenium;
using CSW.PageObjects.External_Applications;
using CSW.PageObjects.Login;
using CSW.Common.Others;
using CSW.Common.DataBase;
using CSW.Common.Database;
using CSW.PageObjects.Functions;

namespace CSW.Drivers
{
    class Riders_ExchangesDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public Riders_ExchangesDriver(IWebDriver webDriver, Dictionary<string, string> data)
        {
            this.driver = webDriver;
            this.data = data;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method to login to rider screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyOffers(string args)
         {
            RiderPage riders = new RiderPage(driver, data);
            Exchanges exchanges = new Exchanges(driver, data);

            //Verify offers displayed
            if (data[KeyRepository.ContractType] == "Exchange")
                exchanges.VerifyOffers("Exchange");  
            else
                riders.VerifyOffers("Rider");

        }

        /// <summary>
        /// MEthod to select the rider offer
        /// </summary>
        /// <param name="args"></param>
        public void SelectOffer(string args)
        {
            RiderPage riders = new RiderPage(driver, data);
            Exchanges exchanges = new Exchanges(driver, data);

            //Select offer
            if (data[KeyRepository.ContractType] == "Exchange")
                exchanges.SelectOffer();
            else
                riders.SelectOffer();
        }

        /// <summary>
        /// Method to verify the page and submit the form
        /// </summary>
        /// <param name="args"></param>
        public void SubmitExchangeForm(string args)
        {
            RiderPage riders = new RiderPage(driver, data);
            Exchanges exchanges = new Exchanges(driver, data);
            MIDatabase midb = new MIDatabase(data);
            LSPDatabase lspdatabase = new LSPDatabase(driver, data);
            ValidatePDF validatePdf = new ValidatePDF(driver, data);
            ALIP alip = new ALIP(driver, data);

            //Submit Exchange form
            exchanges.ReviewAndConfirmExchange();

            //Verify Thank you screen
            exchanges.VerifyThankYouPage("");

            //Verify Database
            lspdatabase.QueryLSPNotes("Exchange"); 

            //Download PDF
            exchanges.VerifyEsigApplicationPDF("Exchange");

            //Verify PDF
            validatePdf.VerifyPDFCFormContent("Exchange");

            //Verify ALIP Entry
            alip.VerifyEntryinALIP("Exchange");
        }

        /// <summary>
        /// Method to verify the page and submit the form
        /// </summary>
        /// <param name="args"></param>
        public void SubmitRiderForm(string args)
        {
            RiderPage riders = new RiderPage(driver, data);
            MIDatabase midb = new MIDatabase(data);
            LSPDatabase lspdatabase = new LSPDatabase(driver, data);
            ValidatePDF validatePdf = new ValidatePDF(driver, data);
            ALIP alip = new ALIP(driver, data);

            //Verify Rider Form
            riders.VerifyRideForm();

            //Answer rider form
            riders.FillRiderForm();

            //Review and submit
            riders.VerifyReviewAndConfirmScreen();

            //Verify Certify screen
            riders.ReviewAndCertify();

            //verify Thank you screen
            riders.VerifyThankYouPage();

            //Verify Database
            lspdatabase.QueryLSPNotes("Riders");

            //Download PDF
            riders.VerifyEsigApplicationPDFDownload();

            //Verify PDF
            validatePdf.VerifyPDFCFormContent("Riders");

            //Verify ALIP Entry
            alip.VerifyEntryinALIP("Riders");
        }

        /// <summary>
        /// Method to choose the Rider and navigate to login screen
        /// </summary>
        /// <param name="args"></param>
        public void CheckEligibility(string args)
        {
            RiderPage riders = new RiderPage(driver, data);
            Exchanges exchanges = new Exchanges(driver, data);
            LoginPage Login = new LoginPage(driver, data);
          
            //Load rider/exchange url based on the policy condition
            if (data[KeyRepository.ContractType] == "Exchange")
                exchanges.CheckEligibility_Exchange(args.Trim());
            else
                riders.CheckEligibility_Rider(args.Trim());
            
        }

     

        /// <summary>
        /// Method to verify Database entries
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDatabaseEntries(string args)
        {
            MIDatabase midb = new MIDatabase(data);
            LSPDatabase lspdatabase = new LSPDatabase(driver, data);

                //Verify MI DB
                midb.VerifyActivityTable(args);
                //Verify LSP Notes
                lspdatabase.QueryLSPNotes(args);        
        }
        
        public void VerifyRiderFormFields(string args)
        {
            RiderPage riders = new RiderPage(driver, data);

            riders.ValidateFormFields("");
        }
    }
}
