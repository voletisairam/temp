﻿using CSW.PageObjects.Payments;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System.Linq;

namespace CSW.Drivers
{
    class OneTimePaymentDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public OneTimePaymentDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method to verify One-Time page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyOneTimePaymentPage (string args)
        {
            OneTimePaymentPage oneTimePayment = new OneTimePaymentPage(driver, data);

            oneTimePayment.VerifyOneTimePayment();
        }

        /// <summary>
        /// Method to make One-Time Payment
        /// </summary>
        /// <param name="args">Arguments to control the payment process, e.g., "NoContinue" to skip the continue button click.</param>
        public void MakeOneTimePayment(string args)
        {
            OneTimePaymentPage oneTimePayment = new OneTimePaymentPage(driver, data);

            oneTimePayment.MakeOneTimePayment(args);
        }

        /// <summary>
        /// Method to verify One-Time page fields
        /// </summary>
        /// <param name="args"></param>
        public void NavigateOneTimePaymentPage()
        {
            OneTimePaymentPage oneTimePayment = new OneTimePaymentPage(driver, data);
            oneTimePayment.ClickOneTimePaymentLink();
        }

      
    }
}
