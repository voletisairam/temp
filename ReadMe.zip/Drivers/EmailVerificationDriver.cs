﻿using CSW.Common.Email;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Drivers
{
    class EmailVerificationDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public EmailVerificationDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        /// <summary>
        /// Method to verify Email 
        /// </summary>
        public void VerifyEmail(string args)
        {
            EmailVerification email = new EmailVerification(driver, data);
            switch (args.Trim())
            {
                case "NewAutoPay":
                    email.VerifyEmailInbox("EFT SetUp Confirmation");
                    break;
                case "UpdateAutoPay":
                    email.VerifyEmailInbox("EFT Update Confirmation");
                    break;
                case "PayFreqChangeConfirmation":
                case "ChangePaymentFrequency":
                    email.VerifyEmailInbox("Payment Frequency Change Confirmation");
                    break;
                case "CancelAutoPay":
                    email.VerifyEmailInbox("Cancel ET");
                    break;
                case "UpdateAccountInfo-UserName":
                case "UpdateAccountInfo-Email":
                case "UpdateAccountInfo-Password":
                    email.VerifyEmailInbox("Account Information - Update Confirmation");
                    break;
                case "UpdateAccountInfo-Phone":
                    email.VerifyEmailInbox("Contact Information Update Phone Confirmation");
                    break;
                case "UpdateAccountInfo-Address":
                    email.VerifyEmailInbox("Contact Information Update Address Confirmation");
                    break;
                case "EditInsured-Confirmation":
                    email.VerifyEmailInbox("Edit Insured Confirmation");
                    break;
                case "ChangePayor-Confirmation":
                    email.VerifyEmailInbox("Change Payor Confirmation");
                    break;
                case "CashValueLetter-Mail":
                    email.VerifyEmailInbox("Cash Value Letter Confirmation");
                    break;
                case "CashValueLetter-Fax":
                    email.VerifyEmailInbox("Fax Cash Value Letter Confirmation");
                    break;
            }
        }
    }
}
