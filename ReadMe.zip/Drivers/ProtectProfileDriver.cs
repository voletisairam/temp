﻿using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.NewRegistration;
using CSW.PageObjects.Payments;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Drivers
{
    class ProtectProfileDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public ProtectProfileDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Name: VerifyProtectProfileSetupPage
        /// Method to verify Protect your profile Registartion pages
        /// </summary>
        /// <param name="args"></param>
        public void VerifyProtectProfileSetupPage(string args)
        {
            ProtectProfilePage pp = new ProtectProfilePage(driver, data);
            pp.SetupProfile(args);
        }

        /// <summary>
        /// Name:SetupMobileNumber
        /// Method to setup mobile number on Protect your profile Registartion pages
        /// </summary>
        /// <param name="args"></param>
        public void SetupMobileNumber(string args)
        {
            ProtectProfilePage pp = new ProtectProfilePage(driver, data);
            pp.FillMobileNumber(args);
        }

        /// <summary>
        /// Name:EnterOTPPage
        /// This method enterd the OTP sent to the new number
        ///                  for profile security management 
        /// </summary>
        /// <param name="args"></param>
        public void EnterSMSOTP(string args)
        {
            ProtectProfilePage pp = new ProtectProfilePage(driver, data);
            pp.EnterProfileOTP(args);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: VerifyThankYouPage                                          ///////////
        ////// Description:This method verify the update sucess
        ///                  for profile security management            ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void VerifySuccessPage(string args)
        {
            ProtectProfilePage pp = new ProtectProfilePage(driver, data);
            pp.MobileAddSuccess(args);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: CreateUserAccountProtectProfile                                          ///////////
        ////// Description:This method creates the account for protect your profile 
        /////                  for profile security management  - Using for New account Creation
        /////                  DataMaintenanceTestSuite
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public bool CreateUserAccountProtectProfile(string args)
        {
            ProtectProfilePage pp = new ProtectProfilePage(driver, data);
            return pp.CreateProtectProfileAccount();

        }


    }
}
