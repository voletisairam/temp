﻿using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;


namespace CSW.Drivers
{
    class PaymentsDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public PaymentsDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }


        #region ManagePayments

        /// <summary>
        /// Method verify Manage Payments page of the contract Payment Details 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyManagePaymentPage(string args)
        { 
            //TODO:Remove-done                      
            HomePage home = new HomePage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            home.NavigateToPage(KeyRepository.PaymentPage);
            //Find the associates policies to switch  single contract / multi contract
            DB.QueryAssociatedPolicies("Payments");
            payments.VerifyManagePaymentDetails();
        }

        /// <summary>
        /// Method helps to Verify Managepayment Billing Section
        /// </summary>
        /// <param name="args"></param>
        public void VerifyManagePaymentBillingSection(string args)
        {
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            DB.QueryPolicyDetails();
            DB.QueryPaymentDetails();
            DB.QueryQuarterlyPaymntElig();
            payments.VerifyPaymentBillingInformation();
        }

        /// <summary>
        /// Method helps to Verify Payment Frequency Section
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentFrequencySection(string args)
        {
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            payments.VerifyPaymentFrequencyOptions();
        }
        /// <summary>
        /// /Method to select the Payment Option 
        /// </summary>
        /// <param name="args"></param>
        public void SelectPaymentOption(string args)
        {
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            payments.SelectPaymentOption(args);
        }

        /// <summary>
        /// /Method to select the Payment Option 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentOption(string args)
        {
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            payments.VerifyPaymentOption(args);
        }


        /// <summary>
        /// Method to select policy type like Monthly /Quaterly autoPay
        /// </summary>
        /// <param name="args"></param>
        public void SelectPolicy(string args)
        {
            CommonFunctions payments = new CommonFunctions(testdata: data);
            payments.SelectPolicy(args);
        }
        

        /// <summary>
        /// Method helps to make a one time payment for Non Autopay
        /// </summary>
        /// <param name="args"></param>
        public void MakePayment(string args)
        {
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            testRequsite.SetPaymentInformation("NoExistingEFT,None,PendingPayment");
        }

        /// <summary>
        /// Method helps to verify the pending payments and wavier of payments -then we need to check the payment frequency not exist
        /// </summary>
        /// <param name="args"></param>
        public void VerifyNoFrequencyOption(string args)
        {
            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            payments.VerifyNoFrequencyOption(args);

        }
        /// <summary>
        /// Method to helps to  Navigate ManagePaymentsPage
        /// </summary>
        /// <param name="args"></param>
        public void NavigateManagePaymentsPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            home.NavigateToPage(KeyRepository.PaymentPage);
        }
        #endregion


        #region --autoPay 
        /// <summary>
        /// Method to update payment frequency of a contract
        /// </summary>
        /// <param name="args"></param>
        public void UpdatePaymentFrequency(string args)
        {
            string requestType, info;
            string[] splitStr = args.Split(',');

            requestType = splitStr[0].Trim();
            if (splitStr.Length > 1)
            {
                info = splitStr[1].Trim();
            }
            else
            {
                info = splitStr[0].Trim();
            }

            ManagePaymentsPage payments = new ManagePaymentsPage(driver, data);
            AutoPayPage Autopay = new AutoPayPage(driver, data);
            HomePage home = new HomePage(driver, data);

            if (requestType != "NoAutoPay")
            {
                home.NavigateToPage(KeyRepository.PaymentPage);
            }

            // Ensure the argument is set correctly
            args = info;

            // Change payment frequency
            Autopay.ChangePaymentFrequency(args.Trim());
        }


        /// <summary>
        /// Method to update payment frequency of a contract
        /// </summary>
        /// <param name="args"></param>
        public void VerifyUpdatePaymentFreqThankYouPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            //Verify Result
            autoPay.VerifyUpdatePaymentFrequencyResult(args.Trim());
        }


        /// <summary>
        /// Method to verify New AutoPay page
        /// </summary
        public void VerifyNewAutoPayPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            // Verifying new AutoPay page
            autoPay.VerifyNewAutoPayPage();
        }


        /// <summary>
        /// Method to verify Update AutoPay Info Page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyUpdateAutoPayInfoPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            // Verifying the AutoPay
            autoPay.VerifyUpdateAutoPayInfoPage();
        }


        /// <summary>
        /// Method to verify the cancel AutoPay page [Before cancelation]
        /// </summary>
        /// <param name="args"></param>
        public void VerifyCancelAutoPayPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            //Verify the cancel Page 
            autoPay.VerifyCancelAutoPayPage(args.Trim());

        }


        /// <summary>
        /// Method to fill New AutoPay form
        /// </summary>
        /// <param name="args"></param>
        public void SubmitNewAutoPayForm(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            // Fill New AutoPay form
            autoPay.SubmitNewAutoPayForm(args.Trim());
        }


        /// <summary>
        /// Method of updating AutoPay settings including bank account information and payment frequency.
        /// </summary>
        /// <param name="args">Arguments specifying the update action and its value, formatted as "Action-Value".</param>
        public void SubmitUpdateAutoPay(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);
            HomePage home = new HomePage(driver, data);

            // Directly use the provided args to determine the action and pass them to UpdateAutoPaySettings.
            // This approach UpdateAutoPaySettings can handle the args in the format "Action-Value"
            // and makes a direct call based on the action type determined by the args.
            autoPay.UpdateAutoPaySettings(args);
        }



        /// <summary>
        /// Method  to Cancel AutoPay
        /// </summary>
        /// <param name="args"></param>
        public void SubmitCancelAutoPay(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            // Submitting the cancelation
            autoPay.SubmitCancelAutoPay(args.Trim()); ;
        }


        /// <summary>
        /// Method to Validate "Thank You" page for new AutoPay setup, accounting for pending payments.
        /// </summary>
        /// <param name="args"></param>
        public void VerifySetupNewAutoPayThankYouPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            // Verify new AutoPay Thank you page
            autoPay.VerifySetupNewAutoPayThankYouPage(args.Trim());
        }


        /// <summary>
        /// Method to Validates the "Thank You" page post AutoPay update, accounting for pending payments.
        /// </summary>
        /// <param name="args"></param>
        public void VerifyUpdateAutoPayThankYouPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);

            // Verify update AutoPay Thank you page
            autoPay.VerifyUpdateAutoPayThankYouPage(args.Trim());
        }


        /// <summary>
        /// Verifies the "Thank You" page following cancellation, accounting for both pending payments and immediate cancellations.
        /// </summary>
        /// <param name="args"></param>
        public void VerifyCancelAutoPayThankYouPage(string args)
        {
            AutoPayPage autoPay = new AutoPayPage(driver, data);
 
           // Verify the cancel Thank you Page
            autoPay.VerifyCancelAutoPayThankYouPage(args.Trim()); 

        }

        /// <summary>
        /// Method helps to delete autoPay
        /// </summary>
        /// <param name="args"></param>
        public void DeleteautoPay(string args)
        {
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            testRequsite.SetPaymentInformation("NoExistingEFT,None,None");
        }
        #endregion



        #region --payment history
        /// <summary>
        /// Method verify Payments History page of the contract Payment Details 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentHistoryPage(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            PaymentHistoryPage payment = new PaymentHistoryPage(driver, data);
           //Find the associates policies to switch  single contract / multi contract
            DB.QueryAssociatedPolicies("Payments");
            payment.VerifyPaymentHistoryPage(args);
        }

        /// <summary>
        /// Method to Navigate Payamnt History Page from MyAccount
        /// </summary>
        /// <param name="args"></param>
        public void MailPaymentHistory(string args)
        {
            PaymentHistoryPage page = new PaymentHistoryPage(driver, data);
            page.ClickMailLink();
            page.VerifyMailPage();
            page.VerifyMailThankyouPage();
        }
        #endregion

    }
}
