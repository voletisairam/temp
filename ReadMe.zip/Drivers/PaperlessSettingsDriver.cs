﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Profile;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;

namespace CSW.Drivers
{
    class PaperlessSettingsDriver
    {

        private IWebDriver driver;
        private Dictionary<string, string> data;

        public PaperlessSettingsDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        //////////////////////////////////////////////////////////
        /////////    Preference Management Page Section    /////////
        //////////////////////////////////////////////////////////

        /// <summary>
        /// Method helps to view the Preference Management page header /text content / buttons etc
        /// </summary>
        /// <param name="args"></param>
        public void ViewPaperlessSettingsPage(string args)
        {
            PaperlessSettingsPage paperless = new PaperlessSettingsPage(driver, data);
            HomePage home = new HomePage(driver, data);
            
            //naviage to the Preference Management Page 
            home.NavigateToPage(KeyRepository.PaperlessSettingsInfoPage);
            //Verify the paperless Management of elments /text/values to be verify
            paperless.VerifyPaperlessSettingsInfo(args);
        }

        /// <summary>
        /// Method to helps to select the Paperless PReference option like OptIn/ OptOut
        /// </summary>
        /// <param name="args"></param>
        public void SelectPaperlessPreference(string args)
        {
            PaperlessSettingsPage paperless = new PaperlessSettingsPage(driver, data);
            paperless.PaperlessSettingsOption(args);
        }

        /// <summary>
        /// Method helps to verify the Paperless Preference ThankYou page like OptIn/OptOut
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaperlessPreferenceThankYouPage(string args)
        {
            PaperlessSettingsPage paperless = new PaperlessSettingsPage(driver, data);
            if (args == "OptIn")
                paperless.VerifyPaperlessSignUpThankYouPage();
            else if (args == "OptOut")
                paperless.VerifyPaperlessOptOutThankYouPage();
        }

        /// <summary>
        /// Method helps us to get the Status of OptIn/ OptOut
        /// </summary>
        /// <param name="args"></param>
        public bool VerifyPaperlessStatus()
        {
            LSPDatabase db = new LSPDatabase(driver, data);
            return db.QueryPreferenceManagementStatusdataEntry();
        }

        /// <summary>
        /// Method helps to verify the data is inserted /updated in database respective tables
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDataBaseEntry(string args)
        {
            LSPDatabase db = new LSPDatabase(driver, data);
            MIDatabase MIDB = new MIDatabase(data);

            if (args == "OptIn")
            {
                //Build the query              
                db.QueryPreferenceManagementHistorydataEntry("New-Opt-In");
                db.QueryPreferenceManagementdataEntry("New-Opt-In");
                MIDB.VerifyActivityTable("Paperless settings");
            }
            else if (args == "OptOut")
            {
                db.QueryPreferenceManagementHistorydataEntry("Re-Opt-In");
                db.QueryPreferenceManagementdataEntry("Re-Opt-In");
                MIDB.VerifyActivityTable("Paperless settings");
            }
        }

        /// <summary>
        /// Method helps to validate the Confirmation email is expected or not
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaperlessPrefenceEmail(string args)
        {
            EmailVerification email = new EmailVerification(driver, data);
            email.VerifyEmailInbox("Paperless Settings Confirmation");
        }
    }

}
