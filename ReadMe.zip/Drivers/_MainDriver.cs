﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using CSW.Common.Excel;
using CSW.PageObjects.Coverage;
using CSW.PageObjects.Registration;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;

namespace CSW.Drivers
{    
    public static class invoke
    {
        /// <summary>
        /// Method to invoke the method from the object
        /// </summary>
        public static bool InvokeMethod(this object objectToCheck, string methodName, string args)
        {
            bool methodexists = false;

            //Create a Type Object
            Type type = objectToCheck.GetType();

            //Save Parameters
            object[] param = new object[] { args };

            //Get hte Method
            MethodInfo method = type.GetMethod(methodName.Trim());

            //If the method exist invoke and set it to true, else false
            if (method != null)
            {
                method.Invoke(objectToCheck, param);
                methodexists = true;
            }
            else
                methodexists = false;

            return methodexists;
        }
    }
    public class _MainDriver : TestData
    {
        /// <summary>
        /// Method to execute the business event.
        /// </summary>
        public void ExecuteMethod(string businessEvent, IWebDriver driver, Dictionary<string, string> testdata)
        {
            //Instantial All Driver Classes
            UserRegistrationDriver registerUser = new UserRegistrationDriver(driver, testdata);
            TestPreRequisites testPreRequisite = new TestPreRequisites(driver, testdata);
            FieldVerificationDriver fieldVerification = new FieldVerificationDriver();
            HomeDriver home = new HomeDriver(driver, testdata);
            LoginDriver login = new LoginDriver(driver, testdata);
            EmailVerificationDriver emailVerificationDriver = new EmailVerificationDriver(driver, testdata);
            ContactInfomationDriver contactInfomation = new ContactInfomationDriver(driver, testdata);
            AccountInformationDriver accountInformation = new AccountInformationDriver(driver, testdata); 
            ChangePayorDriver changePayor = new ChangePayorDriver(driver, testdata);
            EditInsuredDriver editInsured = new EditInsuredDriver(driver, testdata);
            BeneficiariesDriver mybeneficiary = new BeneficiariesDriver(driver, testdata);
            ProcessFlowDriver processflow = new ProcessFlowDriver(driver, testdata);
            PaymentsDriver payments = new PaymentsDriver(driver, testdata);
            OneTimePaymentDriver oneTimePayment = new OneTimePaymentDriver(driver, testdata);
            Riders_ExchangesDriver rider = new Riders_ExchangesDriver(driver, testdata);    
            FISDriver fis=new FISDriver(driver, testdata);
            SecureDocUploadDriver secureDoc = new SecureDocUploadDriver(driver, testdata);
            PaperlessSettingsDriver preferenceManagement = new PaperlessSettingsDriver(driver, testdata);
            ResetPasswordDriver resetPassword = new ResetPasswordDriver(driver, testdata);
            DatabaseVerificationDriver databaseVerificationDriver = new DatabaseVerificationDriver(driver, testdata);
            ServiceVerificationDriver serviceVerificationDriver = new ServiceVerificationDriver(driver, testdata);
            ProtectProfileDriver protectProfileDriver = new ProtectProfileDriver(driver, testdata);

            string[] bemethod;
            string method;
            string args = "";                       

            //If Parameters exists, seperate them from Method Names
            if (businessEvent.Contains(":"))
            {
                bemethod = businessEvent.Split(':');
                method = bemethod[0].Replace(" ", "").Trim();
                args = bemethod[1].Trim();
            }
            else
            {
                method = businessEvent.Replace(" ", "").Trim();
                args = "";
            }

            //Check for the method name in each class and invoke it
            if (!(invoke.InvokeMethod(testPreRequisite, method, args) ||
                invoke.InvokeMethod(registerUser, method, args) ||
                invoke.InvokeMethod(fieldVerification, method, args) ||
                invoke.InvokeMethod(login, method, args) ||
                invoke.InvokeMethod(home, method, args) ||
                invoke.InvokeMethod(contactInfomation, method, args) ||
                invoke.InvokeMethod(accountInformation, method, args) ||
                invoke.InvokeMethod(changePayor, method, args) ||
                invoke.InvokeMethod(editInsured, method, args) ||
                invoke.InvokeMethod(mybeneficiary, method, args) ||
                invoke.InvokeMethod(processflow, method, args) ||
                invoke.InvokeMethod(payments, method, args) ||
                invoke.InvokeMethod(rider, method, args) ||
                invoke.InvokeMethod(oneTimePayment, method, args) ||
                invoke.InvokeMethod(secureDoc, method, args) ||
                invoke.InvokeMethod(preferenceManagement, method, args) ||
                invoke.InvokeMethod(emailVerificationDriver, method, args) ||
                invoke.InvokeMethod(databaseVerificationDriver, method, args) ||
                invoke.InvokeMethod(fis,method,args) ||
                invoke.InvokeMethod(resetPassword,method,args) ||
                invoke.InvokeMethod(serviceVerificationDriver, method, args) ||
                invoke.InvokeMethod(protectProfileDriver, method, args)
                )) 
            {
                if(!string.IsNullOrEmpty(method))
                NYLDSelenium.ReportStepResult("Invalid Keyword:" + method, "Invalid Keyword. Refer to Keyword Dictionary to fix any typo, if not reach out to Automation Team", "FAIL", "no", "yes");
            }
        }
    }
}
