﻿using CSW.Common.Excel;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Drivers
{
    class FieldVerificationDriver
    {
        public void PerformFieldValidation(string args)
        {
            TestData testData = new TestData();
            IList<string> options = new List<string>();

            // Split the input string into two parts: page and remaining
            string[] getOptions = args.Split(new[] { "Page" }, StringSplitOptions.None);
            options = getOptions.ToList();

            if (options.Count == 1)
                options.Add("");
            NYLDSelenium.AddHeader(args + " - Field Validation", "SubHeader");
            if(options[0].Contains("Beneficiary"))
                testData.VerifyfieldAttributes("BeneAll");
            else if (options[0].Contains("ChangePayor"))
                testData.VerifyfieldAttributes("ChangePayor");
            testData.VerifyfieldAttributes(options[0]);

            NYLDSelenium.AddHeader(args + " - Field Validation", "Success");
        }
    }
}
