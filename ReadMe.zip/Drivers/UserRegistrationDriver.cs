﻿using CSW.Common.DataBase;
using CSW.Common.Email;
using CSW.Common.Excel;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.NewRegistration;
using CSW.PageObjects.Registration;
using CSW.PageObjects.SecureDocUpload;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web.UI.WebControls;

namespace CSW.Drivers
{
    class UserRegistrationDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public UserRegistrationDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }
        #region //Registration Methods
        /// <summary>
        /// Method to Register a new user or do a pertial registration
        /// </summary>
        /// <param name="args"></param>
        public void RegisterUser(string args)
        {
            EmailVerification email = new EmailVerification(driver, data);           
            IList<string> options = new List<string>();
            bool verify = false;

            string[] getOptions = args.Split(',');
            options = getOptions.ToList();

            if (options.Count == 1)
                options.Add("");

        if (options[0].ToLower() == "verify")
            verify = true;

        switch (options[0])
        {
            case "OwnerDetails":
                VerifyFIllOwnerDetailsPage(args, verify, options[1]);
                break;
            case "ContractNumber":
                ContractNumberPage(args, verify);
                break;
            case "LoginDetails":
                LoginDetailsPage(args, verify);
                break;
            case "OTP":
                OneTimeVerificationPage(verify);
                break;
            case "ThankYou":
                Thankyoupage(args, verify);
                break;
            case "SecureUploadProfile":
                ProcessPolicyInfoPage verifyDetails = new ProcessPolicyInfoPage(driver, data);
                verifyDetails.VerifyDetailsPage();
                verifyDetails.FillYourOwnerDetailsPage("");
                break;

                default:
                if (options[0].ToLower() == "verify")
                    verify = true;

                string oneTimeCode = "";

                VerifyFIllOwnerDetailsPage(args, verify, ""); //Page1
                if (!driver.Url.Contains("Invalid?Reason"))
                {
                        ContractNumberPage(args, verify);
                        //Registration and ResetPassword using valid pin if in business requirement 
                        if (data[KeyRepository.Funtionality]!="ST" && data[KeyRepository.SubFuntionality].Contains("Registration"))
                        {
                            if (!new TestData().GetValidEmailId(driver, data))
                                NYLDSelenium.ReportStepResult("Use Valid EMail for Registration", "All valid email are taken, not able to proceed the steps. Please report to DevOps Automation Team", "FAIL", "no", "yes");
                        }
                        LoginDetailsPage(options[0].ToLower(), verify); //Page3
               
                    //For smoke test skipping the valid email verification
                    if (data[KeyRepository.Funtionality] != "ST")
                    {
                        if (data[KeyRepository.SubFuntionality].Contains("Registration") && !options[0].Contains("HappyPath"))
                        {
                            oneTimeCode = email.GetOneTimeCodeFromValidEMail();
                        }
                        else
                            oneTimeCode = "999999";
                    }
                    else
                        oneTimeCode = "999999";
                    OneTimeVerificationPage(verify, oneTimeCode); //Page4
                    Thankyoupage(options[1], verify); //Page5
                }
                break;
            }
        }
        
        /// <summary>
        /// verify need to check
        /// </summary>
        /// <param name="args"></param>
        /// <param name="verify"></param>
        /// <param name="reportstopfor"></param>
        public void VerifyFIllOwnerDetailsPage(string args, bool verify, string reportstopfor)
        {
            VerifyYourDetailsPage verifyDetails = new VerifyYourDetailsPage(driver, data);
            LoginPage loginPage = new LoginPage(driver, data);

            // Turrinig Off logging the steps of if the user account is already created
            if (reportstopfor == "useraccounts")
                GetSettor.ReportEvent = "no";
            else if(reportstopfor != "Fieldvalidation")
            loginPage.ClickCreateAccount(reportstopfor);
            if (verify)
                verifyDetails.VerifyDetailsPage();

            verifyDetails.FillOwnerDetailsPage(args, reportstopfor);
        }
        private void ContractNumberPage(string args, bool verify)
        {
            ConfirmContractNumberPage confirmContract = new ConfirmContractNumberPage(driver, data);
            if (verify)
                confirmContract.VerifyEnterContractPage();

            confirmContract.FillEnterContractForm("");
        }
        private void LoginDetailsPage(string args, bool verify)
        {
            CreateYourLoginPage createLogin = new CreateYourLoginPage(driver, data);
            if (verify)
                createLogin.VerifyCreateYourProfilePage();
            createLogin.FillUserProfileDetails(args);
        }
        public void OneTimeVerificationPage(bool verify, string oneTimeCode = "999999", string args = "")
        {
            OneTimeVerificationPage verificationPage = new OneTimeVerificationPage(driver, data);
            if (verify)
                verificationPage.VerifyOneTimeVerificationPage();

            verificationPage.FillOneTimeCode(oneTimeCode);
        }
        public void Thankyoupage(string args, bool verify)
        {
            PageObjects.NewRegistration.ThankYouPage thankYou = new PageObjects.NewRegistration.ThankYouPage(driver, data);

            //5. tHANK yOU
            thankYou.VerifyThankYouPage(args);
        }
        #endregion

        #region // Registration Methods for Secure Doc Upload or Reset password or Grief
        /// <summary>
        /// Method helps to verify for secure doc upload - Owner details page
        /// </summary>
        /// <param name="args"></param>
        public void NavigateProcessPolicyInfoPage(string args)
        {
            Thread.Sleep(100);
            ProcessPolicyInfoPage verifyDetails = new ProcessPolicyInfoPage(driver, data);
            verifyDetails.Page1();
        }
       
        /// <summary>
        /// Method helps to click the Create account and it naviage to owner details page
        /// </summary>
        /// <param name="args"></param>
        public void OwnerDetailsPage(string args)
        {
            LoginPage loginPage = new LoginPage(driver, data);
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Owner Details page -Reset Password" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            loginPage.ClickForgotPassword();
        }

        /// <summary>
        /// method helps to set the value from testdata sheet
        /// </summary>
        /// <param name="args"></param>
        public void SetValue(string args)
        {
            TestPreRequisites testPreRequisites = new TestPreRequisites(driver,data);
            UserRegistrationDriver verifyDetails = new UserRegistrationDriver(driver, data);
            testPreRequisites.SetValue(args);
        }
       
        /// <summary>
        /// Method helps to Fill the Owner Details
        /// </summary>
        /// <param name="args"></param>
        public void EnterOwnerDetails(string args)
        {
            VerifyYourDetailsPage verifyDetails = new VerifyYourDetailsPage(driver, data);
            verifyDetails.FillOwnerdetails(args);
        }

        /// <summary>
        ///Method helps to enter default OTP value
        /// </summary>
        /// <param name="args"></param>
        public void EnterOTP(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);
            resetPassword.RequestPasswordOptions("Default");
        }

        /// <summary>
        /// Method helps to Enter new password and confirm new password
        /// </summary>
        /// <param name="args"></param>
        public void EnterNewPassword(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);
            resetPassword.EnterNewPassword(args);
        }

        /// <summary>
        /// Method helps to Enter new password and confirm new password
        /// </summary>
        /// <param name="args"></param>
        public void ResetPasswordThankYouPage(string args)
        {
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);
            resetPassword.SuccessNewPassword("ResetSuccesful");
        }       

        /// <summary>
        /// This Method helps to Check the LSP Email is valid or not 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyLSPEmail(string args)
        {
            LoginPage loginpage = new LoginPage(driver, data);
            loginpage.VerifyLSPEmaildetails(args);
        }

        /// <summary>
        /// Method to verify Registration grief message
        /// </summary>
        /// <param name="args"></param>
        public void VerifyRegistrationGrief(string args)
        {
            if (args == "AlreadyRegisteredMessage" || args == "SuspendedUserMessage")
            {
                AccountAlreadyExistsPage accountAlreadyExistsPage = new AccountAlreadyExistsPage(driver, data);
                //accountAlreadyExistsPage.VerifyAccountAlreadyInUsePage();
                accountAlreadyExistsPage.VerifyAccountAlreadyInUsePageLogin();

            }
            else if (args == "EmailAlreadyInUse")
            {
                CreateYourLoginPage createYourLogin = new CreateYourLoginPage(driver, data);
                createYourLogin.EmailAlreadyInUsed();
            }
            else if (args == "UsernameInUse")
            {
                CreateYourLoginPage createYourLogin = new CreateYourLoginPage(driver, data);
                createYourLogin.UsernameAlreadyInUsed();
            }
            else
            {
                RegistrationGrief registartionGrief = new RegistrationGrief(driver, data);
                registartionGrief.VerifyRegGriefMsg(args);
            }

        }
        #endregion

        public void NavigateRegistrationPage(string args)
        {
            LoginPage loginPage = new LoginPage(driver, data);
            loginPage.ClickCreateAccount("");
        }

        
    }
}
