﻿using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.PageObjects.Home;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using CSW.PageObjects.Coverage;
using CSW.PageObjects.Profile;
using System.Linq;

namespace CSW.Drivers
{
    class BeneficiariesDriver
    {
        private readonly IWebDriver driver;
        private readonly Dictionary<string, string> data;

        public BeneficiariesDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        public void VerifyMyBeneficiaries(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);

            home.NavigateToPage(KeyRepository.BeneficiaryPage);

            if (args == "ShareTotal")
                mybeneficiary.ValidateShareToTal(args);
            else
                mybeneficiary.VerifyBeneficiaries(args);
        }

        public void AddBeneficiary(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);

            home.NavigateToPage(KeyRepository.BeneficiaryPage);

            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollBy(0,+100);");
            NYLDSelenium.Click("Add Beneficiary", mybeneficiary.AddBeneficiaryLink);

            mybeneficiary.AddBeneficiary(args);
        }

        public void CannotAddFuneralBene(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);

            home.NavigateToPage(KeyRepository.BeneficiaryPage);

            mybeneficiary.VerifyPage1("FuneralHome");
        }

        public void EditBeneficiary(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);

            home.NavigateToPage(KeyRepository.BeneficiaryPage);

            mybeneficiary.EditBeneficiary(args);
        }

        public void VerifyPreventBeneChangeGrief(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);

            home.NavigateToPage(KeyRepository.BeneficiaryPage);

            mybeneficiary.VerifyPreventBeneChangeGrief();
        }

        public void VerifyPreventNoBeneGrief(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);

            home.NavigateToPage(KeyRepository.BeneficiaryPage);
            mybeneficiary.VerifyNoBeneGriefMsg();
        }        

        public void DeleteBeneficiaries(string args)
        {
            var getOptions = args.Split('-');
            var action = getOptions[1].Trim();
            var mybeneficiary = new MyBeneficiariesPage(driver, data);
            var Tampa01 = new LSPDatabase(driver, data);
            Tampa01.GetBeneInfo();

            mybeneficiary.DeleteMultipleBene(args);
        }

        public void AddNewBeneficiary(string args)
        {
            var mybeneficiary = new MyBeneficiariesPage(driver, data);
            mybeneficiary.AddBeneficiary(args);
        }

        public void VerifyBeneThankYouPage(string args)
        {
            var mybeneficiary = new MyBeneficiariesPage(driver, data);
            switch (args.Trim())
            {
                case "Add":
                    mybeneficiary.VerifyThankYouPage("Add");
                    break;
                case "Edit":
                    mybeneficiary.VerifyThankYouPage("Edit");
                    break;
                case "EditDistribution":
                    mybeneficiary.VerifyThankYouPage("EditDistribution");
                    break;
                default:
                    mybeneficiary.VerifyThankYouPage("");
                    break;
            }
        }

        public void NavigateAddBeneficiaryPage(string args)
        {
            var home = new HomePage(driver, data);
            var mybeneficiary = new MyBeneficiariesPage(driver, data);
            home.NavigateToPage(KeyRepository.BeneficiaryPage);

            mybeneficiary.EnterBeneficiaryInfo(args);
        }
    }
}
