﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using NYLDWebAutomationFramework;
using CSW.PageObjects.Payments;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.Common.Email;
using CSW.PageObjects.Coverage;

namespace CSW.Drivers
{
    class EditInsuredDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public EditInsuredDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method to explicitly add headers to steps
        /// </summary>
        /// <param name="action"></param>
        public void AddHeader(string action)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify " + action + " for policy " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
        }


        /// <summary>
        /// Method to drive Verify edit insured details 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyEditInsuredPage(string args)
        {
            HomePage home = new HomePage(driver, data);
            EditInsuredPage editInsured = new EditInsuredPage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);

            home.NavigateToPage(KeyRepository.InsuredPage);
            DB.QueryAssociatedPolicies("EditInsured");
            editInsured.VerifyEditInsuredPage("");
        }

        public void NavigateEditInsuredPage(string args)
        {
            HomePage home = new HomePage(driver, data);

            home.NavigateToPage(KeyRepository.InsuredPage);
        }

        /// <summary>
        /// Method to drive edit insured actions
        /// </summary>
        /// <param name="args"></param>
        public void UpdateEditInsured(string args)
        {
            EditInsuredPage editInsured = new EditInsuredPage(driver, data);
            editInsured.UpdateEditInsured(args.Trim());
        }       

        /// <summary>
        /// Method to Verify EditInsured ThankyouPage screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyEditInsuredThankyouPage(string args)
        {
            EditInsuredPage editInsured = new EditInsuredPage(driver, data);
            editInsured.VerifyEditInsuredThankYouPage();
        }

        /// <summary>
        /// Method to Verify EditInsured GriefMesg screen
        /// </summary>
        /// <param name="args"></param>
        public void VerifyEditInsuredGriefMesg(string args)
        {
            HomePage home = new HomePage(driver, data);
            ChangePayorPage changePayor = new ChangePayorPage(driver, data);
            home.NavigateToPage(KeyRepository.InsuredPage);
            changePayor.VerifyChangePayorEditInsuredGriefMsg("Edit Insured");
        }

        /// <summary>
        /// Method to Verify Processflow - update in edit insurance type
        /// </summary>
        /// <param name="args"></param>
        public void VerifyProcessflowPage(string args)
        {
            EditInsuredPage editInsured = new EditInsuredPage(driver, data);
            editInsured.ProcessFlow(args);
        }
    }
}
