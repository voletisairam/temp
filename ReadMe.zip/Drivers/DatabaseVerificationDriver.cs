﻿using CSW.Common.Database;
using CSW.Common.DataBase;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Drivers
{
    class DatabaseVerificationDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public DatabaseVerificationDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method to verify Data base 
        /// </summary>
        /// <param name="args"></param>
        public void VerifyDatabase(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);

            // Verify the database for Payment functionality
            LSPDatabase database = new LSPDatabase(driver, data);
            MIDatabase MIDB = new MIDatabase(data);
            string requestType, info;
            string[] splitStr = args.Split(',');
            if (splitStr.Length > 1)
            {
                requestType = splitStr[0].Trim();
                info = splitStr[1].Trim();
            }
            else
            {
                requestType = splitStr[0].Trim();
                info = "";
            }

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Database" + "</h3>", "<h3 style=\"color:Blue\">" + requestType + "</h3>", "INFO", "no");

            switch (requestType.Trim())
            {
                case "NewAutoPay":
                    database.QueryLSPNotes("My Payments", requestType);
                    database.QueryAutoPremPayUpdate("PCM");
                    database.QueryAutoPremPayUpdate("ES");
                    break;

                case "CancelAutoPay":
                    // Add database queries specific to CancelAutoPay
                    break;

                case "UpdateAutoPay":
                    database.QueryLSPNotes("My Payments", requestType);

                    //Client corrsepondence PCM Note
                    database.QueryAutoPremPayUpdate("PCM");

                    //Verify Activity table
                    MIDB.VerifyActivityTable("EditEFT");

                    break;
                case "ChangePayor":
                    //Query LSP notes
                    database.QueryLSPNotes("ChangePayor");
                    //Verify Activity table
                    MIDB.VerifyActivityTable("Change Payor");
                    break;
                case "PayFrequencyMToQ":
                    database.ChangeFrequencyPaymentDetails("Q");
                    break;
                case "PayFrequencyQToM":
                    database.ChangeFrequencyPaymentDetails("M");
                    break;
                case "AALDTLP1 Table Entry":
                    database.QueryAALDTLP1Table(); 
                    break;
                case "FAXREQP1 Table Entry":
                    database.QueryFAXREQP1Table();
                    break;
                case "LSPCustomerActivity":
                    database.QueryLSPCustomerActivity(info);
                    break;
            }
        }


        }
}
