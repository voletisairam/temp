﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Excel;
using CSW.PageObjects.Registration;
using CSW.PageObjects.Login;
using CSW.Common.Services;
using CSW.PageObjects.Profile;
using CSW.PageObjects.SecureDocUpload;
using System.Threading;
using CSW.Common.Email;
using NYLDWebAutomationFramework;

namespace CSW.Drivers
{
    class SecureDocUploadDriver
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;


        public SecureDocUploadDriver(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        /// <summary>
        /// Method helps to select the secure doc upload
        /// </summary>
        /// <param name="args"></param>
        public void PerformSecureDocUploadLink(string args)
        {
            RelatedToPage SecDocUploadRelTo = new RelatedToPage(driver, data);
            SecDocUploadRelTo.PerformSecureDocUpload(args);
        }

        /// <summary>
        /// Method helps to Perform Secure DOcupload Options
        /// </summary>
        /// <param name="args"></param>
        public void PerformSecureDocUploadOption(string args)
        {
            RelatedToPage SecDocUploadRelTo = new RelatedToPage(driver, data);
            //choose the Documents Upload Securely related to..Certificate|Claim
            SecDocUploadRelTo.SelectSecureDocumentUploadOption(args);
        }

        /// <summary>
        /// Methodd helps to choose the policy from the list
        /// </summary>
        /// <param name="args"></param>
        public void PerformSecureDocUploadSelectPolicy(string args)
        {
            RelatedToPage SecDocUploadRelTo = new RelatedToPage(driver, data);
            SecDocUploadRelTo.PerformSecureDocUploadSelectPolicy(args);
        }

        /// <summary>
        /// Method helps to NoOptional EMail used
        /// </summary>
        /// <param name="args"></param>
        public void VerifySecureDocUpload_NoOptionalEMail(string args)
        {
            OptionalEmailPage SDUOptionalEmail = new OptionalEmailPage(driver, data);
            SDUOptionalEmail.SubmitUploadDocumentSecurelyOptionalEmail();
        }


        /// <summary>
        /// Method helps to upload the documents secured
        /// </summary>
        /// <param name="args"></param>
        public void PerformSecureDocUpload(string args)
        {
            UploadFilePage SecDocUploadFile = new UploadFilePage(driver, data);
            //Required Files to be Upload based on Test Case
            SecDocUploadFile.SelectSecureDocumentUploadFiles(args);
        }

        /// <summary>
        /// Method helps to Secure doc upload thank you page
        /// </summary>
        /// <param name="args"></param>
        public void VerifySecureDocUploadThankYouPage(string args)
        {
            ThankYouPage SDUThankYou = new ThankYouPage(driver, data);
            SDUThankYou.ValidateSecureDocUploadThankYou(args);
        }

        /// <summary>
        /// Method helps to verify successEamil
        /// </summary>
        /// <param name="args"></param>
        public void VerifySuccessEmail(string args)
        {
            Thread.Sleep(1000);
            ThankYouPage SDUThankYou = new ThankYouPage(driver, data);
            SDUThankYou.VerifySuccessEmailInfo();
        }

        /// <summary>
        /// Method helps to Verify Internal EMails
        /// </summary>
        /// <param name="emailgroupname"></param>
        public void VerifyInternalEmails(string emailgroupname)
        {
            EmailVerification emailVerification = new EmailVerification(driver, data);
            if (emailgroupname == "Nyld_upload_Devs")
                emailVerification.VerifyEmailInbox("Secure Document upload Devs", "nyld_uploads_dev");
            else if (emailgroupname == "NYLDirect_Claims_General_Test")
                emailVerification.VerifyEmailInbox("Secure Document Claims General Test", "NYLDirect_Claims_General_Test");
            else if (emailgroupname == "NYLDirect_Member_services_General_Test")
                emailVerification.VerifyEmailInbox("Secure Document Member services General Test", "NYLDirect_Member_services_General_Test");
        }
    }
}
