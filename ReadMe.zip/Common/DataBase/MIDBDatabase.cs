﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using CSW.Common.Others;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using CSW.Common.Excel;
using System.Text.RegularExpressions;
using NYLDWebAutomationFramework;

namespace CSW.Common.Database
{
    class MIDatabase
    {
        private Dictionary<string, string> data;
        public List<Dictionary<string, string>> queryResult = new List<Dictionary<string, string>>();
        public static string connectionString = "";
        public string query = "";

        public MIDatabase(Dictionary<string, string> testdata)
        {
            data = testdata;
            connectionString = @"Server=" + data[KeyRepository.MIDBServerName] + ";Database=NYL;Trusted_Connection=Yes";
        }

        // Query Template //
        public void QueryDataBase(string sQuery)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                //Set the Command//                
                SqlCommand cmd = new SqlCommand(sQuery, conn);

                //Open the Connection//
                try
                {
                    conn.Open();
                }
                catch (Exception ex)
                {
                    NYLDSelenium.ReportStepResult("Connect to the database", "Could not connect to the database. Report to Automation Team", "Fail", "no", "yes");
                    Console.WriteLine(ex.Message);
                }

                //Execute the Reader//
                SqlDataReader reader = cmd.ExecuteReader();

                // Read each value //                                             
                int k = 0;
                queryResult.Clear();
                while (reader.Read())
                {
                    queryResult.Add(new Dictionary<string, string>());

                    for (int j = 0; j < reader.FieldCount; j++)
                    {
                        string key = reader.GetName(j);
                        string value = reader[j].ToString().Trim();

                        //Save as blank for null values
                        if (value.ToLower().StartsWith("nu") || value.ToLower().StartsWith("\0"))
                            value = "";

                        //Add the item to dictionary
                        queryResult[k].Add(key, value);
                    }
                    k++;
                }

                //Close the Reader//
                reader.Close();
            }

        }

        /// <summary>
        /// Method which has the list of queries used across the solution
        /// </summary>
        /// <param name="args"></param>
        /// <param name="parameter1"></param>
        /// <returns></returns>
        public List<Dictionary<string, string>> PerformDBActivity(string args, string parameter1 = "")
        {
            List<Dictionary<string, string>> expectedContent = new List<Dictionary<string, string>>();
            string sQuery = "";
            

            switch (args)
            {                
                case "GetActivityTableValues":
                    sQuery = "SELECT Activity from NYL.Customer.CustomerActivity where Activity LIKE '" +parameter1+ "%' and Username = '"+ data[KeyRepository.UserName] + "' and AuditDate >='" + CSWData.EventTriggerTime.AddSeconds(-10) + "' order by  AuditDate desc";
                    break;

                case "GetEsigMIDBValues":
                    sQuery = "SELECT L.LeadId as 'LeadID', L.ProductCode as 'ProductCode', L.AutoAcceptStatus as 'AutoAcceptStatus', PII.FirstName as 'First Name', PII.LastName as 'Last Name', ADDR.AddressLine1 as 'Address Line1', ADDR.City, ADDR.State, ADDR.Zip, PII.Dob as 'DOB', PII.Email as 'EmailID', PII.HomePhone 'PhoneNumber', ESIG.SSN as 'SSN', ESIG.CoverageAmt as 'Coverage Amount', PII.HeightFeet as 'Feet', PII.HeightInches as 'Inches', PII.WeightPounds as 'Weight', PII.Smoker as 'Smoker', ESIG.ReplacementBln as 'Replacement' FROM NYL.Leads.Lead as L LEFT JOIN NYL.Leads.MKTInsuranceApp as ESIG on L.LeadID = ESIG.LeadID LEFT JOIN NYL.Leads.PersonalInfo as PII on L.LeadID = PII.LeadID LEFT JOIN NYL.Leads.insurancelead as il on il.LeadId = PII.LeadId LEFT JOIN NYL.Leads.Address as ADDR on L.LeadID = ADDR.LeadID LEFT join NYL.Leads.Audit as a on l.LeadId = a.LeadId LEFT JOIN NYL.Leads.Beneficiary as BENE on L.LeadID = BENE.LeadID LEFT JOIN NYL.leads.AutomaticPayment as PAY on l.leadid = pay.leadid where L.Type = 5  and PII.FirstName = '" + data[KeyRepository.FirstName] + "' and PII.LastName = '" + data[KeyRepository.LastName] + "' and ADDR.State = '" + data[KeyRepository.State] + "' and L.InsertDttm >= '" + CSWData.EventTriggerTime + "';";
                    break;
                
                case "GetEsigHealthResponse":
                    sQuery = "SELECT L.LeadId 'LeadID', HQ.Answer as 'Response', HQ.ConditionsAnswered as 'Health Risks', HQ.QuestionAdditionalInfo as 'Health Question Comments' FROM NYL.Leads.Lead as L LEFT JOIN NYL.Leads.MKTHealthAnswer as HQ on L.LeadId = HQ.LeadID WHERE L.Type = 5  and L.LeadId = '" + data[KeyRepository.LeadID] + "'";
                    break;

                case "GetLeadID":
                    sQuery = "Select l.leadid as 'LeadID' from NYL.Leads.MKTInsuranceApp as m join NYL.Leads.PersonalInfo as p on m.LeadID = p.LeadId join NYL.Leads.lead as l on l.LeadId = m.LeadID join NYL.Leads.Address as ADDR on l.LeadID = ADDR.LeadID where p.firstname = '" + data[KeyRepository.FirstName] + "' and p.lastname ='" + data[KeyRepository.LastName] + "' and ADDR.State = '" + data[KeyRepository.State] + "' and l.InsertDttm >=' " + CSWData.EventTriggerTime + "' order by 1 desc";
                    break;
            }

            QueryDataBase(sQuery);
            expectedContent = queryResult;
            query = sQuery;
            return expectedContent;

        }

        /// <summary>
        /// Method to verify post submission DB updates for Quote and Esig
        /// </summary>
        public void VerifyActivityTable(string args)
        {
            if (data[KeyRepository.DBValidation]=="TRUE")
            {
                string activityText = "";
                string policyNumber = "";
                string last4Digits = "";
                string firstDigit = "";
                string stars = "";
                List<Dictionary<string, string>> dbValues = new List<Dictionary<string, string>>();
                TestData testData = new TestData();

                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Database entries for -" + args + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                //Get Activity text
                int i = data[KeyRepository.PolicyNumber].Length;
                last4Digits = data[KeyRepository.PolicyNumber].Substring(data[KeyRepository.PolicyNumber].Length - 4);
                firstDigit = data[KeyRepository.PolicyNumber].Substring(0, 1);
                stars = Regex.Replace(data[KeyRepository.PolicyNumber].Replace(last4Digits, "").Replace(firstDigit, ""), @"\d", "*");
                policyNumber = firstDigit + stars + last4Digits;
                activityText = testData.GetContent(args.Trim()).Replace("{Policy}", policyNumber);
                CSWData.EventTriggerTime = DateTime.Now.AddSeconds(-60);
                dbValues = PerformDBActivity("GetActivityTableValues", activityText);

                if (dbValues.Count == 0)
                {
                    NYLDSelenium.ReportStepResult("Activity table Query for " + args + "Trigger time: " + CSWData.EventTriggerTime.AddSeconds(-10), query, "INFO", "no");
                    NYLDSelenium.ReportStepResult("Activity table entry could not be found for Contract: " + data[KeyRepository.PolicyNumber] + " &  Activity: " + args, "Activity table entry could not be found for Policy: " + data[KeyRepository.PolicyNumber] + " &  Activity: " + args, "Fail", "no");
                }
                else
                    NYLDSelenium.ReportStepResult("<h4 style=\"color:Green\">" + "Activity table entry found for the Activity: " + args + "</h4>", "<h4 style=\"color:Green\">" + "Activity table entry found for the Activity: " + args + " for the Contract: " + data[KeyRepository.PolicyNumber] + "</h4>", "Pass", "no");
            }
            else
            {
                NYLDSelenium.ReportStepResult("Activity table entry could not be verified for "+ data[KeyRepository.Environment] + " environment", "Marketing Internet database verification could not be performed for " + data[KeyRepository.Environment] + " environment", "INFO", "no");
            }
        }

        /// <summary>
        /// Verify MIDB log after successful esig submission
        /// </summary>
        /// <param name="args"></param>
        public string VerifyMIDatabase(string args = "")
        {
            string replacement, smoker = "", queryUsed = "";
            string[] healthReponses = data[KeyRepository.HQAnswers].Split('|');            
            string filePath = "";

            List<Dictionary<string, string>> dbValues = new List<Dictionary<string, string>>();

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Query MI DB to verify Form Info" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

            //Get logs recorded in MI DB 
            if (data[KeyRepository.DBValidation]=="FALSE")
                NYLDSelenium.ReportStepResult("MI Database validation could not be performed for Stage", "MI DB validation coud not be performed for " + data[KeyRepository.Environment] + " Evnironment", "INFO");
            else
            {
                int startCounter = GetSettor.failCounter;

                dbValues = PerformDBActivity("GetEsigMIDBValues").ToList();
                queryUsed = query;

                if (args != "Grief")
                {

                    //Rephrase DB string to datasheet entry format                                     

                    if (dbValues[0][KeyRepository.Replacement] == "False")
                        replacement = "No";
                    else
                        replacement = "Yes";                    

                    //Define smoker value
                    if (data[KeyRepository.Smoker] == "Yes")
                        smoker = "S";
                    if (data[KeyRepository.Smoker] == "No")
                        smoker = "N";

                    string[] dob = data[KeyRepository.DOB].Split('/');
                    string date = dbValues[0][KeyRepository.DOB].Split(' ')[0];


                    //Verify the entered values against the entries in DB
                    NYLDSelenium.VerifyText("LeadId", data[KeyRepository.LeadID], dbValues[0][KeyRepository.LeadID]);
                    NYLDSelenium.VerifyText("Coverage Amount", data[KeyRepository.CoverageAmount], dbValues[0][KeyRepository.CoverageAmount]);
                    NYLDSelenium.VerifyText("First Name", data[KeyRepository.FirstName], dbValues[0][KeyRepository.FirstName]);
                    NYLDSelenium.VerifyText("Last Name", data[KeyRepository.LastName], dbValues[0][KeyRepository.LastName]);
                    NYLDSelenium.VerifyText("Address", data[KeyRepository.AddressLine1], dbValues[0][KeyRepository.AddressLine1]);
                    NYLDSelenium.VerifyText("City", data[KeyRepository.City], dbValues[0][KeyRepository.City]);
                    NYLDSelenium.VerifyText("State", data[KeyRepository.State], dbValues[0][KeyRepository.State]);
                    NYLDSelenium.VerifyText("Zip", data[KeyRepository.Zip], dbValues[0][KeyRepository.Zip]);
                    NYLDSelenium.VerifyText("DOB", dob[0].TrimStart('0') + "/" + dob[1].TrimStart('0') + "/" + dob[2], dbValues[0][KeyRepository.DOB].Split(' ')[0]);
                    
                    NYLDSelenium.VerifyText("Email", data[KeyRepository.EmailId], dbValues[0][KeyRepository.EmailId]);
                    NYLDSelenium.VerifyText("SSN", data[KeyRepository.SSN], dbValues[0][KeyRepository.SSN]);                    
                    NYLDSelenium.VerifyText("Height Feet", data[KeyRepository.Height].Split('\'')[0], dbValues[0][KeyRepository.Feet]);
                    NYLDSelenium.VerifyText("Height Inches", data[KeyRepository.Height].Split('\'')[1], dbValues[0][KeyRepository.Inches]);
                    NYLDSelenium.VerifyText("Weight", data[KeyRepository.Weight], dbValues[0][KeyRepository.Weight]);
                    NYLDSelenium.VerifyText("Smoker", smoker, dbValues[0][KeyRepository.Smoker]);
                    NYLDSelenium.VerifyText("Replacement", data[KeyRepository.Replacement], replacement);
                    NYLDSelenium.VerifyText("Product Code", "LR10", dbValues[0][KeyRepository.ProductCode]);
                    NYLDSelenium.VerifyText("Auto Accept Status", "P", dbValues[0][KeyRepository.AutoAcceptStatus]);

                    //Verify Health Question response
                    dbValues.Clear();
                    dbValues = PerformDBActivity("GetEsigHealthResponse").ToList();
                    queryUsed = query;

                    for (int i = 0; i < healthReponses.Count(); i++)
                    {
                        //Verify response
                        NYLDSelenium.VerifyText("Health response for Question - " + (i + 1), healthReponses[i].Substring(0, 1), dbValues[i][KeyRepository.Response]);

                        //Verify Comments
                        if (data[KeyRepository.Product].Contains("PL") && data[KeyRepository.HQComments] == "Yes" && healthReponses[i].Substring(0, 1) == "Y")
                        {
                            NYLDSelenium.VerifyText("Health comment for Question - " + (i + 1), "Comment for Question - " + (i + 1), dbValues[i][KeyRepository.HQComments]);
                        }

                        //Verify Impairments
                        if (healthReponses[i].Substring(0, 1) == "Y" && i == (healthReponses.Count() - 1) && data[KeyRepository.HealthRisks] != "")
                        {
                            NYLDSelenium.VerifyText("Health Risks", data[KeyRepository.HealthRisks].Replace("|", ",").Replace(" ", "").ToLower(), dbValues[i][KeyRepository.HealthRisks].Replace("_", ""));
                        }
                    }
                }
                else if (dbValues.Count != 0)
                    NYLDSelenium.ReportStepResult("MI DB did not fetch any values for the query", "Query did not return any result from MI DB.", "Fail");

                int endCounter = GetSettor.failCounter;
                if (startCounter != endCounter)
                    NYLDSelenium.ReportStepResult("Error encountered in MI DB validation", "Query Used: " + queryUsed, "INFO");
                else
                    NYLDSelenium.ReportStepResult("<h4 style=\"color:Green\">" + "MI DB is updated with required values" + "</h4>", "<h4 style=\"color:Green\">" + "Query: " +queryUsed+ "</h4>", "PASS");
            }           

            return filePath;
        }
    }
}

