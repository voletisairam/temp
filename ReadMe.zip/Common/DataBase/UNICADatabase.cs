﻿using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
namespace CSW.Common.DataBase
{
    class UNICADatabase
    {
        private static IWebDriver driver;
        private Dictionary<string, string> data;
        public List<string> temp = new List<string> { };
        public string query;

        //Connection String    
        string connectionString = "Data Source=TPAINTRSQL01M;Initial Catalog=unica_int_prf;Integrated Security=True";
        public UNICADatabase(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
        }

        /// <summary>
        /// Method to execute query in data base and fetch values
        /// </summary>
        /// <param name="sQuery"></param>
        public List<string> QueryDataBase(string sQuery)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                //Set the command
                SqlCommand cmd = new SqlCommand(sQuery, conn);  

                //open the connection
                try
                {
                    conn.Open();
                }
                catch (Exception e)
                {
                    NYLDSelenium.ReportStepResult("Connect to Unica database", "Not able to connect to Unica database. Here is the error message: " + e.ToString(), "FAIL", "no", "yes");
                }

                //Execute the reader
                SqlDataReader reader = cmd.ExecuteReader();

                //Read each value
                int k = 0;
                temp.Clear();
                while (reader.Read())
                {
                    //temp.Add(new List<string>());
                    for (int j = 0; j < reader.FieldCount; j++)
                    {
                        temp.Add(reader[j].ToString().Trim());
                    }
                    k++;
                    //reader.NextResult();

                }

                //Close the Reader 
                reader.Close();

                //if(temp.Count == 0 && !CswWebTest.DMFlag)
                //    NYLDSelenium.ReportStepResult("Query did not return any result", "No result returned for the query: " + sQuery, "INFO", "no");
            }
            return temp;
        }

        public List<string> GetRiderstInfo(bool deactivate = false)
        {
            query = "SELECT [unica_int_prf].[dbo].[INT_CERTIFICATE].[Policy_Number] FROM [unica_int_prf].[dbo].[INT_CERTIFICATE] WHERE (Rider_Eligible_Flag = '1')";
            var RidersandTraderrecords=QueryDataBase(query);
            return RidersandTraderrecords;
        }

        public List<string> GetExchangesInfo(bool deactivate = false)
        {
            query = "SELECT  [unica_int_prf].[dbo].[INT_CERTIFICATE].[Policy_Number] FROM [unica_int_prf].[dbo].[INT_CERTIFICATE] WHERE (Exchange_Eligible_Flag = '1')";
            var RidersandTraderrecords = QueryDataBase(query);
            return RidersandTraderrecords;
        }

    }
}
