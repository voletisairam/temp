﻿
namespace CSW.Common.DataBase
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using OpenQA.Selenium;
    using SeleniumExtras.PageObjects;
    using CSW.Common.Others;
    using System.Threading;
    using CSW.PageObjects.Login;
    using CSW.Drivers;
    using CSW.Common.Excel;
    using CSW.Common.Services;
    using System.Runtime.InteropServices;
    using System.Text.RegularExpressions;
    using System.Globalization;
    using NYLDWebAutomationFramework;
    using System.Text;

    class LSPDatabase
    {
        private static IWebDriver driver;

        private Dictionary<string, string> data;
        public List<Dictionary<string, string>> queryResultList =new List<Dictionary<string, string>> { };
        public List<string> temp1 = new List<string> { };
        List<Dictionary<string, string>> queryList = new List<Dictionary<string, string>> { };

        public static string state = "";
        public static string stateRiderQuery;
        public static string query;

        public static bool RecordFound = false;

        [FindsBy(How = How.XPath, Using = "//*[@class='Gdd5U']")]
        public IWebElement Googlelink { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@class='DV7the']")]
        public IWebElement GoogleUploadlink { get; set; }

        public LSPDatabase(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver;
            data = testdata;
        }


        /// <summary>
        /// Method to execute query in data base and fetch values
        /// </summary>
        /// <param name="sQuery"></param>
        public void QueryDataBase(string sQuery)
        {
            queryResultList = new List<Dictionary<string, string>> { };
            queryResultList = NYLDDatabase.QueryDataBase(sQuery);
        }

        /// <summary>
        /// Method to build query, process and return the values from DB
        /// </summary>
        /// <param name="criteria"></param>
        public void GetDataBaseValues(string criteria)
        {

            string[] splitLSPDate = { };
            string CurrentDate = "";
            string MdlMonth = "";
            string MdlDay = "";
            string MdlYear = "";

            if (data[KeyRepository.LSPDate] != "" && data[KeyRepository.LSPDate] != null)
            {
                splitLSPDate = data[KeyRepository.LSPDate].Split('-');
                MdlMonth = splitLSPDate[1];
                MdlDay = splitLSPDate[2];
                MdlYear = splitLSPDate[0];
            }
            if (criteria == "queryCashValueLetter_Fax")
            {
                DateTime now = DateTime.Now;
                CurrentDate = now.ToString("yyyy-MM-dd");
                Console.WriteLine("CurrentDate: " + CurrentDate);
            }

            switch (criteria)
            {
                case "queryPolicyNumber":
                    query = "SELECT JAPOLN as PolicyNumber, JAMDBM, JAMDBD, JAMDBY, JAMNAM, JAMTID, JASTAT FROM KLSDAT00.JETAPPS WHERE JAPOLN = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryControlNumber":
                    query = "SELECT JACTRL as ControlNumber, JAMDBM, JAMDBD, JAMDBY, JAMNAM, JAMTID, JASTAT FROM KLSDAT00.JETAPPS WHERE JAPOLN= '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryAssociatedPolicies":
                    query = "SELECT REL.CRCTL1, CNTR.MCCSTA, PDP.PDDESC, CNTR.MCPYCD, CNTR.MCTRMM FROM KLSDAT00.CMSUSREL REL, KLSDAT00.CASCNTRM CNTR, KLSDAT00.CASBENE BEN, KLSDAT00.AABILPDP PDP WHERE REL.CRCTL1 = CNTR.MCCNTR AND PDP.PDPLAN = BEN.FPLAN AND BEN.FPOLNO = REL.CRCTL1 AND BEN.FBRCD = '0' AND REL.CRCLTN = (SELECT DISTINCT(CRCLTN) FROM KLSDAT00.CMSUSREL WHERE CRCTL1 ='" + data[KeyRepository.PolicyNumber] + "' AND CRALPH = 'OW1')  AND REL.CRALPH = 'OW1' ORDER BY " + "\r\n" +
                                "CASE CNTR.MCCSTA " + "\r\n" +
                                "WHEN 'I' THEN 1 " + "\r\n" +
                                "WHEN 'R' THEN 2 " + "\r\n" +
                                "WHEN 'E' THEN 3 " + "\r\n" +
                                "WHEN 'D' THEN 4 " + "\r\n" +
                                "WHEN 'L' THEN 5 " + "\r\n" +
                                "WHEN 'X' THEN 6 " + "\r\n" +
                                "WHEN 'P' THEN 7 " + "\r\n" +
                                "WHEN 'T' THEN 8 " + "\r\n" +
                                "WHEN 'N' THEN 9 " + "\r\n" +
                                "WHEN 'S' THEN 10 " + "\r\n" +
                                "WHEN 'C' THEN 11 " + "\r\n" +
                                "WHEN 'M' THEN 12 " + "\r\n" +
                                "ELSE 8 " + "\r\n" +
                                "END, REL.CRCTL1";
                    break;

                case "getLSPDate":
                    query = "select CHAR(DATE(TO_DATE(VARCHAR(PLSOBJ00.GETLSPTODAYDATE()), 'YYYYMMDD')),ISO) as LSPDATE from klsdat00.cascntrm fetch first 1 rows only"; //A0132504
                    break;

                case "queryPaymentDetails":
                    query = "SELECT CASCNTRM.MCCNTR,CASCNTRM.MCCSTA, CASCNTRM.MCPMOD,CASCNTRM.MCPYCD,CASCNTRM.MCEFFM, CASCNTRM.MCEFFD, CASCNTRM.MCEFFY, CASCNTRM.MCPDTM, CASCNTRM.MCPDTD, CASCNTRM.MCPDTY, CASCNTRM.MCPRMA,CASCNTRM.MCPRMM, CASCNTRM.MCBLTM, CASCNTRM.MCBLTD, CASCNTRM.MCBLTY "
                                    + "FROM KLSDAT00.CASCNTRM CASCNTRM " +
                                        "WHERE CASCNTRM.MCCNTR = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPaymentDetailsBankAccount":
                    query = "SELECT ACCTRL, ACBANK, ACACCT "
                                    + "FROM KLSDAT00.APPCTRL " +
                                        "WHERE  ACCO = 'AARP' AND ACCTRL = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPendingEFTContract":
                    query = "SELECT PPPOLN FROM KLSDAT00.APPPND02 WHERE PPCO = 'AARP'";
                    break;

                case "queryFamilyBillGroupID":
                    query = "Select MCGBNO " +
                                "From KLSDAT00.CASCNTRM CNTR " +
                                    "WHERE CNTR.MCCO = 'AARP' AND CNTR.MCCNTR = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "WaiverofPremium":
                    query = "SELECT MCCO, MCCNTR, MCCSTA, MCGBNO, CRALPH, CMCLTN, MCPDTM, MCPDTD, MCPDTY, MCPYCD, CMNAME, CMDOBM, CMDOBD, CMDOBY, CMTIDF, ELEMAL" +
                            " FROM KLSDAT00.CASCNTRM CASCNTRM" +
                            " JOIN KLSDAT00.CMSUSREL CMSUSREL ON CASCNTRM.MCCNTR = CMSUSREL.CRCTL1" +
                            " JOIN KLSDAT00.CMSCLNTM CMSCLNTM ON CMSCLNTM.CMCLTN = CMSUSREL.CRCLTN" +
                            " JOIN KLSDAT00.AAEMALLP AAEMALLP ON CMSUSREL.CRCLTN = AAEMALLP.ELCLNT WHERE" +
                            " CASCNTRM.MCCSTA = 'I'" +
                            " AND CASCNTRM.MCCO = 'AARP'" +
                            " AND CASCNTRM.MCPYCD = 'WP'" +
                            " AND CMSUSREL.CRALPH = 'OW1'" +
                            " AND CASCNTRM.MCCNTR = '" + data[KeyRepository.PolicyNumber] + "'" +
                    "order by cmsclntm.cmcltn";
                    break;

                case "queryFamilyBillDetails":
                    query = "Select CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCBLTM, CNTR.MCBLTD, CNTR.MCBLTY, MCPRMM " +
                            "From KLSDAT00.CASCNTRM CNTR " +
                                "WHERE CNTR.MCCO = 'AARP' AND MCGBNO = '" + data[KeyRepository.FamilyBillGroupID] + "'";
                    break;

                case "pendingPayment":
                    query = "SELECT * FROM KLSDAT00.AANRPMP1 where NMCNTR = '" + data[KeyRepository.PolicyNumber] + "' AND NMSTAT IN('PND', 'ACT') AND NMPSTS = ''";
                    break;

                case "queryAutoPremPayUpdatePCM":
                    query = "select CECO, CETYPE, CEUSER, CEPOLN from KLSDAT00.CCSEXTR "
                                + "where CELTRM = '" + MdlMonth + "' and CELTRD = '" + MdlDay + "' and CELTRY = '" + MdlYear + "' and CEUSER = 'CSW' and CECO = 'AARP' and CEPOLN = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryAutoPremPayUpdateES":
                    query = "select POCOMP, POSIGTYPE, POPOLICY from KLSDAT00.LPOPTPRCS1 "
                                    + "where POADDUSER = 'CSW' and POPOLICY = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPolicyDetailsOwner":
                    query = "SELECT RN.CMNAME, RA.CYCAD1, RA.CYCAD2, RA.CYCCIT, RA.CYCSTA, RA.CYCZIP, RA.CYHPHE, RA.CYFRMM, RA.CYFRMD, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF, RA.CYCNRY, EM.ELEMAL as EmailId " +
                                    "FROM KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSCLNAD RA, KLSDAT00.CMSUSREL RT LEFT JOIN KLSDAT00.AAEMALLP EM ON RT.CRCLTN = EM.ELCLNT " +
                                " WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRCLTN = RA.CYCLTN AND RT.CRALPH = 'OW1' AND RA.CYASEQ = RT.CRASEQ AND RN.CMDOBM != '0' AND RT.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPolicyDetailsInsured":
                    query = "SELECT RN.CMNAME,RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMSXCD " +
                            "FROM KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNTM RN " +
                            "WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRALPH = 'INS' AND RT.CRCTL2 = '0' AND RT.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPolicyDetailsPayor":
                    query = "SELECT RN.CMNAME, RA.CYCAD1, RA.CYCAD2, RA.CYCCIT, RA.CYCSTA, RA.CYCZIP, RA.CYHPHE, RA.CYFRMM, RA.CYFRMD, RA.CYCNRY " +
                            "FROM KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSCLNAD RA " +
                            "WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRCLTN = RA.CYCLTN AND RT.CRALPH = 'PAY' AND RA.CYASEQ = RT.CRASEQ AND RT.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPolicyDetailsEffectiveDate":
                    query = "SELECT BEN.FEFFMM, BEN.FEFFDD, BEN.FEFFYY, CNTR.MCPDTM, CNTR.MCPDTD, MCPDTY, BEN.FPLAMT,CNTR.MCCSTA,PDP.PDDESC, CNTR.MCPYCD, CNTR.MCPMOD, CNTR.MCPRMM, CNTR.MCUSR4, CNTR.MCISST FROM KLSDAT00.CASCNTRM CNTR, KLSDAT00.CASBENE BEN, KLSDAT00.AABILPDP PDP WHERE BEN.FPOLNO = CNTR.MCCNTR AND PDP.PDPLAN = BEN.FPLAN AND CNTR.MCCNTR = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryPolicyDetailsPaymentDetails":
                    query = "SELECT PPRMPD, PAPPYY, PAPPMM, PAPPDD FROM KLSDAT00.NTLPYMTH where PPOLNO = '" + data[KeyRepository.PolicyNumber] + "' ORDER BY PAPPYY DESC, PAPPMM DESC, PAPPDD DESC";
                    break;

                case "getBeneInfo":
                    query = "SELECT RN.CMNAME, RT.CRPCPT, RT.CRALPH,RA.CYCAD1, RA.CYCAD2, RA.CYCCIT, RA.CYCSTA, RA.CYCZIP, RA.CYHPHE, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF, RT.CRCLTN, RA.CYCNRY,RT.CRUSR1 " +
                                "FROM KLSDAT00.CMSUSREL RT left join KLSDAT00.CMSCLNAD RA ON RA.CYASEQ = RT.CRASEQ  AND RT.CRCLTN = RA.CYCLTN, KLSDAT00.CMSCLNTM RN " +
                                "WHERE RT.CRCLTN = RN.CMCLTN AND (RT.CRALPH like 'BN%' or RT.CRALPH = 'IRB') AND RT.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "' ORDER BY " +
                                "CASE RT.CRALPH " +
                                "WHEN 'IRB' THEN 1 " +
                                "WHEN 'BN1' THEN 2 " +
                                "WHEN 'BN2' THEN 3 " +
                                "WHEN 'BN3' THEN 4 " +
                                "WHEN 'BN4' THEN 5 " +
                                "ELSE 6 END ";
                    break;

                case "queryDuplicateContract":
                    query = "Select TTPOLN,TTLCDT from klsdat00.AACTTP1 where  TTPOLN like '" + data[KeyRepository.PolicyNumber] + "%'";
                    break;

                case "queryEmail":
                    query = "SELECT EM.ELEMAL FROM KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSCLNAD RA, KLSDAT00.CMSUSREL RT LEFT JOIN KLSDAT00.AAEMALLP EM ON RT.CRCLTN = EM.ELCLNT " +
                               " WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRCLTN = RA.CYCLTN AND RT.CRALPH = 'OW1'" +
                                "AND RA.CYASEQ = RT.CRASEQ AND RT.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;
                case "queryEmailcontract":
                    query = "SELECT RT.CRCTL1 FROM KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSCLNAD RA, KLSDAT00.CMSUSREL RT LEFT JOIN KLSDAT00.AAEMALLP EM ON RT.CRCLTN = EM.ELCLNT " +
                        "WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRCLTN = RA.CYCLTN AND RT.CRALPH = 'OW1'  AND RA.CYASEQ = RT.CRASEQ AND EM.ELEMAL ='" + data[KeyRepository.EmailId] + "' Fetch first row only";
                    break;
                case "queryCyberFraudEntry":
                    query = "SELECT LUC.FRAUD_SYSTEM, LUC.CYBER_REASON FROM KLSDAT00.CMSUSREL REL, KLSDAT00.UCPLGCY UCP, KLSDAT00.LUCTCYBRS1 LUC WHERE REL.CRALPH = 'OW1' AND REL.CRCLTN = UCP.LSP_CLIENT_ID AND UCP.UC_ID = LUC.UC_ID AND REL.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryCyberFraudDetails":
                    query = "SELECT REL.CRCLTN, UCP.UC_ID FROM KLSDAT00.CMSUSREL REL, KLSDAT00.UCPLGCY UCP WHERE REL.CRALPH = 'OW1' AND REL.CRCLTN = UCP.LSP_CLIENT_ID AND REL.CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;

                case "queryCyberFraudHistory":
                    query = "Select UC_ID, ROW_END_DTTM, INSERT_DTTM, INSERT_PRGM, DATA_ACTION, CYBER_REASON From KLSDAT00.LUCTCYBHS1 Where UC_ID = '" + data[KeyRepository.UclientIdOfPolicy] + "' and INSERT_OPER = '" + Environment.UserName.ToLower() + "'";
                    break;

                case "queryCoverageSummary":
                    query = "SELECT PDP.PDDESC, (digits(BEN.FEFFMM)||'/'|| digits(BEN.FEFFDD)||'/'|| digits(BEN.FEFFYY)) as EFTDATE,  BEN.FPLAMT FROM KLSDAT00.CASCNTRM CNTR, KLSDAT00.CASBENE BEN, KLSDAT00.AABILPDP PDP WHERE BEN.FPOLNO = CNTR.MCCNTR AND PDP.PDPLAN = BEN.FPLAN AND CNTR.MCCNTR = '" + data[KeyRepository.PolicyNumber] + "' ORDER BY BEN.FEFFYY, BEN.FEFFMM, BEN.FEFFDD";
                    break;

                case "getDupContractTTP1Entry":
                    query = "SELECT TTLCDT FROM KLSDAT00.AACTTP1 WHERE TTPOLN like '" + data[KeyRepository.PolicyNumber] + "%'  order by TTLCDT desc";
                    break;

                case "queryCashValueLetter":
                    query = "SELECT LDLNAM,LDLAD1, LDLAD2, LDLAD3, LDLCSZ,LDKEYF FROM KLSDAT00.AALDTLP1 WHERE LDKEYF ='" + data[KeyRepository.PolicyNumber] + "' AND LDPRCD = '" + MdlYear + MdlMonth.PadLeft(2, '0') + MdlDay.PadLeft(2, '0') + "' AND LDLTCD = 'CVLTR' AND LDUSER ='CSW' ORDER BY LDPRCD DESC";
                    break;

                case "queryCashValueLetter_Fax":
                    query = "SELECT FXNUMF, FXNUMT, FXSUB1, FXSUB2 FROM KLSDAT00.FAXREQP1 WHERE FXSUB1 like '%" + data[KeyRepository.PolicyNumber] + "%' AND FXPRDT > '" + CurrentDate + "' AND FXLTCD = 'CVLTR' ORDER BY FXPRDT DESC";
                    break;

                case "queryRiderOffer":
                    query = "SELECT Policy_Number, Status, Rider_Eligible_Flag, Renewal_Exchange_Flag, Attained_Age, Issue_State, CLIENT.State FROM unica_int_prf.dbo.INT_CERTIFICATE CERTIFICATE INNER JOIN unica_int_prf.DBO.INT_CLIENT CLIENT ON CERTIFICATE.Customer_ID = CLIENT.Client_ID " +
                                " where CERTIFICATE.Face_Amount < 50000 AND CERTIFICATE.Payment_Method <> 'WP' AND CLIENT.LBR_Flag <> '1' AND" +
                                stateRiderQuery + " Status = 'I' AND " +
                                " CERTIFICATE.Plan_Code IN ('5YL1', '5YL1D', '5YL1R', '5YTA', 'LBT2R', '5YL1NY', 'LBTRNY', 'LB3R', 'LB5R', 'LBTRMA', 'LBTRMT', 'LB5RMA', 'LB5RMT', 'LB7R', 'LB7RMA', 'LB7RMT', 'LB10') AND CERTIFICATE.Attained_Age BETWEEN 45 AND 75 AND CERTIFICATE.Billing_Mode IN ('M', 'Q') AND" +
                                " (CERTIFICATE.Paid_To_Date < '" + data[KeyRepository.LSPDate] + "' OR CERTIFICATE.Paid_To_Date >= '" + Convert.ToDateTime(data[KeyRepository.LSPDate]).AddDays(62) + "') AND CERTIFICATE.Date_Of_Next_Bill < '" + Convert.ToDateTime(data[KeyRepository.LSPDate]).AddDays(124) + "' AND (DATEPART(MM, CERTIFICATE.EFFECTIVE_DATE) <> '02' AND DATEPART(DD, CERTIFICATE.EFFECTIVE_DATE) <> '29') AND '" + Convert.ToDateTime(data[KeyRepository.LSPDate]) + "' < DATEADD(DAY, -60, CERTIFICATE.Next_Renewal_Anniversary) AND" +
                                " CERTIFICATE.Duration > 1 AND CERTIFICATE.Rider_Eligible_Flag = '1' ORDER BY NEWID()";
                    break;

                case "getFormCode":
                    query = "select FCFRMCODE as \"FormCode\" from klsdat00.lfrmcodp1 where  fcdefault = 'Y' and fcactive = 'Y' and fcenddte is null and fcplan = '" + data[KeyRepository.Product] + "'";
                    break;
                case "queryPreferenceHistoryLogs":
                    query = "SELECT CHG_TYPE FROM KLSDAT00.LPLSPRFHS1 HT inner join  KLSDAT00.CMSUSREL CS ON  HT.ID_REFERENCE_NO=CS.CRCLTN where CS.CRALPH='OW1'  and HT.Preference_channel in('TEXT','EMAIL')  and HT.SYS_END >= '" + CSWData.EventTriggerTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and CS.CRCTL1 ='" + data[KeyRepository.PolicyNumber] + "'" + " order by HT.SYS_END desc ";
                    break;
                case "querypreferenceEntryOpt-InLog":
                    query = "SELECT CHG_TYPE FROM KLSDAT00.LPLSPREFS1 PL inner join  KLSDAT00.CMSUSREL CS ON  PL.ID_REFERENCE_NO=CS.CRCLTN where CS.CRALPH='OW1' and PL.Preference_channel in('TEXT','EMAIL') and PL.INSERT_DATETIME >= '" + CSWData.EventTriggerTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and PL.CHG_TYPE='I' and CS.CRCTL1='" + data[KeyRepository.PolicyNumber] + "'";
                    break;
                case "querypreferenceEntryLog":
                    query = "SELECT CHG_TYPE FROM KLSDAT00.LPLSPREFS1 PL inner join  KLSDAT00.CMSUSREL CS ON  PL.ID_REFERENCE_NO=CS.CRCLTN where CS.CRALPH='OW1' and PL.Preference_channel in('TEXT','EMAIL') and PL.UPDATE_DATETIME >= '" + CSWData.EventTriggerTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and PL.CHG_TYPE='U' and CS.CRCTL1='" + data[KeyRepository.PolicyNumber] + "'";
                    break;
                case "querypreferenceOptStatus":
                    query = "SELECT PL.ENDDATE FROM KLSDAT00.LPLSPREFS1 PL inner join  KLSDAT00.CMSUSREL CS ON  PL.ID_REFERENCE_NO=CS.CRCLTN where CS.CRALPH='OW1' and PL.Preference_channel in('EMAIL') and PL.ENDDATE=0 and CS.CRCTL1='" + data[KeyRepository.PolicyNumber] + "'";
                    break;
                case "queryLSPCVL_Mail":
                    query = "SELECT ACTIVITY FROM KLSDAT00.LSP_CUSTOMER_ACTIVITY_AUDIT_TBL WHERE CLIENTID =(select CRCLTN FROM  KLSDAT00.CMSUSREL RT WHERE RT.CRALPH ='OW1' AND RT.CRCTL1 ='" + data[KeyRepository.PolicyNumber] + "') AND ACTTYPE =32  and CRTTMSTAMP >='" + CSWData.EventTriggerTime.ToString("yyyy-MM-dd HH:mm:ss") + "' ORDER BY CRTTMSTAMP DESC FETCH FIRST ROW ONLY";
                    break;
                case "queryLSPCVL_Fax":
                    query = "SELECT ACTIVITY FROM KLSDAT00.LSP_CUSTOMER_ACTIVITY_AUDIT_TBL WHERE CLIENTID =(select CRCLTN FROM  KLSDAT00.CMSUSREL RT WHERE RT.CRALPH ='OW1' AND RT.CRCTL1 ='" + data[KeyRepository.PolicyNumber] + "') AND ACTTYPE =31  and CRTTMSTAMP >='" + CSWData.EventTriggerTime.ToString("yyyy-MM-dd HH:mm:ss") + "' ORDER BY CRTTMSTAMP DESC FETCH FIRST ROW ONLY";
                    break;
                case "DeathClaimContract":
                    query = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, CNTR.MCUSR4, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF " +
                            "FROM KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSCLNAD RA, KLSDAT00.CMSUSREL RT, KLSDAT00.CASCNTRM CNTR " +
                            "LEFT JOIN KLSDAT00.AAEMALLP EM ON CNTR.MCCNTR = EM.ELCLNT " +
                            "WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRCLTN = RA.CYCLTN " +
                            "AND RT.CRALPH = 'OW1'AND RA.CYASEQ = RT.CRASEQ AND CNTR.MCCNTR = RT.CRCTL1 AND EM.ELTIME IS NULL " +
                            "AND CNTR.MCCSTA = 'D' AND CNTR.MCUSR4 != 'USD' AND CNTR.MCUSR4 != 'DTH' FETCH FIRST ROW ONLY";
                    break;
                case "DeathContractAlreadyUsed":
                    query = "UPDATE KLSDAT00.CASCNTRM SET MCUSR4 = 'DTH' WHERE MCCNTR = '" + data[KeyRepository.PolicyNumber] + "'";
                    break;
                case "queryPaymentHistory":                    
                    data.TryGetValue(KeyRepository.PaidToDate, out string PaidToDate);
                    string comparisonOperator;
                    DateTime paidToDateParsed;
                    if (DateTime.TryParseExact(PaidToDate, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out paidToDateParsed))
                    {
                        if (paidToDateParsed.Month > DateTime.Now.Month)
                        {
                            comparisonOperator = "<=";
                        }
                        else
                        {
                            comparisonOperator = "<";
                        }
                    }
                    else
                    {
                        comparisonOperator = "<";
                    }
                    query = "SELECT " +
                        "KLSDAT00.NTLPYMTH.PPOLNO, " +
                        "KLSDAT00.NTLPYMTH.PPRMPD, " +
                        "KLSDAT00.NTLPYMTH.PYEAR, " +
                        "KLSDAT00.NTLPYMTH.PMONTH, " +
                        "KLSDAT00.NTLPYMTH.PDAY, " +
                        "KLSDAT00.NTLPYMTH.PPDTYY, " +
                        "KLSDAT00.NTLPYMTH.PPDTMM, " +
                        "KLSDAT00.NTLPYMTH.PPDTDD, " +
                        "KLSDAT00.NTLPYMTH.PREVCD " +
                        "FROM " +
                        "KLSDAT00.NTLPYMTH " +
                        "WHERE " +
                        "KLSDAT00.NTLPYMTH.PPOLNO = '" + data[KeyRepository.PolicyNumber] + "'" +
                        "AND (((" + MdlYear + " - KLSDAT00.NTLPYMTH.PYEAR) * 12)+(" + MdlMonth + " - KLSDAT00.NTLPYMTH.PMONTH)" + comparisonOperator + " 24)" +
                        "ORDER BY " +
                        "KLSDAT00.NTLPYMTH.PYEAR DESC, KLSDAT00.NTLPYMTH.PMONTH DESC, KLSDAT00.NTLPYMTH.PDAY DESC, KLSDAT00.NTLPYMTH.PPDTYY ASC, KLSDAT00.NTLPYMTH.PPDTMM ASC, KLSDAT00.NTLPYMTH.PPDTDD ASC";
                    break;
                case "queryClientID":
                    query = "SELECT JACLNT FROM KLSDAT00.JETAPPS WHERE JAPOLN= '" + data[KeyRepository.PolicyNumber] + "'";
                    break;
                default:
                    query = "";
                    NYLDSelenium.ReportStepResult("No Query found", "Query requested for the criteria is not found, check DB code", "Fail", "no", "no");
                    break;
            }
            if (criteria != "queryRiderOffer")
                QueryDataBase(query);
        }

        /// <summary>
        /// MEthod to fetch the current LSP Date
        /// </summary>
        public void GetLSPDate()
        {

            GetDataBaseValues("getLSPDate");
            data[KeyRepository.LSPDate] = queryResultList[0]["LSPDATE"].ToString();
            Console.WriteLine(data[KeyRepository.LSPDate]);

            //Write model date in steps result
            NYLDSelenium.ReportStepResult("Model Date", data[KeyRepository.LSPDate], "INFO", "always", "no");

        }

        /// <summary>
        /// Method to fetch the policy number from congtrol number
        /// </summary>
        public void QueryPolicyNumber()
        {
            GetDataBaseValues("queryPolicyNumber");
            if (queryResultList.Count > 0)
            {
                data[KeyRepository.PolicyNumber] = queryResultList[0]["POLICYNUMBER"].ToString().Trim();
                QueryPolicyDetails();
            }
        }

        /// <summary>
        /// Method helps to Get Policy Details 
        /// </summary>
        /// <returns></returns>
        public bool GetPolicyDetails()
        {
            bool result = false;
            GetDataBaseValues("queryPolicyDetailsOwner");
            if (queryResultList.Count > 0)
            {
                result = true;
            }
            return result;
        }

        /// <summary>
        /// Method to fetch the control number from policy number
        /// </summary>
        public void QueryControlNumber()
        {
            GetDataBaseValues("queryControlNumber");
            if (queryResultList.Count > 0)
            {
                data[KeyRepository.ControlNumber] = queryResultList[0]["ControlNumber"].ToString().Trim();
            }
        }

        /// <summary>
        /// QueryPreferenceManagementEntry
        /// </summary>
        /// <param name="args"></param>
        public void QueryPreferenceManagementHistorydataEntry(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Database entries in Preference History table" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            bool exists = false;
            string msg = "";
            //History Table
            GetDataBaseValues("queryPreferenceHistoryLogs");
            //First time Opt-In history table empty
            if (queryResultList.Count == 0)
            {
                if (args == "New-Opt-In")
                {
                    msg = "Inserted";
                    exists = true;
                }
            }
            //N number times Opt-In or Opt-out call as Exisitng user count is more than 2
            else
            {
                if (queryResultList.Count != 0 && args == "Re-Opt-In")
                {
                    msg = "Updated";
                    exists = true;
                }
            }


            if (exists == false)
                NYLDSelenium.ReportStepResult("Records not found-in History Preferences Table", "Could not fetch Records for Paperless Settings , for the Contract: " + data[KeyRepository.PolicyNumber] + "--" + query, "Fail", "no", "no");
            else
                NYLDSelenium.ReportStepResult("<h3 style =\"color:Green\">" + "Verify record is " + msg + " in Preferences History Table" + "</h3>", "Record " + msg + " succesfully, for the Contract: " + data[KeyRepository.PolicyNumber], "Pass", "no");
        }

        public void QueryPreferenceManagementdataEntry(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Database entries in Preference Table" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            bool exists = false;
            string msg = "";

            //2 --Text/Email -Preferences Channel type
            if (args == "New-Opt-In")
            {
                msg = "Inserted";
                GetDataBaseValues("querypreferenceEntryOpt-InLog");
                if (queryResultList.Count != 0)
                    exists = true;
            }
            else
            {
                if (args == "Re-Opt-In")
                {
                    msg = "Updated";
                    GetDataBaseValues("querypreferenceEntryLog");
                    if (queryResultList.Count != 0)
                        exists = true;
                }
            }

            if (exists == false)
                NYLDSelenium.ReportStepResult("Records not found-in Preference Table", "Could not fetch Records for Paperless Settings , for the Contract: " + data[KeyRepository.PolicyNumber] + "--" + query, "Fail", "no", "no");
            else
                NYLDSelenium.ReportStepResult("<h3 style =\"color:Green\">" + "Verify record is " + msg + " in Preference Table" + "</h3>", "Record " + msg + " succesfully, for the Contract: " + data[KeyRepository.PolicyNumber], "Pass", "no");

        }

        /// <summary>
        /// QueryPreferenceManagementStatusEntry
        /// </summary>
        /// <param name="args"></param>
        public bool QueryPreferenceManagementStatusdataEntry()
        {
            string msg; bool status = false;
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Database entries in Preference Table" + " </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //Opt Status
            GetDataBaseValues("querypreferenceOptStatus");
            //User pepaerless settings Opt-In / Opt-Out (if count ==1 then Opt-In and if count==0 Opt-Out)
            if (queryResultList.Count != 0) { msg = "New-Opt-In"; status = true; }
            else msg = "Opt-out";

            if (status == false)
                NYLDSelenium.ReportStepResult("Records not found-in Preference Table for Opt In Entry", "Could not fetch Records for Paperless Settings -Opt In Entry , for the Contract: " + data[KeyRepository.PolicyNumber] + "--" + query, "INFO", "always", "no");
            else
                NYLDSelenium.ReportStepResult("<h3 style =\"color:Green\">" + "Verify record found in Preference Table for Opt In Entry" + "</h3>", "Fetch the Records for Paperless Settings, for the Contract: " + data[KeyRepository.PolicyNumber] + "and Status is -" + msg, "Pass", "always");

            return status;
        }

        public void VerifyPolicyDetails(string args)
        {
            GetDataBaseValues("queryPolicyDetailsOwner");
            if (args == "Email" && queryResultList.Count != 0)
            {
                NYLDSelenium.VerifyText("VerifyEmail", data[KeyRepository.EmailId].Replace("'", ""), queryResultList[0]["EMAILID"].ToString().Trim());
            }
        }
        /// <summary>
        /// Method to Query all policy related information, Owner, Payor and Insured
        /// </summary>
        /// <param name="args"></param>

        public void QueryPolicyDetails(string args = "")
        {
            CommonFunctions CF = new CommonFunctions(data);
            string fullName;
            string[] fullNameSplit;
            DateTime now = DateTime.Now;
            DateTime Add1date = DateTime.Now;
            DateTime Add2date = DateTime.Now;
            DateTime CurrentDate;
            int i = 1;

            try
            {
                /////////////////////Owner Query/////////////////////
                GetDataBaseValues("queryPolicyDetailsOwner");

                while (i <= queryResultList.Count())
                {
                    if (queryResultList[i - 1]["CYFRMM"].ToString().Trim() != "0")
                    {
                        if (i == 1)
                            Add1date = Convert.ToDateTime(queryResultList[0]["CYFRMM"].ToString().Trim() + "/" + queryResultList[0]["CYFRMD"].ToString().Trim() + "/" + DateTime.Parse(data[KeyRepository.LSPDate].Trim()).Year);
                        else
                            Add2date = Convert.ToDateTime(queryResultList[1]["CYFRMM"].ToString().Trim() + "/" + queryResultList[1]["CYFRMD"].ToString().Trim() + "/" + DateTime.Parse(data[KeyRepository.LSPDate].Trim()).Year);
                    }
                    i++;
                }

                // Determine the logic on which address to pick and set the variable to 1 or 2
                //Get Current date            
                CurrentDate = Convert.ToDateTime(data[KeyRepository.LSPDate]);
                int snwbrdAddr = 0;
                //Compare if date is greater than 1st date then take 2 record as the address
                if (queryResultList.Count() > 1)
                {
                    if ((CurrentDate > Add1date) && (CurrentDate > Add2date))
                    {
                        if (Add1date.Month > Add2date.Month)
                            snwbrdAddr = 0;
                        else
                            snwbrdAddr = 1;
                    }
                    else if ((CurrentDate > Add1date) && (CurrentDate < Add2date))
                        snwbrdAddr = 0;
                    else
                        snwbrdAddr = 1;
                }
                if (queryResultList.Count() != 0)
                {

                    int j = snwbrdAddr;

                    fullName = queryResultList[j]["CMNAME"].ToString().Trim();
                    if (!(fullName.Contains("/")))
                        goto nextRecord;
                    fullNameSplit = fullName.Split('/');
                    if (args != "Case")
                    {
                        data[KeyRepository.LastName] = fullNameSplit[0].Trim().First().ToString().ToUpper() + fullNameSplit[0].Substring(1).Trim();
                        data[KeyRepository.FirstName] = fullNameSplit[1].Trim().First().ToString().ToUpper() + fullNameSplit[1].Substring(1).Trim();
                    }
                    else
                    {
                        data[KeyRepository.LastName] = fullNameSplit[0].Trim();
                        data[KeyRepository.FirstName] = fullNameSplit[1].Trim();
                    }
                    if (fullNameSplit.Count() > 2)
                    {
                        data[KeyRepository.MiddleName] = fullNameSplit[2].Trim();
                        data[KeyRepository.Title] = fullNameSplit[3];
                        if (fullNameSplit.Count() > 4)
                            data[KeyRepository.Suffix] = fullNameSplit[4].Trim();
                    }
                    data[KeyRepository.AddressLine1] = queryResultList[j]["CYCAD1"].ToString().Trim();
                    data[KeyRepository.AddressLine2] = queryResultList[j]["CYCAD2"].ToString().Trim();
                    data[KeyRepository.City] = queryResultList[j]["CYCCIT"].ToString().Trim();
                    data[KeyRepository.State] = queryResultList[j]["CYCSTA"].ToString().Trim();
                    data[KeyRepository.Zip] = queryResultList[j]["CYCZIP"].ToString().Trim();
                    data[KeyRepository.Phone] = queryResultList[j]["CYHPHE"].ToString().Trim();
                    data[KeyRepository.Country] = queryResultList[j]["CYCNRY"].ToString().Trim();

                    if (queryResultList[j]["CMTIDF"].ToString().Length == 8)
                    {
                        data[KeyRepository.SSN] = "0" + queryResultList[j]["CMTIDF"].ToString().Trim();
                    }
                    else if (queryResultList[j]["CMTIDF"].ToString().Length < 8)
                    {
                        data[KeyRepository.SSN] = queryResultList[j]["CMTIDF"].ToString().Trim().PadLeft(9, '0');
                    }
                    else
                    {
                        data[KeyRepository.SSN] = queryResultList[j]["CMTIDF"].ToString().Trim();
                    }

                    if (queryResultList[j]["EMAILID"].ToString() != null && queryResultList[j]["EMAILID"].ToString() != "" && args == "" && !(queryResultList[j]["EMAILID"].ToString().Contains("test@email.com")))
                    {
                        data[KeyRepository.EmailId] = queryResultList[j]["EMAILID"].ToString().Trim();
                    }
                    else
                    {
                        data[KeyRepository.EmailId] = data[KeyRepository.FirstName] + data[KeyRepository.SSN].Substring(5, 4) + now.Month + now.Day + now.Minute + "@auto" + now.Year + ".com";
                        data[KeyRepository.EmailId] = data[KeyRepository.EmailId].Replace(" ", "");
                    }

                    data[KeyRepository.DOB] = DateTime.Parse(queryResultList[j]["CMDOBM"].ToString() + "/" + queryResultList[j]["CMDOBD"].ToString() + "/" + queryResultList[j]["CMDOBY"].ToString()).ToString("MM/dd/yyyy");
                    if (data[KeyRepository.ContractSource] != "ExistingUserAccountsSheet")
                    {
                        if ((data[KeyRepository.ContractSource] == "DM" || data[KeyRepository.ContractSource] == "DataMine" || data[KeyRepository.UserAccountStatus] != "Active"))
                        {
                            if (data[KeyRepository.ContractSource] == "DM")
                            {
                                data[KeyRepository.UserName] = null;
                            }
                            data.TryGetValue(KeyRepository.UserName, out string UserNameStatus);
                            if (string.IsNullOrEmpty(UserNameStatus))
                            {
                                CF.getUserName();
                                data[KeyRepository.Password] = "2W3e4r5t!";
                            }
                        }
                    }

                    ///////////////////////////////////////// Get Effective and Paid To Date ////////////////////////////

                    GetDataBaseValues("queryPolicyDetailsEffectiveDate");

                    data[KeyRepository.EffectiveDate] = queryResultList[0]["FEFFMM"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["FEFFDD"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["FEFFYY"].ToString().PadLeft(2, '0');
                    data[KeyRepository.PaidToDate] = queryResultList[0]["MCPDTM"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["MCPDTD"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["MCPDTY"].ToString().PadLeft(2, '0');
                    data[KeyRepository.Premium] = queryResultList[0]["MCPRMM"].ToString();
                    data[KeyRepository.IssuedState] = queryResultList[0]["MCISST"].ToString();
                    data[KeyRepository.CoverageAmount] = queryResultList[0]["FPLAMT"].ToString().Trim();
                    data[KeyRepository.Status] = queryResultList[0]["MCCSTA"].ToString().Trim();
                    data[KeyRepository.PolicyName] = queryResultList[0]["PDDESC"].ToString().Trim();
                    data[KeyRepository.CurrentPaymentFrequency] = queryResultList[0]["MCPMOD"].ToString().Trim();
                    data[KeyRepository.PayCode] = queryResultList[0]["MCPYCD"].ToString().Trim();

                    ///////////////////////////////////////// Get Last Payment Date and Last Payment Amount ////////////////////////////

                    GetDataBaseValues("queryPolicyDetailsPaymentDetails");

                    if (queryResultList.Count() > 0)
                    {
                        data[KeyRepository.LastPaymentAmt] = queryResultList[0]["PPRMPD"].ToString();
                        data[KeyRepository.LastPaymentDate] = queryResultList[0]["PAPPMM"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["PAPPDD"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["PAPPYY"].ToString().PadLeft(2, '0');
                    }
                    else
                    {
                        data[KeyRepository.LastPaymentAmt] = "";
                        data[KeyRepository.LastPaymentDate] = "";
                    }

                    string insfullName;
                    string[] insfullNameSplit;
                    now = DateTime.Now;

                    /////////////////////////////////////////// Insured Name  //////////////////////////////////////////////////////////////////////

                    GetDataBaseValues("queryPolicyDetailsInsured");

                    insfullName = queryResultList[0]["CMNAME"].ToString();
                    if (!(insfullName.Contains("/")))
                        goto nextRecord;
                    insfullNameSplit = insfullName.Split('/');
                    data[KeyRepository.InsuredLastName] = insfullNameSplit[0];
                    data[KeyRepository.InsuredFirstName] = insfullNameSplit[1];
                    data[KeyRepository.InsuredMiddleName] = insfullNameSplit[2];
                    data[KeyRepository.InsuredFullName] = insfullNameSplit[1] + " " + insfullNameSplit[0];
                    if (insfullName.Length > 3)
                        data[KeyRepository.InsuredTitle] = insfullNameSplit[3];
                    else
                        data[KeyRepository.InsuredTitle] = "";

                    //insured dob
                    data[KeyRepository.InsuredDOBMonth] = queryResultList[0]["CMDOBM"].ToString();
                    data[KeyRepository.InsuredDOBDay] = queryResultList[0]["CMDOBD"].ToString();
                    data[KeyRepository.InsuredDOBYear] = queryResultList[0]["CMDOBY"].ToString();

                    if (queryResultList[0]["CMSXCD"].ToString().Trim() == "M")
                        data[KeyRepository.InsuredGender] = "Male";
                    else
                        data[KeyRepository.InsuredGender] = "Female";

                    nextRecord:
                    Console.WriteLine("");

                    /////////////////////////////////////////// Payor Name  //////////////////////////////////////////////////////////////////////
                    GetDataBaseValues("queryPolicyDetailsPayor");

                    i = 1;
                    while (i <= queryResultList.Count())
                    {
                        if (queryResultList[i - 1]["CYFRMD"] != "0")
                        {
                            if (i == 1)
                                Add1date = Convert.ToDateTime(queryResultList[0]["CYFRMM"].ToString().Trim() + "/" + queryResultList[0]["CYFRMD"].ToString().Trim() + "/" + DateTime.Parse(data[KeyRepository.LSPDate].Trim()).Year);
                            else
                                Add2date = Convert.ToDateTime(queryResultList[1]["CYFRMM"].ToString().Trim() + "/" + queryResultList[1]["CYFRMD"].ToString().Trim() + "/" + DateTime.Parse(data[KeyRepository.LSPDate].Trim()).Year);
                        }
                        i++;
                    }

                    //Determine the logic on which address to pick and set the variable to 1 or 2
                    //Get Current date
                    CurrentDate = Convert.ToDateTime(data[KeyRepository.LSPDate]);
                    snwbrdAddr = 0;
                    //Compare if date is greater than 1st date then take 2 record as the address
                    if (queryResultList.Count() > 1)
                    {
                        if ((CurrentDate > Add1date) && (CurrentDate > Add2date))
                        {
                            if (Add1date.Month > Add2date.Month)
                                snwbrdAddr = 0;
                            else
                                snwbrdAddr = 1;
                        }
                        else if ((CurrentDate > Add1date) && (CurrentDate < Add2date))
                            snwbrdAddr = 0;
                        else
                            snwbrdAddr = 1;
                    }
                    j = snwbrdAddr;

                    string payfullName;
                    string[] payfullNameSplit;

                    payfullName = queryResultList[j]["CMNAME"].ToString();
                    if (!(payfullName.Contains("/")))
                        goto End;
                    payfullNameSplit = payfullName.Split('/');
                    data[KeyRepository.PayorLastName] = payfullNameSplit[0];
                    data[KeyRepository.PayorFirstName] = payfullNameSplit[1];
                    data[KeyRepository.PayorAddressLine1] = queryResultList[j]["CYCAD1"].ToString().Trim();
                    data[KeyRepository.PayorAddressLine2] = queryResultList[j]["CYCAD2"].ToString().Trim();
                    data[KeyRepository.PayorCity] = queryResultList[j]["CYCCIT"].ToString().Trim();
                    data[KeyRepository.PayorState] = queryResultList[j]["CYCSTA"].ToString().Trim();
                    data[KeyRepository.PayorZip] = queryResultList[j]["CYCZIP"].ToString().Trim();
                    data[KeyRepository.PayorPhone] = queryResultList[j]["CYHPHE"].ToString().Trim();
                    data[KeyRepository.PayorCountry] = queryResultList[j]["CYCNRY"].ToString().Trim();

                End:
                    Console.WriteLine("");
                }
            }
            catch
            {
               // NYLDSelenium.ReportStepResult("QueryPolictyDetails", "Failed to QueryPolicyDetails" + data[KeyRepository.PolicyNumber], "Fail");
            }

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryAssociatedPolicies                                                                     ///////////
        ////// Description:  Method to Query all associated policies and segregate Viper and Payment             ///////////
        //////                eligible policies                                                                 ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void QueryAssociatedPolicies(string args = "")
        {
            string delim;

            CSWData.AssociatedPolicies = "";
            CSWData.VIPERPolicies = "";
            CSWData.PaymentEligPolicies = "";
            List<Dictionary<string, string>> associatedPolicies = new List<Dictionary<string, string>> { };
            CommonFunctions CF = new CommonFunctions(data);

            GetDataBaseValues("queryAssociatedPolicies");
            associatedPolicies = queryResultList;

            for (int i = 0; i < associatedPolicies.Count(); i++)
            {
                if (i != 0)
                {
                    delim = ";";
                }
                else
                {
                    delim = "";
                }
                Console.WriteLine("associatedPolicies: " + associatedPolicies[i]["MCCSTA"]);

                if (associatedPolicies[i]["MCCSTA"].ToString() != "D")
                {
                    if (args == "SummaryPage")
                    {
                        CSWData.AssociatedPolicies = CSWData.AssociatedPolicies + delim + associatedPolicies[i]["MCCSTA"].ToString().Trim() + " " + associatedPolicies[i]["CRCTL1"].ToString().Trim() + " " + associatedPolicies[i]["PDDESC"].ToString().Trim();
                    }
                    else if (args == "Beneficiaries" || args == "EditInsured")
                    {
                        CSWData.AssociatedPolicies = CSWData.AssociatedPolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " - " + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                    }
                    else
                        CSWData.AssociatedPolicies = CSWData.AssociatedPolicies + delim + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                }
                else
                    CSWData.DeathClaimPolicies = true;

                if ((associatedPolicies[i]["MCCSTA"].ToString() == "V") || (associatedPolicies[i]["MCCSTA"].ToString() == "I") || (associatedPolicies[i]["MCCSTA"].ToString() == "P") || (associatedPolicies[i]["MCCSTA"].ToString() == "E") || (associatedPolicies[i]["MCCSTA"].ToString() == "R"))
                {
                    if (associatedPolicies[i]["MCCSTA"].ToString().Trim() == "I")
                    {
                        data[KeyRepository.PolicyNumber] = associatedPolicies[i]["CRCTL1"].ToString().Trim();
                        QueryPolicyDetails();
                        CF.GetContractCardcolor();

                        //Capture payment eligible policies - Inforce and Lapse policies                                
                        if (data[KeyRepository.PolicyStatus] == "Inforce" || data[KeyRepository.PolicyStatus] == "Lapse" || data[KeyRepository.PolicyStatus] == "Cancelled")
                        {
                            CSWData.PaymentEligPolicies = CSWData.PaymentEligPolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " - " + associatedPolicies[i]["CRCTL1"].ToString().Trim();

                            if (data[KeyRepository.PolicyStatus] == "Lapse")
                            {
                                CSWData.LapsePolicies = CSWData.LapsePolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " " + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                            }
                        }
                        if (data[KeyRepository.PolicyStatus] == "Inforce" || associatedPolicies[i]["MCPYCD"].ToString() == "NN")
                        {
                            if (args == "Benes")
                            {
                                if (!(associatedPolicies[i]["PDDESC"].ToString().Trim().Contains("Young")))
                                    CSWData.VIPERPolicies = CSWData.VIPERPolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " - " + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                            }
                            else
                                CSWData.VIPERPolicies = CSWData.VIPERPolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " - " + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                        }
                    }
                    else
                    {
                        if (!((associatedPolicies[i]["PDDESC"].ToString().Trim().Contains("Young")) && (args == "Benes")))
                            CSWData.VIPERPolicies = CSWData.VIPERPolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " - " + associatedPolicies[i]["CRCTL1"].ToString().Trim();

                    }
                }
                if (associatedPolicies[i]["MCCSTA"].ToString() == "L")
                {
                    //Capture payment eligible policies - direct Lapse policies                         
                    CSWData.PaymentEligPolicies = CSWData.PaymentEligPolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " - " + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                    CSWData.LapsePolicies = CSWData.LapsePolicies + delim + associatedPolicies[i]["PDDESC"].ToString().Trim() + " " + associatedPolicies[i]["CRCTL1"].ToString().Trim();
                }

            }

            if ((CSWData.VIPERPolicies != null) && (CSWData.VIPERPolicies != ""))
                CSWData.VIPERPolicies = CSWData.VIPERPolicies.Trim(';');

            if ((CSWData.PaymentEligPolicies != null) && (CSWData.PaymentEligPolicies != ""))
                CSWData.PaymentEligPolicies = CSWData.PaymentEligPolicies.Trim(';');

            if ((CSWData.LapsePolicies != null) && (CSWData.LapsePolicies != ""))
                CSWData.LapsePolicies = CSWData.LapsePolicies.Trim(';');



        }
       
        public void QueryLSPNotes(string activity, string otherdetails = "")
        {
            string ntuser = "";
            bool gotrecord = false;
            string[] splitLSPDate;
            Console.WriteLine("LSPDate is " + data[KeyRepository.LSPDate]);
            splitLSPDate = data[KeyRepository.LSPDate].Split('-');

            string MdlMonth = splitLSPDate[1];
            string MdlDay = splitLSPDate[2];
            string MdlYear = splitLSPDate[0];
            string expLSPNotes = "";
            string actLSPNotes = "";
            string src;
            string time = "";

            if (data[KeyRepository.Environment].Trim() == "Stage")
                src = "CSCWEBS";
            else
                src = "CSCWEBQ";

            //Phrase expected LSP note
            switch (activity)
            {
                case "Reset Password":
                    ntuser = "EMAINT_Q";
                    expLSPNotes = "SWO sent email for password reset to : " + data[KeyRepository.UserName] + " at Email Address : " + data[KeyRepository.EmailId].ToLower() + ". Performed by : " + Environment.UserName;
                    break;

                case "Email Verification":
                    ntuser = "EMAINT_Q";
                    expLSPNotes = "SWO sent Account Verification Email to complete registration to : " + data[KeyRepository.UserName] + " at Email Address : " + data[KeyRepository.EmailId].ToLower() + ". Performed by : " + Environment.UserName.ToLower();
                    break;

                case "Deactivate User":
                    ntuser = "EMAINT_Q";
                    expLSPNotes = "Deactivated CSW account - unable to verify owner : " + data[KeyRepository.UserName] + " for Email Address : " + data[KeyRepository.EmailId].ToLower() + " for Contract Number : " + data[KeyRepository.PolicyNumber] + " Deactivation Reason : " + otherdetails + ". Performed by : " + Environment.UserName.ToLower();
                    if (expLSPNotes.Length > 225)
                        expLSPNotes = expLSPNotes.Substring(0, 225);
                    break;

                case "Edit Insured":
                    switch (otherdetails)
                    {
                        case "Namechange":
                        case "Allchange":
                            expLSPNotes = "INTERNET//Received Name Change";
                            break;

                        case "DOBchange":
                            expLSPNotes = "INTERNET//Received Date Of Birth Change";
                            break;

                        case "Genderchange":
                            expLSPNotes = "INTERNET//Received Gender Change";
                            break;
                    }
                    ntuser = src;
                    break;

                case "ContactInfo-UpdateAddress":
                    expLSPNotes = "Address Changed.";
                    ntuser = "CSW";
                    break;

                case "ContactInfo-UpdatePhone":
                    expLSPNotes = "Phone Changed.";
                    ntuser = "CSW";
                    break;

                case "Apply Cyber Fraud":
                    expLSPNotes = "SWO has Set Cyber Fraud Flag on : " + data[KeyRepository.PolicyNumber] + ". Additional notes: test Wilken";
                    break;

                case "Remove Cyber Fraud":
                    expLSPNotes = "SWO has Set Cyber Fraud Flag on : " + data[KeyRepository.PolicyNumber] + ". Additional notes: test Wilken";
                    break;

                case "Request Duplicate Contract":
                    break;

                case "Request Cash Value Letter":
                    break;

                case "Change Bene Information":
                    switch (otherdetails)
                    {
                        case "AddAddress":
                            expLSPNotes = "Address Added.";
                            break;

                        case "EditAddress":
                            expLSPNotes = "Address Changed.";
                            break;

                        case "AddPhone":
                        case "EditPhone":
                            expLSPNotes = "Phone Changed.";
                            break;

                        case "IRB":
                            expLSPNotes = "BN1 Beneficiaries updated.";
                            break;

                        case "PerStirpes":
                            expLSPNotes = "Per Stirpes designation was added to Client " + CSWData.BeneInfo[CSWData.ExpBeneIndex][13];
                            break;
                    }

                    ntuser = "CSW";
                    time = "AND NTNOTT >= '" + CSWData.EventTriggerTime.AddSeconds(-50).ToString("HHmmss") + "' and NTNOTT <= '" + CSWData.EventTriggerTime.AddMinutes(2).ToString("HHmmss") + "'";
                    break;

                case "My Payments":
                    switch (otherdetails)
                    {
                        case "Existing EFT":
                            expLSPNotes = "EFT Updated";
                            break;

                        case "New EFT":
                            expLSPNotes = "New EFT Requested";
                            break;

                        case "PayFreq Change M to Q":
                            expLSPNotes = "Payment mode changed from M to Q";
                            break;

                        case "PayFreq Change Q to M":
                            expLSPNotes = "Payment mode changed from Q to M";
                            break;

                        case "Cancel EFT":
                            expLSPNotes = "EFT Cancelled";
                            break;

                        case "Cancel Pending EFT":
                            expLSPNotes = "EFT in progress. Cancel sent to Premium Accounting";
                            break;
                    }
                    ntuser = "CSW";
                    break;

                case "ApplyCyberFraudProtection":
                    expLSPNotes = "CSW cyberfraud record inserted for UC 00" + data[KeyRepository.UclientIdOfPolicy] + ".";
                    ntuser = "CSW";
                    break;

                case "RemoveCyberFraudProtection":
                    expLSPNotes = "CSW cyberfraud record inserted for UC 00" + data[KeyRepository.UclientIdOfPolicy] + ".";
                    ntuser = "CSW";
                    break;

                case "CyberFraudRegistration":
                    expLSPNotes = "A customer service website user who is in cyber fraud protection status has attempted to Register. User Agent Data:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/5";
                    if (expLSPNotes.Length > 225)
                        expLSPNotes = expLSPNotes.Substring(0, 225);
                    ntuser = "CSW";
                    break;
                case "CyberFraudLogin":
                    expLSPNotes = "A customer service website user who is in cyber fraud protection status has attempted to Login. User Agent Data:Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.";
                    if (expLSPNotes.Length > 225)
                        expLSPNotes = expLSPNotes.Substring(0, 225);
                    ntuser = "CSW";
                    break;

                case "CyberFraudResetPassword":
                    expLSPNotes = "A customer service website user who is in cyber fraud protection status has attempted to Reset password. User Agent Data:Mozilla/5.0 (Windows NT 10.0;Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Sa";
                    if (expLSPNotes.Length > 225)
                        expLSPNotes = expLSPNotes.Substring(0, 225);
                    ntuser = "CSW";
                    break;

                case "Riders":
                    expLSPNotes = "Rider Application Submitted for Policy " + data[KeyRepository.PolicyNumber] + ", Control#";
                    ntuser = "CSW";
                    break;

                case "Exchange":
                    expLSPNotes = "WILL TERMINATE FOR EXCHANGE";
                    ntuser = "CSW";
                    break;
            }

            Thread.Sleep(20000);

            if (activity != "ChangePayor")
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Query LSP Notes " + activity + " " + otherdetails + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                string NTUSRSearch = "";

                //Build the query without the  timestamp
                if (activity == "SubmitRiderForm" || activity == "SubmitExchangeForm")
                    NTUSRSearch = "NTUSR = '" + ntuser + "'";

                string sQuery = "SELECT NTCMT1, NTCMT2, NTCMT3 from klsdat00.casnotfy  " +
                                "WHERE  NTPOLN = '" + data[KeyRepository.PolicyNumber] + "' and NTNOTM = '" + MdlMonth.TrimStart('0') + "' AND NTNOTD = '" + MdlDay + "' AND NTNOTY = '" + MdlYear + "'" + time + NTUSRSearch;

                Console.WriteLine("the query is  " + sQuery);

                queryList = NYLDDatabase.QueryDataBase(sQuery);

                if (queryList.Count > 0)
                {
                    foreach (var record in queryList)
                    {
                        actLSPNotes = record["NTCMT1"] + record["NTCMT2"] + record["NTCMT3"].Trim();
                        actLSPNotes = actLSPNotes.Trim();

                        if (activity == "Riders")
                        {
                            if (actLSPNotes.Trim().Contains(expLSPNotes.Trim()))
                            {
                                CSWData.TempVal = "";
                                gotrecord = true;
                                CSWData.TempVal = CSWData.TempVal + ";" + actLSPNotes.Trim().Split(' ').Last();
                            }
                        }
                        else
                        {
                            if (actLSPNotes.Trim().Contains(expLSPNotes.Trim()))
                            {
                                gotrecord = true;
                                break;
                            }
                        }
                    }

                    if (gotrecord == false)
                    {
                        NYLDSelenium.ReportStepResult("LSP Notes Query for " + activity, sQuery, "INFO", "no");

                        NYLDSelenium.ReportStepResult("Verify LSP Notes for " + activity, "Expected notes entry not logged: " + expLSPNotes + " Actual notes entry: " + actLSPNotes, "FAIL", "no");
                    }
                    else
                        NYLDSelenium.ReportStepResult("Verify LSP Notes for " + activity, "LSP notes verification by Query: " + sQuery + " was successful", "PASS", "no");
                }
                else
                {
                    NYLDSelenium.ReportStepResult("LSP Notes Query for " + activity, sQuery, "INFO", "no");
                    NYLDSelenium.ReportStepResult("Verify LSP Notes for " + activity, "LSP Notes entry " + expLSPNotes + " is not found", "FAIL", "no");
                }
            }
            else
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Query LSP Notes " + activity + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

                string payorClientID = "";

                //Get Client ID first
                string sQuery = "SELECT CRCLTN from KLSDAT00.CMSUSREL  where CRCTL1 = '" + data[KeyRepository.PolicyNumber] + "' and CRALPH = 'PAY'";

                Console.WriteLine("the query is  " + sQuery);

                queryList = NYLDDatabase.QueryDataBase(sQuery);

                if (queryList.Count > 0)
                {
                    payorClientID = queryList[0]["CRCLTN"].ToString().Trim();
                }

                //Query for Payor Entry
                sQuery = "select NTCMT1 from klsdat00.casnotfy where NTUSR = 'CSW' and NTPOLN = '" + data[KeyRepository.PolicyNumber] + "' and NTNOTM = '" + MdlMonth + "' AND NTNOTD = '" + MdlDay + "' AND NTNOTY = '" + MdlYear + "' AND NTNOTT >= '" + CSWData.EventTriggerTime.AddSeconds(-10).ToString("HHmmss") + "' and NTNOTT <= '" + CSWData.EventTriggerTime.AddMinutes(2).ToString("HHmmss") + "'";

                Console.WriteLine("the query is  " + sQuery);

                queryList = NYLDDatabase.QueryDataBase(sQuery);

                if (queryList.Count > 0)
                {
                    string CPlspNotes = "";
                    foreach (var record in queryList)
                    {
                        CPlspNotes += record["NTCMT1"].ToString().Trim() + ";";
                    }

                    if (CPlspNotes.Contains("Address Added.") || CPlspNotes.Contains("Phone Changed.") || CPlspNotes.Contains("PAY Payor relationship updated for client " + payorClientID + "."))
                        NYLDSelenium.ReportStepResult("LSP notes entry for Change payor", "Address, Phone and Payor change description lsp notes added successfully" + sQuery, "Pass", "no");
                    else
                        NYLDSelenium.ReportStepResult("LSP Notes for " + activity, "LSP Notes for " + activity + " is not logged. Query: " + sQuery, "FAIL", "no");
                }
            }
        }

        ///TODO:this method reference call - need to replace with new code 
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryCyberFraudAlerts                                                                       ///////////
        ////// Description:  Query if a cyber fraud alert entry exists for a policy number and fetch Client ID   ///////////        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public bool QueryCyberFraudAlerts()
        {
            //NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Query Cyber Fraud flag entry Table: KLSDAT00.LUCTCYBRS1 for policy: " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            // NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify CyberFraud Protection Flag for :" + args.Trim() + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            bool exists = false;
            //Build the query              
            GetDataBaseValues("queryCyberFraudEntry");
            if (queryResultList.Count() > 0)
                exists = true;

            //Build the query              
            GetDataBaseValues("queryCyberFraudDetails");
            if (queryResultList.Count() > 0)
            {
                data[KeyRepository.ClientIdOfPolicy] = queryResultList[0]["CRCLTN"].ToString().Trim();
                data[KeyRepository.UclientIdOfPolicy] = queryResultList[0]["UC_ID"].ToString().Trim();
            }
            else
                NYLDSelenium.ReportStepResult("Get client ID for the Policy number: " + data[KeyRepository.PolicyNumber], "Client ID could not be found for " + data[KeyRepository.PolicyNumber], "FAIL", "no");

            return exists;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryCyberFraudAlerts                                                                       ///////////
        ////// Description:  Query if a cyber fraud alert entry exists for a policy number and fetch Client ID   ///////////        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void QueryCyberFraudFlagAlerts(string args)
        {
            bool exists = false; string msg = "";
            //Build the query              
            GetDataBaseValues("queryCyberFraudEntry");
            if (queryResultList.Count() > 0)
            {
                exists = true;
                msg = "is found";
            }
            else
            {
                msg = "is not found";
            }

            if (args.Contains("Remove") && queryResultList.Count() == 0)
            {
                exists = true;
                msg = "is not found";
            }
            else if (args.Contains("Remove") && queryResultList.Count() == 0)
            {
                exists = false;
                msg = "is found";
            }

            //Build the query              
            GetDataBaseValues("queryCyberFraudDetails");
            if (queryResultList.Count() > 0)
            {
                data[KeyRepository.ClientIdOfPolicy] = queryResultList[0]["CRCLTN"].ToString().Trim();
                data[KeyRepository.UclientIdOfPolicy] = queryResultList[0]["UC_ID"].ToString().Trim();
            }

            if (exists)
                NYLDSelenium.ReportStepResult("Cyber fraud alert entry in table after " + args + " the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + msg
                    + " in the cyber fraud table", "PASS", "no", "no");
            else
                NYLDSelenium.ReportStepResult("Cyber fraud alert entry in table after " + args + " the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + msg
                    + " in the cyber fraud table", "FAIL", "no", "yes");
        }

        public void QueryCyberFraudDetails(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify CyberFraud Protection Flag for :" + args.Trim() + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            GetDataBaseValues("queryCyberFraudDetails");
            if (queryResultList.Count() > 0)
            {
                data[KeyRepository.ClientIdOfPolicy] = queryResultList[0]["CRCLTN"].ToString().Trim();
                data[KeyRepository.UclientIdOfPolicy] = queryResultList[0]["UC_ID"].ToString().Trim();
            }
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryCyberFraudAlerts                                                                       ///////////
        ////// Description:  Query if a cyber fraud history entry exists for a policy number                     ///////////        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public bool QueryCyberFraudHistory()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Query Cyber Fraud history Table: KLSDAT00.LUCTCYBHS1 for policy " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            bool HistoryLog = false;

            //Build the query              
            GetDataBaseValues("queryCyberFraudHistory");
            if (queryResultList.Count() > 0)
                HistoryLog = true;

            return HistoryLog;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryCyberFraudAlerts                                                                       ///////////
        ////// Description:  Query if a cyber fraud history entry exists for a policy number                     ///////////        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void QueryCyberFraudFlagHistory(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Query Cyber Fraud history Table: KLSDAT00.LUCTCYBHS1 for policy " + data[KeyRepository.PolicyNumber] + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            bool HistoryLog = false;

            //Build the query              
            GetDataBaseValues("queryCyberFraudHistory");
            if (queryResultList.Count() > 0)
                HistoryLog = true;

            if (args.Contains("Apply") && queryResultList.Count() == 0)
                HistoryLog = true;

            if (HistoryLog)
                NYLDSelenium.ReportStepResult("Cyber fraud alert entry in history table " + args + " the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is not logged in the cyber fraud history table after applying cyber fraud flag", "PASS", "no");
            else
                NYLDSelenium.ReportStepResult("Cyber fraud alert entry in history table " + args + "  the flag", "Entry for policy number " + data[KeyRepository.PolicyNumber] + " is logged in the cyber fraud history table for after applying cyber fraud flag", "FAIL", "yes");
        }
        public List<string> DataMine_New(string policyCondition)
        {
            NYLDSelenium.AddHeader("Pre-requisite:Query to get the contracts from LSP Database. Starting", "mainheader");         
           
            TestData testData = new TestData();
            string[] datamineConditions = testData.GetDataMineOptionsContent(policyCondition).Split(',');

            int startDate = 0;
            int endDate = 0;
            string condition1 = "";
            string condition2 = "";
            bool checkStatus = false;

            if (datamineConditions[0] != "")
            {
                startDate = Convert.ToInt16(datamineConditions[0].Trim());
                endDate = Convert.ToInt16(datamineConditions[1].Trim());
                condition1 = datamineConditions[2].Trim();
                condition2 = datamineConditions[3].Trim();
                checkStatus = (datamineConditions[4].Trim().ToLower() == "true");
            }

            switch (policyCondition)
            {
                case "MonthlyPayFreq":
                    NYLDSelenium.ReportStepResult("Verify test data availability for contract with Monthly only payment frequency", "Could not run the test as policy that meets the pre-requisite is not available. Contact Automation Team.", "FAIL", "no", "yes");
                    break;

                case "PendingEFT":
                    QueryPendingEFTContract();
                    break;

                case "RiderOffer":
                    data[KeyRepository.State] = condition1;
                    DatamineRider(data[KeyRepository.State]);
                    break;
                case "RiderContract":
                    UNICADatabase unica = new UNICADatabase(driver, data);
                    temp1 = unica.GetRiderstInfo();
                    break;
                case "Exchange":
                    UNICADatabase unica1 = new UNICADatabase(driver, data);
                    temp1 = unica1.GetExchangesInfo();
                    break;
                case "FISSync":
                    GetFISRecord();
                    break;
                case "WaiverofPremium":
                    GetWaiverofPremiumContracts();
                    break;
                case "ViewCoverage":
                    GetViewCoverage();
                    break;
                case "DuplicateRequest":
                    GetDuplicateRequestContract();
                    break;
                case "NoDuplicateRequest":
                    GetNoDuplicateRequestContract();
                    break;
                case "DeathClaimContract":
                    GetDataBaseValues("DeathClaimContract");
                    GetDeathClaimPolicies();
                    break;
                default:
                    policyCondition = policyCondition.Split('_')[0];
                    if (policyCondition.StartsWith("PTD"))
                        policyCondition = "PTD";
                    Console.WriteLine("Verify Following conditions to get the Contract: ", "\n Conditions: " + startDate + " " + endDate + " " + condition1 + " " + condition2 + " " + policyCondition + " " + checkStatus);
                    Datamine(startDate, endDate, condition1, condition2, policyCondition, checkStatus);
                    break;
            }
            NYLDSelenium.AddHeader("Pre-requisite:Query to get the contracts from LSP Database. Ended", "mainheader");
            return temp1;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: Datamine                                                                                    ///////////
        ////// Description:  Query and get a policy and register as Test data which meets prerequisite as        ///////////
        /////                passed in parameters from DB                                                        ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Datamine(int startday, int endday, string actype = "", string states = "", string DataMineOption = "", bool calcStatus = false)
        {
            string stclause = "";
            string acclause = "";
            bool RecordFound = false;
            string riderClause = "";
            string dQuery = "";
            StringBuilder policyNumbers = new StringBuilder();
            string enddate = "";
            string startdate = "";

            //Paid to date Effective date relation
            if (actype == "Existing" || actype == "ExistingNoPTD")
                acclause = " AND NOT(CNTR.MCEFFM = CNTR.MCPDTM AND CNTR.MCEFFD = CNTR.MCPDTD AND CNTR.MCEFFY = CNTR.MCPDTY) ";
            else if (actype != "")
                acclause = " AND CNTR.MCEFFM = CNTR.MCPDTM AND CNTR.MCEFFD = CNTR.MCPDTD AND CNTR.MCEFFY = CNTR.MCPDTY ";
            Console.WriteLine(DataMineOption);
            //Check policy to belong toa geography
            switch (states)
            {
                case "All":
                    stclause = "";
                    break;

                case "National":
                    stclause = "AND CNTR.MCISST NOT IN ('FL','VT','CA') ";
                    break;

                case "Exception":
                    stclause = "AND CNTR.MCISST IN ('FL','VT','CA') ";
                    break;

                case "InStates":
                    stclause = "AND CNTR.MCISST IN ('CA', 'FL', 'MD', 'NC', 'NJ', 'PA', 'PR') ";
                    break;

                case "NotInStates":
                    stclause = "AND CNTR.MCISST NOT IN ('CA', 'FL', 'MD', 'NC', 'NJ', 'PA', 'PR') ";
                    break;

                case "FuneralHome":
                    stclause = "AND CNTR.MCISST IN ('IN', 'MN', 'MI', 'IL', 'OK', 'NY') ";
                    break;

                default:
                    stclause = "";
                    break;
            }

            // for Registered user status verification and Delete user
            RestServices restcall = new RestServices(data);
            data[KeyRepository.AuthToken] = restcall.SubmitRestCall("GenerateOAuthToken");
            int countvalue = 0; int k = 0;
            //Loop with lower and upper range to query for policy
            //for (int i = startday; i <= endday; i++)
            for (int i = endday; i >= startday; i--)
            {             
                string ptdMonth = "";
                string ptdDay = "";
                string ptdYear = "";
                string ptd = "";
                string EFD = "CNTR.MCEFFY >= '2020' AND ";
                string payCode = "IN";
                string status = "AND CNTR.MCCSTA = 'I'";
                DateTime mdlDate = Convert.ToDateTime(data[KeyRepository.LSPDate]);
                //vary the parameter based on lower and upper limit
                if (DataMineOption == "PastDue")
                {
                    mdlDate = mdlDate.AddDays(-i);

                    ptdMonth = mdlDate.Month.ToString("00");
                    ptdDay = mdlDate.Day.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    ptd = "AND CNTR.MCPDTM = '" + ptdMonth + "' and CNTR.MCPDTD = '" + ptdDay + "' and CNTR.MCPDTY = '" + ptdYear;
                }
                if (DataMineOption == "DebitDate")
                {
                    ptdMonth = mdlDate.Month.ToString("00");
                    ptdDay = i.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    ptd = "AND CNTR.MCPDTD = '" + ptdDay;
                    EFD = "CNTR.MCEFFY > '2020' AND ";
                    //status = "AND CNTR.MCCSTA IN('V', 'I', 'P', 'E', 'R')"; // To test if works TC Failed
                    status = "AND CNTR.MCCSTA IN('I')";

                }
                if (DataMineOption == "InStates" || DataMineOption == "NotInStates")
                {
                    ptdMonth = mdlDate.Month.ToString("00");
                    ptdDay = i.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    ptd = "AND CNTR.MCPDTD = '" + ptdDay + "' and CNTR.MCPDTY = '" + ptdYear;
                }
                if (DataMineOption == "FuneralHome" || DataMineOption == "SuspendedUser")
                {
                    ptdMonth = i.ToString("00");
                    ptdDay = mdlDate.Day.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    ptd = "AND CNTR.MCPDTM = '" + ptdMonth + "' and CNTR.MCPDTY = '" + ptdYear;
                }
                if (DataMineOption == "EFTNotEligible")
                {
                    ptdYear = mdlDate.AddYears(i).Year.ToString("0000");

                    ptd = "AND CNTR.MCSUSP = 'N' AND CNTR.MCBLTM < CNTR.MCPDTM AND CNTR.MCPDTY = '" + ptdYear;
                    EFD = "CNTR.MCEFFY = '" + ptdYear + "' AND";
                }
                if (DataMineOption == "MonthlyPayFreq")
                {
                    if (i == 1)
                    {
                        ptd = "AND CNTR.MCPDTD != CNTR.MCEFFD and CNTR.MCPDTY = '" + Convert.ToDateTime(data[KeyRepository.LSPDate]).Year;
                        EFD = "CNTR.MCEFFY = '" + Convert.ToDateTime(data[KeyRepository.LSPDate]).Year + "' AND ";
                    }
                    else
                    {
                        ptd = "AND CNTR.MCPDTD != CNTR.MCEFFD and CNTR.MCPDTY = '" + Convert.ToDateTime(data[KeyRepository.LSPDate]).AddYears(-i).Year;
                        EFD = "CNTR.MCEFFY = '" + Convert.ToDateTime(data[KeyRepository.LSPDate]).AddYears(-i).Year + "' AND ";
                    }
                }
                if (DataMineOption == "DuplicateRequest" || DataMineOption == "NoDuplicateRequest")
                {
                    mdlDate = mdlDate.AddDays(-i);

                    ptdMonth = mdlDate.Month.ToString("00");
                    ptdDay = mdlDate.Day.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    ptd = "AND CNTR.MCPDTM = '" + ptdMonth + "' and CNTR.MCPDTD = '" + ptdDay + "' and CNTR.MCPDTY = '" + ptdYear;
                }
                if (DataMineOption == "PTD")
                {
                    if (actype == "ExistingNoPTD")
                        mdlDate = mdlDate.AddDays(i);
                    else
                        mdlDate = mdlDate.AddDays(-i);

                    ptdMonth = mdlDate.Month.ToString("00");
                    ptdDay = mdlDate.Day.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    int day = endday - i + 1;
                    ptd = "AND CNTR.MCPDTM = '" + ptdMonth + "' AND CNTR.MCPDTD = '" + ptdDay + "' AND CNTR.MCPDTY = '" + ptdYear;
                    EFD = "";
                }
                if (DataMineOption == "MonthlyGoodValue")
                {
                    ptdMonth = i.ToString("00");
                    ptd = "AND CNTR.MCPMOD = 'M";
                    status = "AND CNTR.MCCSTA = 'I'";
                    payCode = "NN";
                    EFD = "";
                }
                if (DataMineOption == "QuarterlyGoodValue")
                {
                    ptdMonth = i.ToString("00");
                    ptd = "AND CNTR.MCPMOD = 'Q";
                    status = "AND CNTR.MCCSTA = 'I'";
                    payCode = "NN";
                    EFD = "";
                }
                if (DataMineOption == "RiderContract")
                {
                    mdlDate = mdlDate.AddDays(-i);

                    ptdMonth = mdlDate.Month.ToString("00");
                    ptdDay = mdlDate.Day.ToString("00");
                    ptdYear = mdlDate.Year.ToString("0000");

                    ptd = "AND CNTR.MCPDTY >= '2020";
                    riderClause = "AND CB.FPOLNO = CNTR.MCCNTR AND CB.FBRCD !='0'";

                }
                if (DataMineOption == "OneRiderContract")
                {
                    dQuery = "Select distinct CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB where CB.FBRCD='1' and CNTR.MCCNTR = RT.CRCTL1 AND RN.CMCLTN = RT.CRCLTN AND RT.CRALPH = 'OW1' AND RT.CRCLTN = RA.CYCLTN AND RA.CYASEQ = RT.CRASEQ AND RN.CMNAME NOT LIKE '%[0-9]%' AND RN.CMNAME NOT LIKE '[0-9]%' AND RN.CMNAME NOT LIKE '%[0-9]' AND RN.CMNAME NOT LIKE '%-%' AND CNTR.MCPYCD = 'IN' AND CNTR.MCCO = 'AARP' and CNTR.MCPDTY >= '2023' AND CNTR.MCCSTA IN ('I') AND RN.CMDOBM != '0' AND CNTR.MCSUSP != 'Y' AND NOT(CNTR.MCEFFM = CNTR.MCPDTM AND CNTR.MCEFFD = CNTR.MCPDTD AND CNTR.MCEFFY = CNTR.MCPDTY) order by CNTR.MCPDTM fetch first 300 rows only";

                }
                if (DataMineOption.Contains("Payment:NoExistingEFT,QuarterlyElig-Monthly"))
                {
                    //Build the query
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF " +
                                            "From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB " +
                                                "where CNTR.MCCNTR = RT.CRCTL1 AND RN.CMCLTN = RT.CRCLTN AND RT.CRALPH = 'OW1' AND RT.CRCLTN = RA.CYCLTN AND RA.CYASEQ = RT.CRASEQ AND RN.CMNAME NOT LIKE '%[0-9]%' AND RN.CMNAME NOT LIKE '[0-9]%' AND RN.CMNAME NOT LIKE '%[0-9]' AND RN.CMNAME NOT LIKE '%-%' AND " + EFD + " CNTR.MCPYCD = '" + payCode + "' AND CNTR.MCCO = 'AARP' " + " " + status + " AND RN.CMDOBM != '0'  AND CNTR.MCSUSP != 'Y' " + stclause + acclause + riderClause + " fetch first 100 rows only";
                }
                if (DataMineOption == "NoEMailInLsp")
                {
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF FROM KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSCLNAD RA, KLSDAT00.CMSUSREL RT ,KLSDAT00.CASCNTRM CNTR LEFT JOIN KLSDAT00.AAEMALLP EM ON CNTR.MCCNTR = EM.ELCLNT WHERE RT.CRCLTN = RN.CMCLTN AND RT.CRCLTN = RA.CYCLTN AND RT.CRALPH = 'OW1'  AND RA.CYASEQ = RT.CRASEQ AND  CNTR.MCCNTR = RT.CRCTL1 AND EM.ELEMAL IS NULL AND EM.ELTIME IS NULL AND CNTR.MCCSTA = 'I'  FETCH FIRST 300 ROWS ONLY";
                }
                else if (DataMineOption == "NonViperContract365Days")
                {
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB where CNTR.MCCNTR = RT.CRCTL1 AND RN.CMCLTN = RT.CRCLTN AND RT.CRALPH = 'OW1' AND RT.CRCLTN = RA.CYCLTN AND RA.CYASEQ = RT.CRASEQ AND RN.CMNAME NOT LIKE '%[0-9]%' AND RN.CMNAME NOT LIKE '[0-9]%' AND RN.CMNAME NOT LIKE '%[0-9]' AND RN.CMNAME NOT LIKE '%-%' AND CNTR.MCPYCD = 'IN' AND CNTR.MCCO = 'AARP' and CNTR.MCPDTY <='2022' AND CNTR.MCCSTA IN ('L','N','S','X') AND RN.CMDOBM != '0' AND CNTR.MCSUSP != 'Y' AND NOT(CNTR.MCEFFM = CNTR.MCPDTM AND CNTR.MCEFFD = CNTR.MCPDTD AND CNTR.MCEFFY = CNTR.MCPDTY) order by CNTR.MCPDTM fetch first 300 rows only";
                }
                else if (DataMineOption == "NonViperContract")
                {
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB where CNTR.MCCNTR = RT.CRCTL1 AND RN.CMCLTN = RT.CRCLTN AND RT.CRALPH = 'OW1' AND RT.CRCLTN = RA.CYCLTN AND RA.CYASEQ = RT.CRASEQ AND RN.CMNAME NOT LIKE '%[0-9]%' AND RN.CMNAME NOT LIKE '[0-9]%' AND RN.CMNAME NOT LIKE '%[0-9]' AND RN.CMNAME NOT LIKE '%-%' AND CNTR.MCPYCD = 'IN' AND CNTR.MCCO = 'AARP' and CNTR.MCPDTY >='2022' AND CNTR.MCCSTA IN ('L','N','S','X') AND RN.CMDOBM != '0' AND CNTR.MCSUSP != 'Y' AND NOT(CNTR.MCEFFM = CNTR.MCPDTM AND CNTR.MCEFFD = CNTR.MCPDTD AND CNTR.MCEFFY = CNTR.MCPDTY) order by CNTR.MCPDTM fetch first 300 rows only";
                }
                else if (DataMineOption == "PermContract")
                {
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB where CB.FPLAN='PL10' and CNTR.MCCNTR = RT.CRCTL1 AND RN.CMCLTN = RT.CRCLTN AND RT.CRALPH = 'OW1' AND RT.CRCLTN = RA.CYCLTN AND RA.CYASEQ = RT.CRASEQ AND RN.CMNAME NOT LIKE '%[0-9]%' AND RN.CMNAME NOT LIKE '[0-9]%' AND RN.CMNAME NOT LIKE '%[0-9]' AND RN.CMNAME NOT LIKE '%-%' AND CNTR.MCPYCD = 'IN' AND CNTR.MCCO = 'AARP' and CNTR.MCPDTY >= '2022' AND CNTR.MCCSTA IN ('I') AND RN.CMDOBM != '0' AND CNTR.MCSUSP != 'Y' AND NOT(CNTR.MCEFFM = CNTR.MCPDTM AND CNTR.MCEFFD = CNTR.MCPDTD AND CNTR.MCEFFY = CNTR.MCPDTY) order by CNTR.MCPDTM fetch first 300 rows only";
                }
                else if (states == "FuneralHome")
                {
                    //Build the query regardless of the start and end day
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF " +
                            "From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB " +
                            "where CNTR.MCCNTR = RT.CRCTL1 " +
                            "AND RN.CMCLTN = RT.CRCLTN " +
                            "AND RT.CRALPH = 'OW1' " +
                            "AND RT.CRCLTN = RA.CYCLTN " +
                            "AND RA.CYASEQ = RT.CRASEQ " +
                            "AND RN.CMNAME NOT LIKE '%[0-9]%' " +
                            "AND RN.CMNAME NOT LIKE '[0-9]%' " +
                            "AND RN.CMNAME NOT LIKE '%[0-9]' " +
                            "AND RN.CMNAME NOT LIKE '%-%' " +
                            "AND CNTR.MCEFFY >= '2020' " +
                            "AND CNTR.MCPYCD = 'IN' " +
                            "AND CNTR.MCCO = 'AARP' " +
                            "AND CNTR.MCCSTA = 'I' " +
                            "AND RN.CMDOBM != '0' " +
                            "AND CNTR.MCSUSP != 'Y' " +
                            "AND CNTR.MCISST IN('IN', 'MN', 'MI', 'IL', 'OK', 'NY') " +
                            "fetch first 100 rows only";
                }
                else if (DataMineOption == "PTD")
                {
                    if (ptd == "")
                        ptd = "AND CNTR.MCPDTY >= '2020";

                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF " +
                               "FROM KLSDAT00.CASCNTRM CNTR JOIN KLSDAT00.CMSUSREL RT ON CNTR.MCCNTR = RT.CRCTL1 JOIN KLSDAT00.CMSCLNTM RN ON RT.CRCLTN = RN.CMCLTN " +
                               "WHERE MCCNTR = CRCTL1 AND CMCLTN = CRCLTN AND CMNAME NOT LIKE '%[0-9]%' AND CMNAME NOT LIKE '[0-9]%' AND CMNAME NOT LIKE '%[0-9]' AND CMNAME NOT LIKE '%-%' AND  " + EFD + " CNTR.MCCO = 'AARP' AND " +
                               "RT.CRALPH = 'OW1' " + ptd + "' " + status + " " + stclause + " fetch first 100 rows only";
                }
                else
                {
                    if (ptd == "")
                        ptd = "AND CNTR.MCPDTY >= '2020";

                    //Build the query
                    dQuery = "SELECT DISTINCT CNTR.MCCNTR, CNTR.MCCSTA, CNTR.MCPDTM, CNTR.MCPDTD, CNTR.MCPDTY, CNTR.MCEFFY, RN.CMNAME, RN.CMDOBM, RN.CMDOBD, RN.CMDOBY, RN.CMTIDF " +
                                            "From KLSDAT00.CASCNTRM CNTR, KLSDAT00.CMSCLNTM RN, KLSDAT00.CMSUSREL RT, KLSDAT00.CMSCLNAD RA, KLSDAT00.CASBENE CB " +
                                               "where CNTR.MCCNTR = RT.CRCTL1 AND RN.CMCLTN = RT.CRCLTN AND RT.CRALPH = 'OW1' AND RT.CRCLTN = RA.CYCLTN AND RA.CYASEQ = RT.CRASEQ AND RN.CMNAME NOT LIKE '%[0-9]%' AND RN.CMNAME NOT LIKE '[0-9]%' AND RN.CMNAME NOT LIKE '%[0-9]' AND RN.CMNAME NOT LIKE '%-%' AND " + EFD + " CNTR.MCPYCD = '" + payCode + "' AND CNTR.MCCO = 'AARP' " + ptd + "' " + status + " AND RN.CMDOBM != '0'  AND CNTR.MCSUSP != 'Y' " + stclause + acclause + riderClause + " fetch first 100 rows only";


                }
               
                enddate = (i == endday) ? $"{ptdMonth}/{ptdDay}/{ptdYear}" : "";
                startdate = (i == startday) ? $"{ptdMonth}/{ptdDay}/{ptdYear}" : "";

                string tempPolicy = "";
                Console.WriteLine("Query is " + dQuery);
                queryList = NYLDDatabase.QueryDataBase(dQuery);
                Console.WriteLine("LSP query result: Count of record " + queryList.Count + " for the day from LSP " + i);               
                if (queryList.Count > 0)
                {
                    foreach (var record in queryList)
                    {
                        data[KeyRepository.PolicyNumber] = record["MCCNTR"].ToString().Trim();
                        policyNumbers.Append(data[KeyRepository.PolicyNumber] + ";");
                        if (tempPolicy.Trim() != data[KeyRepository.PolicyNumber] && !string.IsNullOrEmpty(record["CMNAME"].ToString().Trim()) && record["CMDOBM"].ToString().Trim() != "0" && record["CMDOBD"].ToString().Trim() != "0" && record["CMDOBY"].ToString().Trim() != "0" && record["CMTIDF"].ToString().Trim().Length >= 9)
                        {
                            if (!string.IsNullOrEmpty(data[KeyRepository.PolicyNumber]))
                            {
                                k++;
                                Console.WriteLine("Verify the:" + k + " record");
                            }
                            //checking the bad contract ;
                            if (!BadContractCheck(DataMineOption, calcStatus))
                            {
                                LoginPage LP = new LoginPage(driver, data);
                                RecordFound = GetUserStatus(DataMineOption);
                                if (RecordFound)
                                {
                                  
                                    driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                                    RecordFound = true;
                                    goto breakLoop;
                                }
                                tempPolicy = data[KeyRepository.PolicyNumber];
                            }
                            else
                            {
                                countvalue = k;
                                Console.WriteLine("################## NYLD FRAMEWORK LOG ############## :: " + GetSettor.failCounter);
                                Console.WriteLine("The policy status is: " + data[KeyRepository.PolicyStatus] + "and the policy type is :" + data[KeyRepository.PolicyNumber]);
                            }
                        }                       
                    }

                breakLoop:
                    if (RecordFound)
                        goto RegPage;

                }
                if (i == startday && !RecordFound)
                    goto RegPage;
            }

            RegPage:
            if (RecordFound)
            {
                TestPreRequisites testRequsite = new TestPreRequisites(driver, data);

                //Registration
                if (data[KeyRepository.SubFuntionality] != "Registration")
                    RegisterDatamineUser();

                NYLDSelenium.ReportStepResult("DataMine successful", "Able to find the record that meets the Test criteria: " + DataMineOption + "<br>Query:<br>" + dQuery, "PASS", "no", "no");
                //check payment prerequisite
                QueryPaymentDetails();
                if (data[KeyRepository.PayCode] == "ET" && (DataMineOption != "NoEMailInLsp"))
                    testRequsite.SetPaymentInformation("NoExistingEFT");
            }
            else
            {
                if (countvalue == 0)
                {
                    NYLDSelenium.ReportStepResult("Contract List : ", policyNumbers.ToString() , "INFO", "no");
                    NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the record that meets the Test criteria: " + DataMineOption 
                        + "<br>The Query executed between the dates as follows startdate:" + startdate + "Enddate: "+ enddate +"<br>" +"<br>Last PTD date Query sample:<br>" + dQuery, "FAIL", "no", "yes");
                }
                else
                {
                    NYLDSelenium.ReportStepResult("Contract List : ", policyNumbers.ToString(), "INFO", "no");
                    NYLDSelenium.ReportStepResult("DataMine Successful, But finded records not meets the test criteria to proceed further", "Able to find the records but does are not meets the Test criteria: " + DataMineOption 
                        + "<br>The Query executed between the dates as follows startdate:" + startdate + "Enddate: " + enddate + "<br>" + "<br>Last PTD date Query sample:<br>" + dQuery, "FAIL", "no", "yes");
                }
            }            
        }

        public void UpdateMCUSR4()
        {
            //ValidateMCUSRUpdate/
            string dQuery = "UPDATE KLSDAT00.CASCNTRM " +
                "SET MCUSR4 = 'DTH' " +
                "WHERE MCCNTR = '" + data[KeyRepository.PolicyNumber] + "'";
            QueryDataBase(dQuery);
        }

        public void RegisterDatamineUser()
        {
            QueryPolicyDetails("");
            TestData testData = new TestData();
            data[KeyRepository.NYLApplicationRole] = "Owner";
            //Need to add for lite owner role
            //if ()
            //    data[KeyRepository.NYLApplicationRole] = "Lite Owner";
            testData.CreateAccount(driver,data, 0);
        }

        public void GetFISRecord()
        {
            string dQuery = "SELECT * FROM kLSDAT00.AAEMALLP AAEMALLP INNER JOIN kLSDAT00.CMSUSREL CMSUSREL ON AAEMALLP.ELCLNT = CMSUSREL.CRCLTN INNER JOIN kLSDAT00.CASCNTRM CASCNTRM ON CMSUSREL.CRCTL1 = CASCNTRM.MCCNTR WHERE CMSUSREL.CRALPH = 'OW1' AND CASCNTRM.MCCSTA = 'I' AND CASCNTRM.MCPYCD = 'IN' AND MCCO= 'AARP'";
            QuerryExecute(dQuery, 7);
        }

        public void GetViewCoverage()
        {
            string dQuery = "select count(ABAHCD) as eligible, ABACCD, ABAHCD, ABAACD from rvilib.rvabrep rvabrep JOIN kLSDAT00.CASCNTRM CASCNTRM ON CASCNTRM.MCCNTR = rvabrep.ABACCD AND CASCNTRM.MCCSTA = 'I'  JOIN kLSDAT00.CMSUSREL CMSUSREL ON CASCNTRM.MCCNTR = CMSUSREL.CRCTL1 AND CMSUSREL.CRALPH = 'OW1' where ABAHCD = 'WELKIT' and ABAACD = 'H' Group by ABACCD, ABAHCD, ABAACD,MCAPPY Having count(ABAHCD) = 1 and MCAPPY >='2020' fetch first 300 rows only ";
            QuerryExecute(dQuery, 1);
        }

        public void GetDuplicateRequestContract()
        {
            string startdate = DateTime.ParseExact(data[KeyRepository.LSPDate].Replace("-", "/"), @"yyyy/MM/dd", new CultureInfo("en-US")).AddDays(-30).ToString("yyyyMMdd");
            string enddate = data[KeyRepository.LSPDate].Replace("-", "");
            string dQuery = "SELECT  SUBSTRING(TTPOLN, 1, 9) AS TTPOLN  FROM KLSDAT00.AACTTP1 WHERE TTLCDT between '" + startdate + "' and '" + enddate + "' order by TTLCDT desc fetch first 300 rows only";
            QuerryExecute(dQuery, 0, "DuplicateRequest");
        }
        public void GetNoDuplicateRequestContract()
        {
            string startdate = DateTime.ParseExact(data[KeyRepository.LSPDate].Replace("-", "/"), @"yyyy/MM/dd", new CultureInfo("en-US")).AddDays(-30).ToString("yyyyMMdd");
            string enddate = data[KeyRepository.LSPDate].Replace("-", "");
            string dQuery = "select CRCTL1 from KLSDAT00.cmsclntm cmsclntm inner join KLSDAT00.cmsusrel cmsusrel on cmsclntm.cmcltn = cmsusrel.crcltn inner join KLSDAT00.cascntrm cascntrm on cascntrm.mccntr = cmsusrel.crctl1 where mccsta = 'I' and mcsusp != 'Y'and mcco = 'AARP' and CRALPH = 'OW1' and REPLACE(CONCAT(MCPDTY,concat(',',concat((CASE  WHEN LENGTH(Trim(MCPDTM))=2 then concat('',concat(MCPDTM,'')) WHEN LENGTH(Trim(MCPDTM))= 1 then concat('0',concat(MCPDTM, '')) END),concat(',', (CASE  WHEN LENGTH(Trim(MCPDTD)) = 2 then concat('', concat(MCPDTD, '')) WHEN LENGTH(Trim(MCPDTD)) = 1 then concat('0', concat(MCPDTD, '')) END))))),',','') between '" + startdate + "' and '" + enddate + "' and CRCTL1 NOT IN(SELECT SUBSTRING(TTPOLN, 1, 9) AS TTPOLN FROM KLSDAT00.AACTTP1)  order by MCPDTM desc,MCPDTD desc fetch first 100 rows only";
            QuerryExecute(dQuery, 0, "NoDuplicateRequest");
        }

        ////////////////// Death Claim policy //////////////////
        public void GetDeathClaimPolicies()
        {
            //Fetch required results
            if (queryResultList.Count() != 0)
            {
                data[KeyRepository.PolicyNumber] = queryResultList[0]["MCCNTR"].ToString().Trim();
                QueryPolicyDetails("");
            }
        }
        public void GetWaiverofPremiumContracts()
        {
            string dQuery = "SELECT MCCO,MCPDTD, MCCSTA, MCGBNO, CRALPH, CMCLTN, MCPDTM,MCCNTR, MCPDTY, MCPYCD, CMNAME, CMDOBM, CMDOBD, CMDOBY, CMTIDF, ELEMAL" +
            " FROM KLSDAT00.CASCNTRM CASCNTRM" +
            " JOIN KLSDAT00.CMSUSREL CMSUSREL ON CASCNTRM.MCCNTR = CMSUSREL.CRCTL1" +
            " JOIN KLSDAT00.CMSCLNTM CMSCLNTM ON CMSCLNTM.CMCLTN = CMSUSREL.CRCLTN" +
            " JOIN KLSDAT00.AAEMALLP AAEMALLP ON CMSUSREL.CRCLTN = AAEMALLP.ELCLNT WHERE" +
            " CASCNTRM.MCCSTA = 'I'" +
            " AND CASCNTRM.MCCO = 'AARP'" +
            " AND CASCNTRM.MCPYCD = 'WP'" +
            " AND CMSUSREL.CRALPH = 'OW1' " +
            "order by cmsclntm.cmcltn fetch first 100 rows only";
            QuerryExecute(dQuery, 7);
        }
        public bool GetViewByCoverageEligible()
        {
            string dQuery = "select count(ABAHCD) as eligible, ABACCD, ABAHCD, ABAACD from rvilib.rvabrep rvabrep JOIN kLSDAT00.CASCNTRM CASCNTRM ON CASCNTRM.MCCNTR = rvabrep.ABACCD AND CASCNTRM.MCCSTA = 'I' JOIN kLSDAT00.CMSUSREL CMSUSREL ON CASCNTRM.MCCNTR = CMSUSREL.CRCTL1 AND CMSUSREL.CRALPH = 'OW1' where ABAHCD = 'WELKIT' and ABAACD = 'H' Group by ABACCD, ABAHCD, ABAACD,MCAPPY Having count(ABAHCD) = 1 and ABACCD = '" + data[KeyRepository.PolicyNumber] + "'";
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            RecordFound = false;

            queryList = NYLDDatabase.QueryDataBase(dQuery);

            if (queryList.Count > 0)
            {
                foreach (var record in queryList)
                {
                    data[KeyRepository.PolicyNumber] = record["ABACCD"].ToString().Trim();
                    Console.WriteLine(data[KeyRepository.PolicyNumber]);
                    QueryPolicyDetails();
                    CF.GetContractCardcolor();
                    if (data[KeyRepository.PolicyStatus] == "Inforce")
                    {
                        RecordFound = true;
                        if (RecordFound)
                            NYLDSelenium.ReportStepResult("DataMine Successful Query", dQuery, "INFO", "no");
                    }
                }
            }
            return RecordFound;
        }

        //Method helps to verify the status of profilemantenace
        public bool GetUserStatus(string DatamineOption)
        {
            RecordFound = false;
            //Local
            return ValidContract(DatamineOption);
        }

        /// <summary>
        /// Method helps to skip the contracts which is already register
        /// </summary>
        /// <param name="arg"></param>
        /// <returns></returns>
        public bool ValidContract([Optional] string arg)
        {
            CommonFunctions CF = new CommonFunctions(data);
            RestServices restServices = new RestServices(data);
            bool RecordFound = false; bool isDigitNSymbolPresent = false;
            TestData testData = new TestData();

            QueryPolicyNumber();
            GetDataBaseValues("queryPolicyDetailsEffectiveDate");
            //If the contract is not paid to date then skip the contract
            data.TryGetValue(KeyRepository.PaidToDate, out string PaidToDate);
            if (!string.IsNullOrEmpty(PaidToDate))
            {
                CF.GetContractCardcolor();

                bool isNotPTD = arg != "PTD";
                bool isCancelled = data[KeyRepository.PolicyStatus] == "Cancelled";
                bool isInvalidPolicyNumber = data[KeyRepository.PolicyNumber] == null || !data[KeyRepository.PolicyNumber].StartsWith("A");

                if ((isNotPTD && isCancelled) || isInvalidPolicyNumber)
                { RecordFound = false; }
                else
                {
                    //verify if the special characters present then skip the contract
                    isDigitNSymbolPresent = Regex.IsMatch(data[KeyRepository.LastName].Trim(), @"^[a-zA-Z]+$");

                    if (isDigitNSymbolPresent == true)
                    {
                        string accountStatus = testData.VerifyAccountStatus(data);
                        if (accountStatus == "Active")
                        {
                            restServices.SubmitOAuth2RestCall("SearchUser", "nylid");
                            string status = restServices.SubmitOAuth2RestCall("DeleteUser", "success");
                            accountStatus = testData.VerifyAccountStatus(data);                            
                            if (status == "True" && accountStatus != "Active")
                            {
                                RecordFound = true;
                            }
                        }
                        else
                        {
                            RecordFound = true;
                        }
                        GetDataBaseValues("queryEmail");
                        if (queryResultList.Count != 0)
                        {
                            data[KeyRepository.EmailId] = queryResultList[0]["ELEMAL"].ToString().Trim();
                            if (queryResultList[0]["ELEMAL"].ToString().Trim().Contains("Web@service"))
                                RecordFound = false;
                        }
                    }
                }
            }
            else
                RecordFound = false;

            Console.WriteLine("Valid Contract " + RecordFound);
            return RecordFound;
        }       

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: pendingPayment                                                                              ///////////
        ////// Description:  Check if policy has pending payment to be processed                                 ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool PendingPayment()
        {
            bool pendingPaymentExist = false;

            //Build the query
            GetDataBaseValues("pendingPayment");

            if (queryResultList.Count() > 0)
                pendingPaymentExist = true;
            else
                pendingPaymentExist = false;

            return pendingPaymentExist;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: Waiver of Premium                                                                              ///////////
        ////// Description:  Check if policy has Waiver of Premium to be processed                                 ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool GetWaiverofPremium()
        {
            bool WaiverofPremiumExist = false;

            //Build the query
            GetDataBaseValues("WaiverofPremium");

            if (queryResultList.Count() > 0)
                WaiverofPremiumExist = true;
            else
                WaiverofPremiumExist = false;

            return WaiverofPremiumExist;
        }

        /// <summary>
        /// Method to verfy EFT  payment information update
        /// </summary>
        /// <param name="args"></param>
        public void QueryAutoPremPayUpdate(string args)
        {           
            string query = "";

            // Build the query
            if (args.Trim() == "PCM")
            {
                string[] splitLSPDate = data[KeyRepository.LSPDate].Split('-');
                string MdlMonth = splitLSPDate[1];
                string MdlDay = splitLSPDate[2];
                string MdlYear = splitLSPDate[0];
                query = "select CECO, CETYPE, CEUSER, CEPOLN from KLSDAT00.CCSEXTR "
                            + "where CELTRM = '" + MdlMonth + "' and CELTRD = '" + MdlDay + "' and CELTRY = '" + MdlYear + "' and CEUSER = 'CSW' and CECO = 'AARP' and CEPOLN = '" + data[KeyRepository.PolicyNumber] + "'";
            }
            else if (args.Trim() == "ES")
            {
                query = "select POCOMP, POSIGTYPE, POPOLICY from KLSDAT00.LPOPTPRCS1 "
                                + "where POADDUSER = 'CSW' and POPOLICY = '" + data[KeyRepository.PolicyNumber] + "'";
            }

            Console.WriteLine("the query is  " + query);
            List<Dictionary<string, string>> queryList = NYLDDatabase.QueryDataBase(query);
            Thread.Sleep(5000);
            if (queryList.Count > 0)
            {
                foreach (var record in queryList)
                {                    
                    string actNote = "";
                    if (args.Trim() == "PCM")
                    {
                        actNote = record["CETYPE"].ToString().Trim();
                    }
                    else if (args.Trim() == "ES")
                    {
                        actNote = record["POSIGTYPE"].ToString().Trim();
                    }

                    if (args.Trim() == actNote)
                    {
                        NYLDSelenium.ReportStepResult("Verify " + args + " Note entry", args + " note entry of the Automatic premium payment made for the policy: " + data[KeyRepository.PolicyNumber], "PASS", "no");
                    }
                    else
                    {
                        NYLDSelenium.ReportStepResult("Query for " + args, query, "INFO");
                        NYLDSelenium.ReportStepResult("Verify " + args + " Note entry", args + " note entry of the Automatic premium payment made for the policy: " + data[KeyRepository.PolicyNumber] + " not Listed", "FAIL", "no");
                    }
                }
            }
            else
            {
                NYLDSelenium.ReportStepResult("Query for " + args, query, "INFO");
                NYLDSelenium.ReportStepResult("Verify " + args + " Note entry", args + " note entry of the Automatic premium payment made for the policy: " + data[KeyRepository.PolicyNumber] + " not Listed", "FAIL", "no");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: DatamineRider                                                                                    ///////////
        ////// Description:  Query and get a policy and register as Test data which meets prerequisite as        ///////////
        /////                passed in parameters from DB                                                        ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DatamineRider(string state = "")
        {
            stateRiderQuery = "";

            //queryPendingEFTContract("queryRiderContract");

            if (state != "" && state != null)
                stateRiderQuery = " CERTIFICATE.Issue_State =  '" + state + "' OR CLIENT.State = '" + state + "' AND";


            LoginPage LP = new LoginPage(driver, data);
            UserRegistrationDriver REG = new UserRegistrationDriver(driver, data);
            List<List<string>> ContractsToRegister = new List<List<string>> { };

            GetDataBaseValues("queryRiderOffer");


            driver.Navigate().GoToUrl(data[KeyRepository.URL]);
            LP.LoginPageLoad();
            NYLDSelenium.PageLoad("CSW Login", LP.LoginHeader, "no", "no");

            if (RecordFound)
            {
                QueryPolicyDetails("");
                REG.RegisterUser("");
                NYLDSelenium.ReportStepResult("DataMine successful", "Able to find the rider contract which is in Inforce status for the state: " + data[KeyRepository.State], "PASS", "no", "no");
            }
            else
            {
                NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the rider contract which is in Inforce status for the state: " + data[KeyRepository.State], "FAIL", "no", "yes");
            }

        }

        public void QueryPendingEFTContract(string args = "")
        {
            LoginPage LP = new LoginPage(driver, data);
            UserRegistrationDriver REG = new UserRegistrationDriver(driver, data);
            List<Dictionary<string, string>> ContractsToRegister = new List<Dictionary<string, string>> { };

            //bool RecordFound = false;
            bool checkStatus = false;
            if (args != "")
            {
                state = data[KeyRepository.State];
                GetDataBaseValues("queryRiderContract");
                checkStatus = true;

                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                LP.LoginPageLoad();
                NYLDSelenium.PageLoad("CSW Login", LP.LoginHeader, "no", "no");
            }
            else
            {
                GetDataBaseValues("queryPendingEFTContract");

                ContractsToRegister = queryResultList;
                for (int i = 0; i < ContractsToRegister.Count(); i++)
                {
                    data[KeyRepository.PolicyNumber] = ContractsToRegister[i]["PPPOLN"].ToString().Trim();
                    if (!BadContractCheck(args, checkStatus))
                    {
                        Thread.Sleep(10000);
                        //Local
                        if (ValidContract())
                        {
                            RecordFound = true;
                            goto breakLoop;
                        }
                    }
                }

            }


        breakLoop:
            if (RecordFound)
            {
                QueryPolicyDetails("");
                REG.RegisterUser("");
                NYLDSelenium.ReportStepResult("DataMine successful", "Able to find the record that meets the Test criteria: " + data[KeyRepository.State], "PASS", "no", "no");
            }
            else
            {
                if (args == "queryRiderContract")
                    NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the rider contract which is in Inforce status for the state: " + data[KeyRepository.State], "FAIL", "no", "yes");
                else
                    NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the record that meets the Test criteria: " + data[KeyRepository.State], "FAIL", "no", "yes");
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: badContractCheck                                                                            ///////////
        ////// Description:  Method to check, if a policy from data mine query meets pre requisite               ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool BadContractCheck(string args = "", bool calcStatus = false)
        {
            CommonFunctions CF = new CommonFunctions(data);
            TestData testdata = new TestData();
            bool BadContract = false;
            string tempPolicyNumber = data[KeyRepository.PolicyNumber];
            double dayPastPTD = 0;
            List<string> skipcontract = new List<string>();
            skipcontract = new List<string>() { testdata.GetInputData("SkipContract") };
            string badcontractmsg = "";
            try
            {
                QueryAssociatedPolicies();
                data[KeyRepository.PolicyNumber] = tempPolicyNumber;
                QueryPolicyDetails();
                QueryPaymentDetails();
                CF.GetContractCardcolor();

                //multi contract check --  Identified bad Contract List in Datasheet
                if (skipcontract.Where(s => s.Contains(data[KeyRepository.PolicyNumber])).FirstOrDefault() != null)
                {
                    BadContract = true;
                    badcontractmsg = "Badcontract found in skip in list";
                }

                //if contract has Lastname Testing
                if ((data[KeyRepository.LastName]).Contains("Testing"))
                {
                    BadContract = true;
                    badcontractmsg = "Badcontract found in skip in list";
                }
                //check the days past from pay to date            
                dayPastPTD = (Convert.ToDateTime(data[KeyRepository.PaysToDate]) - Convert.ToDateTime(data[KeyRepository.PaidToDate])).TotalDays;

                if (!BadContract)
                {
                    if (args == "DuplicateRequest" || args == "NoDuplicateRequest")
                    {
                        if (CSWData.AssociatedPolicies.Split(';').Count() > 1)
                            BadContract = true;

                        else if (args == "DuplicateRequest")
                        {
                            if (GetDupContractTTP1Entry() != true)
                                BadContract = true;
                        }
                        else if (args == "NoDuplicateRequest")
                        {
                            if (GetDupContractTTP1Entry() == true)
                                BadContract = true;
                        }
                    }
                    else if (CSWData.AssociatedPolicies.Split(';').Count() > 1 || QueryCyberFraudAlerts())
                    {
                        BadContract = true;
                        badcontractmsg = "Badcontract found in AssociatedPolicies";
                    }
                    else if (calcStatus)
                    {
                        if (args == "PastDue" && data[KeyRepository.PolicyStatus] == "Cancelled")
                            BadContract = true;
                        else if (args == "queryRiderContract" && (data[KeyRepository.PolicyStatus] == "Cancelled" || data[KeyRepository.PolicyStatus] == "Lapse"))
                            BadContract = true;
                        else if (args != "PastDue" && args != "queryRiderContract" && (data[KeyRepository.PolicyStatus] == "Cancelled" || data[KeyRepository.PolicyStatus] == "Lapse"))
                            BadContract = true;

                        badcontractmsg = "Badcontract found in " + calcStatus;
                    }
                    else
                    {
                        if (args == "MonthlyPayFreq" && !BadContract)
                        {
                            double daysPastEFD = (Convert.ToDateTime(data[KeyRepository.PaidToDate]) - Convert.ToDateTime(data[KeyRepository.EffectiveDate])).TotalDays;
                            if (daysPastEFD == 0 || daysPastEFD == 30 || daysPastEFD == 180 || daysPastEFD == 270)
                                BadContract = true;
                        }
                        else if (data[KeyRepository.LastName].ToLower().Contains("donot") || data[KeyRepository.FirstName].ToLower().Contains("donot"))
                            BadContract = true;

                        badcontractmsg = "Badcontract found in Verify daysPastEFD";
                    }
                    //Bad contracts skip
                }
            }
            catch
            {
                BadContract = false;
            }
            Console.WriteLine(badcontractmsg + ": " + data[KeyRepository.PolicyNumber] + " and date difference " + dayPastPTD);
            return BadContract;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryPaymentDetails                                                                         ///////////
        ////// Description:  Query payment information and its associated bank information of the policy         ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool QueryPaymentDetails()
        {
            bool valid = false;
            //Build the query
            GetDataBaseValues("queryPaymentDetails");

            data[KeyRepository.PolicyStatus] = queryResultList[0]["MCCSTA"].ToString().Trim();
            data[KeyRepository.CurrentPaymentFrequency] = queryResultList[0]["MCPMOD"].ToString().Trim();
            data[KeyRepository.PayCode] = queryResultList[0]["MCPYCD"].ToString().Trim();
            data[KeyRepository.EffectiveDate] = queryResultList[0]["MCEFFM"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["MCEFFD"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["MCEFFY"].ToString().PadLeft(2, '0');
            data[KeyRepository.PaidToDate] = queryResultList[0]["MCPDTM"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["MCPDTD"].ToString().PadLeft(2, '0') + "/" + queryResultList[0]["MCPDTY"].ToString().PadLeft(2, '0');
            data[KeyRepository.PaymentDate] = queryResultList[0]["MCPDTD"].ToString();
            data[KeyRepository.QuarterlyPremium] = string.Format("{0:0.00}", Math.Round((Convert.ToDouble(queryResultList[0]["MCPRMA"].ToString()) / 4), 2, MidpointRounding.AwayFromZero));
            data[KeyRepository.MonthlyPremium] = string.Format("{0:0.00}", Math.Round((((Convert.ToDouble(queryResultList[0]["MCPRMA"].ToString()) / 12)) + 1), 2, MidpointRounding.AwayFromZero));
            data[KeyRepository.Premium] = queryResultList[0]["MCPRMM"].ToString();
            data[KeyRepository.PaysToDate] = queryResultList[0]["MCBLTM"].ToString() + "/" + queryResultList[0]["MCBLTD"].ToString() + "/" + queryResultList[0]["MCBLTY"].ToString();

            //Query to extract Bank details -> routing number, Account number, Paremium dues and history

            GetDataBaseValues("queryPaymentDetailsBankAccount");

            if (queryResultList.Count() != 0)
            {
                data[KeyRepository.RoutingNumber] = queryResultList[0]["ACBANK"].ToString().Trim();
                data[KeyRepository.AccountNumber] = queryResultList[0]["ACACCT"].ToString().Trim();
                valid = true;
            }

            return valid;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryPaymentDetails                                                                         ///////////
        ////// Description:  Query -Updated the payment frequency information         ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void ChangeFrequencyPaymentDetails(string Freqchange)
        {
            //Build the query
            GetDataBaseValues("queryPaymentDetails");
            data[KeyRepository.CurrentPaymentFrequency] = queryResultList[0]["MCPMOD"].ToString().Trim();

            if (data[KeyRepository.CurrentPaymentFrequency] == Freqchange)
                NYLDSelenium.ReportStepResult("Payment Frequency change confirmation", "Payment Frequency change sucessfully to " + Freqchange, "PASS");
            else
                NYLDSelenium.ReportStepResult("Payment Frequency change confirmation", "Payment Frequency change not sucessfully to " + Freqchange, "FAIL", "always");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getDupContractTTP1Entry                                                                     ///////////
        ////// Description:  query TTP1 table from Policy Number                                                 ///////////        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
        public bool GetDupContractTTP1Entry()
        {
            bool entryFound = false;

            string dd, mm, yy;
            DateTime mdlDate = Convert.ToDateTime(data[KeyRepository.LSPDate]);
            DateTime ttpDate;

            //Build the query
            GetDataBaseValues("getDupContractTTP1Entry");

            if (queryResultList.Count > 0)
            {
                if (queryResultList[0]["TTLCDT"].ToString().Length == 8)
                {
                    string result = DateTime.ParseExact(queryResultList[0]["TTLCDT"].ToString(), "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture).ToString("yyyy-MM-dd");
                    yy = queryResultList[0]["TTLCDT"].ToString().Substring(0, 4);
                    mm = queryResultList[0]["TTLCDT"].ToString().Substring(4, 2);
                    dd = queryResultList[0]["TTLCDT"].ToString().Substring(6, 2);
                    ttpDate = Convert.ToDateTime(result);

                    if ((mdlDate.Date - ttpDate.Date).Days <= 30)
                        entryFound = true;
                }
            }

            return entryFound;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryQuarterlyPaymntElig                                                                    ///////////
        ////// Description:  Check the policy is eligible for Quarterly payment frequency                        ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void QueryQuarterlyPaymntElig()
        {
            string[] policyList = { };
            bool LapsePolicy = false;

            //check if current policy is of lapse status
            if (CSWData.LapsePolicies != null && CSWData.LapsePolicies != "")
            {
                policyList = CSWData.LapsePolicies.Split(';');
                for (int i = 0; i < policyList.Count() - 1; i++)
                {
                    string[] phrasePolicy = policyList[i].Split(' ');
                    string polnum = phrasePolicy.Last().Trim();

                    if (data[KeyRepository.PolicyNumber] == polnum)
                        LapsePolicy = true;
                    else
                        LapsePolicy = false;
                }
            }

            //dont check quarterly eligibility if policy status is a laspe policy
            if (!LapsePolicy)
            {
                try
                {
                    //check the diff between paid to date and effective date
                    double dayPastEFD = (Convert.ToDateTime(data[KeyRepository.PaidToDate]) - Convert.ToDateTime(data[KeyRepository.EffectiveDate])).TotalDays;
                    DateTime effectiveDate = Convert.ToDateTime(data[KeyRepository.PaidToDate]);
                    DateTime PaidToDate = Convert.ToDateTime(data[KeyRepository.PaidToDate]);
                    CommonFunctions CF = new CommonFunctions(data);
                    CSWData.QuarterlyEligibility = false;
                    if (CF.CalculateQuarterlyEligibility(effectiveDate, PaidToDate))
                        CSWData.QuarterlyEligibility = true;
                }
                catch (Exception e)
                {
                    NYLDSelenium.ReportStepResult("Failed to check quarterly eligibility ", "Here is the exception: " + e.ToString().Replace("\r\n", " "), "Fail", "always", "yes");
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: QueryAALDTLP1Table                                                                        ///////////
        ////// Description:  Query to check if record is created for cash value letter creation                  ///////////        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
        public void QueryAALDTLP1Table()
        {
            //Iterate 5 times
            //and inside iteration call the database query
            //if queryResultList count == 0, wait for 20sec
            //else queryResultList count = 1 verify  expected vs Actual address
            string cvlAddr = "", recEntry = "";
            cvlAddr = data[KeyRepository.CVLAddressData].Replace(",", "").Replace(" ", "");
            for (int i = 0; i < 5; i++)
            {
                //Build the query
                GetDataBaseValues("queryCashValueLetter");
                if (queryResultList.Count() == 0)
                {
                    Thread.Sleep(20000);
                    if (i == 5)
                        NYLDSelenium.ReportStepResult("Verify record is created in AALDTLP1 Table", "AALDTLP1 Table Entry not found", "PASS");
                }
                if (queryResultList.Count() == 1)
                {
                    // query table results queryResultList[0][0] = LDLNAM +queryResultList[0][1] = LDLAD1+ queryResultList[0][2] = LDLAD2 +queryResultList[0][3] = LDLAD3 + queryResultList[0][4] = LDLCSZ + queryResultList[0][5] = LDKEYF
                    recEntry = queryResultList[0]["LDLNAM"].ToString().Trim() + "|" + queryResultList[0]["LDLAD1"].ToString().Trim() + "|" + queryResultList[0]["LDLAD2"].ToString().Trim() + "|" + queryResultList[0]["LDLAD3"].ToString().Trim() + "|" + queryResultList[0]["LDLCSZ"].ToString().Trim();
                    recEntry = recEntry.Replace(",", "").Replace(" ", "");
                    if (cvlAddr == recEntry)
                        NYLDSelenium.ReportStepResult("Verify record is created in AALDTLP1 Table and Address column are matching as expected", "Address, city, state and Zip values are found as expected", "PASS");
                    else
                        NYLDSelenium.ReportStepResult("Verify record is created in AALDTLP1 Table and Address column are matching as expected", "The table entry found in AALDTLP1 table but 'Address, City, State and ZipCode values' are empty or invalid.", "FAIL", "no", "no");
                    break;// Exit the loop if queryResultList.Count() == 1
                }

                if (queryResultList.Count() > 1)
                {
                    NYLDSelenium.ReportStepResult("Verify record is created in AALDTLP1 Table and Address column are matching as expected", "Multiple records Found", "PASS", "no", "no");
                    break;
                }

            }

        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: QueryFAXREQP1Table                                                                        ///////////
        ////// Description:  Query to check if record is created for Fax cash value letter creation                  ///////////        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
        public void QueryFAXREQP1Table()
        {
            string cvlAddr = "", recEntry = "";
            //Fax number getting updated to 813-288-5263 always, check with kelly
            cvlAddr = data[KeyRepository.CVLFaxNumber].ToString().Replace(")", "-").Replace("(", "") + "|Cash Value Letter FAX " + data[KeyRepository.PolicyNumber];
            for (int i = 0; i < 5; i++)
            {
                //Build the query
                GetDataBaseValues("queryCashValueLetter_Fax");
                if (queryResultList.Count() == 0)
                {
                    Thread.Sleep(20000);
                    if (i == 5)
                        NYLDSelenium.ReportStepResult("Verify record is created in FAXREQP1 Table and verify FaxNumber and policy number columns are matching as expected", "FAXREQP1 Table Entry not found", "PASS");
                }
                if (queryResultList.Count() == 1)
                {
                    // FXNUMF, FXNUMT, FXSUB1, FXSUB2                    
                    recEntry = queryResultList[0]["FXNUMT"].ToString().Trim() + "|" + queryResultList[0]["FXSUB1"].ToString().Trim();
                    if (cvlAddr == recEntry)
                        NYLDSelenium.ReportStepResult("Verify record is created in FAXREQP1 Table and verify FaxNumber and policy number columns are matching as expected", queryResultList[0]["FXNUMF"].ToString().Trim() + " and" + queryResultList[0]["FXSUB1"].ToString().Trim() + " values are found as expected", "PASS", "no", "no");
                    else
                        NYLDSelenium.ReportStepResult("Verify record is created in FAXREQP1 Table and verify FaxNumber and policy number columns are matching as expected", "The FaxNumber and policy number columns are not matching", "FAIL", "no", "no");
                    break;// Exit the loop if queryResultList.Count() == 1
                }

                if (queryResultList.Count() > 1)
                {
                    NYLDSelenium.ReportStepResult("Verify record is created in FAXREQP1 Table and verify FaxNumber and policy number columns are matching as expected", "Multiple records Found", "PASS", "no", "no");
                    break;
                }

            }

        }

        /// <summary>
        /// Description:  Query to check if record is created for cash value letter creation in lsp customer activity table
        /// </summary>
        public void QueryLSPCustomerActivity(string info)
        {
            Console.WriteLine("info: " + info);
            for (int i = 0; i < 5; i++)
            {
                //Build the query
                if (info == "CashValueLetter-Mail")
                    GetDataBaseValues("queryLSPCVL_Mail");
                else if (info == "CashValueLetter-Fax")
                    GetDataBaseValues("queryLSPCVL_Fax");

                if (queryResultList.Count() == 0)
                {
                    Thread.Sleep(50000);
                    if (i == 5)
                        NYLDSelenium.ReportStepResult("Verify record is created in LSPCustomerActivity Table", "LSPCustomerActivity Table Entry not found", "PASS");
                }
                if (queryResultList.Count() == 1)
                {
                    NYLDSelenium.ReportStepResult("Verify entry is found in LSPCustomerActivity Table", queryResultList[0]["ACTIVITY"].ToString().Trim() + " entry was  found in LSP_CUSTOMER_ACTIVITY_AUDIT_TBL Table", "PASS", "no", "no");
                    break;
                }
                if (queryResultList.Count() > 1)
                {
                    NYLDSelenium.ReportStepResult("Verify entry is found in LSPCustomerActivity Table", "Multiple records Found", "FAIL", "no", "no");
                    break;
                }
            }
        }


        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryCoverageSummary                                                                       ///////////
        ////// Description:  Query coverage summary section details of details page                              ///////////        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public void QueryCoverageSummary()
        {
            RestServices webServices = new RestServices(data);
            //Build the query
            GetDataBaseValues("queryCoverageSummary");

            CSWData.CoverageSummaryInfo.Clear();
            //Read each value
            for (int i = 0; i < queryResultList.Count(); i++)
            {
                CSWData.CoverageSummaryInfo.Add(new List<string>());

                CSWData.CoverageSummaryInfo[i].Add(queryResultList[i]["PDDESC"].ToString().Trim());  //Product
                CSWData.CoverageSummaryInfo[i].Add(queryResultList[i]["EFTDATE"].ToString().Trim());  //Effective Date
                CSWData.CoverageSummaryInfo[i].Add(queryResultList[i]["FPLAMT"].ToString().Trim());  //Coverage Amount
                // Cash Surrender -//Webservie Call to retrieve CSV      
                CSWData.CoverageSummaryInfo[i].Add(String.Format("{0:0.00}", Decimal.Parse(webServices.SubmitRestCall("CashSurrenderValue"))));
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: queryFamilyBill                                                                             ///////////
        ////// Description:  Get family bill information like Group Id and Group preimums for a contract         ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void QueryFamilyBill()
        {
            RestServices restServices = new RestServices(data);
            IList<DateTime> PremiumDueDate = new List<DateTime>();
            IList<DateTime> PaysToDate = new List<DateTime>();
            IList<double> PremiumAmount = new List<double>();
            CSWData.TempVal = "";
            double PremiumAmountGroup = 0;

            //Get Family bill group id
            GetDataBaseValues("queryFamilyBillGroupID");

            if (queryResultList.Count() > 0)
                data[KeyRepository.FamilyBillGroupID] = queryResultList[0]["MCGBNO"].ToString().Trim();
            else
                NYLDSelenium.ReportStepResult("Query Family Bill Group ID", "Unable to fetch family bill group ID for policy number: " + data[KeyRepository.PolicyNumber], "FAIL", "no", "yes");

            //Get Family bill details
            GetDataBaseValues("queryFamilyBillDetails");

            //Get total Group Amount 
            for (int i = 0; i < queryResultList.Count(); i++)
            {
                PremiumAmountGroup = PremiumAmountGroup + Convert.ToDouble(queryResultList[i]["MCPRMM"]);
                CSWData.TempVal = CSWData.TempVal + " " + queryResultList[i]["MCCNTR"].ToString().TrimEnd();

            }

            if (queryResultList.Count() > 0)
            {
                DateTime PaidToDate = Convert.ToDateTime(queryResultList[0]["MCPDTM"].ToString().Trim() + "/" + queryResultList[0]["MCPDTD"].ToString().Trim() + "/" + queryResultList[0]["MCPDTY"].ToString().Trim());
                DateTime BilledToDate = Convert.ToDateTime(queryResultList[0]["MCBLTM"].ToString().Trim() + "/" + queryResultList[0]["MCBLTD"].ToString().Trim() + "/" + queryResultList[0]["MCBLTY"].ToString().Trim());
                PremiumDueDate.Add(PaidToDate);
                PaysToDate.Add(BilledToDate);
                PremiumAmount.Add(Convert.ToDouble(queryResultList[0]["MCPRMM"].ToString()));

                //CSWData.tempval = CSWData.tempval + " " + queryResultList[0][0].ToString().TrimEnd();


                data[KeyRepository.PaidToDate] = PremiumDueDate.Min().Date.ToString("MM/dd/yyyy");
                string BilledUptoDate = PaysToDate.Min().Date.ToString("MM/dd/yyyy");
                //data[KeyRepository.Premium] = Math.Round((PremiumAmount.Sum()), 2, MidpointRounding.AwayFromZero).ToString("#.00");
                data[KeyRepository.Premium] = Math.Round((PremiumAmountGroup), 2, MidpointRounding.AwayFromZero).ToString("#.00");

                //to get the  PaymentDueDate
                CSWData.PaymentInformation.Clear();
                restServices.SubmitRestCall("PaymentInformation");

                Thread.Sleep(2000);
                CSWData.PaymentInformation.Clear();
                CSWData.PaymentInformation.Add("Group Premium Due: " + data[KeyRepository.PaidToDate] + " $" + data[KeyRepository.Premium]);

                int ratio = (Convert.ToDateTime(data[KeyRepository.LSPDate]).CompareTo(Convert.ToDateTime(data[KeyRepository.PaidToDate])));
                if (ratio < 0)
                    CSWData.PaymentInformation.Add("Total Amount Due: " + "$" + data[KeyRepository.Premium] + " Pays To " + data[KeyRepository.PaymentDueDate]);
                else
                    CSWData.PaymentInformation.Add("Past Due: " + "$" + data[KeyRepository.Premium] + " Pays To " + data[KeyRepository.PaymentDueDate]);
            }
            else
                NYLDSelenium.ReportStepResult("Query Family Bill details", "Family bill group ID did not find any result", "FAIL", "no");
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getBeneInfo                                                                                 ///////////
        ////// Description:  Query for the beneficiary information                                               ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void GetBeneInfo()
        {
            TestData testData = new TestData();
            //Execute Query
            GetDataBaseValues("getBeneInfo");

            CSWData.BeneInfo.Clear();

            // Assuming 'queryResultList' is already populated with some data
            for (int i = 0; i < queryResultList.Count; i++)
            {
                CSWData.BeneInfo.Add(new List<string>());
                Dictionary<string, string> dictionary = queryResultList[i];

                foreach (KeyValuePair<string, string> kvp in dictionary)
                {
                    string key = kvp.Key;
                    string value = kvp.Value;

                    // Process the key-value pair
                    Console.WriteLine($"Key: {key}, Value: {value}");

                    if (key == "CRUSR1")
                        CSWData.BeneInfo[i].Add(testData.GetMappedValue("Relation", queryResultList[i]["CRUSR1"].ToString().Trim(), "reverse"));
                    else
                    {
                        CSWData.BeneInfo[i].Add(queryResultList[i][key].ToString());
                        if (queryResultList[i]["CRALPH"].ToString().Trim() == "IRB")
                            CSWData.TempEmail = "IRB";
                    }
                }
            }
        }

        /// <summary>
        /// Fetch the expected health questions to be displayed in the application
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public List<string> GetHealthQuestionsNumbers(string type = "hqnos")
        {
            string state, sQuery, versionnum;
            List<string> hlthqnumbers = new List<string>();

            //Assign version number to be queried
            if (data[KeyRepository.PFC] == "")
                versionnum = GetQuestionVersion();
            else
                versionnum = data[KeyRepository.Version];

            //Loop to fetch the result with appropriate state values
            for (int i = 1; i <= 2; i++)
            {
                if (i == 1)
                    state = data[KeyRepository.State].Trim();
                else
                    state = "**";

                Console.WriteLine("i am in for loop " + i);

                //Build the query                    
                if (versionnum == "")
                    sQuery = (@"SELECT  AAQUEVER.QUST as QUST, TRIM(AAQUEVER.QUNUM) as QUNUM, TRIM(AAQUEVER.QUSEQ) as QUSEQ, CASE WHEN LQHDRTXTS1.HEADER_TEXT IS NOT NULL THEN TRIM(LQHDRTXTS1.HEADER_TEXT) || ' ' || TRIM(AAQUETX.QUTTXT) ELSE TRIM(AAQUETX.QUTTXT) END FROM KLSDAT00.AAQUEVER AAQUEVER INNER JOIN  KTLDAT00.AASRCMST AASRCMST ON AASRCMST.SQSTVR = AAQUEVER.QUVER  LEFT JOIN KLSDAT00.LQUESHDRS1 LQUESHDRS1 ON AAQUEVER.QUVER = LQUESHDRS1.QUESTION_VERSION  AND AAQUEVER.QUNUM = LQUESHDRS1.QUESTION_NUMBER LEFT JOIN KLSDAT00.LQHDRTXTS1 LQHDRTXTS1 ON LQUESHDRS1.HEADER_ID = LQHDRTXTS1.HEADER_ID INNER JOIN KLSDAT00.AAQUETX AAQUETX ON AAQUEVER.QUNUM = AAQUETX.QUTNUM WHERE AASRCMST.SSRCCD = '" + data[KeyRepository.SourceCode] + "' AND AAQUEVER.QUST = '" + state + "'");
                else
                    sQuery = (@"SELECT  AAQUEVER.QUST as QUST, TRIM(AAQUEVER.QUNUM) as QUNUM, TRIM(AAQUEVER.QUSEQ) as QUSEQ, CASE WHEN LQHDRTXTS1.HEADER_TEXT IS NOT NULL THEN TRIM(LQHDRTXTS1.HEADER_TEXT) || ' ' || TRIM(AAQUETX.QUTTXT) ELSE TRIM(AAQUETX.QUTTXT) END FROM KLSDAT00.AAQUEVER AAQUEVER LEFT JOIN KLSDAT00.LQUESHDRS1 LQUESHDRS1 ON AAQUEVER.QUVER = LQUESHDRS1.QUESTION_VERSION AND AAQUEVER.QUNUM = LQUESHDRS1.QUESTION_NUMBER LEFT JOIN KLSDAT00.LQHDRTXTS1 LQHDRTXTS1 ON LQUESHDRS1.HEADER_ID = LQHDRTXTS1.HEADER_ID INNER JOIN KLSDAT00.AAQUETX AAQUETX ON AAQUEVER.QUNUM = AAQUETX.QUTNUM WHERE AAQUEVER.QUVER = '" + versionnum + "' AND AAQUEVER.QUST = '" + state + "'");

                //Execute the query
                QueryDataBase(sQuery);

                //Fetch required results
                // Assuming 'queryResultList' is already populated with some data
                for (int k = 0; k < queryResultList.Count; k++)
                {
                    Dictionary<string, string> dictionary = queryResultList[k];

                    foreach (KeyValuePair<string, string> kvp in dictionary)
                    {
                        string key = kvp.Key;
                        string value = kvp.Value;

                        // Process the key-value pair
                        Console.WriteLine($"Key: {key}, Value: {value}");
                        if (key == "QUSEQ")
                            hlthqnumbers.Add(queryResultList[k][key].ToString().Trim());
                    }
                   // break;
                }
            }

            return hlthqnumbers;
        }

        /// <summary>
        /// Get Question Version for the products that require PFC Code
        /// </summary>
        /// <returns></returns>
        public string GetQuestionVersion()
        {
            string state, qver = "", sQuery;
            bool versionSet = false;

            //Get LSP Date
            GetLSPDate();

            //Loop to fetch the result with appropriate state values
            for (int i = 1; i <= 2; i++)
            {
                if (i == 1)
                    state = data[KeyRepository.State].Trim();
                else
                    state = "**";

                bool bCurrent = true;

                //Build query to fetch the version number
                if ((GetFormCode() == data[KeyRepository.PFC]) || (data[KeyRepository.PFC] == ""))
                    sQuery = (@"SELECT FCQUESVER, FCSTRTDTE, FCENDDTE FROM KLSDAT00.LFRMCODP1 WHERE FCPLAN = '" + data[KeyRepository.Product] + "' AND FCACTIVE = 'Y' AND FCSTEGRP='" + state + "' AND FCSTRTDTE <= '" + data[KeyRepository.LSPDate] + "' AND FCDEFAULT = 'Y'");
                else
                {
                    sQuery = (@"SELECT FCQUESVER, FCSTRTDTE, FCENDDTE FROM KLSDAT00.LFRMCODP1 WHERE FCPLAN = '" + data[KeyRepository.Product] + "' AND FCACTIVE = 'Y' AND  FCFRMCODE = '" + data[KeyRepository.PFC] + "'");
                    bCurrent = false;
                }

                //Execute the query
                QueryDataBase(sQuery);

                //Fetch the results
                // Assuming 'queryResultList' is already populated with some data
                for (int k = 0; k < queryResultList.Count; k++)
                {
                    Dictionary<string, string> dictionary = queryResultList[k];

                    foreach (KeyValuePair<string, string> kvp in dictionary)
                    {
                        string key = kvp.Key;
                        string value = kvp.Value;

                        // Process the key-value pair
                        Console.WriteLine($"Key: {key}, Value: {value}");


                        if (bCurrent)
                        {

                            string endDate = queryResultList[k]["FCENDDTE"].ToString().Trim();
                            int endDateExpiry = -1;
                            if (endDate != null && endDate != "")
                                endDateExpiry = DateTime.Compare(Convert.ToDateTime(endDate), Convert.ToDateTime(data[KeyRepository.LSPDate]));

                            if (endDateExpiry < 0)
                            {
                                qver = queryResultList[k]["FCQUESVER"].ToString().Trim();
                                versionSet = true;
                            }
                        }
                        else
                        {
                            qver = queryResultList[k]["FCQUESVER"].ToString().Trim();
                            versionSet = true;
                        }
                    }
                   // break;
                }

                if (versionSet) //do we need this here, since we're only getting back 1 result-set? - kamil
                    break;
            }
            return qver;
        }

        public void QuerryExecute(string dQuery, int position, [Optional] string arg)
        {
            TestPreRequisites testRequsite = new TestPreRequisites(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            Console.WriteLine("Query is " + dQuery);

            List<Dictionary<string, string>> queryList = NYLDDatabase.QueryDataBase(dQuery);

            // for Registered user status verification and Delete user
            RestServices restcall = new RestServices(data);
            data[KeyRepository.AuthToken] = restcall.SubmitRestCall("GenerateOAuthToken");
            if (queryList.Count > 0)
            {
                var queryListCopy = new List<Dictionary<string, string>>(queryList);
                foreach (var record in queryList)
                {
                    data[KeyRepository.PolicyNumber] = record.Values.ElementAt(position).Trim();
                    Console.WriteLine(data[KeyRepository.PolicyNumber]);
                    if (!BadContractCheck(arg, true))
                    {
                        if (data[KeyRepository.PolicyStatus] == "Inforce")
                        {
                            LoginPage LP = new LoginPage(driver, data);
                            RecordFound = GetUserStatus(arg);
                            NYLDSelenium.PageLoad("CSW Login", LP.LoginHeaderNewUser, "no", "no");
                            if (RecordFound)
                                break;
                        }
                    }
                }
            }

            if (RecordFound)
            {
                RegisterDatamineUser();
                NYLDSelenium.ReportStepResult("DataMine successful", "Able to find the record that meets the Test criteria: " + data[KeyRepository.PreTestDataSet] + "<br>Query:<br>" + dQuery, "PASS", "no", "no");
            }
            else
            {
                NYLDSelenium.ReportStepResult("DataMine Unsuccessful", "Unable to find the record that meets the Test criteria: " + data[KeyRepository.PreTestDataSet] + "<br>Query:<br>" + dQuery, "FAIL", "no", "yes");
            }
        }

        /// <summary>
        /// Get the form code to display required details for the product in application
        /// </summary>
        /// <returns></returns>
        public string GetFormCode()
        {
            queryResultList = new List<Dictionary<string, string>>();
            List<string> formcode = null;

            //Query the control number
            if (data[KeyRepository.Product].Contains("PL"))
                data[KeyRepository.Product] = "PL10";
            else
                data[KeyRepository.Product] = "LR10";

            GetDataBaseValues("getFormCode");

            // Assuming 'queryResultList' is already populated with some data
            for (int k = 0; k < queryResultList.Count; k++)
            {
                Dictionary<string, string> dictionary = queryResultList[k];

                foreach (KeyValuePair<string, string> kvp in dictionary)
                {
                    string key = kvp.Key;
                    string value = kvp.Value;

                    // Process the key-value pair
                    Console.WriteLine($"Key: {key}, Value: {value}");
                    formcode.Add(queryResultList[k][key].ToString().Trim());
                }
              //  break;
            }

            return formcode[0];
        }

        public class PaymentHistoryResult
        {
            public List<string> PaymentHistory { get; set; }
            public List<string> PaymentReversalHistory { get; set; }

            public PaymentHistoryResult()
            {
                PaymentHistory = new List<string>();
                PaymentReversalHistory = new List<string>();
            }
        }
        public PaymentHistoryResult QueryPaymentHistory(string args)
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Verify Database entries in Payment History table" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            PaymentHistoryResult result = new PaymentHistoryResult();
            GetDataBaseValues("queryPaymentHistory");

            result.PaymentHistory.Clear();

            // Assuming 'queryResultList' is already populated with some data

            for (int k = 0; k < queryResultList.Count; k++)
            {
                string policyNumber = data[KeyRepository.PolicyNumber] = queryResultList[k]["PPOLNO"].ToString().Trim();
                string premiumAmount = queryResultList[k]["PPRMPD"].ToString().Trim();
                string paidDate = queryResultList[k]["PMONTH"].ToString().Trim() + "/" + queryResultList[k]["PDAY"].ToString().Trim() + "/" + queryResultList[k]["PYEAR"].ToString().Trim();
                string paidToDate = queryResultList[k]["PPDTMM"].ToString().Trim() + "/" + queryResultList[k]["PPDTDD"].ToString().Trim() + "/" + queryResultList[k]["PPDTYY"].ToString().Trim();
                string combined = paidDate + " " + premiumAmount + " " + paidToDate;

                if (!string.IsNullOrEmpty(queryResultList[k]["PREVCD"].ToString()))
                {
                    result.PaymentReversalHistory.Add(combined);
                }
                else
                {
                    result.PaymentHistory.Add(combined);
                }
            }

            return result;
        }

        public void GetClientId()
        {
            RestServices restServices = new RestServices(data);
            GetDataBaseValues("queryClientID");
            if (queryResultList.Count > 0)
            {
                data[KeyRepository.ClientId] = queryResultList[0]["JACLNT"].ToString().Trim();
            }
        }
    }
}