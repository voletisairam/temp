﻿using CSW.Common.Others;
using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using PasswordEncryptDecrpt;
using System.Xml;
using System.IO;
using NYLDWebAutomationFramework;
using CSW.Common.Services.APIRequests;
using Newtonsoft.Json;
using CSW.Common.Excel;

namespace CSW.Common.Services
{
    class RestServices
    {
        //ClientID, ClientSecret Credentials
        private static readonly string clientid1 = Properties.Settings.Default.MuleClientID1;
        private static readonly string clientSecret1 = Properties.Settings.Default.MuleClientSecret1;
        private static readonly string clientId = Properties.Settings.Default.MuleClientID;
        private static readonly string clientSecret = Properties.Settings.Default.MuleClientSecret;
        private static readonly string endpoint = Properties.Settings.Default.MuleServiceEndPoint;
        private Dictionary<string, string> data;

        public RestServices(Dictionary<string, string> testdata)
        {
            data = testdata;
        }

        //Submit Rest Call using RestSharp
        public string SubmitRestCall(string method, string exptime = "10", string desc = "")
        {
            string result = "";
            var client = CreateClient();
            //Set the Request based on the input method
            var request = CreateRequest(method, desc);

            //Wait for 0.5 seconds before making the call (this is to throttle down the execution of the spreadsheet)
            Thread.Sleep(500);

            //Get the response by executing the request
            RestResponse response = (RestResponse)client.Execute(request);

            //If Status is OK then get the output
            if (response.StatusCode.ToString() == "OK")
            {
                switch (method)
                {
                    case "GenerateOAuthToken":
                        result = ParseJSONResponse(method, response.Content, "");
                        break;
                    default:
                        result = ParseXMLResponse(method, response.Content);
                        break;
                }                     
            }

            //Return result to driver class
            return result;
        }
        public string SubmitOAuth2RestCall(string apiName, string key) {            

            var client = CreateClient(data[KeyRepository.AuthToken]);
            var request = CreateRequest(apiName, key);
            Thread.Sleep(500);

            RestResponse response = (RestResponse)client.Execute(request);

            return response.StatusCode == HttpStatusCode.OK ? ParseJSONResponse(apiName, response.Content, key) : null;
        }

        private RestClient CreateClient(string token = null)
        {
            var client = new RestClient(endpoint);

            if (token == null)
                client.Authenticator = new HttpBasicAuthenticator(Properties.Settings.Default.MuleServiceUserName, PasswordDecrypter.Decrypt(Properties.Settings.Default.MuleServicePassword));
            else      
                client.Authenticator = new OAuth2AuthorizationRequestHeaderAuthenticator(token, "Bearer");
            return client;
        }

        private RestRequest CreateRequest( string method, string desc)
        {
            string resource = GetEndPoint(method, out Method reqMethod);
            string GUID = GenerateGUID();
            string uniqueCorrelationId = "Auto_Test_120520242025";
            //Security Credentials
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            var request = new RestRequest(resource, reqMethod);

            switch (method)
            {
                case "GenerateOAuthToken":
                    //For Digital Apps Only
                    request.AddHeader("X-CORRELATION-ID", "1q2we3e4r5t6y6ye");
                    request.AddHeader("client_id", clientId);
                    request.AddHeader("client_secret", clientSecret);
                    request.AddHeader("grant_type", "CLIENT_CREDENTIALS"); 
                    request.AddHeader("Content-Type", "application/json");
                    request.AddHeader("scope", "read-write");
                    break;
                case "SearchUser":
                case "DeviceInfo":
                case "RegisterUser":
                case "RegisterSMS":
                case "RegisterSMSOTP":
                    request.AddHeader("X-CORRELATION-ID", uniqueCorrelationId);
                    request.AddHeader("Content-Type", "application/json");
                    request.AddParameter("application/json", CreatePayload(method, "8", desc), ParameterType.RequestBody);
                    break;
                default:
                    request.AddHeader("clientid", clientId);
                    request.AddHeader("clientSecret", clientSecret);
                    request.AddHeader("Connection", "Keep-Alive");
                    request.AddHeader("TransRefGUID", GUID);
                    request.AddHeader("Content-Type", "application/xml");

                    request.AddParameter("application/xml", CreatePayload(method, "8", desc), ParameterType.RequestBody);
                    break;
            }

            return request;
        }

        private string GenerateGUID()
        {
            string GUID = "AUT" + Environment.MachineName + DateTime.Now.ToString("yyyyMMddHHmmss");
           // data[KeyRepository.GUID] = GUID;
            return GUID;
        }

        public string GetEndPoint(string method, out Method requestMethod)
        {
            string endPoint = "";
            requestMethod = Method.POST;
            switch (method)
            {
                case "AddBenefeciary":

                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/502/50204";
                    break;
                case "UpdatePartyPayFrequency":
                case "DeleteEFT":
                case "AddEFT":
                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/184";
                    break;

                case "PaymentInformation":
                case "CheckEFTElig":
                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/208";
                    break;

                case "PaymentModeElig":
                case "QMPayFreqElig":
                case "MQPayFreqElig":
                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/212";
                    break;

                case "CashSurrenderValue":
                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/203";
                    break;

                case "AddOneTimePayment":
                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/508";
                    break;
                case "UpdatePartyTransaction":
                case "ApplyCyberFraudProtection":
                case "RemoveCyberFraudProtection":
                    endPoint = "https://modl-api4.nylaarp.newyorklife.com/0.1-m/acord/186";
                    break;
                case "GenerateOAuthToken":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/business/v1/api/auth/token";
                    break;
                case "SearchUser":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/business/v1/api/account/search";
                    break;
                case "DeviceInfo":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/business/v1/api/mfa/" + data[KeyRepository.NylId];
                    requestMethod = Method.GET;
                    break;
                case "RegisterUser":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/web/v1/api/account";
                    break;
                case "RegisterSMS":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/business/v1/api/mfa/" + data[KeyRepository.NylId] + "/pair/sms";
                    break;
                case "RegisterSMSOTP":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/business/v1/api/mfa/" + data[KeyRepository.NylId] +"/pair/sms";
                    requestMethod = Method.PATCH;
                    break;
                case "DeleteUser":
                    endPoint = "https://mdl.api.nylaarp.newyorklife.com/web/v1/api/account/" + data[KeyRepository.NylId] + "/delete";
                    requestMethod = Method.DELETE;
                    break;
            }

            return endPoint;
        }

        public RestRequest Request(string method, string desc, string authttype = "BasicAuth")
        {
            string resource = "";
            string GUID = "AUT" + Environment.MachineName + DateTime.Now.ToString("yyyyMMddHHmmss");

            try
            {
                data.Add("GUID", GUID);
            }
            catch
            {
                data[KeyRepository.GUID] = GUID;
            }


            //Security Credentials
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            //Get EndPoint
            resource = GetEndPoint(method, out Method requestMethod);

            //Post Request
            var request = new RestRequest(resource, requestMethod);

            ///// Add Headers and Parameters //////
            request.AddHeader("clientid", clientId);
            request.AddHeader("clientSecret", clientSecret);
            request.AddHeader("Connection", "Keep-Alive");
            request.AddHeader("TransRefGUID", GUID);  //Need to be unique
            request.AddHeader("Content-Type", "application/xml");

            // Get the Payload
            string payload = CreatePayload(method, "8", desc);
            if (!string.IsNullOrEmpty(payload))
            {
                request.AddParameter("application/xml", payload, ParameterType.RequestBody);
            }

            //Return the request to submit call
            return request;
        }

        
        /// <summary>
        /// Build xml request to submit as webservice request
        /// </summary>
        /// <param name="method"></param>
        /// <param name="exptime"></param>
        /// <param name="desc"></param>
        /// <returns></returns>
        public string CreatePayload(string method, string exptime = "10", string desc = "")
        {
            string payload = null;

            switch (method)
            {
                case "GenerateToken":
                    GenerateToken generate = new GenerateToken(data);
                    payload = generate.GenerateTokenXML();
                    break;

                case "GetRateResult":
                    GetRateResult getRate = new GetRateResult(data);
                    payload = getRate.GetRateResultXML();
                    break;

                case "AddBenefeciary":
                    AddBenefeciary benefeciary = new AddBenefeciary(data);
                    payload = benefeciary.AddBenefeciaryXML(desc);
                    break;

                case "AddEFT":
                    AddEFT add = new AddEFT(data);
                    payload = add.AddEFTXML(desc);
                    break;

                case "UpdatePartyPayFrequency":
                    UpdatePartyPayFrequency update = new UpdatePartyPayFrequency(data);
                    payload = update.UpdatePartyPayFrequencyXML(desc);
                    break;

                case "DeleteEFT":
                    DeleteEFT delete = new DeleteEFT(data);
                    payload = delete.DeleteEFTXML();
                    break;

                case "PaymentInformation":
                case "CheckEFTElig":
                    Payment_EFT payment_cancel_EFT = new Payment_EFT(data);
                    payload = payment_cancel_EFT.Payment_EFTXML();
                    break;

                case "PaymentModeElig":
                case "QMPayFreqElig":
                case "MQPayFreqElig":
                    Payment_EFT payment_Cancel_EFT = new Payment_EFT(data);
                    payload = payment_Cancel_EFT.PaymentModeEligibleXml();
                    break;

                case "AddOneTimePayment":
                    Payment_EFT payment_Cancel = new Payment_EFT(data);
                    payload = payment_Cancel.OneTimePaymentXml();
                    break;

                case "CashSurrenderValue":
                    ClassSurrenderValue classSurrender = new ClassSurrenderValue(data);
                    payload = classSurrender.ClassSurrenderValueXml();
                    break;

                case "ApplyCyberFraudProtection":
                    CyberFraudIndicator cyber = new CyberFraudIndicator(data);
                    payload = cyber.InsertCyberFraudIndicatorXml();
                    break;
                case "RemoveCyberFraudProtection":
                    CyberFraudIndicator removecyberFraud = new CyberFraudIndicator(data);
                    payload = removecyberFraud.RemoveCyberFraudIndicatorXml();
                    break;
                case "SearchUser":
                    SearchUserInfo user = new SearchUserInfo(data);
                    payload = user.GetUserInfo();
                    break;
                case "RegisterUser":
                    UserAccountRegistration register = new UserAccountRegistration(data);
                    payload = register.PingAccountRegister();
                    break;
                case "RegisterSMS":
                    UserAccountRegistration registersms = new UserAccountRegistration(data);
                    payload = registersms.PingPairSMS();
                    break;
                case "RegisterSMSOTP":
                    UserAccountRegistration registersmsotp = new UserAccountRegistration(data);
                    payload = registersmsotp.PingPairWithSMSOTP();
                    break;
                default:
                    payload = (@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:nyl=""http://NYLDirect.CSL.Service""> 
	    	                <soapenv:Header/>
	    	                    <soapenv:Body> 
	   	                            <nyl:DoesUserExist> 
	   	                               <nyl:uid>") + data[KeyRepository.UserName] + (@"</nyl:uid> 
	                                </nyl:DoesUserExist>
	                            </soapenv:Body>
	                        </soapenv:Envelope>");
                    break;
            }
            Console.WriteLine(payload);
            return payload;
        }

        /// <summary>
        /// Method to process the output of web service request and required output for script to process
        /// </summary>
        /// <param name="method"></param>
        /// <param name="response"></param>
        /// <returns></returns>
        public string ParseXMLResponse(string method, string response)
        {
            int pwdcount;
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(response);
            string value = "";

            if (method == "PaymentModeElig")
            {
                XmlNodeList Extensionlist = doc.GetElementsByTagName("OLifEExtension");

                IList<string> Eligiblecount = new List<string>();

                foreach (XmlNode node in Extensionlist)
                {
                    if (node.InnerText == "Y")
                        Eligiblecount.Add(node.InnerText);
                }
                if (Eligiblecount.Count == 2)
                    value = "Eligible";
                else
                    value = "Not Eligible";
            }
            else if (method == "MQPayFreqElig")
            {
                XmlNodeList altPremModes = doc.GetElementsByTagName("AltPremMode");
                string eligibleMode = "Not Eligible";

                foreach (XmlNode altPremMode in altPremModes)
                {
                    foreach (XmlNode childNode in altPremMode.ChildNodes)
                    {
                        if (childNode.Name == "PaymentMode" && childNode.Attributes["tc"] != null && childNode.Attributes["tc"].Value == "3")
                        {
                            foreach (XmlNode extensionNode in altPremMode.ChildNodes)
                            {
                                if (extensionNode.Name == "OLifEExtension" && extensionNode.Attributes["ExtensionCode"] != null && extensionNode.Attributes["ExtensionCode"].Value == "EligibleMode" && extensionNode.InnerText == "Y")
                                {
                                    eligibleMode = "Eligible";
                                    break;
                                }
                            }
                        }
                    }
                }

                value = eligibleMode;
            }
            else if (method == "QMPayFreqElig")
            {
                XmlNodeList altPremModes = doc.GetElementsByTagName("AltPremMode");
                string eligibleMode = "Not Eligible";

                foreach (XmlNode altPremMode in altPremModes)
                {
                    foreach (XmlNode childNode in altPremMode.ChildNodes)
                    {
                        if (childNode.Name == "PaymentMode" && childNode.Attributes["tc"] != null && childNode.Attributes["tc"].Value == "4")
                        {
                            foreach (XmlNode extensionNode in altPremMode.ChildNodes)
                            {
                                if (extensionNode.Name == "OLifEExtension" && extensionNode.Attributes["ExtensionCode"] != null && extensionNode.Attributes["ExtensionCode"].Value == "EligibleMode" && extensionNode.InnerText == "Y")
                                {
                                    eligibleMode = "Eligible";
                                    break;
                                }
                            }
                        }
                    }
                }

                value = eligibleMode;
            }
            else if (method == "GenerateToken")
            {
                XmlNodeList TokenelemList = doc.GetElementsByTagName("GenerateConfirmationTokenResult");
                value = TokenelemList[0].InnerText;
            }
            else if (method == "CheckEFTElig")
            {
                XmlNodeList EFTElig = doc.GetElementsByTagName("KeyValue");
                switch (EFTElig[0].InnerText)
                {
                    case "0":
                        value = "Not Eligible";
                        break;
                    case "1":
                        value = "Existing EFT";
                        break;
                    case "2":
                        value = "No Existing EFT";
                        break;
                    default:
                        value = "Could not verify";
                        break;
                }
            }
            else if (method == "PaymentInformation")
            {
                //make PaymentInformation array global variable

                string[] RephraseDueDate = { };

                //XmlNode SuspenseAmount = doc.SelectSingleNode("//PreviousBalanceAmt");
                //XmlNode SuspenseAmount = doc.SelectSingleNode("//PI:TXLife/TXLifeResponse/OLifE/FinancialStatement/BillingStatement/PreviousBalanceAmt", nsmgr);
                XmlNodeList BillingStatement = doc.GetElementsByTagName("BillingStatement");
                XmlNodeList dues = BillingStatement[0].ChildNodes;

                //get payment information nodes
                XmlNodeList SuspenseAmount = doc.GetElementsByTagName("PreviousBalanceAmt");
                XmlNodeList PremiumDueAmntNodes = doc.GetElementsByTagName("PaymentAmt");
                XmlNodeList PremiumDueDateNodes = doc.GetElementsByTagName("BilledToDate");
                XmlNodeList DueAmnt = doc.GetElementsByTagName("DuesAmt");
                XmlNodeList DueGroup = doc.GetElementsByTagName("GroupingCode");
                XmlNodeList PaymentDueDateNode = doc.GetElementsByTagName("PaymentDueDate");

                IList<string> PremiumDueAmnt = new List<string>();
                IList<string> PremiumDueDate = new List<string>();
                IList<string> PaymentDueDate = new List<string>();

                foreach (XmlNode node in PremiumDueAmntNodes)
                {
                    if (node.ParentNode.Name == "BillingStatement" || node.ParentNode.Name == "BillingDetail")
                    {
                        PremiumDueAmnt.Add(node.InnerText);
                    }
                }

                foreach (XmlNode node in PremiumDueDateNodes)
                {
                    if (node.ParentNode.Name == "BillingStatement" || node.ParentNode.Name == "BillingDetail")
                    {
                        PremiumDueDate.Add(node.InnerText);
                    }
                }
                foreach (XmlNode node in PaymentDueDateNode)
                {
                    if (node.ParentNode.Name == "BillingStatement" || node.ParentNode.Name == "BillingDetail")
                    {
                        PaymentDueDate.Add(node.InnerText);
                    }
                }

                //format premium due date to match UI             
                for (int i = 0; i < PremiumDueDate.Count; i++)
                {
                    PremiumDueDate[i] = PremiumDueDate[i].Split('-')[1].TrimStart('0') + "/" + PremiumDueDate[i].Split('-')[2].TrimStart('0') + "/" + PremiumDueDate[i].Split('-')[0].TrimStart('0');
                }

                // format premium pays to date to match UI 
                PaymentDueDate[0] = PaymentDueDate[0].Split('-')[1].TrimStart('0') + "/" + PaymentDueDate[0].Split('-')[2].TrimStart('0') + "/" + PaymentDueDate[0].Split('-')[0].TrimStart('0');
                data[KeyRepository.PaymentDueDate] = PaymentDueDate[0].Split('/')[0].PadLeft(2, '0') + "/" + PaymentDueDate[0].Split('/')[1].PadLeft(2, '0') + "/" + PaymentDueDate[0].Split('/')[2];
                //Add Premium Due and total amount due to the list
                if (PremiumDueAmnt.Count != 0 && PremiumDueAmnt != null)
                {
                    for (int i = 0; i < PremiumDueAmnt.Count; i++)
                    {
                        if (i == 0)
                        {
                            data[KeyRepository.EFTPremium] = PremiumDueAmnt[i];
                            if (data[KeyRepository.ContractCardColor] == "Red" || data[KeyRepository.ContractCardColor] == "Yellow" || (data[KeyRepository.ContractCardColor] == "Grey" && data[KeyRepository.PolicyStatus] != "Cancelled"))
                                CSWData.PaymentInformation.Add("Past Due: " + "$" + PremiumDueAmnt[i] + " Pays To " + Convert.ToDateTime(PaymentDueDate[i]).ToString("MM/dd/yyyy"));
                            else
                                CSWData.PaymentInformation.Add("Total Amount Due: " + "$" + PremiumDueAmnt[i] + " Pays To " + Convert.ToDateTime(PaymentDueDate[i]).ToString("MM/dd/yyyy"));

                        }
                        else
                        {
                            data[KeyRepository.FISPremium] = PremiumDueAmnt[i].Trim();
                            CSWData.PaymentInformation.Add("Premium Due: " + Convert.ToDateTime(PremiumDueDate[i - 1]).ToString("MM/dd/yyyy") + " " + "$" + PremiumDueAmnt[i]);
                        }
                    }
                }

                //Add Suspense amount classified to Credit or Prior amount due               
                if (SuspenseAmount[0].InnerText != "0.00")
                {
                    if (SuspenseAmount[0].InnerText.Contains("-"))
                        CSWData.PaymentInformation.Add("Credit: " + "($" + SuspenseAmount[0].InnerText.TrimStart('-') + ")");
                    else
                        CSWData.PaymentInformation.Add("Prior Amount Due: " + "$" + SuspenseAmount[0].InnerText);
                }

                //Add Group Due amount
                if (DueAmnt[0].InnerText != "0.00")
                    CSWData.PaymentInformation.Add(DueGroup[0].InnerText + " Dues: " + "$" + SuspenseAmount[0].InnerText);



            }
            else if ((method == "AddBenefeciary") || (method == "AddEFT") || (method == "DeleteEFT") || (method == "AddOneTimePayment") || (method == "ApplyCyberFraudProtection") || (method == "RemoveCyberFraudProtection"))
            {
                XmlNodeList ResultCodeList = doc.GetElementsByTagName("ResultCode");
                value = ResultCodeList[0].Attributes["tc"].Value;

                if (ResultCodeList[0].Attributes["tc"].Value == "1")
                {
                    value = method + " was processing";
                }
                else
                {
                    XmlNodeList ResultInfoList = doc.GetElementsByTagName("ResultInfoDesc");
                    value = ResultInfoList[0].InnerText;
                }


            }

            else if (method == "CashSurrenderValue")
            {
                XmlNodeList ResultCodeList = doc.GetElementsByTagName("CashSurrValue");
                if (string.IsNullOrEmpty(ResultCodeList[0].InnerText))
                    value = "0.00";
                else
                    value = ResultCodeList[0].InnerText;

            }
            else if (method == "GenerateOAuthToken")
            {
                XmlNodeList authToken = doc.GetElementsByTagName("access_token");
                if (string.IsNullOrEmpty(authToken[0].InnerText))
                    value = "Access token not generated";
                else
                    value = authToken[0].InnerText;
            }
            else
            {
                string profilestatus = "";
                XmlNodeList ResultInfoList = doc.GetElementsByTagName("ResultInfoDesc");

                XmlNodeList profStatelemList = doc.GetElementsByTagName("a:ProfileStatus");
                if (profStatelemList.Count != 0)
                    profilestatus = profStatelemList[0].InnerText;

                XmlNodeList pwdcountelemList = doc.GetElementsByTagName("b:BadPasswordCount");

                if (pwdcountelemList.Count != 0)
                    if (pwdcountelemList[0].InnerText == "")
                        pwdcount = 0;
                    else
                        pwdcount = Int32.Parse(pwdcountelemList[0].InnerText);
                else
                    pwdcount = 0;

                switch (method)
                {
                    case "DisabledUser":
                        if (profilestatus == "Disabled")
                        {
                            value = "yes";
                        }
                        break;
                    case "DeactivatedUser":
                        if (profilestatus == "Deactivated")
                        {
                            value = "yes";
                        }
                        else if (profilestatus == "Registered")
                        {
                            XmlNodeList IsDeactiveElemList = doc.GetElementsByTagName("b:IsDeactivated");
                            string IsDeactive = IsDeactiveElemList[0].InnerText;
                            if (IsDeactive == "true")
                            {
                                value = "yes";
                            }

                        }
                        break;
                    case "SuspendedUser":

                        if (profilestatus == "Suspended" && pwdcount == 5)
                        {
                            value = "yes";
                        }
                        break;
                    case "ActiveUser":
                        if (profilestatus == "Active" && pwdcount < 5)
                        {
                            value = "yes";
                        }
                        break;
                    case "Email":
                        XmlNodeList EmailID = doc.GetElementsByTagName("b:Email");
                        string eMail = EmailID[0].InnerText;
                        value = eMail;
                        break;
                    case "BadPasswordCount":
                        XmlNodeList badPINcountelemList = doc.GetElementsByTagName("b:BadPasswordCount");
                        string badPasswordcount = badPINcountelemList[0].InnerText;
                        value = badPasswordcount;
                        break;
                    case "BadPinCount":
                        XmlNodeList badPINcountelemListRP = doc.GetElementsByTagName("b:BadPinCount");
                        string badPINcount = badPINcountelemListRP[0].InnerText;
                        value = badPINcount;
                        break;
                    case "IsAccountDisabled":
                        XmlNodeList acctDisabledelemListRP = doc.GetElementsByTagName("a:AccountStatus");
                        string accDisabled = acctDisabledelemListRP[0].InnerText;
                        value = accDisabled;
                        break;

                    case "ProfileStatus":

                        if (profilestatus == "Registered")
                        {
                            XmlNodeList IsDeactiveElemList = doc.GetElementsByTagName("b:IsDeactivated");
                            string IsDeactive = IsDeactiveElemList[0].InnerText;
                            if (IsDeactive == "true")
                            {
                                profilestatus = "Deactivated";
                            }
                        }
                        value = profilestatus;
                        break;
                    default:
                        value = "no";
                        break;
                }
            }

            return value;
        }

        public string ParseJSONResponse(string method, string response, string key)
        {
            JObject json = JObject.Parse(response);
            string value = null;
            switch (method)
            {
                case "GenerateOAuthToken":
                    value = json["access_token"].ToString();
                    break;
                case "RegisterUser":
                    if (key == "status")
                    {
                        try
                        {
                            if (json.ContainsKey("user"))
                            {
                                JObject user = (JObject)json["user"];
                                value = user["status"].ToString();
                            }
                            else
                                Console.WriteLine("The 'user' key does not exist.");
                        }
                        catch { }
                    }
                    break;
                case "SearchUser":
                    if (key == "nylid")
                    {
                        try
                        {
                            if (json.ContainsKey("users"))
                            {
                                JArray usersArray = (JArray)json["users"];
                                if (usersArray.Count == 0)
                                    Console.WriteLine("The 'users' array is empty.");
                                else
                                {
                                    JObject user = (JObject)usersArray[0];
                                    value = user["nylid"].ToString();
                                    data[KeyRepository.NylId] = value;
                                }
                            }
                            else
                                Console.WriteLine("The 'users' key does not exist.");
                        }
                        catch { }
                    }
                    else if (key == "status")
                    {
                        try
                        {
                            if (json.ContainsKey("users"))
                            {
                                JArray usersArray = (JArray)json["users"];
                                if (usersArray.Count > 0)
                                {
                                    JObject user = (JObject)usersArray[0];
                                    value = user["status"].ToString();
                                }
                                else
                                    Console.WriteLine("The 'users' array is empty.");
                            }
                            else
                                Console.WriteLine("The 'users' key does not exist.");
                        }
                        catch { }
                    }
                    break;
                case "DeviceInfo":
                    if (key == "phoneNumber")
                    {
                        try
                        {
                            if (json.ContainsKey("devices"))
                            {
                                JArray devices = (JArray)json["devices"];

                                foreach (var device in devices)
                                {
                                    if (device["deviceType"].ToString() == "SMS")
                                    {
                                        return device["phoneNumber"].ToString();
                                    }
                                }
                            }
                            else
                                Console.WriteLine("The 'devices' key does not exist.");
                        }
                        catch { }
                    }
                    break;
                case "RegisterSMS":
                    value = json[key].ToString();
                    data[KeyRepository.NLYPairId] = value;
                    break;
                case "RegisterSMSOTP":
                    value = json[key].ToString();
                    break;
                case "DeleteUser":
                    value = json[key].ToString();
                    break;
            }

            return value;
        }

        /// <summary>
        /// This method is use to fetch the Emails for the specficEmail Group
        /// </summary>
        /// <param name="EmailService"></param>
        /// <param name="SpecficEmail"></param>
        /// <param name="EmailGroupName"></param>
        /// <returns></returns>
        public string GetEMails(string emailType, string EmailGroupName)
        {
            string GUID = Environment.MachineName + DateTime.Now.ToString("yyyyMMddHHmmss");

            //Create Client Object with URL in Constructor
            var client = new RestClient(endpoint)
            {
                //Authenticator = new HttpBasicAuthenticator("SVC_AUT_MULE_Q", "abcd1234")
                Authenticator = new HttpBasicAuthenticator(Properties.Settings.Default.MuleServiceUserName, PasswordDecrypter.Decrypt(Properties.Settings.Default.MuleServicePassword))
            };

            //Set the Request based on the input method
            var request = GetEmailRequest(emailType, EmailGroupName);

            //Get the response by executing the request
            Thread.Sleep(2000);
            RestResponse response = (RestResponse)client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
                return response.Content.ToString();
            else
                return "no data found";
        }

        /// <summary>
        /// This method is use to get the Emaillist / SpecficEmail
        /// </summary>
        /// <param name="args"></param>
        /// <param name="arg1"></param>
        /// <param name="groupname"></param>
        /// <returns></returns>
        public RestRequest GetEmailRequest(string emailType, string groupname)
        {
            String resource = "";

            //Security Credentials
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;

            //Post Request
            if (emailType == "GetEmailList")
            {
                resource = @"https://modl-api4.nylaarp.newyorklife.com/0.1-m/insurance/documentupload/email-list";
            }
            else
            {
                resource = @"https://modl-api4.nylaarp.newyorklife.com/0.1-m/insurance/documentupload/email/" + emailType;
            }
            var request = new RestRequest(resource, Method.GET);

            ///// Add Headers and Parameters //////

            request.AddHeader("clientid", clientId);
            request.AddHeader("clientSecret", clientSecret);
            request.AddHeader("Connection", "Keep-Alive");
            request.AddHeader("TransRefGUID", "sdfsdfsd");  //Need to be unique
            request.AddHeader("user", groupname + "@newyorklife.com");
            request.AddHeader("Content-Type", "application/json");

            request.AddQueryParameter("folderName", "Inbox");
            request.AddQueryParameter("maxcount", "100");

            return request;
        }

        /// <summary>
        /// Method helps to make onetimepayment
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public string Makeonetimepayment(IWebDriver driver, Dictionary<string, string> data)
        {
            string status = "";
            RestServices webServices = new RestServices(data);
            try
            {
                double daysPastEFD = (Convert.ToDateTime(data[KeyRepository.LSPDate]) - Convert.ToDateTime(data[KeyRepository.PaidToDate])).TotalDays;
                if (daysPastEFD > 0)
                {
                    return status = webServices.SubmitRestCall("AddOneTimePayment");
                }
            }
            catch
            {
                GetSettor.failCounter++;
            }
            return status;
        }
       
        #region Revisit code
        /// <summary>
        /// Method to call rest service to fetch offers
        /// </summary>
        /// <param name="args"></param>
        public void GetOffersAPI(string args = "")
        {
            //Dummy method ----Please to work on this
        //    string GUID = Environment.MachineName + DateTime.Now.ToString("yyyyMMddHHmmss");

        //    //Create Client Object with URL in Constructor
        //    var client = new RestClient(endpoint)
        //    {
        //        //Authenticator = new HttpBasicAuthenticator("SVC_AUT_MULE_Q", "abcd1234")
        //        Authenticator = new HttpBasicAuthenticator(Properties.Settings.Default.MuleServiceUserName, PasswordDecrypter.Decrypt(Properties.Settings.Default.MuleServicePassword))
        //    };

        //    //Set the Request based on the input method
        //    var request = Request();

        //    //Get the response by executing the request
        //    Thread.Sleep(2000);
        //    RestResponse response = (RestResponse)client.Execute(request);

        //    if (response.StatusCode.ToString() == "NotFound")
        //    {
        //        NYLDSelenium.ReportStepResult("Get Offers API :" + endpoint, "Get offers API is not responding and response form service request is " + response.Content, "FAIL", "no", "yes");
        //    }

        //    //return response.Content.ToString();
        //    if (GetRestOutput(response.Content, args))
        //        data[KeyRepository.RiderFlag] = "True";
        //    else
        //        data[KeyRepository.RiderFlag] = "False";

        }
        ///// <summary>
        ///// Method to submit and retreive the webservices request, process and and return expected values
        ///// </summary>
        ///// <param name="method"></param>
        ///// <param name="exptime"></param>
        ///// <param name="desc"></param>
        ///// <returns></returns>
        public string SubmitWSCall(string method, string exptime = "10", string desc = "")
        {
        //    HttpWebRequest request = CreateWebRequest(method);

        //    //Credentials
        //    request.UseDefaultCredentials = true;
        //    request.PreAuthenticate = true;
        //    request.Credentials = CredentialCache.DefaultCredentials;


        //    XmlDocument soapEnvelopeXml = new XmlDocument();

        //    Console.WriteLine("Exp time is " + exptime);
        //    CSWData.XML = "";
        //    CSWData.XML = Request(method, exptime, desc);
        //    soapEnvelopeXml.LoadXml(CSWData.XML);


        //    using (Stream stream = request.GetRequestStream())
        //    {
        //        soapEnvelopeXml.Save(stream);
        //    }

        //    try
        //    {
        //        using (WebResponse response = request.GetResponse())
        //        {
        //            using (StreamReader rd = new StreamReader(response.GetResponseStream()))
        //            {
        //                string soapResult = rd.ReadToEnd();
        //                Console.WriteLine(soapResult);
        //                return GetWSOutput(method, soapResult);
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        NYLDSelenium.ReportStepResult("Webservices error encountered for: " + method, "Web service error encountered with the message: " + e, "Fail", "onerror", "yes");
                return "";
        }
     
        #endregion

    }
}

