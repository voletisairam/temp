﻿using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class AddEFT
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public AddEFT(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }
        public  string AddEFTXML(string desc)
        {
            string ptc;
            if (desc == "")
            {
                desc = "Monthly";
                ptc = "4";
            }
            else
                ptc = "3";

            xml = (@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns=""http://ACORD.org/Standards/Life/2"">								
	                            <soapenv:Header/>							
	                            <soapenv:Body>						
                            <TXLife Version=""2.25.00"">
                                 <UserAuthRequest>										
		                            <UserLoginName>") + Environment.UserName + (@"</UserLoginName> 								
		                            <VendorApp>								
			                            <AppName>Customer Service Website</AppName>							
		                            </VendorApp>								
	                            </UserAuthRequest> 									
	                            <TXLifeRequest>					
		                            <TransRefGUID>NYL-c2248249-bb58-4965-a437-7d0f727ff2d0</TransRefGUID>				
		                            <TransType tc=""184"">Billing Change Information</TransType>				
		                            <BusinessService DataRep=""Full""/>				
		                            <TransExeDate>2014-07-08</TransExeDate> 				
		                            <TransExeTime>13:52:00-06:00</TransExeTime> 				
		                            <OLifE>				
			                            <SourceInfo>			
				                            <SourceInfoName>NYLAARP Website</SourceInfoName>		
			                            </SourceInfo>			
			                            <Holding id=""Holding_001"">
			                            <Authorization>
					                            <SignatureInfo>
						                            <SubmissionType tc=""4"">Phone</SubmissionType>
					                            </SignatureInfo>
				                            </Authorization>			
				                            <Policy id=""Policy_001"">		
					                            <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>	
					                            <CarrierCode>") + "AARP" + (@"</CarrierCode>	
					                            <PaymentMode tc=""") + ptc + (@""">") + desc + (@"</PaymentMode>	
					                            <PaymentMethod tc=""7"">Electronic Funds Transfer</PaymentMethod>	
				                            </Policy>		
				                            <Banking>		
					                            <BankAcctType tc=""2"">Checking</BankAcctType>	
					                            <AccountNumber>111000025</AccountNumber>	
					                            <RoutingNum>011103093</RoutingNum>	
				                            </Banking>		
			                            </Holding>			
		                            </OLifE>				
	                            </TXLifeRequest>					
                            </TXLife>
                            </soapenv:Body>							
                            </soapenv:Envelope>");

            return xml;

        }
    }
}
