﻿using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class ClassSurrenderValue
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public ClassSurrenderValue(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }
        public  string ClassSurrenderValueXml()
        {
            xml = (@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns=""http://ACORD.org/Standards/Life/2"">
                              <soapenv:Header/>
                              <soapenv:Body>
                                <TXLife>
                                 <TXLifeRequest>
                                  <TransRefGUID>Sample1</TransRefGUID >
                                    <TransType tc =""203""/>
                                    <OLifE>
                                     <Holding>
                                       <Policy>
                                        <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>
                                        <CarrierCode>AARP</CarrierCode>
                                       </Policy>
                                     </Holding>
                                    </OLifE>
                                 </TXLifeRequest>
                              </TXLife>
                           </soapenv:Body>
                         </soapenv:Envelope>");
            return xml;
        }
    }
}
