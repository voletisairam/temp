﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class GetRateResult
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public GetRateResult( Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }

        public  string GetRateResultXML()
        {
            xml = (@"<GetRateResult>
                              <MethodParameters>
                                <requestInfo>
                                  <CarrierCode>AARP</CarrierCode>
                                  <Gender>F</Gender>
                                  <LineofBusiness>LIFE</LineofBusiness>
                                  <MaxAge>55</MaxAge>
                                  <MaxCoverageAmt>50000</MaxCoverageAmt>
                                  <MinAge>55</MinAge>
                                  <MinCoverageAmt>50000</MinCoverageAmt>
                                  <ProductCode>LB10</ProductCode>
                                  <SmokerStatus >S</SmokerStatus>
                                  <State>FL</State>
                                </requestInfo>
                              </MethodParameters>
                            </GetRateResult>");
            return xml;
        }
    }
}
