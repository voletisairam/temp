﻿using CSW.Common.Excel;
using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace CSW.Common.Services.APIRequests
{
    class Payment_EFT
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public Payment_EFT(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }

        public string Payment_EFTXML()
        {
            xml = (@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns=""http://ACORD.org/Standards/Life/2"">
                            <soapenv:Header/>
                            <soapenv:Body>
                             <TXLife Version = ""2.13.00"">
                              <UserAuthRequest>
                                  <UserLoginName>""") + Environment.UserName + (@"""</UserLoginName>
                                  <VendorApp>
                                     <AppName>Customer Service Website</AppName>
                                 </VendorApp>
                               </UserAuthRequest>
                             <TXLifeRequest>
                           <TransRefGUID>208</TransRefGUID>
                        <TransType tc=""208"">New Business Submission</TransType>
                        <BusinessService DataRep=""View""/>
                        <TransExeDate>2014-05-20</TransExeDate>
                        <TransExeTime>10:48:40-08:00</TransExeTime>
                           <OLifE>
                             <Holding id=""Holding_0001"">
                                    <Policy>
                                       <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>
                                       <CarrierCode>AARP</CarrierCode>
                                    </Policy>
                                 </Holding>
                             </OLifE>
                          </TXLifeRequest>
                        </TXLife>
                     </soapenv:Body>
                   </soapenv:Envelope>");
            return xml;
        }

        public string PaymentModeEligibleXml()
        {
            CommonFunctions commonFunctions = new CommonFunctions(data);
            xml = (@"<soapenv:Envelope soapenv:encodingStyle=""http://schemas.xmlsoap.org/soap/encoding/"" xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns=""http://ACORD.org/Standards/Life/2"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:soap-enc=""http://schemas.xmlsoap.org/soap/encoding/"">
                            <soapenv:Header/>
                                <soapenv:Body>
                                    <TXLife>
                                        <TXLifeRequest>
                                        <TransRefGUID>Sample1</TransRefGUID>
                                            <TransType tc=""212""/>
                                                <OLifE>
                                                    <Holding>
                                                        <Policy>
                                                            <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>
                                                            <CarrierCode>AARP</CarrierCode>
                                                            <PaymentMethod tc=""7""/>
                                                            <PaymentMode tc=""4""/>
                                                            <EffDate>") +commonFunctions.Dateformat("YYYY-MM-DD", data[KeyRepository.EffectiveDate]) + (@"</EffDate>
                                                        </Policy>
                                                    </Holding>
                                                </OLifE>
                                        </TXLifeRequest>
                                  </TXLife>
                                </soapenv:Body>
                            </soapenv:Envelope> ");
            return xml;
        }

        /// <summary>
        /// Method helps to pay one time payment
        /// </summary>
        /// <returns></returns>
        public string OneTimePaymentXml()
        {
            TestData testData = new TestData();
            string BankRoutingNumber = testData.GetInputData("BankRoutingNumber");
            string BankAccountNumber = testData.GetInputData("BankAccountNumber");
            string futuredate = Convert.ToDateTime(data[KeyRepository.LSPDate]).AddDays(5).ToString("yyyy-MM-dd");
            xml = (@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"">
                            <soapenv:Header/>
                            <soapenv:Body>
                             <TXLife Version=""2.26.00"" xmlns=""http://ACORD.org/Standards/Life/2"">
                             <UserAuthRequest>
		                            <UserLoginName>") + Environment.UserName + (@"</UserLoginName> 								
                               <VendorApp>
                                <AppName>Customer Service Website</AppName>
                               </VendorApp>
                              </UserAuthRequest>
                        <TXLifeRequest>
                         <TransRefGUID>Sample1</TransRefGUID>
                           <TransType tc=""508"">Payment Transaction</TransType>
                           <TransExeDate>2015-01-24</TransExeDate>
                           <TransExeTime>13:52:00-06:00</TransExeTime>
                           <BusinessService DataRep =""Full""/>
                           <OLifE>
                               <SourceInfo>
                                   <SourceInfoName>Customer360</SourceInfoName>
                               </SourceInfo>
                                <Holding id=""Holding_001"">
                                 <Policy id=""Policy_001"">
                                    <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>
                                    <CarrierCode>AARP</CarrierCode>
                                    <FinancialActivity>
                                     <Payment>
                                      <PaymentForm tc =""6"">Personal Check</PaymentForm>
                                       <CheckDate>") + futuredate + (@"</CheckDate>  
                                        <PaymentAmt>50.00</PaymentAmt>
                                      </Payment>
                                      </FinancialActivity>
                                   </Policy>
                                 <Banking>
                                 <BankAcctType tc=""2"">Checking</BankAcctType>
                                  <AccountNumber>") + BankAccountNumber + (@"</AccountNumber>
                                  <RoutingNum>") + BankRoutingNumber + (@"</RoutingNum>
                                 </Banking>
                                 </Holding>
                                 <Party id=""Party_001"">                                  
                                <FullName>") + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + (@"</FullName>
                                 </Party>
                                 <Relation OriginatingObjectID=""Holding_001"" RelatedObjectID =""Party_001"" id=""Relation_001"">
                                   <OriginatingObjectType tc=""4"">Holding</OriginatingObjectType>
                                   <RelatedObjectType tc=""6"">Party</RelatedObjectType>
                                   <RelationRoleCode tc=""31"">Payer</RelationRoleCode>
                                </Relation>
                              </OLifE>
                            </TXLifeRequest>
                          </TXLife>
                         </soapenv:Body>
                         </soapenv:Envelope>");
            return xml;
        }
    }
}
