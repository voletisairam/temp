﻿using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class CyberFraudIndicator
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";


        //GetBeneInfo() -- PartyKey 
        public CyberFraudIndicator(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }
        public string InsertCyberFraudIndicatorXml()
        {
            string Transdate = Convert.ToDateTime(data[KeyRepository.LSPDate]).ToString("yyyy-MM-dd");
            xml = (@"<soapenv:Envelope xmlns:soapenv = ""http://schemas.xmlsoap.org/soap/envelope/"" xmlns = ""http://ACORD.org/Standards/Life/2"" >   
                <soapenv:Header/>    
                 <soapenv:Body>     
                  <TXLife Version=""2.25.00"">      
                   <TXLifeRequest>      
                   <TransRefGUID>Insert Cyber Fraud Indicator</TransRefGUID>         
                      <TransType tc=""186""/>          
                       <TransExeDate>") + Transdate + (@"</TransExeDate>          
                       <TransExeTime>13:52:00-06:00</TransExeTime>              
                            <BusinessService DataRep=""FULL""/>                
                             <ProcessingInstruction>                
                             <OLifEExtension VendorCode=""08"" ExtensionCode=""SuppressNote"">N</OLifEExtension>                   
                                </ProcessingInstruction>                   
                                <OLifE>                   
                                <SourceInfo>                   
                                <SourceInfoName>LSP</SourceInfoName>                   
                                </SourceInfo>                                            
                                <Party id=""Party_1"">                    
                                 <RestrictionInfo DataRep=""Full"">                     
                                  <RestrictionCode tc=""37""/>                      
                                   <RestrictionReason tc=""45""/>                       
                                       <OLifEExtension VendorCode=""08"" ExtensionCode=""FraudSystem"">CSW</OLifEExtension>                          
                                       </RestrictionInfo>                          
                                       <PartyKey>") + data[KeyRepository.ClientIdOfPolicy] + (@"</PartyKey>                          
                                       <Person>                         
                                       <FirstName>") + data[KeyRepository.FirstName] + (@"</FirstName>                          
                                       <LastName>") + data[KeyRepository.LastName] + (@"</LastName>                          
                                       </Person>                          
                                       </Party>                          
                                       <Activity id=""Activity_001"">                           
                                        <ActivityTypeCode tc=""16"">Change Party</ActivityTypeCode>                                
                                             <Opened>") + DateTime.Today.ToString("yyyy-MM-dd") + (@"</Opened>                                
                                                 <OpenedTime>20:12:12</OpenedTime>   
		                                        <UserCode>") + Environment.UserName + (@"</UserCode>                            
                                                </Activity>                                   
                                                </OLifE>                                   
                                                </TXLifeRequest>                                   
                                                </TXLife>                                   
                                                </soapenv:Body>
                                                </soapenv:Envelope>");
            return xml;
        }

        public string RemoveCyberFraudIndicatorXml()
        {
            string Transdate = Convert.ToDateTime(data[KeyRepository.LSPDate]).ToString("yyyy-MM-dd");
            xml = (@"<soapenv:Envelope xmlns:soapenv = ""http://schemas.xmlsoap.org/soap/envelope/"" xmlns = ""http://ACORD.org/Standards/Life/2"" >   
                <soapenv:Header/>    
                 <soapenv:Body>     
                  <TXLife Version =""2.25.00"">      
                   <TXLifeRequest>      
                   <TransRefGUID>Update Cyber Fraud Indicator</TransRefGUID>         
                      <TransType tc =""186""/>          
                       <TransExeDate>") + Transdate + (@"</TransExeDate>          
                       <TransExeTime>13:52:00-06:00</TransExeTime>               
                            <BusinessService DataRep =""Full""/>                
                             <ProcessingInstruction>                
                             <OLifEExtension VendorCode =""08"" ExtensionCode =""SuppressNote"">N</OLifEExtension>                   
                                </ProcessingInstruction>                   
                                <OLifE>                   
                                <SourceInfo>                   
                                <SourceInfoName>LSP</SourceInfoName>                   
                                </SourceInfo>
                                <Party id=""Party_1"">                    
                                 <RestrictionInfo DataRep =""Remove"">                     
                                  <RestrictionCode tc=""37""/>                      
                                   <RestrictionReason tc =""45"" />
                                    <OLifEExtension VendorCode =""08"" ExtensionCode =""FraudSystem"">CSW</OLifEExtension>
                                       </RestrictionInfo>                          
                                       <PartyKey>") + data[KeyRepository.ClientIdOfPolicy] + (@"</PartyKey>                          
                                       <Person>                         
                                       <FirstName>") + data[KeyRepository.FirstName] + (@"</FirstName>                          
                                       <LastName>") + data[KeyRepository.LastName] + (@"</LastName>                          
                                       </Person>                          
                                       </Party>                          
                                       <Activity id =""Activity_001"">                           
                                        <ActivityTypeCode tc = ""16"">Change Party</ActivityTypeCode>                                
                                             <Opened>") + DateTime.Today.ToString("yyyy-MM-dd").Trim() + (@"</Opened>                                
                                                 <OpenedTime>20:12:12</OpenedTime >   
		                                        <UserCode>") + Environment.UserName + (@"</UserCode>                            
                                                </Activity>                                   
                                                </OLifE>                                   
                                                </TXLifeRequest>                                   
                                                </TXLife>                                   
                                                </soapenv:Body>
                                                </soapenv:Envelope>");
            return xml;
        }

    }
}
