﻿using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class UpdatePartyPayFrequency
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public UpdatePartyPayFrequency(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }

        public string UpdatePartyPayFrequencyXML(string changeReq)
        {
            string ptc;
            if (changeReq == "Monthly")
            {
                changeReq = "Monthly";
                ptc = "4";
            }
            else
            {
                ptc = "3";
                changeReq = "Quarterly";
            }

            string dtConv = DateTime.Now.AddMinutes(-5).ToString(@"MM/dd/yyyy hh:mm tt");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// General Info Section ////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            xml = (@"<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"">
                                               <SOAP-ENV:Header/>
                                               <SOAP-ENV:Body>
                                                  <TXLife Version=""2.26.00"" xmlns=""http://ACORD.org/Standards/Life/2"">
                                                     <UserAuthRequest>
                                                        <VendorApp>
                                                           <AppName>Customer Service WebSite</AppName>
                                                        </VendorApp>
                                                        <UserLoginName>") + Environment.UserName + (@"</UserLoginName>
                                                     </UserAuthRequest>
                                                     <TXLifeRequest>
                                                        <TransRefGUID>Relation_Change-000000001</TransRefGUID>
                                                        <TransType tc=""184"">Billing Change Information</TransType>
                                                        <BusinessService DataRep=""Partial""/>
                                                        <TransExeDate>") + DateTime.Today.ToString("yyyy-MM-dd") + (@"</TransExeDate>
                                                         <OLifE>				
			                            <SourceInfo>			
				                            <SourceInfoName>NYLAARP Website</SourceInfoName>		
			                            </SourceInfo>			
			                            <Holding id=""Holding_001"">
				                            <Policy id=""Policy_001"">		
					                            <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>	
					                            <CarrierCode>") + "AARP" + (@"</CarrierCode>	
					                            <PaymentMode tc=""") + ptc + (@""">") + changeReq + (@"</PaymentMode>	
				                            </Policy>	
			                            </Holding>			
		                            </OLifE>
                                </TXLifeRequest>					
                            </TXLife>
                             </SOAP-ENV:Body>
                               </SOAP-ENV:Envelope>");
            return xml;
        }
    }
}
