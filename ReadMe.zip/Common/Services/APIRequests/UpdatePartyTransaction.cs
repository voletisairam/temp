﻿using CSW.Common.Excel;
using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class UpdatePartyTransaction
    {
        public static string xml;
        public static IWebDriver driver;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public UpdatePartyTransaction(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            xml = "";
        }
        public static string UpdatePartyTranscationXml()
        {
            string dtConv = DateTime.Now.AddMinutes(-5).ToString(@"MM/dd/yyyy hh:mm tt");
            DateTime date = DateTime.ParseExact(dtConv, @"yyyy-MM-dd hh:mm tt", new CultureInfo("en-US"));
            string updatepartyInfo;
            string partysectionInfo;
            string relationsectionInfo;
            string endingsectionInfo;
            string activitysectionInfo;
            TestData testData = new TestData();


            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// General Info Section ////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            updatepartyInfo = (@"<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"">
                                               <SOAP-ENV:Header/>
                                               <SOAP-ENV:Body>
                                                  <TXLife Version=""2.26.00"" xmlns=""http://ACORD.org/Standards/Life/2"">
                                                     <UserAuthRequest>
                                                        <VendorApp>
                                                           <AppName>Customer Service WebSite</AppName>
                                                        </VendorApp>
                                                        <UserLoginName>") + Environment.UserName + (@"</UserLoginName>
                                                     </UserAuthRequest>
                                                     <TXLifeRequest>
                                                        <TransRefGUID>Relation_Change-000000001</TransRefGUID>
                                                        <TransType tc=""186"">Holding CHange - Relation Change Request</TransType>
                                                        <TransExeDate>") + DateTime.Today.ToString("yyyy-MM-dd") + (@"</TransExeDate>
                                                       <TransSubType tc=""18606""/>
                                                        <ChangeSubType ChangeID=""Party_001"">
                                                           <TranContentCode tc=""2"">update</TranContentCode>
                                                           <ChangeTC tc=""22"">Relationship Change</ChangeTC>
                                                        </ChangeSubType>
                                                        <ProcessingInstruction>	
														<OLifEExtension VendorCode=""08"" ExtensionCode=""SuppressNote"">N</OLifEExtension>	
                                                        </ProcessingInstruction>
                                                        < OLifE >
                                                           < Holding id = ""Holding_1"" >
                                                                 < Policy >   
                                                                    < PolNumber > ") + data[KeyRepository.PolicyNumber] + (@" </ PolNumber >   
                                                                    < CarrierCode > AARP </ CarrierCode >   
                                                                 </ Policy >   
                                                       </ Holding > ");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Party Info Section   ////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // Set the counter to zero
            int bncount1 = 1;
            int rlcount1 = 1;
            int extbenecount1 = 0;
            //Set Party Section as Empty
            partysectionInfo = "";


            //Get Existing Bene counts
            int BN11 = 0;
            int BN21 = 0;
            int BN31 = 0;


            //IRB = IRB + Regex.Matches(desc, "IRB").Count;
            BN11 = BN11 + Regex.Matches(desc, "BN1").Count + Regex.Matches(desc, "IRB").Count;
            BN21 = BN21 + Regex.Matches(desc, "BN2").Count;
            BN31 = BN31 + Regex.Matches(desc, "BN3").Count;

            double everyBN1Pct1 = 0;
            double finalBN1percent1 = 0;
            double everyBN2Pct1 = 0;
            double finalBN2percent1 = 0;
            double everyBN3Pct1 = 0;
            double finalBN3percent1 = 0;
            //double everyIRBPct = 0;
            //double finalIRBpercent = 0;

            if (BN11 != 0)
            {
                everyBN1Pct1 = 100 / BN11;
                everyBN1Pct1 = Math.Round(everyBN1Pct1, 2);
                finalBN1percent1 = 100 - everyBN1Pct1 * (BN11 - 1);
            }

            if (BN21 != 0)
            {
                everyBN2Pct1 = 100 / BN21;
                everyBN2Pct1 = Math.Round(everyBN2Pct1, 2);
                finalBN2percent1 = 100 - everyBN2Pct1 * (BN21 - 1);
            }

            if (BN31 != 0)
            {
                everyBN3Pct1 = 100 / BN31;
                everyBN3Pct1 = Math.Round(everyBN3Pct1, 2);
                finalBN3percent1 = 100 - everyBN3Pct1 * (BN31 - 1);
            }

            //Get New Bene counts & New Data Info                    
            string[] NewBeneDt1;
            NewBeneDt1 = desc.Split(';');
            Console.WriteLine(" The lenght  of array is " + NewBeneDt1.GetLength(0));

            // Add Party info - For New Benes
            for (int i = 0; i <= NewBeneDt1.Count() - 1; i++)
            {
                string[] NewBeneInfo;

                //Get Bene Info for each
                NewBeneInfo = NewBeneDt1[i].Split('|');

                //Check the Type of Bene Info
                switch (NewBeneInfo[0])
                {
                    case "Person":
                    case "Estate":
                    case "Trust":
                    case "FuneralHome":
                        string[] PersonDt;
                        CommonFunctions CF1 = new CommonFunctions(data);
                        PersonDt = CF1.RandData("Person", i).Split('/');

                        Console.WriteLine(PersonDt[0]);
                        Console.WriteLine(PersonDt[1]);
                        Console.WriteLine(PersonDt[2]);
                        Console.WriteLine(PersonDt[3]);
                        Console.WriteLine(PersonDt[4]);

                        partysectionInfo = partysectionInfo + Environment.NewLine +
                            (@"<Party id=""Party_00") + bncount1.ToString() +
                                  (@"""><PartyTypeCode tc=""1""/>
                                                        <GovtID>") + CF1.RandData("SSN", i) + (@"</GovtID>
                                                       <GovtIDTC tc=""1""/>
                                                       <Person>
                                                         <FirstName>") + PersonDt[1] + (@"</FirstName>
                                                         <LastName>") + PersonDt[3] + (@"</LastName>
                                                         <MiddleName>") + PersonDt[2] + (@"</MiddleName>
                                                         <Prefix>") + PersonDt[0] + (@"</Prefix>
                                                         <MarStat tc=""1"">") + PersonDt[5] + (@"</MarStat>
                                                         <Gender tc=""2"">") + PersonDt[4] + (@"</Gender>
                                                         <BirthDate>") + "1966-07-24" + (@"</BirthDate>
                                                         <BirthJurisdictionTC tc=""12"">") + "FL" + (@"</BirthJurisdictionTC>
                                                       </Person>");
                        break;
                    case "Organization":
                    case "Business":
                        CommonFunctions CF2 = new CommonFunctions(data);
                        partysectionInfo = partysectionInfo + Environment.NewLine + (@"<Party id=""Party_00") + bncount1.ToString() +
                              (@"""><PartyTypeCode tc=""2""/>
                                                        <GovtID>") + CF2.RandData("TID", i) + (@"</GovtID>
                                                        <GovtIDTC tc=""2""/>
                                                     <FullName>") + CF2.RandData("Organization", i) + (@"</FullName>");
                        break;
                }

                //Address Info
                string condition = "";
                if (NewBeneInfo.Count() > 4)
                    condition = NewBeneInfo[4].Trim();
                if (!condition.Contains("NoAddress"))
                {
                    string[] AddressDt;
                    string stateTypeCode = "";
                    CommonFunctions CF3 = new CommonFunctions(data);
                    AddressDt = CF3.RandData("Address", i).Split('/');
                    stateTypeCode = testData.GetMappedValue("TypeCode", AddressDt[3].Trim());

                    partysectionInfo = partysectionInfo + Environment.NewLine +
                                     (@"<Address id=""Address_00") + bncount1.ToString() + (@""">
                                                  <Line1>") + AddressDt[0] + (@"</Line1>
                                                  <City>") + AddressDt[2] + (@"</City>
                                                  <AddressStateTC tc=""" + stateTypeCode + "\">") + AddressDt[3] + (@"</AddressStateTC>
                                                  <Zip>") + AddressDt[4] + (@"</Zip>
                                                  <AddressCountryTC tc=""1"">") + AddressDt[5] + (@"</AddressCountryTC>
                                                </Address>");
                }

                if (!condition.Contains("NoPhone"))
                {
                    string phone;
                    CommonFunctions CF4 = new CommonFunctions(data);
                    phone = CF4.RandData("Phone", i);

                    partysectionInfo = partysectionInfo + Environment.NewLine +
                                     (@"<Phone id=""Phone_00") + bncount1.ToString() + (@""">
                                                   <PhoneTypeCode tc=""1"">Home</PhoneTypeCode>
                                                   <DialNumber>") + phone + (@"</DialNumber>
                                                </Phone>");
                }

                partysectionInfo = partysectionInfo + Environment.NewLine +
                             (@"<EMailAddress id=""EMail_00") + bncount1.ToString() + (@""">
                                                   <AddrLine>") + "QATESTER@mail.com" + (@"</AddrLine>
                                                </EMailAddress>
                                                <Attachment id=""Attachment_00") + bncount1.ToString() + (@""">
                                                  <AttachmentType tc=""14"">General Note</AttachmentType>
                                                  <!--Client Notes-->
                                                  <AttachmentData>CSW Automation</AttachmentData>
                                                </Attachment>
                                         </Party>");
                bncount1++;
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Relation Info Section   /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            //Set the Relation Info Section to Empty
            relationsectionInfo = "";
            double everybenepercent1 = 0;
            double finalbenepercent1 = 0;
            string benepercnt1 = "";

            int bn11ct = 0;
            int bn21ct = 0;
            int bn31ct = 0;
            //int irbct = 0;
            //Get the total number of Benes - New and existing
            int nbcount1 = extbenecount1 + NewBeneDt1.Count();
            everybenepercent1 = 100 / nbcount1;
            everybenepercent1 = Math.Round(everybenepercent1, 2);
            finalbenepercent1 = 100 - everybenepercent1 * (nbcount1 - 1);

            // Add Relation info - For New Benes
            for (int i = 0; i <= NewBeneDt1.Count() - 1; i++)
            {
                Console.WriteLine("Mapped values is " + testData.GetMappedValue("Relation", "Spouse"));
                string[] NewBeneInfo;

                //Get the Bene Info for each Bene
                NewBeneInfo = NewBeneDt1[i].Split('|');

                switch (NewBeneInfo[1])
                {
                    case "IRB":
                    case "BN1":
                        bn11ct++;
                        if ((bn11ct == BN11) && (extbenecount1 == 0))
                            benepercnt1 = String.Format("{0:0.00}", finalBN1percent1);
                        else
                            benepercnt1 = String.Format("{0:0.00}", everyBN1Pct1);

                        break;

                    case "BN2":
                        bn21ct++;
                        if ((bn21ct == BN21) && (extbenecount1 == 0))
                            benepercnt1 = String.Format("{0:0.00}", finalBN2percent1);
                        else
                            benepercnt1 = String.Format("{0:0.00}", everyBN2Pct1);
                        break;

                    case "BN3":
                        bn31ct++;
                        if ((bn31ct == BN31) && (extbenecount1 == 0))
                            benepercnt1 = String.Format("{0:0.00}", finalBN3percent1);
                        else
                            benepercnt1 = String.Format("{0:0.00}", everyBN3Pct1);
                        break;
                }

                relationsectionInfo = relationsectionInfo + Environment.NewLine +
                          (@"<Relation id=""Relation_00") + rlcount1.ToString() + (@""" OriginatingObjectID=""Holding_1"" RelatedObjectID=""Party_00") + rlcount1.ToString() + (@""">
                                      <OriginatingObjectType tc=""4""/>
                                        <RelationRoleCode tc=""") + testData.GetMappedValue("BeneType", NewBeneInfo[1]) + (@""">") + NewBeneInfo[1] + (@"</RelationRoleCode>
                                         <!--BN1-->
                                         <RelationDescription tc=""") + testData.GetMappedValue("Relation", NewBeneInfo[3]) + (@"""/>
                                         <RelatedObjectType tc=""6""/>
                                         <InterestPercent>") + benepercnt1 + (@"</InterestPercent>");

                if (NewBeneInfo[1] == "IRB")
                {
                    relationsectionInfo = relationsectionInfo + Environment.NewLine + (@"<IrrevokableInd tc = """) + "1" + (@""" />
                                                      <KeyedValue>
                                                        <KeyName>RelationInfo</KeyName>
                                                        <KeyValue>Spouse</KeyValue>
                                                      </KeyedValue>");
                }

                relationsectionInfo = relationsectionInfo + Environment.NewLine +
                                   (@"</Relation>");
                rlcount1++;
            }

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Activity Info Section   /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            activitysectionInfo = (@"<Activity id=""Activity_001"">
                            <ActivityTypeCode tc = ""16"" > Change Party </ ActivityTypeCode>
                            <Opened > 2012 - 01 - 24 </ Opened >
                     <OpenedTime > 20:12:12 </ OpenedTime >
                            <UserCode> ") + Environment.UserName + (@"</ UserCode >
                            </Activity >");




            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Relation Info Section   /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            endingsectionInfo = (@"</OLifE>
                                          </TXLifeRequest>
                                        </TXLife>
                                    </SOAP-ENV:Body>
                               </SOAP-ENV:Envelope>");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// All Sections            /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            xml = updatepartyInfo + partysectionInfo + relationsectionInfo + activitysectionInfo + endingsectionInfo;
            return xml;

        }
    }
}
