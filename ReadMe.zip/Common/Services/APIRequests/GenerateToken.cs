﻿using CSW.Common.Others;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;

namespace CSW.Common.Services.APIRequests
{
    
    class GenerateToken : WebBrowser
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public GenerateToken(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }
        public  string  GenerateTokenXML()
        {
            xml = (@"<soapenv:Envelope xmlns:soapenv=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:nyl=""http://NYLDirect.CSL.Service"">
		    	               <soapenv:Header/>
		    	                    <soapenv:Body>  
		   	                          <nyl:GenerateConfirmationToken> 
		   	                              <nyl:userName>") + data[KeyRepository.UserName] + (@"</nyl:userName>
		                                  <nyl:tokenExpirationInMinutesFromNow>") + exptime + (@"</nyl:tokenExpirationInMinutesFromNow>
		                              </nyl:GenerateConfirmationToken>
		                            </soapenv:Body> 
		                       </soapenv:Envelope>");
            return xml;
        }
        
    }
}
