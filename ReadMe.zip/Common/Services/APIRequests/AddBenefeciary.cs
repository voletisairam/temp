﻿using CSW.Common.Excel;
using CSW.Common.Others;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    class AddBenefeciary
    {
        public static string xml;
        public static Dictionary<string, string> data;
        public static string exptime = "10";
        public static string desc = "";

        public AddBenefeciary(Dictionary<string, string> testdata)
        {
            data = testdata;
            xml = "";
        }
        public  string AddBenefeciaryXML(string desc)
        {
            string policysection;
            string partysection;
            string relationsection;
            string endingsection;

            TestData testData = new TestData();


            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// General Info Section ////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            policysection = (@"<SOAP-ENV:Envelope xmlns:SOAP-ENV=""http://schemas.xmlsoap.org/soap/envelope/"">
                                               <SOAP-ENV:Header/>
                                               <SOAP-ENV:Body>
                                                  <TXLife Version=""2.26.00"" xmlns=""http://ACORD.org/Standards/Life/2"">
                                                     <UserAuthRequest>
                                                        <VendorApp>
                                                           <AppName>Customer Service WebSite</AppName>
                                                        </VendorApp>
                                                        <UserLoginName>") + Environment.UserName + (@"</UserLoginName>
                                                     </UserAuthRequest>
                                                     <TXLifeRequest>
                                                        <TransRefGUID>Relation_Change-000000001</TransRefGUID>
                                                        <TransType tc=""502"">Holding CHange - Relation Change Request</TransType>
                                                        <TransExeDate>") + DateTime.Today.ToString("yyyy-MM-dd") + (@"</TransExeDate>
                                                       <TransSubType tc=""50204""/>
                                                        <ChangeSubType ChangeID=""Party_001"">
                                                           <TranContentCode tc=""2"">update</TranContentCode>
                                                           <ChangeTC tc=""22"">Relationship Change</ChangeTC>
                                                        </ChangeSubType>
                                                        <OLifE>
                                                           <Holding id=""Holding_1"">
                                                              <Policy>
                                                                 <PolNumber>") + data[KeyRepository.PolicyNumber] + (@"</PolNumber>
                                                                 <CarrierCode>AARP</CarrierCode>
                                                              </Policy>
                                                           </Holding>");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Party Info Section   ////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // Set the counter to zero
            int bncount = 1;
            int rlcount = 1;
            int extbenecount = 0;
            //Set Party Section as Empty
            partysection = "";


            //Get Existing Bene counts
            int BN1 = 0;
            int BN2 = 0;
            int BN3 = 0;

            //Juan
            //for (int i = 0; i < CSWData.BeneInfo.Count ; i++)
            //{
            //    switch (CSWData.BeneInfo[i][2])
            //    {
            //        case "IRB":
            //         //   IRB++;
            //        //    break;
            //        case "BN1":
            //            BN1++;
            //            break;
            //        case "BN2":
            //            BN2++;
            //            break;
            //        case "BN3":
            //            BN3++;
            //            break;
            //    }
            //}

            //IRB = IRB + Regex.Matches(desc, "IRB").Count;
            BN1 = BN1 + Regex.Matches(desc, "BN1").Count + Regex.Matches(desc, "IRB").Count;
            BN2 = BN2 + Regex.Matches(desc, "BN2").Count;
            BN3 = BN3 + Regex.Matches(desc, "BN3").Count;

            double everyBN1Pct = 0;
            double finalBN1percent = 0;
            double everyBN2Pct = 0;
            double finalBN2percent = 0;
            double everyBN3Pct = 0;
            double finalBN3percent = 0;
            //double everyIRBPct = 0;
            //double finalIRBpercent = 0;

            if (BN1 != 0)
            {
                everyBN1Pct = 100 / BN1;
                everyBN1Pct = Math.Round(everyBN1Pct, 2);
                finalBN1percent = 100 - everyBN1Pct * (BN1 - 1);
            }

            if (BN2 != 0)
            {
                everyBN2Pct = 100 / BN2;
                everyBN2Pct = Math.Round(everyBN2Pct, 2);
                finalBN2percent = 100 - everyBN2Pct * (BN2 - 1);
            }

            if (BN3 != 0)
            {
                everyBN3Pct = 100 / BN3;
                everyBN3Pct = Math.Round(everyBN3Pct, 2);
                finalBN3percent = 100 - everyBN3Pct * (BN3 - 1);
            }

            //if (IRB != 0)
            //{
            //    everyIRBPct = 100 / IRB;
            //    everyIRBPct = Math.Round(everyIRBPct, 2);
            //    finalIRBpercent = 100 - everyIRBPct * (IRB - 1);
            //}

            //Get New Bene counts & New Data Info                    
            string[] NewBeneDt;
            NewBeneDt = desc.Split(';');
            Console.WriteLine(" The lenght  of array is " + NewBeneDt.GetLength(0));

            // Add Party info - For New Benes
            for (int i = 0; i <= NewBeneDt.Count() - 1; i++)
            {
                string[] NewBeneInfo;

                //Get Bene Info for each
                NewBeneInfo = NewBeneDt[i].Split('|');

                //Check the Type of Bene Info
                switch (NewBeneInfo[0])
                {
                    case "Person":
                   
                        string[] PersonDt;
                        CommonFunctions CF1 = new CommonFunctions(data);
                        PersonDt = CF1.RandData("Person", i).Split('/');

                        Console.WriteLine(PersonDt[0]);
                        Console.WriteLine(PersonDt[1]);
                        Console.WriteLine(PersonDt[2]);
                        Console.WriteLine(PersonDt[3]);
                        Console.WriteLine(PersonDt[4]);

                        partysection = partysection + Environment.NewLine +
                            (@"<Party id=""Party_00") + bncount.ToString() +
                                  (@"""><PartyTypeCode tc=""1""/>
                                                        <GovtID>") + CF1.RandData("SSN", i) + (@"</GovtID>
                                                       <GovtIDTC tc=""1""/>
                                                       <Person>
                                                         <FirstName>") + PersonDt[1] + (@"</FirstName>
                                                         <LastName>") + PersonDt[3] + (@"</LastName>
                                                         <MiddleName>") + PersonDt[2] + (@"</MiddleName>
                                                         <Prefix>") + PersonDt[0] + (@"</Prefix>
                                                         <MarStat tc=""1"">") + PersonDt[5] + (@"</MarStat>
                                                         <Gender tc=""2"">") + PersonDt[4] + (@"</Gender>
                                                         <BirthDate>") + "1966-07-24" + (@"</BirthDate>
                                                         <BirthJurisdictionTC tc=""12"">") + "FL" + (@"</BirthJurisdictionTC>
                                                       </Person>");
                        break;

                   
                    case "Estate":
                    case "Trust":
                   

                        CommonFunctions CF2 = new CommonFunctions(data);
                        partysection = partysection + Environment.NewLine + (@"<Party id=""Party_00") + bncount.ToString() +
                              (@"""><PartyTypeCode tc=""2""/>
                                                        <GovtID>") + CF2.RandData("TID", i) + (@"</GovtID>
                                                        <GovtIDTC tc=""2""/>
                                                     <FullName>") + NewBeneInfo[0] + (@"</FullName>");
                        break;
                    case "Organization":
                    case "Business":
                    case "FuneralHome":

                        CommonFunctions CF3 = new CommonFunctions(data);
                        partysection = partysection + Environment.NewLine + (@"<Party id=""Party_00") + bncount.ToString() +
                              (@"""><PartyTypeCode tc=""2""/>
                                                        <GovtID>") + CF3.RandData("TID", i) + (@"</GovtID>
                                                        <GovtIDTC tc=""2""/>
                                                     <FullName>") + CF3.RandData("Organization", i) + (@"</FullName>");
                        break;
                }

                //Address Info
                string condition = "";
                if (NewBeneInfo.Count() > 4)
                    condition = NewBeneInfo[4].Trim();
                if (!condition.Contains("NoAddress"))
                {
                    string[] AddressDt;
                    string stateTypeCode = "";
                    CommonFunctions CF4 = new CommonFunctions(data);
                    AddressDt = CF4.RandData("Address", i).Split('/');
                    stateTypeCode = testData.GetMappedValue("TypeCode", AddressDt[3].Trim());

                    partysection = partysection + Environment.NewLine +
                                     (@"<Address id=""Address_00") + bncount.ToString() + (@""">
                                                  <Line1>") + AddressDt[0] + (@"</Line1>
                                                  <City>") + AddressDt[2] + (@"</City>
                                                  <AddressStateTC tc=""" + stateTypeCode + "\">") + AddressDt[3] + (@"</AddressStateTC>
                                                  <Zip>") + AddressDt[4] + (@"</Zip>
                                                  <AddressCountryTC tc=""1"">") + AddressDt[5] + (@"</AddressCountryTC>
                                                </Address>");
                }

                if (!condition.Contains("NoPhone"))
                {
                    string phone;
                    CommonFunctions CF5 = new CommonFunctions(data);
                    phone = CF5.RandData("Phone", i);

                    partysection = partysection + Environment.NewLine +
                                     (@"<Phone id=""Phone_00") + bncount.ToString() + (@""">
                                                   <PhoneTypeCode tc=""1"">Home</PhoneTypeCode>
                                                   <DialNumber>") + phone + (@"</DialNumber>
                                                </Phone>");
                }

                partysection = partysection + Environment.NewLine +
                             (@"<EMailAddress id=""EMail_00") + bncount.ToString() + (@""">
                                                   <AddrLine>") + "QATESTER@mail.com" + (@"</AddrLine>
                                                </EMailAddress>
                                                <Attachment id=""Attachment_00") + bncount.ToString() + (@""">
                                                  <AttachmentType tc=""14"">General Note</AttachmentType>
                                                  <!--Client Notes-->
                                                  <AttachmentData>CSW Automation</AttachmentData>
                                                </Attachment>
                                         </Party>");
                bncount++;
            }


            // Add Party info - Client ID for existing Benes
            //for (int i = 0; i < CSWData.BeneInfo.Count; i++)
            //{
            //    partysection = partysection + Environment.NewLine + (@"<Party id=""Party_00") + bncount.ToString() + (@"""><PartyKey>") + CSWData.BeneInfo[i][13] + ("</PartyKey>  </Party>");
            //    bncount++;
            //    extbenecount++;
            //}

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Relation Info Section   /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            //Set the Relation Info Section to Empty
            relationsection = "";
            double everybenepercent = 0;
            double finalbenepercent = 0;
            string benepercnt = "";

            int bn1ct = 0;
            int bn2ct = 0;
            int bn3ct = 0;
            //int irbct = 0;
            //Get the total number of Benes - New and existing
            int nbcount = extbenecount + NewBeneDt.Count();
            everybenepercent = 100 / nbcount;
            everybenepercent = Math.Round(everybenepercent, 2);
            finalbenepercent = 100 - everybenepercent * (nbcount - 1);

            // Add Relation info - For New Benes
            for (int i = 0; i <= NewBeneDt.Count() - 1; i++)
            {
                Console.WriteLine("Mapped values is " + testData.GetMappedValue("Relation", "Spouse"));
                string[] NewBeneInfo;

                //Get the Bene Info for each Bene
                NewBeneInfo = NewBeneDt[i].Split('|');

                switch (NewBeneInfo[1])
                {
                    case "IRB":
                    case "BN1":
                        bn1ct++;
                        if ((bn1ct == BN1) && (extbenecount == 0))
                            benepercnt = String.Format("{0:0.00}", finalBN1percent);
                        else
                            benepercnt = String.Format("{0:0.00}", everyBN1Pct);

                        break;

                    case "BN2":
                        bn2ct++;
                        if ((bn2ct == BN2) && (extbenecount == 0))
                            benepercnt = String.Format("{0:0.00}", finalBN2percent);
                        else
                            benepercnt = String.Format("{0:0.00}", everyBN2Pct);
                        break;

                    case "BN3":
                        bn3ct++;
                        if ((bn3ct == BN3) && (extbenecount == 0))
                            benepercnt = String.Format("{0:0.00}", finalBN3percent);
                        else
                            benepercnt = String.Format("{0:0.00}", everyBN3Pct);
                        break;

                        //    case "IRB":

                        //        irbct++;

                        //        if ((irbct == IRB)&& (extbenecount == 0))
                        //            benepercnt = String.Format("{0:0.00}", finalIRBpercent);
                        //        else
                        //            benepercnt = String.Format("{0:0.00}", everyIRBPct);
                        //        break;
                }

                relationsection = relationsection + Environment.NewLine +
                          (@"<Relation id=""Relation_00") + rlcount.ToString() + (@""" OriginatingObjectID=""Holding_1"" RelatedObjectID=""Party_00") + rlcount.ToString() + (@""">
                                      <OriginatingObjectType tc=""4""/>
                                        <RelationRoleCode tc=""") + testData.GetMappedValue("BeneType", NewBeneInfo[1]) + (@""">") + NewBeneInfo[1] + (@"</RelationRoleCode>
                                         <!--BN1-->
                                         <RelationDescription tc=""") + testData.GetMappedValue("Relation", NewBeneInfo[3]) + (@"""/>
                                         <RelatedObjectType tc=""6""/>
                                         <InterestPercent>") + benepercnt + (@"</InterestPercent>");

                if (NewBeneInfo[1] == "IRB")
                {
                    relationsection = relationsection + Environment.NewLine + (@"<IrrevokableInd tc = """) + "1" + (@""" />
                                                      <KeyedValue>
                                                        <KeyName>RelationInfo</KeyName>
                                                        <KeyValue>Spouse</KeyValue>
                                                      </KeyedValue>");
                }

                relationsection = relationsection + Environment.NewLine +
                                   (@"</Relation>");
                rlcount++;
            }

            //If Existing Benes are odd
            // Add Relation info - Client ID for existing Benes
            //for (int i = 0; i < CSWData.BeneInfo.Count; i++)
            //{
            //    switch (CSWData.BeneInfo[i][2])
            //    {
            //        case "BN1":
            //        case "IRB":
            //            bn1ct++;

            //            if (bn1ct == BN1)
            //                benepercnt = String.Format("{0:0.00}", finalBN1percent);
            //            else
            //                benepercnt = String.Format("{0:0.00}", everyBN1Pct);
            //            break;

            //        case "BN2":
            //            bn2ct++;

            //            if (bn2ct == BN2)
            //                benepercnt = String.Format("{0:0.00}", finalBN2percent);
            //            else
            //                benepercnt = String.Format("{0:0.00}", everyBN2Pct);
            //            break;

            //        case "BN3":
            //            bn3ct++;

            //            if (bn3ct == BN3)
            //                benepercnt = String.Format("{0:0.00}", finalBN3percent);
            //            else
            //                benepercnt = String.Format("{0:0.00}", everyBN3Pct);
            //            break;
            //            //case "IRB":
            //            //    bn3ct++;

            //            //    if (irbct == IRB)
            //            //        benepercnt = String.Format("{0:0.00}", finalIRBpercent);
            //            //    else
            //            //        benepercnt = String.Format("{0:0.00}", everyIRBPct);
            //            //    break;
            //    }

            //    relationsection = relationsection + Environment.NewLine +
            //          (@"<Relation id=""Relation_00") + rlcount.ToString() + (@""" OriginatingObjectID=""Holding_1"" RelatedObjectID=""Party_00") + rlcount.ToString() + (@""">
            //                  <OriginatingObjectType tc=""4""/>
            //                  <RelationRoleCode tc=""") + TestData.GetMappedValue("BeneType", CSWData.BeneInfo[i][2]) + (@""">") + CSWData.BeneInfo[i][2] + (@"</RelationRoleCode>
            //                  <!--BN1-->
            //                  <RelationDescription tc=""") + TestData.GetMappedValue("Relation", "Spouse") + (@"""/>
            //                  <RelatedObjectType tc=""6""/>
            //                  <InterestPercent>") + benepercnt + (@"</InterestPercent>
            //               </Relation>");

            //    rlcount++;
            //}


            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// Relation Info Section   /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            endingsection = (@"</OLifE>
                                          </TXLifeRequest>
                                        </TXLife>
                                    </SOAP-ENV:Body>
                               </SOAP-ENV:Envelope>");

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////// All Sections            /////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            xml = policysection + partysection + relationsection + endingsection;
            Console.WriteLine(xml);

            return xml;
        }
    }
}
