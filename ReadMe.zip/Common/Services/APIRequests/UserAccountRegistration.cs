﻿using CSW.Common.Others;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Services.APIRequests
{
    internal class UserAccountRegistration
    {
        public static Dictionary<string, string> data;

        public UserAccountRegistration(Dictionary<string, string> testdata)
        {
            data = testdata;
        }

        public string PingAccountRegister()
        {
            var body = new
            {
                clientId = data[KeyRepository.ClientId],
                userName = data[KeyRepository.UserName],
                password = data[KeyRepository.Password],
                email = data[KeyRepository.EmailId],
                firstName = data[KeyRepository.FirstName],
                lastName = data[KeyRepository.LastName],
                nylApplicationRole = data[KeyRepository.NYLApplicationRole]
            };

            string json = JsonConvert.SerializeObject(body);
            return json;
        }

        public string PingAccountLitePreRegister()
        {
            var body = new
            {
                clientId = data[KeyRepository.ClientId],
                userName = "user$" + data[KeyRepository.UserName],
                password = "6Y7u8i9o!",
                email = data[KeyRepository.EmailId],
                firstName = data[KeyRepository.FirstName],
                lastName = data[KeyRepository.LastName],
                nylApplicationRole = "Lite Owner",
                nylSmInfo = "alip=true",
                nylSmPasswordFlag = "16777216"


            };

            string json = JsonConvert.SerializeObject(body);
            return json;
        }

        public string PingPairSMS()
        {
            var body = new
            {
                phone = data[KeyRepository.ProfilePhone]
            };
            string json = JsonConvert.SerializeObject(body);
            return json;
        }
        public string PingPairWithSMSOTP()
        {
            var body = new
            {
                otp = "999999",
                pairingId = data[KeyRepository.NLYPairId]
            };
            string json = JsonConvert.SerializeObject(body);
            return json;
        }

    }
}
