﻿using CSW.Common.Others;
using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;

namespace CSW.Common.Services.APIRequests
{
    class SearchUserInfo
    {
        public static Dictionary<string, string> data;

        public SearchUserInfo(Dictionary<string, string> testdata)
        {
            data = testdata;
        }

        public string GetUserInfo()
        {
            var body = new
            {
                clientId = data[KeyRepository.ClientId],
                condition = "or"
            };

            string json = JsonConvert.SerializeObject(body);
            return json;
        }
    }
}
