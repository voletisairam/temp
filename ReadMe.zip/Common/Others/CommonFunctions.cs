﻿using CSW.Common.DataBase;
using CSW.Common.Excel;
using CSW.PageObjects.Login;
using CSW.PageObjects.Payments;
using CSW.PageObjects.Registration;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using SeleniumExtras.WaitHelpers;
using Spire.Pdf;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Actions = OpenQA.Selenium.Interactions.Actions;

namespace CSW.Common.Others
{
    class CommonFunctions : WebBrowser
    {
        static string cswTabInstance = "";
        static string outlookTabInstance = "";
        static string newTabInstance = "";
        public string fisTabInstance = "";
        private Dictionary<string, string> data;

        public CommonFunctions(Dictionary<string, string> testdata)
        {
            data = testdata;
        }

        /// <summary>
        /// MEthod to verify payment past due informatin displayed in Summary and Details page
        /// </summary>
        /// <param name="args"></param>
        public void VerifyPaymentDueInformation(string actualPaymentDueInformation)
        {
            string expectedDueInformation = new CSW.Common.Excel.TestData().GetContent("PaymentDue Information");

            NYLDSelenium.VerifyText("Payment Due information", expectedDueInformation, actualPaymentDueInformation);
        }

        /// <summary>
        /// Method to actual contract card color based on attribue
        /// </summary>
        /// <param name="args"></param>
        public string GetActualContractCardColor(string contractCardColot)
        {
            string actualContractCardColor = "";

            if (contractCardColot.Contains("bg-white"))
                actualContractCardColor = "White";
            else if (contractCardColot.Contains("alert-danger"))
                actualContractCardColor = "Red";
            else if (contractCardColot.Contains("alert-secondary"))
                actualContractCardColor = "Grey";
            else if (contractCardColot.Contains("alert-warning"))
                actualContractCardColor = "Yellow";

            return actualContractCardColor;
        }

        /// <summary>
        /// Method to determine expected policy status, payment button color based on paid to date and LSP date
        /// </summary>
        public void GetContractCardcolor()
        {
            double dayPastPTD;

            if (data[KeyRepository.PaidToDate].Split('/')[0].Trim('0') == "2" &&
                (data[KeyRepository.PaidToDate].Split('/')[1] == "29" ||
                 data[KeyRepository.PaidToDate].Split('/')[1] == "30" ||
                 data[KeyRepository.PaidToDate].Split('/')[1] == "31"))
            {
                data[KeyRepository.PaidToDate] = "2/28/" + data[KeyRepository.PaidToDate].Split('/')[2];
            }

            //check the days past from pay to date   
            DateTime LSP = Convert.ToDateTime(data[KeyRepository.LSPDate]);

            //DateTime PaidToDate = Convert.ToDateTime(data[KeyRepository.PaidToDate]);

            dayPastPTD = (Convert.ToDateTime(data[KeyRepository.LSPDate]) - Convert.ToDateTime(data[KeyRepository.PaidToDate])).TotalDays;
            bool newAccount = (Convert.ToDateTime(data[KeyRepository.PaidToDate]).ToString("MM/dd/yyyy") == Convert.ToDateTime(data[KeyRepository.EffectiveDate]).ToString("MM/dd/yyyy"));
            bool nationalState = ((data[KeyRepository.IssuedState] != "FL") && (data[KeyRepository.IssuedState] != "VT") && (data[KeyRepository.IssuedState] != "CA"));

            data[KeyRepository.PaymentDueAbove52] = "false";

            //Check if Premium is Zero



            if (dayPastPTD < 0)
            {
                data[KeyRepository.PolicyStatus] = "Inforce";
                data[KeyRepository.PaymentButtonColor] = "Blue";
                data[KeyRepository.PaymentHistoryLink] = "Link";
                data[KeyRepository.ContractCardColor] = "White";
            }
            else if (dayPastPTD <= 31)
            {
                data[KeyRepository.PolicyStatus] = "Inforce";
                data[KeyRepository.PaymentButtonColor] = "Red";
                data[KeyRepository.PaymentHistoryLink] = "Link";
                data[KeyRepository.ContractCardColor] = "Yellow";
            }
            else if (dayPastPTD >= 32)
            {
                if (newAccount)
                {
                    data[KeyRepository.PolicyStatus] = "Cancelled";
                    data[KeyRepository.PaymentButtonColor] = "NoButton";
                    data[KeyRepository.PaymentHistoryLink] = "NoLink";
                    data[KeyRepository.ContractCardColor] = "Grey";

                    if (dayPastPTD > 52)
                        data[KeyRepository.PaymentDueAbove52] = "false";
                    data[KeyRepository.PaymentHistoryLink] = "NoLink";
                }
                else
                {
                    if (dayPastPTD >= 32 && dayPastPTD <= 52)
                    {
                        if (nationalState)
                        {
                            data[KeyRepository.PolicyStatus] = "Lapse";
                            data[KeyRepository.PaymentButtonColor] = "Red";
                            data[KeyRepository.PaymentHistoryLink] = "Link";
                            data[KeyRepository.ContractCardColor] = "Red";
                        }
                        else
                        {
                            data[KeyRepository.PolicyStatus] = "Inforce";
                            data[KeyRepository.PaymentButtonColor] = "Red";
                            data[KeyRepository.PaymentHistoryLink] = "Link";
                            data[KeyRepository.ContractCardColor] = "Yellow";

                        }
                    }
                    else if (dayPastPTD >= 53 && dayPastPTD <= 62)
                    {
                        if (nationalState)
                        {
                            data[KeyRepository.PolicyStatus] = "Lapse";
                            data[KeyRepository.PaymentButtonColor] = "NoButton";
                            data[KeyRepository.PaymentHistoryLink] = "NoLink";
                            data[KeyRepository.ContractCardColor] = "Red";
                        }
                        else
                        {
                            data[KeyRepository.PolicyStatus] = "Inforce";
                            data[KeyRepository.PaymentButtonColor] = "NoButton";
                            data[KeyRepository.PaymentHistoryLink] = "NoLink";
                            data[KeyRepository.ContractCardColor] = "Yellow";
                        }
                        data[KeyRepository.PaymentDueAbove52] = "true";
                    }
                    else if (dayPastPTD >= 63)
                    {
                        data[KeyRepository.PolicyStatus] = "Lapse";
                        data[KeyRepository.PaymentButtonColor] = "NoButton";
                        data[KeyRepository.PaymentHistoryLink] = "NoLink";
                        data[KeyRepository.ContractCardColor] = "Red";
                        data[KeyRepository.PaymentDueAbove52] = "true";
                    }
                }
            }

            //Determine Policy Status
            DeterminePolicyStatus();

            //Payment code NN
            if (data[KeyRepository.PayCode] == "NN")
            {
                data[KeyRepository.ContractCardColor] = "White";
                data[KeyRepository.PolicyStatus] = "Inforce";
                data[KeyRepository.PaymentButtonColor] = "NoButton";
                data[KeyRepository.PaymentHistoryLink] = "NoLink";

            }
        }

        public void DeterminePolicyStatus()
        {
            switch (data[KeyRepository.Status])
            {
                case "R":
                    data[KeyRepository.PolicyStatus] = "Reduced Paid-Up";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "E":
                    data[KeyRepository.PolicyStatus] = "Extended Term";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "D":
                    data[KeyRepository.PolicyStatus] = "Claim Filed";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "L":
                    data[KeyRepository.PolicyStatus] = "Lapse";
                    data[KeyRepository.PaymentButtonColor] = "Grey";
                    break;

                case "X":
                    data[KeyRepository.PolicyStatus] = "Expired";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "P":
                    data[KeyRepository.PolicyStatus] = "Paid-Up";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "T":
                    data[KeyRepository.PolicyStatus] = "Exchanged";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "N":
                    data[KeyRepository.PolicyStatus] = "30-Day Cancel";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "S":
                    data[KeyRepository.PolicyStatus] = "Cash Surrender";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "C":
                    data[KeyRepository.PolicyStatus] = "Cancelled";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "M":
                    data[KeyRepository.PolicyStatus] = "Matured Contract ";
                    GetCardColorUsingPolicyStatus();
                    break;

                case "PN":
                    data[KeyRepository.PolicyStatus] = "Pending";
                    GetCardColorUsingPolicyStatus();
                    break;
            }
        }

        private void GetCardColorUsingPolicyStatus()
        {
            if (data[KeyRepository.PolicyStatus] != "Inforce" && data[KeyRepository.PolicyStatus] != "Lapse")
            {
                if (data[KeyRepository.PolicyStatus] == "Mature Contract" || data[KeyRepository.PolicyStatus] == "Paid-Up" || data[KeyRepository.PolicyStatus] == "Claim Filed")
                {
                    data[KeyRepository.ContractCardColor] = "White";
                    data[KeyRepository.PaymentButtonColor] = "NoButton";
                    data[KeyRepository.PaymentHistoryLink] = "NoLink";
                }
                else
                {
                    data[KeyRepository.ContractCardColor] = "Grey";
                    data[KeyRepository.PaymentButtonColor] = "NoButton";
                    data[KeyRepository.PaymentHistoryLink] = "NoLink";
                }

            }
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getDropDownValue                                                                            ///////////
        ////// Description:  Get current value displayed in any list box                                         ///////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
        public string GetDropDownValue(IWebElement We)  //TODO: We already have VerifySelectedItem framework method. Please remove it
        {
            SelectElement SE = new SelectElement(We);
            string selOption = SE.SelectedOption.Text;
            return selOption;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: sortContracts                                                                               ////////////
        ////// Description: Classify contracts by their status and then sort them in ascending                   ////////////
        //////              and arrange them in order expected in summary page                                   ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public void SortContracts(string args)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(testdata: data);
            string IPolicies = "";
            string RPolicies = "";
            string EPolicies = "";
            string DPolicies = "";
            string LPolicies = "";
            string XPolicies = "";
            string PPolicies = "";
            string TPolicies = "";
            string NSPolicies = "";
            string CPolicies = "";
            string MPolicies = "";
            string ElsePolicies = "";
            string[] numberOfAssocPolicies = args.Split(';');

            //group policies into their respective status
            for (int i = 0; i < numberOfAssocPolicies.Count(); i++)
            {
                string[] policySplit = numberOfAssocPolicies[i].Split(' ');
                data[KeyRepository.PolicyNumber] = policySplit[1].Trim();

                switch (policySplit[0])
                {
                    case "I":
                        DB.QueryPolicyDetails();
                        DB.QueryPaymentDetails();
                        CF.GetContractCardcolor();

                        if (data[KeyRepository.PolicyStatus] == "Inforce" || data[KeyRepository.PayCode] == "NN")
                            IPolicies = IPolicies + "," + data[KeyRepository.PolicyNumber];
                        else if (data[KeyRepository.PolicyStatus] == "Cancelled")
                            CPolicies = CPolicies + "," + data[KeyRepository.PolicyNumber];
                        else
                            LPolicies = LPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "R":
                        RPolicies = RPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "E":
                        EPolicies = EPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "D":
                        DPolicies = DPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "L":
                        LPolicies = LPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "X":
                        XPolicies = XPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "P":
                        PPolicies = PPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "T":
                        TPolicies = TPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "N":
                    // 30 Day Cancel and Cash Surrender are being treated as one status.
                    case "S":
                        NSPolicies = NSPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "C":
                        CPolicies = CPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    case "M":
                        MPolicies = MPolicies + "," + data[KeyRepository.PolicyNumber];
                        break;

                    default:
                        ElsePolicies = ElsePolicies + "," + data[KeyRepository.PolicyNumber];
                        break;
                }
            }
            CSWData.TempVal = "";
            CSWData.TempVal = (SortPolicies(IPolicies.TrimStart(',')) + SortPolicies(RPolicies.TrimStart(',')) + SortPolicies(EPolicies.TrimStart(',')) + SortPolicies(LPolicies.TrimStart(',')) + SortPolicies(XPolicies.TrimStart(',')) + SortPolicies(PPolicies.TrimStart(',')) + SortPolicies(TPolicies.TrimStart(',')) + SortPolicies(NSPolicies.TrimStart(',')) + SortPolicies(CPolicies.TrimStart(',')) + SortPolicies(MPolicies.TrimStart(',')) + SortPolicies(ElsePolicies.TrimStart(','))).TrimStart(',');
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: sortPolicies                                                                                ////////////
        ////// Description: sort policy in ascending                                                             ////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public string SortPolicies(string args)
        {
            string sortedPolicy = "";
            if (args != "")
            {
                string[] policySplit = args.Trim().Split(',');
                IList<string> contractNumber = new List<string>();
                StringBuilder SB = new StringBuilder();

                for (int i = 0; i < policySplit.Count(); i++)
                {
                    contractNumber.Add(policySplit[i]);
                }
                contractNumber = contractNumber.OrderBy(x => x).ToList();

                foreach (string s in contractNumber)
                {
                    SB.Append(s).Append(",");
                }
                sortedPolicy = SB.ToString().TrimEnd(',');
            }
            if (sortedPolicy != "")
                sortedPolicy = "," + sortedPolicy;
            return sortedPolicy;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: FormatString                                                                                ///////////
        ////// Description:  Get text value of webelement and format it to simple plain string                   ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public string FormatString(string input)
        {
            string Output = Regex.Replace(input, @"\r\n", " ").Replace("  ", " ").Trim();
            return Output;
        }

        public string EmailMasking()
        {
            string email = "";
            string[] emailPart = new string[3];
            string emailPart3 = "";
            emailPart = data[KeyRepository.EmailId].Split('@');
            string[] tempSplit = emailPart[1].ToString().Split('.');
            emailPart[1] = tempSplit[0].ToString();
            emailPart3 = tempSplit[1].ToString();

            int count1 = emailPart[0].ToString().Count();
            int count2 = emailPart[1].ToString().Count();


            emailPart[0] = ReplaceMask(emailPart[0].ToString(), count1 - 2, 1);
            emailPart[1] = ReplaceMask(emailPart[1].ToString(), count2 - 1, 1);

            email = emailPart[0] + "@" + emailPart[1] + "." + emailPart3;

            email = email.Substring(0, 1).ToLower() + email.Substring(1, email.Length - 1);
            return email;

        }

        private string ReplaceMask(string text, int count, int index)
        {
            //string masked = "";
            //string stringMask = "";

            //for (int i = index; i < count; i++)
            //{
            //    stringMask = stringMask + "*";                
            //}
            char[] charArray = text.ToCharArray();
            while (count > 0)
            {
                charArray[index] = '*';
                index++;
                count--;
            }
            string masked = new string(charArray);
            return masked;
            //text = text.Remove(index);            

            //masked = text.ToLower() + stringMask;
            //return masked;
        }

        public string[] SplitPinCode()
        {
            string[] pinCode = new string[6];

            int start = 0;
            int count = 1;
            for (int i = 0; i <= 5; i++)
            {
                string text = data[KeyRepository.PinCode];
                string digit = text.Substring(start, count);

                pinCode[i] = digit;


                start++;
            }


            return pinCode;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: randData                                                                                    ///////////
        ////// Description:  Method called to get a random set of details as test data                           ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public string RandData(string datatype, int partynum)
        {
            int secondsSinceMidnight = Convert.ToInt32(DateTime.Now.Subtract(DateTime.Today).TotalSeconds);
            Random rnd = new Random(secondsSinceMidnight);
            string randvalue = "";
            int rval = rnd.Next(1, 12);
            int rvals = rnd.Next(1, 7);
            int rphone = rnd.Next();

            switch (datatype)
            {
                case "Person":
                    switch (partynum)
                    {
                        case 0:
                            randvalue = "Mr./VijayKumar" + RandomString(rvals) + "/P/Nadella/Male/Single";
                            break;
                        case 1:
                            randvalue = "Mr/Robert/V/Ferman/Male/Married";
                            break;
                        case 2:
                            randvalue = "Mr/Chis/Walles/Jones/Male/Single";
                            break;
                        case 3:
                            randvalue = "Mrs/Emily/F/Watson/Female/Married";
                            break;
                        case 4:
                            randvalue = "Mrs/Tom/T/Cruise/Male/Married";
                            break;
                        case 5:
                            randvalue = "Mr/Bill/V/Thompson/Male/Single";
                            break;
                        case 6:
                            randvalue = "Miss/Mary/D/Labella/Female/Single";
                            break;
                        case 7:
                            randvalue = "Mrs/Larisa/B/Levitskaya/Female/Married";
                            break;
                        case 8:
                            randvalue = "Mr/Rich/C/Schroeder/Male/Married";
                            break;
                        case 9:
                            randvalue = "Mrs./Joelle/S/Smith/Female/Married";
                            break;
                        case 10:
                            randvalue = "Mr./Niel/P/Harris/Male/Single";
                            break;
                        case 11:
                            randvalue = "Mr./Sunder/M/Pichai/Male/Married";
                            break;
                        case 12:
                            randvalue = "Mr./Brad/T/Pitt/Male/Married";
                            break;
                    }
                    break;

                case "Organization":
                    switch (partynum)
                    {
                        case 0:
                            randvalue = "Wounder Warriors of America";
                            break;
                        case 1:
                            randvalue = "Hungry People";
                            break;
                        case 2:
                            randvalue = "Feed America";
                            break;
                        case 3:
                            randvalue = "Good Deeds Inc";
                            break;
                        case 4:
                            randvalue = "Florida Charities Inc";
                            break;
                        case 5:
                            randvalue = "Walmart Inc";
                            break;
                        case 6:
                            randvalue = "Final Destination";
                            break;
                        case 7:
                            randvalue = "Food for Thought Inc";
                            break;
                        case 8:
                            randvalue = "Bill Mellinda Gate Foundation";
                            break;
                        case 9:
                            randvalue = "American Red Cross";
                            break;
                        case 10:
                            randvalue = "UNHRC";
                            break;
                        case 11:
                            randvalue = "Cry Foundation";
                            break;
                        case 12:
                            randvalue = "MyHome Foundation";
                            break;

                    }
                    break;

                case "Address":
                    switch (partynum)
                    {
                        case 0:
                            randvalue = "4 Pacemaker Drev/Suite 65/Columbus/Ohio/54341/United States";
                            break;
                        case 1:
                            randvalue = "2035 Abott Drive/Building 3/Chorlette/North Carolina/35423/United States";
                            break;
                        case 2:
                            randvalue = "1 Corporate Parkway//Los Angeles/California/92342/United States";
                            break;
                        case 3:
                            randvalue = "1 Corporate Parkway//Los Angeles/California/92342/United States";
                            break;
                        case 4:
                            randvalue = "644 Lutz Drive/Suite # 4/Tampa/Florida/33544/United States";
                            break;
                        case 5:
                            randvalue = "76 Main Street//Marietta/Georgia/30067/United States";
                            break;
                        case 6:
                            randvalue = "5603 Arapahoe Road//Denver/Colorado/93453/United States";
                            break;
                        case 7:
                            randvalue = "344 Water Street//New York/New York/09454/United States";
                            break;
                        case 8:
                            randvalue = "456 Durham Road/Suite 100/Raliegh/North Carolina/43553/United States";
                            break;
                        case 9:
                            randvalue = "342 Willman Road//Chicago/Illinois/34533/United States";
                            break;
                        case 10:
                            randvalue = "100 Lincoln Highway/Suite 1/Piscataway/New Jersey/07605/United States";
                            break;
                        case 11:
                            randvalue = "100 Cattaooga Drive//Atltanta/Georgia/34034/United States";
                            break;
                        case 12:
                            randvalue = "345 Theodre Avenue//Atltanta/Georgia/34034/United States";
                            break;

                    }
                    break;

                case "Relation":
                    switch (partynum)
                    {
                        case 0:
                            randvalue = "Friend";
                            break;
                        case 1:
                            randvalue = "Spouse";
                            break;
                        case 2:
                            randvalue = "Parent";
                            break;
                        case 3:
                            randvalue = "Grandparent";
                            break;
                        case 4:
                            randvalue = "Parent";
                            break;
                        case 5:
                            randvalue = "Grandparent";
                            break;
                        case 6:
                            randvalue = "Grandchild";
                            break;
                        case 7:
                            randvalue = "Sibling";
                            break;
                        case 8:
                            randvalue = "Relative";
                            break;
                        case 9:
                            randvalue = "Friend";
                            break;
                        case 10:
                            randvalue = "In-Law";
                            break;
                        case 11:
                            randvalue = "Relative";
                            break;
                        case 12:
                            randvalue = "Parent";
                            break;

                    }

                    break;

                case "Phone":
                    string characters = "123456789";
                    StringBuilder phno = new StringBuilder(10);
                    for (int i = 0; i < 10; i++)
                    {
                        phno.Append(characters[rnd.Next(characters.Length)]);

                    }
                    randvalue = phno.ToString();
                    break;

                case "SSN":
                case "TID":
                    randvalue = NYLDDatabase.GetUniqueSSN();
                    break;
            }
            return randvalue;
        }

        public static string RandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public void ShowValidation(string option)
        {
            LoginPage lg = new LoginPage(driver, data);
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);

            string getValue = "";

            switch (option)
            {
                case "Personal":
                    if (NYLDSelenium.ElemExist("Show Button", resetPassword.SSNShowBtn, false, "no", "no"))
                    {
                        string SSN4 = data[KeyRepository.SSN].Substring(data[KeyRepository.SSN].Length - 4);
                        //NYLDSelenium.ScrollToView(regPage1.SSNShowBtn);
                        NYLDSelenium.Click("SSN Show", resetPassword.SSNShowBtn);
                        getValue = NYLDSelenium.GetAttribute("Get SSN input", resetPassword.SSN, "value");
                        NYLDSelenium.VerifyText("SSN Show Button", SSN4, getValue);
                    }
                    break;

                case "Password":
                    if (NYLDSelenium.ElemExist("Show Button", resetPassword.PwdShowBtn, false, "no", "no"))
                    {
                        //NYLDSelenium.ScrollToView(regPage2.PwdShowBtn);
                        NYLDSelenium.Click("Password Show", resetPassword.PwdShowBtn);
                        getValue = NYLDSelenium.GetAttribute("Get Pwd input", resetPassword.Password, "value");
                        NYLDSelenium.VerifyText("Entered Password", data[KeyRepository.Password], getValue);

                        NYLDSelenium.Click("Confirm password Show", resetPassword.ConfirmPwdShowBtn);
                        getValue = NYLDSelenium.GetAttribute("Get Confirm Pwd input", resetPassword.ConfirmPassword, "value");
                        NYLDSelenium.VerifyText("Confirm password Show Button", data[KeyRepository.Password], getValue);
                    }
                    break;

                case "Login":
                    if (NYLDSelenium.ElemExist("Show Button", lg.LoginShowBtn, false, "no", "no"))
                    {
                        //NYLDSelenium.ScrollToView(lg.UserName);
                        Thread.Sleep(2000);
                        lg.LoginShowBtn.Click();
                        getValue = NYLDSelenium.GetAttribute("Get Pwd input", lg.Password, "value");
                        NYLDSelenium.VerifyText("Password Show Button", data[KeyRepository.Password], getValue);
                    }
                    break;

            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: movetoElement                                                                               ///////////
        ////// Description:  Perform Click action on element when the field is not responding for usual Click    ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void MovetoElement(string xpath, IWebDriver driver)
        {
            Actions builder = new Actions(driver);

            try
            {
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].Click();", driver.FindElement(By.XPath(xpath)));
            }
            catch
            {
                builder.MoveToElement(driver.FindElement(By.XPath(xpath))).Click().Build().Perform();
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: getOwnerandInsuredDetails                                                                   ///////////
        ////// Description:  Get owner and insured details and compare with expected value                       ///////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void GetOwnerandInsuredDetails(IWebElement Owner, IWebElement Insured, out string ExpOwnerNameandAddr, out string ActualOwnerNameandAddr, out string ExpectedInsuredName, out string ActualInsuredName)
        {
            string country;
            string sep;
            string address;
            string stateandzip;
            LSPDatabase DB = new LSPDatabase(driver, data);

            DB.QueryPolicyDetails("Case");
            // Phrase owner address based on country option selected
            if (data[KeyRepository.Country] == "US")
            {
                country = "";
                sep = ",";
                stateandzip = data[KeyRepository.State] + " " + data[KeyRepository.Zip];
            }
            else if (data[KeyRepository.Country] == "CN")
            {
                country = "Canada";
                sep = ",";
                stateandzip = data[KeyRepository.State] + " " + data[KeyRepository.Zip];
            }
            else
            {
                country = "Other Country";
                sep = ",";
                stateandzip = "";
            }

            //Phrase address line of Owner address based on Address line 2 availability
            if (data[KeyRepository.AddressLine2] == "")
            {
                address = data[KeyRepository.AddressLine1];
            }
            else
            {
                address = data[KeyRepository.AddressLine1] + " " + data[KeyRepository.AddressLine2];
            }


            if (data[KeyRepository.Country] == "CN")
            {
                //Address displayed in DB
                ExpOwnerNameandAddr = "Contract Owner" + " " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + stateandzip + " " + data[KeyRepository.City].Trim() + sep + " " + country;
                data[KeyRepository.Address] = address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + stateandzip + " " + country;
            }
            else if (data[KeyRepository.Country] != "CN")
            {
                //Address displayed in DB
                ExpOwnerNameandAddr = "Contract Owner" + " " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + stateandzip + " " + country;
                data[KeyRepository.Address] = address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + stateandzip + " " + country;
            }
            else
            {
                //Address displayed in DB
                ExpOwnerNameandAddr = "Contract Owner" + " " + data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName] + " " + address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + country;
                data[KeyRepository.Address] = address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + country;
            }


            //Insured Name expected
            //Due to new  change removed the middle name -->+ " " + data[KeyRepository.InsuredMiddleName].Trim() 
            ExpectedInsuredName = ("Insured " + data[KeyRepository.InsuredFirstName].Trim() + " " + data[KeyRepository.InsuredLastName].Trim()).Replace("  ", " ");

            //Address displayed in UI
            ActualOwnerNameandAddr = NYLDSelenium.GetAttribute("Contract Owner", Owner);
            ActualOwnerNameandAddr = Regex.Replace(ActualOwnerNameandAddr, "\r\n", " ");

            //Phrase first name and last name from the insured webelement captured
            ActualInsuredName = NYLDSelenium.GetAttribute("Contract Insured block", Insured);
            ActualInsuredName = Regex.Replace(ActualInsuredName, "\r\n", " ");

            DB.QueryPolicyDetails();
        }

        public static string SelectCountryByCode(IWebElement cPcountry, string countryCode)
        {
            IWebElement elem = cPcountry;
            SelectElement SelectList = new SelectElement(elem);
            IList<IWebElement> options = SelectList.Options;
            string fullCountryName = "";


            foreach (IWebElement dropEle in options)
            {
                string dropText = dropEle.GetAttribute("text");
                //string dropTrim = dropText.Substring(0, 2);
                if (dropText == countryCode)
                {
                    SelectList.SelectByText(dropText);
                    fullCountryName = dropText;
                    break;
                }
            }
            return fullCountryName;
        }

        public static void WindowsTabFocus(string option, string tabInstance)
        {
            string tabValue = GetTabInstance(tabInstance);
            switch (option)
            {
                case "SaveTab":
                    // save a reference to our new CSW tab's window handle, this would be the last entry in the WindowHandles collection
                    tabValue = driver.WindowHandles[driver.WindowHandles.Count - 1];
                    break;
                case "OpenNewTab":
                    // execute some JavaScript to open a new window
                    driver.ExecuteJavaScript("window.open();");
                    // save a reference to our CSW tab's window handle, this would be the last entry in the WindowHandles collection
                    tabValue = driver.WindowHandles[driver.WindowHandles.Count - 1];
                    // switch our WebDriver to the CSW tab's window handle
                    driver.SwitchTo().Window(tabValue);
                    break;
                case "NavigateTab":
                    // switch our WebDriver to the specific windows tab's window handle
                    driver.SwitchTo().Window(tabValue);
                    break;
                case "CloseTab":
                    // now lets close our Outlook tab
                    driver.SwitchTo().Window(tabValue).Close();
                    break;
                case "NavigateNewTab":
                    // save a reference to our New window handle, this would be the last entry in the WindowHandles collection
                    tabValue = driver.WindowHandles[driver.WindowHandles.Count - 1];
                    // switch our WebDriver to the Outlook tab's window handle
                    driver.SwitchTo().Window(tabValue);
                    break;
            }
            SetTabInstance(tabInstance, tabValue);
        }

        private static void SetTabInstance(string tabInstance, string tabValue)
        {
            if (tabInstance == "outlookTabInstance")
                outlookTabInstance = tabValue;
            else if (tabInstance == "cswTabInstance")
                cswTabInstance = tabValue;
            else if (tabInstance == "newTabInstance")
                newTabInstance = tabValue;
        }

        private static string GetTabInstance(string tabInstance)
        {
            string tabValue = "";
            if (tabInstance == "outlookTabInstance")
                tabValue = outlookTabInstance;
            else if (tabInstance == "cswTabInstance")
                tabValue = cswTabInstance;
            else if (tabInstance == "newTabInstance")
                tabValue = newTabInstance;

            return tabValue;
        }

        public static void SetEmailTriggerTime(string emailType, int i)
        {
            string dtConv = DateTime.Now.AddMinutes(-i).ToString(@"MM/dd/yyyy hh:mm tt");
            TestSetUp.date = DateTime.ParseExact(dtConv, @"MM/dd/yyyy hh:mm tt", new CultureInfo("en-US"));

            NYLDSelenium.ReportStepResult(emailType + " triggered time", TestSetUp.date.ToString(), "INFO");
            CSWData.EventTriggerTime = TestSetUp.date;
        }

        public static string PathPDFCreation(string path)
        {

            DateTime currentDate = DateTime.Now;
            string day = currentDate.Day.ToString();
            string month = currentDate.Month.ToString();
            string year = currentDate.Year.ToString();

            string folderName = path + @"\PDF_" + month + day + year;
            string msg = NYLDGeneric.CreateFolder(folderName);
            Console.WriteLine(msg);

            return folderName;
        }

        public void ErrorCertByPass()
        {
            if (data[KeyRepository.Environment] == "QA" || data[KeyRepository.Environment] == "Model" || data[KeyRepository.Environment] == "MODEL")
            {
                if (NYLDSelenium.ElemExist("Error Cert", NYLDSelenium.GetWE("//h1[text()='Your connection is not private']"), false, "no", "no"))
                {
                    NYLDSelenium.GetWE("//button[@id='details-button' and contains(.,'Advanced')]").Click();
                    NYLDSelenium.GetWE("//p[@id='final-paragraph' and contains(.,'unsafe')]").Click();
                }
            }
        }

        /// <summary>
        /// Method to get the element to send the values to fill the form fields
        /// </summary>
        public IList<IWebElement> GetWEbelements(string id)
        {
            IList<IWebElement> element = null;
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(1));

            try
            {
                element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../input"))));
            }
            catch (Exception)
            {
                try
                {
                    element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/..//input"))));
                }
                catch (Exception)
                {
                    try
                    {
                        element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../../input"))));
                    }
                    catch
                    {
                        try
                        {
                            element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../select"))));
                        }
                        catch
                        {
                            try
                            {
                                element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../..//input"))));
                            }
                            catch
                            {
                                try
                                {
                                    element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//th[contains(text(), '" + id + "')]/following-sibling::td"))));
                                }
                                catch
                                {
                                    try
                                    {
                                        element = wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/..//select"))));
                                    }
                                    catch
                                    {
                                        try
                                        {
                                            IWebElement z = driver.FindElement(By.XPath("//label[contains(text(), '" + id + "')]/../input"));
                                            element = driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../input"));
                                        }
                                        catch
                                        {
                                            element = driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../select"));
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }

            if (element.Count == 0)
                element = driver.FindElements(By.XPath("//label[contains(text(), '" + id + "')]/../select"));

            return element;

        }

        public string GetCurrentFrequencyWithPremium(string args)
        {
            LSPDatabase database = new LSPDatabase(driver, data);
            string premiumEFT = "";
            string frequency = data[KeyRepository.CurrentPaymentFrequency];

            //Set to Frequency and month info
            if (frequency == "M")
                args = "Monthly,1";
            else if (frequency == "Q")
                args = "Quarterly,3";
            else if (frequency == "S")
                args = "SemiAnnually,6";
            else if (frequency == "A")
                args = "Annually,12";

            if (data[KeyRepository.PayCode] != "FB")
                database.QueryPaymentDetails();
            else if (data[KeyRepository.PayCode] == "FB")
                database.QueryFamilyBill();


            //set to Premium or PremiumEFT
            if (data[KeyRepository.PayCode] == "IN")
                premiumEFT = (Convert.ToDecimal(data[KeyRepository.Premium]) - Convert.ToDecimal(args.Split(',')[1])).ToString();
            else
            {
                if (data[KeyRepository.Premium] == "0")
                    data[KeyRepository.Premium] = Convert.ToInt32(data[KeyRepository.Premium]).ToString("0.00");

                premiumEFT = data[KeyRepository.Premium];
            }

            args = args + "," + premiumEFT;

            //Set  Current Frequency to ChangeFrequency
            if (frequency == "M")
                args = args + "," + "Quarterly" + "," + data[KeyRepository.QuarterlyPremium];
            else if (frequency == "Q")
                args = args + "," + "Monthly" + "," + data[KeyRepository.MonthlyPremium];

            GetContractCardcolor();
            return args;
        }

        /// <summary>
        /// Pick a date is used for Autopay and managepayments
        /// </summary>
        /// <param name="pickadate"></param>
        /// <returns></returns>
        public string PaidToDate([Optional] string Selectedpickadate)
        {
            //month//date//year
            string PaidToDate = "";
            string[] PaidToDateSplit = data[KeyRepository.PaidToDate].Split('/');

            if (!string.IsNullOrEmpty(Selectedpickadate))
            {
                //pickadate +15-15 based on paid to date 
                int paidtodate = Convert.ToInt32(PaidToDateSplit[1].PadLeft(2, '0'));
                int pickadate = Convert.ToInt32(Selectedpickadate.PadLeft(2, '0'));


                if (paidtodate + 15 - pickadate < 0)
                {
                    //-1 month
                    PaidToDateSplit = DateTime.ParseExact(data[KeyRepository.PaidToDate], @"MM/dd/yyyy", new CultureInfo("en-US")).AddMonths(-1).ToString("MM/dd/yyyy").Split('/');
                }
                else if (paidtodate + 15 - pickadate >= 29)
                {
                    //+1 month
                    PaidToDateSplit = DateTime.ParseExact(data[KeyRepository.PaidToDate], @"MM/dd/yyyy", new CultureInfo("en-US")).AddMonths(1).ToString("MM/dd/yyyy").Split('/');
                }
            }

            if (string.IsNullOrEmpty(Selectedpickadate))
                PaidToDate = PaidToDateSplit[0].PadLeft(2, '0') + "/" + PaidToDateSplit[1].PadLeft(2, '0') + "/" + PaidToDateSplit[2];
            else
                PaidToDate = PaidToDateSplit[0].PadLeft(2, '0') + "/" + Selectedpickadate.PadLeft(2, '0') + "/" + PaidToDateSplit[2];

            return PaidToDate;
        }

        /// <summary>
        /// Method helps to make changes for dateformat in api service request
        /// </summary>
        /// <param name="pickadate"></param>
        /// <returns></returns>
        public string Dateformat(string format, string date)
        {
            string Dateformat = "";
            string[] DateSplit = date.Split('/');  //TODO Raj 2023 - Need to have in common methods

            if (format == "DD/MM/YYYY")
                Dateformat = DateSplit[0].PadLeft(2, '0') + "/" + DateSplit[1].PadLeft(2, '0') + "/" + DateSplit[2];
            else if (format == "YYYY-MM-DD")
                Dateformat = DateSplit[2] + "-" + DateSplit[0].PadLeft(2, '0') + "-" + DateSplit[1].PadLeft(2, '0');
            return Dateformat;
        }

        public void GetAddressInfo()
        {
            //TODO : This is a temporary fix to directly call SelectPolicy, CancelEFT for MultiQET, MutliMET
            string stateandzip;
            string address;
            string sep = ",";
            string country = "";
            stateandzip = data[KeyRepository.State] + " " + data[KeyRepository.Zip];

            ////TODO: Raj 2023  - Manually test to see why we need to handle this address

            //Phrase address line of Owner address based on Address line 2 availability
            if (data[KeyRepository.AddressLine2] == "")
            {
                address = data[KeyRepository.AddressLine1];
            }
            else
            {
                address = data[KeyRepository.AddressLine1] + " " + data[KeyRepository.AddressLine2];
            }

            if (stateandzip != "")
            {
                data[KeyRepository.Address] = address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + stateandzip + " " + country;
            }
            else
            {
                data[KeyRepository.Address] = address.Trim() + " " + data[KeyRepository.City].Trim() + sep + " " + country;
            }
        }

        public string GetPolicyStatusMessage()
        {
            string Mesg = "";

            if (data[KeyRepository.PolicyStatus] == "Cancelled")
                Mesg = new CSW.Common.Excel.TestData().GetContent("Cancelled");
            else if (data[KeyRepository.PolicyStatus] == "Reduced Paid-Up")
                Mesg = new CSW.Common.Excel.TestData().GetContent("Reduced Paid-Up");
            else if (data[KeyRepository.PolicyStatus] == "Exchanged")
                Mesg = new CSW.Common.Excel.TestData().GetContent("Exchanged");
            else if (data[KeyRepository.PolicyStatus] != "Lapse")
                Mesg = "Contract is active.";
            else
                Mesg = "Contract is no longer active and premiums are past due.";

            return Mesg;
        }

        public void ChangePayorByCountry(string args, IWebElement Country, out string[] Payorfields, out string pFN, out string pLN, out string pPN, out string pCY,
            out string pAL1, out string pAL2, out string pST, out string pZP, out string pCN, out string StatenZip)
        {
            TestData testData = new TestData();
            pFN = NYLDGeneric.GenerateFirstName();
            pLN = NYLDGeneric.GenerateLastName();
            pPN = "(200) 123-1234";
            pCY = "Tampa";
            List<string> addresslist = testData.GetAddresses(state: "Any");
            pAL1 = addresslist[0];
            pAL2 = "";

            //Define field to validated based on country selected
            if (args == "CA")
            {
                NYLDSelenium.SelectList("Country", Country, "Canada", "bytext");
                Payorfields = new string[] { "First Name", "Last Name", "Primary phone number", "Address", "City", "Postal Code" };
                pCN = "CA - Canada";
                pST = "AB";
                pZP = "T4X 0M3";
                StatenZip = pST + " " + pZP;
            }
            else if (args == "US")
            {
                Payorfields = new string[] { "First Name", "Last Name", "Primary phone number", "Address", "City", "Zip" };
                NYLDSelenium.SelectList("Country", Country, "United States", "bytext");
                pCN = "US - United States";
                pST = "FL";
                pZP = "33607";
                StatenZip = pST + " " + pZP;
            }
            else
            {
                Payorfields = new string[] { "First Name", "Last Name", "Address", "City" };
                pCN = "EG - EGYPT";
                pST = "";
                pZP = "";
                StatenZip = pST + " " + pZP;
            }
        }

        public void ChangePayorByTestDataConfigState(string args, IWebElement FirstName, IWebElement LastName, IWebElement PhoneNumber, IWebElement AddresLine1, IWebElement AddressLine2,
            IWebElement City, IWebElement Country, IWebElement State, IWebElement Zip, IWebElement Province, IWebElement PostalCode,
            out string pFN, out string pLN, out string pPN, out string pAL1, out string pCY, out string StatenZip, out string pCN, out string pAL2)
        {
            TestData testData = new TestData();
            pFN = "Test" + NYLDGeneric.GenerateFirstName();
            pLN = "Test" + NYLDGeneric.GenerateLastName();
            pPN = "(200) 123-1234";
            pAL1 = "";
            pAL2 = "";
            pCY = "";
            string state, pST, pZP;
            List<string> addresslist = new List<string>();

            // Clear and update Non Country specific fields
            ClearAndSendKeys(FirstName, pFN);
            ClearAndSendKeys(LastName, pLN);
            ClearAndSendKeys(PhoneNumber, pPN);

            NYLDSelenium.ReportStepResult("Select Country: " + args, "Select Country", "INFO", "no");
            pCN = CommonFunctions.SelectCountryByCode(Country, testData.GetMappedValue("Country", args.Trim()));

            // Update country specific fields
            switch (args.Trim())
            {
                case "US":
                    addresslist = testData.GetAddresses(state: "MI");
                    pAL1 = addresslist[0];
                    pAL2 = addresslist[1];
                    pCY = addresslist[3];
                    state = testData.GetMappedValue("State", "MI");
                    pST = "MI";
                    pZP = addresslist[5];
                    StatenZip = pST + " " + pZP;

                    NYLDSelenium.SelectList("Update payor State", State, state, "bytext", true);
                    ClearAndSendKeys(AddresLine1, pAL1);
                    ClearAndSendKeys(AddressLine2, pAL2);
                    ClearAndSendKeys(City, pCY);
                    ClearAndSendKeys(Zip, pZP);
                    break;

                case "CA":
                    addresslist = testData.GetAddresses(state: "Any");
                    pAL1 = addresslist[0];
                    pAL2 = addresslist[1];
                    pCY = "Edmonton";
                    state = testData.GetMappedValue("State", "AB");
                    pST = "AB";
                    pZP = "T4X 0A5";
                    StatenZip = pST + " " + pZP;

                    NYLDSelenium.SelectList("Update payor State", Province, state, "bytext", true);

                    ClearAndSendKeys(AddresLine1, pAL1);
                    ClearAndSendKeys(AddressLine2, pAL2);
                    ClearAndSendKeys(City, pCY);
                    ClearAndSendKeys(PostalCode, pZP);
                    break;

                default:
                    addresslist = testData.GetAddresses(state: "Any");
                    pAL1 = addresslist[0];
                    pAL2 = addresslist[1];
                    pCY = addresslist[3];
                    pCN = args.Trim() + " - " + pCN;
                    pST = "";
                    pZP = "";
                    StatenZip = "";
                    ClearAndSendKeys(AddresLine1, pAL1);
                    ClearAndSendKeys(AddressLine2, pAL2);
                    ClearAndSendKeys(City, pCY);
                    break;
            }
        }

        private void ClearAndSendKeys(IWebElement element, string value)
        {
            NYLDSelenium.Clear("Clear " + element.GetAttribute("name"), element);
            NYLDSelenium.SendKeys("Update " + element.GetAttribute("name"), element, value);
        }


        /// <summary>
        /// Method helps to verify the IwantoLinks working or not
        /// </summary>
        /// <param name="page"></param>
        /// <param name="Iwantto"></param>
        public void ValidateIWantToLinks(string page, string element)
        {
            NYLDSelenium.AddHeader("Validate the Quicklinks", "SubHeader");

            IList<IWebElement> Iwantto = driver.FindElements(By.XPath(element));

            //Capture the current URL 
            var currenturl = driver.Url; int count = Iwantto.Count;

            //loop to Iwantto links
            for (var i = 0; i < count; i++)
            {
                Iwantto = driver.FindElements(By.XPath(element));
                string linktext = Iwantto[i].Text;

                if (!string.IsNullOrEmpty(linktext))
                {
                    string url = Iwantto[i].GetAttribute("href");
                    //Click the each link 
                    NYLDSelenium.Click(linktext, Iwantto[i], true);

                    Thread.Sleep(4000);
                    //Capture the url and compre with the existing url

                    if (!driver.PageSource.ToLower().Contains(linktext.ToLower().Substring(linktext.Length - 3, 3)))
                        NYLDSelenium.ReportStepResult("Verify " + page + "-Quick Link" + linktext, page + "--Quick Link  :" + linktext + " is not working", "FAIL", "always");
                    driver.Navigate().GoToUrl(currenturl);
                }
                if (i == 5)
                    break;
            }
            driver.Navigate().GoToUrl(currenturl);
        }

        public string GetDaySuffix(int day)
        {
            switch (day)
            {
                case 1:
                case 21:
                case 31:
                    return "st";
                case 2:
                case 22:
                    return "nd";
                case 3:
                case 23:
                    return "rd";
                default:
                    return "th";
            }
        }       

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: SelectPolicy                                                               ///////////
        ////// Description: Selecting the policy                                                ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public void SelectPolicy(string args)
        {
            LSPDatabase Tampa01 = new LSPDatabase(driver, data);
            ManagePaymentsPage paymentsPage = new ManagePaymentsPage(driver, data);
            string ActualPolicyName = "";
            bool policyFound = false;
            string requestType, info;
            string[] splitStr = args.Split(',');
            requestType = splitStr[0].Trim();
            info = splitStr.Length > 1 ? splitStr[1].Trim() : "";

            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Select Policy" + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            //scrolling to the element exist
            NYLDSelenium.ElemExist("Contract Number ", paymentsPage.ContractNumberDropdown, true, "yes");

            SelectElement SE = new SelectElement(paymentsPage.ContractNumberDropdown);
            //Find the policies count

            IList<IWebElement> policies = SE.Options;

            int j = string.IsNullOrEmpty(info) ? 0 : int.Parse(info);
            //select policy which meets test criteria
            for (; j < policies.Count; j++)
            {
                SelectElement select = new SelectElement(paymentsPage.ContractNumberDropdown);
                IList<IWebElement> options = select.Options;

                ActualPolicyName = options[j].GetAttribute("text").Trim();
                data[KeyRepository.PolicyNumber] = ActualPolicyName.Split(' ').Last();
                Tampa01.QueryPolicyDetails();
                Tampa01.QueryPaymentDetails();
                GetContractCardcolor();

                //Select the contract from dropdown
                ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollBy(0,-8000);");
                Thread.Sleep(5000);
                NYLDSelenium.SelectList("Policy drop down", paymentsPage.ContractNumberDropdown, ActualPolicyName, "bytext", true);
                Thread.Sleep(3000);

                if (IsPolicyMatchingCriteria(requestType, paymentsPage, Tampa01, info))
                {
                    policyFound = true;
                    break;
                }
            }

            //If Expected Policy Not Found, fail the test case
            if (!policyFound)
            {
                NYLDSelenium.ReportStepResult("Select the policy that meets the condition :" + requestType.Trim(), "Policy with required condition is not found in the dropdown list : " + requestType.Trim() + ".Reach out to automation team.", "FAIL", "always", "yes");
            }
            else
            {
                NYLDSelenium.ReportStepResult("Select the policy that meets the condition : " + requestType.Trim(), "Selected the Policy that required condition: " + requestType.Trim() + ".", "PASS", "always");
            }
        }

        private bool IsPolicyMatchingCriteria(string requestType, ManagePaymentsPage paymentsPage, LSPDatabase Tampa01, string info)
        {
            switch (requestType)
            {
                case "ExistingAutoPay":
                    return data[KeyRepository.PolicyStatus] == "Inforce" && data[KeyRepository.PayCode] == "ET" && (data[KeyRepository.Funtionality] != "Payment" || NYLDSelenium.ElemExist("Update AutoPay section", paymentsPage.UpdateAutoPaymentHeader, true, "no", "no", "no"));
                case "MonthlyAutoPay":
                    return data[KeyRepository.PolicyStatus] == "Inforce" && data[KeyRepository.PayCode] == "ET" && data[KeyRepository.CurrentPaymentFrequency] == "M" && (data[KeyRepository.Funtionality] != "Payment" || NYLDSelenium.ElemExist("Update AutoPay section", paymentsPage.UpdateAutoPaymentHeader, true, "no", "no", "no"));
                case "QuarterlyAutoPay":
                    return data[KeyRepository.PolicyStatus] == "Inforce" && data[KeyRepository.PayCode] == "ET" && data[KeyRepository.CurrentPaymentFrequency] == "Q" && (data[KeyRepository.Funtionality] != "Payment" || NYLDSelenium.ElemExist("Update AutoPay section", paymentsPage.UpdateAutoPaymentHeader, true, "no", "no", "no"));
                case "NoAutoPayFreqEligible":
                    Tampa01.QueryQuarterlyPaymntElig();
                    return CSWData.QuarterlyEligibility && data[KeyRepository.PayCode] == "IN" && data[KeyRepository.PolicyStatus] == "Inforce" && (data[KeyRepository.Funtionality] != "Payment" || NYLDSelenium.ElemNotExist("New AutoPay section", paymentsPage.AutoPayOption_label, true, "no", "no", "no"));
                case "NoAutoPay":
                    return data[KeyRepository.PayCode] == "IN" && data[KeyRepository.PolicyStatus] == "Inforce" && (data[KeyRepository.Funtionality] != "Payment" || NYLDSelenium.ElemNotExist("New AutoPay section", paymentsPage.AutoPayOption_label, true, "no", "no", "no"));
                case "NewAutoPay":
                    return data[KeyRepository.PayCode] == "IN" && data[KeyRepository.PolicyStatus] == "Inforce" && (data[KeyRepository.Funtionality] != "Payment" || NYLDSelenium.ElemExist("New AutoPay section", paymentsPage.AutoPayOption_label, true, "no", "no", "no"));
                case "Lapse":
                    return data[KeyRepository.PolicyStatus] == "Lapse";
                case "Inforce":
                    return data[KeyRepository.PolicyStatus] == "Inforce";
                case "Index":
                    var uri = new Uri(driver.Url);
                    var query = System.Web.HttpUtility.ParseQueryString(uri.Query);
                    var cpolValue = query.Get("cpol");
                    return cpolValue == info;
                default:
                    return false;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        ////// Name: CalculateQuarterlyEligibility                                              ///////////
        ////// Description: CalculateQuarterlyEligibility Mode change for Payment Frequency     ///////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        public bool CalculateQuarterlyEligibility(DateTime startDate, DateTime endDate)
        {
            if (endDate < startDate)
            {
                throw new ArgumentException("End date must be greater than or equal to the start date.");
            }
            DateTime startDateToCompare = DateTime.Parse(startDate.ToString());
            DateTime endDateToCompare = DateTime.Parse(endDate.ToString());
            TimeSpan totalDaysDifference = endDateToCompare - startDateToCompare;
            int totalDays = (int)totalDaysDifference.TotalDays;
            int totalQuartersDifference = totalDays % 3;
            if (totalQuartersDifference == 0)
                return true;
            return false;
        }

        public void getUserName()
        {
            string firstName = data[KeyRepository.FirstName];
            if (firstName.Length > 5)
            {
                firstName = firstName.Substring(0, 5);
            }

            string ssnPart = data[KeyRepository.SSN].Substring(3, 5);
            string uniquePart = new Random().Next(1000, 9999).ToString(); // 4-digit random number

            data[KeyRepository.UserName] = ("AUT" + firstName + ssnPart + uniquePart).Replace(" ", "");

            if (data[KeyRepository.UserName].Length > 15)
            {
                data[KeyRepository.UserName] = data[KeyRepository.UserName].Substring(0, 15);
            }
        }

        public string ExpectedBeneClassName(string beneClassification)
        {
            string expectedBeneClassName = "First";
            switch (beneClassification)
            {
                case "BN2":
                    expectedBeneClassName = "Second";
                    break;
                case "BN3":
                    expectedBeneClassName = "Third";
                    break;
                case "BN1":
                default:
                    expectedBeneClassName = "First";
                    break;
            }

            return expectedBeneClassName;
        }
       
    }
}
