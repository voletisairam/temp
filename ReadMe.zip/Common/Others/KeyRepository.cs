﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSW.Common.Others
{
    class KeyRepository
    {
        public static string TestCaseID = "TestCaseID";
        public static string TestCaseDescription = "TestCaseDescription";
        public static string AuthToken = "AuthToken";
        //pages
        public static string CoveragePage = "My coverage";
        public static string BeneficiaryPage = "My beneficiaries";
        public static string PayorPage = "Change payor";
        public static string InsuredPage = "Edit insured";
        public static string OneTimePaymentPage = "One-time payment";
        public static string PaymentPage = "Payment management";
        public static string PaymentHistory = "Payment history";
        public static string ContactInfoPage = "Contact information";
        public static string AccountInfoPage = "Account information";
        public static string PaperlessSettingsInfoPage = "Paperless settings";
        public static string DocumentsInfoPage = "Documents";
        public static string LogoutPage = "Logout";


        public static string URL = "URL";
        public static string WSUrl = "Webservices URL";
        public static string TokenWaitTime = "Token Wait Time";
        public static string Browser = "Browser";
        public static string Environment = "Environment";
        public static string PhoneNumber = "PhoneNumber Number";
        public static string Module = "Module";
        public static string TestName = "Test Name";
        public static string DataType = "DataType";
        public static string UserAccountStatus = "UserAccountStatus";
        public static string ContractCount = "ContractCount";
        public static string ContractType = "ContractType";
        public static string PreTestDataSet = "PreTestDataSet";
        public static string ContractSource = "ContractSource";
        public static string BusinessFlow = "BusinessFlow";
        public static string PostTestDataReset = "PostTestDataReset";
        public static string Smoker = "Smoker";
        public static string LSPDate = "LSP Date";
        public static string PolicyNumber = "Policy Number";
        public static string ZipCode = "Zip";
        public static string ControlNumber = "Control Number";
        public static string FamilyBillGroupID = "Family Bill GroupID";
        public static string ClientIdOfPolicy = "ClientId";
        public static string UclientIdOfPolicy = "U ClientId";
        public static string Status = "Status";
        public static string PolicyStatus = "Policy Status";        
        public static string ContractCardColor = "Contract Card Color";
        public static string PaymentButtonColor = "Payment Button Color";
        public static string PaymentHistoryLink = "Payment History Link";
        public static string PaymentDueAbove52 = "Payment Due Above52";
        public static string TempValue = "Temporary Value";
        public static string TestID = "Functionality_Sub-Functionality_Test Number";
        public static string MIDBServerName = "MIDB ServerName";
        public static string Channel = "Channel";
        public static string Queue = "Queue";
        public static string PinCode = "PinCode";
        public static string SubFuntionality = "Functionality_Sub-Functionality";
        public static string Funtionality = "Functionality";

        public static string FirstName = "First Name";
        public static string LastName = "Last Name";
        public static string MiddleName = "Middle Name";
        public static string Title = "Title";
        public static string Suffix = "Suffix";
        public static string Address = "Address";
        public static string AddressLine1 = "Address Line1";
        public static string AddressLine2 = "Address Line2";
        public static string State = "State";
        public static string City = "City";
        public static string Zip = "Zip";
        public static string Country = "Country";
        public static string DOB = "Date Of Birth";
        public static string EmailId = "Email Id";
        public static string EmailIdSet = "Email Id Set";
        public static string SSN = "SSN";
        public static string Phone = "PhoneNumber";
        public static string UserNameSet = "UserNameSet";
        public static string UserName = "UserName";
        public static string Password = "Password";
        public static string PrevPassword = "PrevPassword";
        public static string ClientId = "ClientId";
        public static string NylId = "nylid";
        public static string ProfilePhone = "ProfilePhoneNumber";
        public static string NLYPairId = "NYLPairId";        
        public static string NYLApplicationRole = "NYLApplicationRole";

        //CVL Info
        public static string CVLAddressData = "CVLAddressData";
        public static string CVLFaxNumber = "CVLFaxNumber";

        //Payment Info
        public static string EffectiveDate = "Effective Date";
        public static string PaysToDate = "Pays To Date";
        public static string PaidToDate = "Paid To Date";
        public static string Premium = "Premium";
        public static string IssuedState = "Issued State";
        public static string CoverageAmount = "Coverage Amount";
        public static string DeltaCoverage = "Delta Coverage";
        public static string PolicyName = "Policy Name";
        public static string CurrentPaymentFrequency = "Current Payment Frequency";
        public static string PayCode = "PayCode";
        public static string LastPaymentAmt = "Last Payment Amt";
        public static string LastPaymentDate = "Last Payment Date";
        public static string EFTPremium  = "FIS Premium";
        public static string FISPremium = "FIS Premium";
        public static string QuarterlyPremium = "Quarterly Premium";
        public static string MonthlyPremium = "Monthly Premium";
        public static string PaymentDate = "Payment Date";
        public static string RoutingNumber = "Routing Number";
        public static string AccountNumber = "Account Number";
        public static string PaymentDueDate = "Payment Due Date";
        //Insured Info
        public static string InsuredTitle = "Insured Title";
        public static string InsuredFirstName = "Insured FirstName";
        public static string InsuredLastName = "Insured LastName";
        public static string InsuredMiddleName = "Insured MiddleName";
        public static string InsuredFullName = "Insured FullName";
        public static string InsuredDOBDay = "Insured DOBDay";
        public static string InsuredDOBMonth = "Insured DOBMonth";
        public static string InsuredDOBYear = "Insured DOBYear";
        public static string InsuredGender = "Insured Gender";

        //Payor Info
        public static string PayorFirstName = "Payor FirstName";
        public static string PayorLastName = "Payor LastName";
        public static string PayorAddressLine1 = "Payor AddressLine1";
        public static string PayorAddressLine2 = "Payor AddressLine2";
        public static string PayorState = "Payor State";
        public static string PayorCity = "Payor City";
        public static string PayorZip = "Payor Zip";
        public static string PayorPhone = "Payor PhoneNumber";
        public static string PayorCountry = "Payor Country";

        public static string BlankMessage = "Blank Message";
        public static string InvalidMessage = "Invalid Message";
        public static string MaximumLength = "Maximum Length";
        public static string ValidInput = "Valid Input";
        public static string InvalidInput = "Invalid Input";
        public static string FieldType = "Field Type";
        public static string ErrorTrigger = "Error Trigger";
        public static string FieldName = "Field Name";
        public static string PageName = "Page";
        public static string Attributetypes = "Attribute Type";


        //Riders
        public static string RiderUserName = "Rider UserName";
        public static string RiderFlag = "Rider Flag";
        public static string Product = "Product";
        public static string Version = "Question Version";
        public static string PFC = "PFC";
        public static string SourceCode = "Source Code";
        public static string Height = "Height";
        public static string Weight = "Weight";
        public static string TemplateType = "Template Type";
        public static string HQAnswers = "HQ Answers";
        public static string HQComments = "HQ Comments";
        public static string HealthRisks = "Health Risks";
        public static string Member = "Member";
        public static string Age = "Age";
        public static string LeadID = "Lead ID";
        public static string Replacement = "Replacement";
        public static string Feet = "Feet";
        public static string Inches = "Inches";
        public static string Response = "Response";
        public static string ProductCode = "ProductCode";
        public static string AutoAcceptStatus = "AutoAcceptStatus";
        public static string TemplateFormId = "TemplateFormId";
        public static string Read_SignDisclaimer = "Read_SignDisclaimer";
        public static string EmailIdInfo = "EmailIdInfo";
        public static string GUID = "GUID";

        public static string CAResidents = "CAResidents";
        public static string DBValidation = "DBValidation";
        public static string ResettheRow = "ResettheRow";
        public static string ReResettheRow = "ReResettheRow";

        public static string Regrex = "RegExpression";
        public static string EmailLastname = "EmailLastname";
        public static string selectedpickadate = "selectedpickadate";
        public static string PostpreProcess = "PostpreProcess";
        public static string Regerror = "Regerror";
    }
}
