﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;

namespace CSW.Common.Others
{
    class CSWData
    {
        public static string TempVal = "";
        public static string TempLastName = "";
        public static string TempSSN= "";
        public static string TempDOB = "";
        public static string TempUserName = "";
        public static string TempEmail = "";
        public static string TempPassword = "";
        public static string TempInvalidPIN = "";
        public static string XML = "";

        public static string AssociatedPolicies = "";
        public static string VIPERPolicies = "";
        public static string PaymentEligPolicies = "";
        public static string LapsePolicies = "";
        // public static Hashtable ContentMisc;

        public static bool EmailVerificationflag = false;
        public static bool DMFlagOff = true;
        public static bool QuarterlyEligibility = true;
        public static bool MonthlyEligibility = true;
        public static bool PageVerification = true;
        public static bool DeathClaimPolicies = false;

        public static DateTime EventTriggerTime;

        public static List<List<string>> BeneInfo = new List<List<string>>();
        public static List<String> NewBeneInfo = new List<string>();
        public static IList<string> PaymentInformation = new List<string>();
        public static List<List<string>> CoverageSummaryInfo = new List<List<string>>();
        public static List<List<string>> RiderInfo = new List<List<string>>();
        public static List<string> PaymentHistory = new List<string>();

        public static string Exisitngpolicyfromsheet = "";
        public static int ExpBeneIndex = 0;

    }
}
