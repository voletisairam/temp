﻿using CSW.Common.Others;
using CSW.Common.Services;
using CSW.PageObjects.Email;
using Newtonsoft.Json;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace CSW.Common.Email
{
    public class EmailVerification
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public EmailVerification(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        public static string expectedFilespath = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.TemplatePath + @"\Email\";
        public static string finalFilesPath = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.OutlookEmailDirectory;

        public static DateTime dtUI = new DateTime();
        public static bool emailReceived = false;
        public static string expSubject = "";
        public static string expEmailTemplate = "";
        public static bool switchNewTab = false;
        public static bool cyberFraudEmail;
        public static bool updateConfirmationEmail;
        public static bool paymentEmail;


        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////



        //Main Logic
        [FindsBy(How = How.XPath, Using = "//div[@title='Folders']")]
        public IWebElement Folders { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@title='CSW']")]
        public IWebElement CSWFolder { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@aria-label='Message list']//span[text()='CSW']")]
        public IWebElement CSWFolderList { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@title='Folders']/button")]
        public IWebElement OpenFolders { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href,'reset')]")]
        public IWebElement RestPasswordLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(text(), 'request a new code')]")]
        public IWebElement ResendLink { get; set; }

        public static string emailverification;
        /// <summary>
        /// Verify Email body connect to match with template
        /// </summary>
        /// <param name="emailType"></param>
        public void VerifyEmail(string emailType)
        {
            if (!emailverification.Contains("nyld_uploads_dev")&& !emailverification.Contains("NYLDirect_Claims_General_Test") && !emailverification.Contains("NYLDirect_Member_services_General_Test"))
            {
                List<String> actemailContent = new List<string>();
                List<String> expemailContent = new List<string>();
                string expemailfile = finalFilesPath + emailType + "_Expected_" + data[KeyRepository.PolicyNumber] + ".txt";
                string actemailfile = finalFilesPath + emailType + "_Actual_" + data[KeyRepository.PolicyNumber] + ".txt";

                if (emailReceived)
                {
                    string paidToDate = data[KeyRepository.PaidToDate].Split('/')[0].TrimStart('0') + "/" + data[KeyRepository.PaidToDate].Split('/')[1].TrimStart('0') + "/" + data[KeyRepository.PaidToDate].Split('/')[2];
                    //Read expected email content from template
                    using (StreamReader sr = new StreamReader(expectedFilespath + expEmailTemplate))
                    {
                        string expemaillines;
                        while ((expemaillines = sr.ReadLine()) != null)
                        {
                            if (expemaillines.Contains("{DateTime}"))
                            {
                                expemaillines = expemaillines.Replace("{DateTime}", DateTime.Now.ToString("ddd M/d/yyyy h:mm tt"));
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{Date}"))
                            {
                                if (emailType == "Cyber Fraud Alert" || emailType == "PM Reset Password")
                                    expemaillines = expemaillines.Replace("{Date}", DateTime.Now.ToString("MM-dd-yyyy"));
                                else
                                    expemaillines = expemaillines.Replace("{Date}", DateTime.Now.ToString("MM-dd-yyyy"));
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{FirstName}"))
                            {
                                expemaillines = expemaillines.Replace("{FirstName}", data[KeyRepository.FirstName]);
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{PinCode}"))
                            {
                                expemaillines = expemaillines.Replace("{PinCode}", data[KeyRepository.PinCode]);
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{PaidtoDate}"))
                            {
                                if (emailType.Contains("Payment"))
                                    expemaillines = expemaillines.Replace("{PaidtoDate}", Convert.ToDateTime(paidToDate).ToString("MM/dd/yyyy"));
                                else
                                    expemaillines = expemaillines.Replace("{PaidtoDate}", paidToDate);
                                expemailContent.Add(expemaillines);
                            }
                            else if (updateConfirmationEmail)
                            {
                                if (expemaillines.Contains("{UserFieldName}"))
                                {
                                    expemaillines = expemaillines.Replace("{UserFieldName}", CSWData.TempVal.Trim());
                                    expemailContent.Add(expemaillines);
                                }
                            }
                            else if (expemaillines.Contains("{FullName}"))
                            {
                                expemaillines = expemaillines.Replace("{FullName}", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName]);
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{ClientID}"))
                            {
                                expemaillines = expemaillines.Replace("{ClientID}", data[KeyRepository.ClientIdOfPolicy]);
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{FullDate}"))
                            {
                                expemaillines = expemaillines.Replace("{FullDate}", string.Format("{0:f}", CSWData.EventTriggerTime));
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{UserName}"))
                            {
                                expemaillines = expemaillines.Replace("{UserName}", Environment.UserName.ToLower());
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{AdditionalNotes}"))
                            {
                                expemaillines = expemaillines.Replace("{AdditionalNotes}", CSWData.TempVal.Trim());
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{EmailID}"))
                            {
                                expemaillines = expemaillines.Replace("{EmailID}", data[KeyRepository.EmailId].Trim());
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{ContractNumber}"))
                            {
                                expemaillines = expemaillines.Replace("{ContractNumber}", data[KeyRepository.PolicyNumber]);
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{UpdateConfirmOption}"))
                            {
                                expemaillines = expemaillines.Replace("{UpdateConfirmOption}", CSWData.TempVal.Trim().ToLower());
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{URL}"))
                            {
                                expemaillines = expemaillines.Replace("{URL}", data[KeyRepository.URL].Trim());
                                expemailContent.Add(expemaillines);
                            }
                            else if (expemaillines.Contains("{Token}"))
                            {
                                //string token = new CSW.Common.Services.Webservices(driver, data).SubmitRestCall("GenerateToken", "100");
                                expemaillines = expemaillines.Replace("{Token}", data[KeyRepository.URL].Replace("Login", "Confirm?token=").Trim());
                                expemailContent.Add(expemaillines);
                            }
                            else
                                expemailContent.Add(expemaillines);
                        }
                    }

                    SaveExpectedEmailContent(expemailfile, expemailContent);

                    //Read actual email content from template
                    using (StreamReader sr = new StreamReader(actemailfile))
                    {
                        int i = 1;
                        bool startAdd = false;

                        string actemaillines;
                        //       Console.WriteLine("Actual Email Content is::");

                        while ((actemaillines = sr.ReadLine()) != null)
                        {

                            //Set the Start Add only after To address encountered
                            if (!actemaillines.Contains("CS_Web_Dev_Support"))
                            {
                                startAdd = true;
                                if (startAdd)
                                    actemailContent.Add(actemaillines);
                            }

                            i++;
                        }
                    }

                    //Remove the empty rows from the array
                    expemailContent.RemoveAll(item => item == "\t\r\n"); expemailContent.RemoveAll(string.IsNullOrWhiteSpace);
                    actemailContent.RemoveAll(item => item == "\t\r\n"); actemailContent.RemoveAll(string.IsNullOrWhiteSpace);

                    //Compare actual email with expected email

                    //NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received and the expected content", actemailfile + " email is received and content is as expected", "PASS");


                    #region --hide the email validation

                    if (expemailContent.Count() != actemailContent.Count())
                    {

                        //If there is mismatch between actual and expected content, verify from which line the mismatch starts

                        NYLDSelenium.ReportStepResult("Verify the content of email for: " + emailType, "There is mismatch in no. of lines in expected: " + expemailContent.Count() + " and actual: " + actemailContent.Count() + " email", "FAIL", "no", "no");
                    }

                    else if (expemailContent.Count() == actemailContent.Count())
                    {
                        for (int i = 0; i < expemailContent.Count(); i++)
                        {
                            if (expemailContent[i].Trim().Replace("-", "/") != actemailContent[i].Trim().Replace("-", "/"))
                            {
                                int linetoReview = i + 1;
                                if (!actemailContent[i].Contains("http"))
                                {
                                    NYLDSelenium.ReportStepResult("Verify the content of email for: " + emailType, "There is mismatch in  at line #" + linetoReview + ". Expected: " + expemailContent[i] + " Actual: " + actemailContent[i], "FAIL", "no", "no");
                                }
                                break;
                            }
                        }
                        NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received and the expected content", actemailfile + " email is received and content is as expected", "PASS");
                    }
                    else
                    {
                        if (actemailContent.SequenceEqual(expemailContent))
                        {
                            NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received and the expected content", emailType + " email is received and content is as expected", "PASS");
                        }
                    }

                    #endregion
                }
                else
                    NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received", emailType + " email is not received with in the time frame from:  " + CSWData.EventTriggerTime + " To : " + DateTime.Now, "FAIL");

                try
                {
                    //  File.Delete(expemailfile);
                    //  File.Delete(actemailfile);
                }
                catch { }
                cyberFraudEmail = false;
                updateConfirmationEmail = false;
                paymentEmail = false;
            }
        }


        /// <summary>
        /// Method helps to get the emaail subject with template
        /// </summary>
        /// <param name="Eventtype"></param>
        public void GetEmailContentValues(string Eventtype)
        {
            switch (Eventtype)
            {
                case "Paperless Settings Confirmation":
                    expSubject = "Your paperless settings have been updated";
                    expEmailTemplate = "PaperlessSettingsConfirmation.txt";
                    break;

                case "Registration Success":
                    expSubject = "Success, " + data[KeyRepository.FirstName] + ": Your account has been created.";
                    expEmailTemplate = "RegistrationSuccess.txt";
                    break;

                case "Account Verification":
                    expSubject = "New York Life Account Access Code";
                    expEmailTemplate = "AccountVerification.txt";
                    break;

                case "Reset Password":
                    expSubject = "Thank you for updating your account";
                    expEmailTemplate = "ResetPassword.txt";
                    break;

                case "PM Reset Password":
                    expSubject = "Thank you for updating your account";
                    expEmailTemplate = "PMResetPassword.txt";
                    break;

                case "Password Confirmation":
                    expSubject = "Thank you for updating your information!";
                    expEmailTemplate = "PasswordConfirmation.txt";
                    break;

                case "Change Payor Confirmation":
                    expSubject = "Change payor request received";
                    expEmailTemplate = "ChangePayorConfirmation.txt";
                    break;

                case "Contact Information Update Address Confirmation":
                    expSubject = "Thank you for keeping your contact information updated!";
                    expEmailTemplate = "ContactInfoUpdateAddressConfirmation.txt";
                    break;

                case "Contact Information Update Phone Confirmation":
                    expSubject = "Thank you for keeping your contact information updated!";
                    expEmailTemplate = "ContactInfoUpdatePhoneConfirmation.txt";
                    break;

                case "Edit Insured Confirmation":
                    expSubject = "FW: " + data[KeyRepository.FirstName] + ", thank  you for updating your information";
                    expEmailTemplate = "EditInsuredConfirmation.txt";
                    break;

                case "Change Beneficiary Confirmation":
                    expSubject = "Thanks for keeping your contract updated";
                    expEmailTemplate = "ChangeBeneficiaryConfirmation.txt";
                    break;

                case "Account Information - Update Confirmation":
                    expSubject = "Thank you for updating your information";
                    expEmailTemplate = "UpdateConfirmation.txt";
                    break;

                case "EFT SetUp Confirmation":
                    expSubject = "FW: " + data[KeyRepository.FirstName] + ", thank  you for updating your payment preferences";
                    expEmailTemplate = "PaymentEnrollmentConfirmation.txt";
                    paymentEmail = true;
                    break;

                case "EFT Update Confirmation":
                    expSubject = data[KeyRepository.FirstName] + ", thank  you for updating your payment preferences";
                    expEmailTemplate = "PaymentChangeConfirmation.txt";
                    paymentEmail = true;
                    break;

                case "Cancel ET":
                    expSubject = "Your AutoPay enrollment has been cancelled";
                    expEmailTemplate = "CancelET.txt";
                    paymentEmail = true;
                    break;

                case "Cash Value Letter Confirmation":
                    expSubject = "Cash value letter request received";
                    expEmailTemplate = "CashValueLetterRequestConfirmation.txt";
                    break;

                case "Cancel Pending ET":
                    expSubject = "Your AutoPay enrollment will be cancelled";
                    expEmailTemplate = "CancelPendingET.txt";
                    paymentEmail = true;
                    break;

                case "Payment Frequency Change Confirmation":
                    expSubject = "Thank you for updating your payment frequency";
                    expEmailTemplate = "PaymentFrequencyChangeConfirmation.txt";
                    paymentEmail = true;
                    break;

                case "Cyber Fraud Alert":
                    expSubject = "Cyber Fraud Alert: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "CyberFraudAlert.txt";
                    cyberFraudEmail = true;
                    break;

                case "Deactivated Customer Notification":
                    expSubject = "Deactivated Customer Notification";
                    expEmailTemplate = "DeactivatedCustomerNotification.txt";
                    break;

                case "Rider SubmitAddress Confirmation":
                    expSubject = "Thank you for your application for an AARP Term Rider from New York Life";
                    expEmailTemplate = "RiderSubmitConfirmation.txt";
                    break;

                case "Fax Cash Value Letter Confirmation":
                    expSubject = "Cash value fax request received";
                    expEmailTemplate = "FaxCashValueLetterRequestConfirmation.txt";
                    break;
                case "Secure Document Upload successful":
                    expSubject = "Success! Your documents have been uploaded";
                    expEmailTemplate = "SecureDocUploadSuccess.txt";
                    break;
                case "Secure Document upload Devs":
                    expSubject = "Secure document upload email with attachments";
                    expEmailTemplate = "";
                    break;
                case "Secure Document Claims General Test":
                    expSubject = "NYL Secure Document Upload";
                    expEmailTemplate = "";
                    break;
                case "Secure Document Member services General Test":
                    expSubject = "NYL Secure Document Upload";
                    expEmailTemplate = "";
                    break;
            }
        }

        /// <summary>
        /// Method helps to verify the email
        /// </summary>
        /// <param name="emailType"></param>
        /// <param name="emailgroupname"></param>
        /// <param name="tsMinutes"></param>
        /// <param name="hardStop"></param>
        public void VerifyEmailInbox(string emailType, string emailgroupname = "NYLD_Automation", int tsMinutes = 1, string hardStop = "no")
        {
            //inital declaration of email received as false
            emailReceived = false;

            //Ref:test data sheet Email Verification is set ot On or OFF- Verify Email verification flag is set to true excelsheet
            if (CSWData.EmailVerificationflag == true)
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + " Email reception and verification for type: " + emailType + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO");

                //Get the subject name and tempalte based on email type
                GetEmailContentValues(emailType);

                //Capture the email when email is trigger
                CommonFunctions.SetEmailTriggerTime(emailType, tsMinutes);

                //Iterations to check email is receive 
                for (int i = 1; i <= 10; i++)
                {
                    //wait for few seconds if the email is not received 
                    if (emailgroupname.Contains("NYLDirect_Claims_General_Test") || emailgroupname.Contains("NYLDirect_Member_services_General_Test"))
                        Thread.Sleep(150000);
                    else 
                        Thread.Sleep(30000);

                    //If email is received  step out from loop
                    if (VerifyEmails(emailType, emailgroupname))
                        break;
                }

                //to display email if not received with in 15 min or with in the 10 iterations 
                if (!emailReceived)
                    NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received", emailType + " email is not received for first name " + data[KeyRepository.FirstName], "FAIL", "always", "no");
            }
            else //Verify Email verification flag is set to true excelsheet
                NYLDSelenium.ReportStepResult(" Email verification : " + emailType, "Didn't verify the email as email verification flag in Test Configuration sheet is set to no", "INFO");
        }

        /// <summary>
        /// Method helps to verify the email content and OTP verification
        /// </summary>
        /// <param name="emailType"></param>
        /// <param name="groupname"></param>
        /// <param name="time"></param>
        /// <param name="counter"></param>
        /// <returns></returns>
        private bool VerifyEmails(string emailType, string groupname)
        {
            bool resendlink = false;
            string myJsonResponse = "";
            string emailBodyExtract = "";
            DateTime dtemail = new DateTime();
            EmailInformation.EmailList Emaillist = new EmailInformation.EmailList();
            EmailInformation.IndividualEmailInfo IndividualEmailInfo = new EmailInformation.IndividualEmailInfo();
            RestServices restService = new RestServices(data);
            //Email verification groupname to capture
            emailverification = groupname;
            try
            {
                //Get service request for GetEmailList fetch first 100 emails
                myJsonResponse = restService.GetEMails("GetEmailList", groupname);


                //from response no data found /  404 error message or other than 200 message the loop of GetEmail stop
                if (myJsonResponse == "no data found")
                    NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received", emailType + " email is not received ", "FAIL", "always", "yes");
                else
                {
                    //Response contect to invoke -Emaillist class
                    Emaillist = JsonConvert.DeserializeObject<EmailInformation.EmailList>(myJsonResponse);

                    //emails count is used to iteratate the for loop;
                    int emailsCount = Emaillist.emails.Count;
                    int k = 0;

                    //To iterate the EMail list one by one to verify the expected email is received or not
                    for (int i = 0; i < emailsCount; i++)
                    {
                        //Capture the email receive time 
                        string emailtime = Emaillist.emails[i].emailHeaders.receivedDateTime.ToString(@"MM/dd/yyyy hh:mm tt");
                        dtemail = DateTime.ParseExact(emailtime, @"MM/dd/yyyy hh:mm tt", new CultureInfo("en-US"));
                        //To decrease the current email time due  to match with the server time
                        dtemail = dtemail.AddHours(-3.40);


                        //This logic is for registration and reset password due to email didnt have any identity from who ? receving email's
                        var emailfrom = Emaillist.emails[i].emailHeaders.from.address.ToString();

                        if (data[KeyRepository.SubFuntionality].Contains("Registration") || data[KeyRepository.SubFuntionality].Contains("Reset"))
                            if (!emailfrom.ToLower().Contains(data[KeyRepository.EmailLastname].ToLower()))
                                emailReceived = false;
                            else
                                NYLDSelenium.ReportStepResult("Email Received From :" + emailfrom, emailfrom + " is received", "PASS", "no");

                        //  check if email  time is with in trigger time 
                        if (myJsonResponse != "no data found")
                        {
                            if (dtemail > TestSetUp.date)
                            {
                                //Subject validation
                                var emailsubject = Emaillist.emails[i].subject.ToString();
                                if ((!emailsubject.Contains("Secure") && emailsubject.Trim().Contains(expSubject.Trim())) || (emailsubject.Contains("Secure") && Emaillist.emails[i].hasAttachments == true))
                                {
                                    //Get the eMail Title  ( Get Email Body by id)
                                    myJsonResponse = restService.GetEMails(Emaillist.emails[i].id, groupname);

                                    //Get the Email body to validate the body content etc
                                    IndividualEmailInfo = JsonConvert.DeserializeObject<EmailInformation.IndividualEmailInfo>(myJsonResponse);
                                    var content = HtmlUtilities.HtmlToPlainText(IndividualEmailInfo.body, groupname);

                                    if (!groupname.Contains("nyld_uploads_dev") && !groupname.Contains("NYLDirect_Claims_General_Test") && !groupname.Contains("NYLDirect_Member_services_General_Test"))
                                        emailBodyExtract = GetBetween(content, "Subject:", content.Substring(content.Length - 600)) + content.Substring(content.Length - 600);
                                    else
                                        emailBodyExtract = content;

                                    string nameBodyExtract = "";

                                    //Logic to extract the name based on the email type
                                    if (emailType == "Contact Information Update Address Confirmation" && !emailBodyExtract.Contains("address"))
                                        break;
                                    else if (emailType == "Contact Information Update Phone Confirmation" && !emailBodyExtract.Contains("phone number"))
                                        break;
                                    else if ((emailType == "Cancel ET" && emailBodyExtract.Contains("Thank you for updating your payment preferences. Your request has been processed")) || (emailType == "Cancel Pending ET" && !emailBodyExtract.Contains("your Automatic Premium Payment cancelation will begin with the next payment")))
                                        nameBodyExtract = emailBodyExtract;
                                    else if ((emailType == "Cancel Pending ET" || emailType == "Rider SubmitAddress Confirmation"))
                                        nameBodyExtract = GetBetween(emailBodyExtract, "Dear", ":").Replace("\r", "").Replace("\n", "").Trim();
                                    else if (emailType == "Cyber Fraud Alert")
                                        nameBodyExtract = GetBetween(emailBodyExtract, "Name:", "Event").Replace("\r", "").Replace("\n", "").Trim();
                                    else if (emailType == "Registration Success")
                                        nameBodyExtract = GetBetween(emailBodyExtract, "Your registration is complete,", "Your").Replace("\r", "").Replace("\n", "").Trim();
                                    else
                                        nameBodyExtract = emailBodyExtract;

                                    // Verify the email content with expected subject and it includes body content verification 
                                    if (nameBodyExtract.Contains("Success! Your documents have been uploaded") ||
                                        nameBodyExtract.Contains("Thank you for updating your information!") ||
                                         nameBodyExtract.Contains("New York Life Account Access Code")
                                        || nameBodyExtract.Contains("Your paperless settings have been updated")
                                        || nameBodyExtract.Contains(data[KeyRepository.FirstName]) || nameBodyExtract.Contains(data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName]))
                                    {
                                        if (emailType.Contains("Paperless Settings Confirmation"))
                                            NYLDSelenium.ReportStepResult("Email Received", "Paperless Settings Confirmation email is recieved and content is as expected", "PASS","no");
                                        else
                                            NYLDSelenium.ReportStepResult("Email Received and subject :"+emailsubject, emailType + " is received", "PASS","no");

                                        SaveEmailContent(emailType, emailBodyExtract.Replace("•", "").Replace("customer’s", "customers"));

                                        switch (emailType)
                                        {
                                            case "Reset Password":
                                                data[KeyRepository.PinCode] = GetBetween(emailBodyExtract, " one-time verification code on the login page to finish:", "You have 10 minutes").Replace("\r", "").Replace("\n", "").Trim();
                                                emailReceived = true;
                                                break;

                                            case "Account Verification":
                                                data[KeyRepository.PinCode] = GetBetween(emailBodyExtract, "Please use this one-time verification code:", "To keep your account secure").Replace("\r", "").Replace("\n", "").Trim();
                                                emailReceived = true;
                                                break;

                                            case "PM Reset Password":
                                                NYLDSelenium.Click("Reset Password", RestPasswordLink);
                                                switchNewTab = true;
                                                emailReceived = true;
                                                break;

                                            case "Registration Success":
                                            case "Password Confirmation":
                                            case "Change Payor Confirmation":
                                            case "Contact Information Update Address Confirmation":
                                            case "Contact Information Update Phone Confirmation":
                                            case "Edit Insured Confirmation":
                                            case "Change Beneficiary Confirmation":
                                            case "Account Information - Update Confirmation":
                                            case "EFT SetUp Confirmation":
                                            case "EFT Update Confirmation":
                                            case "Cancel ET":
                                            case "Cash Value Letter Confirmation":
                                            case "Payment Frequency Change Confirmation":
                                            case "Cancel Pending ET":
                                            case "Cyber Fraud Alert":
                                            case "Deactivated Customer Notification":
                                            case "Rider SubmitAddress Confirmation":
                                            case "Fax Cash Value Letter Confirmation":
                                            case "Secure Document Upload successful":
                                            case "Paperless Settings Confirmation":
                                                emailReceived = true;
                                                break;
                                        }

                                    }
                                    else if (nameBodyExtract.Contains(data[KeyRepository.PolicyNumber]) || nameBodyExtract.Contains("IsAuthenticated: TRUE"))
                                    {
                                        if ((expSubject == "Secure document upload email with attachments") || (expSubject == "NYL Secure Document Upload"))
                                            NYLDSelenium.ReportStepResult("Email Received :" + emailType, emailType + " is received", "PASS");

                                        switch (expSubject)
                                        {

                                            case "Secure document upload email with attachments":
                                                emailReceived = true;
                                                break;

                                            case "NYL Secure Document Upload":
                                                emailReceived = true;
                                                break;
                                        }
                                    }
                                }

                                if (emailReceived)
                                {
                                    k = i;
                                    break;
                                }
                                else
                                {
                                    //If email is not received with in 5 iteration try to click resendlink request
                                    if (((i == 0) || (i == 5)) && emailType == "Account Verification" && resendlink == false)
                                    {
                                        IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);");
                                        NYLDSelenium.Click("Resendlink", ResendLink, true, "no", "no");
                                        resendlink = true;
                                    }
                                }
                            }
                            else
                            {  //If email is not received with in 4 iteration try to click resendlink request
                                if (((i == 0) || (i == 4)) && emailType == "Account Verification")
                                {
                                    IJavaScriptExecutor js3 = (IJavaScriptExecutor)driver; js3.ExecuteScript("window.scrollBy(0,-1000);");
                                    NYLDSelenium.Click("Resendlink", ResendLink, true, "no", "no");
                                    resendlink = true;
                                }
                                break;
                            }
                        }
                        //this condtion to verify for scure doc upload light autentication
                        if (emailReceived == true && data[KeyRepository.ContractType] == "NoOptionalEmail")
                        {
                            string emailsubjects = "";
                            //  check if email  time is with in trigger time 
                            if (dtemail >= TestSetUp.date)
                            {
                                emailsubjects = Emaillist.emails[k + 1].subject.ToString();
                                if (!emailsubjects.Contains("FW: Success! Your documents have been uploaded"))
                                    NYLDSelenium.ReportStepResult("Account Verification Email for NoOptionalEmail enter - email was not received", "Account Verification Email for NoOptionalEmail enter - email was not received", "FAIL", "always", "yes");
                            }
                        }

                        if (emailsCount == 0) emailReceived = false;

                        //Verify the content of expected email vs actual email
                        if (emailReceived)
                            VerifyEmail(emailType);

                        switchNewTab = false;
                    }
                }
            }
            catch
            {
                emailReceived = false;
            }
            return emailReceived;
        }


        /// <summary>
        /// Method helps to save email content from verify emaillist
        /// </summary>
        /// <param name="emailType"></param>
        /// <param name="emailContent"></param>
        private void SaveEmailContent(string emailType, string emailContent)
        {
            File.WriteAllText(finalFilesPath + emailType + "_Actual_" + data[KeyRepository.PolicyNumber] + ".txt", emailContent);
        }

        /// <summary>
        /// method helps to save expected email content from emaillisr
        /// </summary>
        /// <param name="expemailfile"></param>
        /// <param name="expemailContent"></param>
        private void SaveExpectedEmailContent(string expemailfile, List<string> expemailContent)
        {
            TextWriter tw = new StreamWriter(expemailfile);

            foreach (String s in expemailContent)
            {
                if (s.Replace("850 2658", "850‑2658") != null)
                    tw.WriteLine(s);
            }
            tw.Close();
        }

        /// <summary>
        /// method helps to replace tof weekday replace with empty in email content
        /// </summary>
        /// <param name="emailTime"></param>
        /// <returns></returns>

        private string GetDateWDay(string emailTime)
        {
            return emailTime.Replace("Mon ", "").Replace("Tue ", "").Replace("Wed ", "").Replace("Thu ", "").Replace("Fri ", "").Trim();
        }

        /// <summary>
        /// Method helps to get the specific lines in between the start and end keywords
        /// </summary>
        /// <param name="strSource"></param>
        /// <param name="strStart"></param>
        /// <param name="strEnd"></param>
        /// <returns></returns>
        public static string GetBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }


        /// <summary>
        /// Method helps to check the valida email from api / default
        /// </summary>
        /// <returns></returns>
        public string GetOneTimeCodeFromValidEMail()
        {
            string oneTimeCode = null;
            EmailVerification OE = new EmailVerification(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            CSWData.EmailVerificationflag = true;
            OE.VerifyEmailInbox("Account Verification");
            if (EmailVerification.emailReceived)
                oneTimeCode = data[KeyRepository.PinCode];
            else
                NYLDSelenium.ReportStepResult("Account Verification Email with PinCode not received", "Account Verification Email with PinCode was not received", "FAIL", "always", "yes");

            return oneTimeCode;
        }

    }
}
