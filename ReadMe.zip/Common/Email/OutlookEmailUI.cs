﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using NYLDWebAutomationFramework;
using CSW.Common.Others;
using System.IO;
using System.Threading;
using System.Threading;
using System.Collections.ObjectModel;
using System.Globalization;
using CSW.PageObjects.Login;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;

namespace CSW.Common.Email
{
   public  class OutlookEmailUI
    {
        private IWebDriver driver;
        private Dictionary<string, string> data;

        public OutlookEmailUI(IWebDriver webDriver, Dictionary<string, string> testdata)
        {
            driver = webDriver; //
            data = testdata;
            PageFactory.InitElements(webDriver, this);
        }

        public static string expectedFilespath = Properties.Settings.Default.TemplatePath + @"\Email\";
        public static string finalFilesPath = Properties.Settings.Default.OutlookEmailDirectory;

        public static DateTime dtUI = new DateTime();
        public static bool emailArrive = false;
        public static string expSubject = "";
        public static string expEmailTemplate = "";
        public static bool switchNewTab = false;
        public static bool cyberFraudEmail;
        public static bool updateConfirmationEmail;
        public static bool paymentEmail;


        /////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////           Page Objects    //////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////

        //Login
        [FindsBy(How = How.XPath, Using = "//div[@role='heading' and contains(.,'Sign in')]")]
        public IWebElement LoginSignIn { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='email']")]
        public IWebElement LoginEmail { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='password']")]
        public IWebElement LoginPwd { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='submit']")]
        public IWebElement LoginNext { get; set; }

        [FindsBy(How=How.XPath, Using ="//div[contains(text(),'Work or school account')]")]
        public IWebElement WorkOrSchoolAccount { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@role='heading' and contains(.,'Stay signed in')]")]
        public IWebElement LoginStaySignedIn { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(.,'Inbox')]")]
        public IWebElement OutlookInbox { get; set; }

        //Logout
        [FindsBy(How = How.XPath, Using = "(//div[@id='O365_MainLink_MePhoto']//img)[1]")]
        public IWebElement ProfileMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@id='meControlSignoutLink']")]
        public IWebElement LogoutBtn { get; set; }

        //Main Logic
        [FindsBy(How = How.XPath, Using = "//div[@title='Folders']")]
        public IWebElement Folders { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@title='CSW']")]
        public IWebElement CSWFolder { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@aria-label='Message list']//span[text()='CSW']")]
        public IWebElement CSWFolderList { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@title='Folders']/button")]
        public IWebElement OpenFolders { get; set; }

        [FindsBy(How = How.XPath, Using = "(//div[@role='complementary' and @aria-label='Reading Pane']//div[@class='wide-content-host']/div//div[3]/div/div)[2]")]
        public IWebElement ReadPanelDate { get; set; }

        
        //[FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div")]
        [FindsBy(How = How.XPath, Using = "//div[@aria-label='Email message']")]
        //[FindsBy(How = How.XPath, Using = "(//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div)[3]/div[1]/div/div/div/div")]
        //[FindsBy(How = How.XPath, Using = "(//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div)[3]/div/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]")]
        //[FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div[2]/div[1]/div/div/div/div")]
        public IWebElement EmailBody { get; set; }
        
//        [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div[3]/div/div/div/p[2]")]
     [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div[3]/div/div/div/p[2]")]

        //*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div[3]/div/div/div/p[2]
        //[FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div[3]/div/div/div/p[2]")]
        public IWebElement ResetPasswordPinCode { get; set; }

        //  [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div[2]/div[1]/div/div/div/div/div[3]/div/div/div/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr[1]/td")]
        //[FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div[3]/div/div/div/p[2]")]

        //*[@id="ReadingPaneContainerId"]/div/div/div/div/div/div[2]/div[1]/div/div/div/div/div[3]/div/div/div/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr[1]/td
        [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div[3]/div/div/div/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr[1]/td")]
       public IWebElement EmailVerificationPinCode1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div[2]/div[1]/div/div/div/div/div[3]/div/div/div/div/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr[1]/td")]
        public IWebElement EmailVerificationPinCode2 { get; set; }


        //[FindsBy(How = How.XPath, Using = "(//div[@role='complementary' and @aria-label='Reading Pane']//div[@class='wide-content-host']//div[2]/div/div)[2]")]
        //public IWebElement ReadPanelDateMotest { get; set; }



        //    [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div[2]/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]")]
//        [FindsBy(How = How.XPath, Using = "(//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div)[2]/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]")]
        //[FindsBy(How = How.XPath, Using = "(//*[@id='ReadingPaneContainerId']/div/div/div/div/div/div)[3]/div/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]")]
        [FindsBy(How = How.XPath, Using = "//*[@id='ReadingPaneContainerId']/div/div/div/div[2]/div/div/div[1]/div/div/div/div/div[1]/div[3]/div[1]/div[2]")]
        [FindsBy(How=How.XPath,Using = "//div[@aria-label='Email message']//div[((contains(text(),'AM')) or contains(text(),'PM')) and not(contains(text(),'Retention'))]")]
        public IWebElement ReadPanelDateMotest { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@role='complementary' and @aria-label='Reading Pane']//div[@class='wide-content-host']//div/div[3]/div/div[2]")]
        //public IWebElement ReadPanelDateMotest { get; set; }


        [FindsBy(How = How.XPath, Using = "//a[@href and contains(.,'Confirm?token')]")]
        public IWebElement EmailVerificationLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href,'reset')]")]
        public IWebElement RestPasswordLink { get; set; }


        public void VerifyEmail(string emailType)
        {
            List<String> actemailContent = new List<string>();
            List<String> expemailContent = new List<string>();
            string expemailfile = finalFilesPath + emailType + "_Expected_" + data[KeyRepository.PolicyNumber] + ".txt";
            string actemailfile = finalFilesPath + emailType + "_Actual_" + data[KeyRepository.PolicyNumber] + ".txt";

            if (emailArrive)
            {
                string paidToDate = data[KeyRepository.PaidToDate].Split('/')[0].TrimStart('0') + "/" + data[KeyRepository.PaidToDate].Split('/')[1].TrimStart('0') + "/" + data[KeyRepository.PaidToDate].Split('/')[2];
                //Read expected email content from template
                using (StreamReader sr = new StreamReader(expectedFilespath + expEmailTemplate))
                {
                    string expemaillines;
                    while ((expemaillines = sr.ReadLine()) != null)
                    { 
                        if (expemaillines.Contains("{DateTime}"))
                        {
                            expemaillines = expemaillines.Replace("{DateTime}", DateTime.Now.ToString("ddd M/d/yyyy h:mm tt"));
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{Date}"))
                        {
                            if (emailType == "Cyber Fraud Alert" || emailType == "PM Reset Password")
                                expemaillines = expemaillines.Replace("{Date}", DateTime.Now.ToString("MM/dd/yyyy"));
                            else
                                expemaillines = expemaillines.Replace("{Date}", DateTime.Now.ToString("M/d/yyyy"));
                            expemailContent.Add(expemaillines);
                        }                      
                        else if (expemaillines.Contains("{FirstName}"))
                        {
                            expemaillines = expemaillines.Replace("{FirstName}", data[KeyRepository.FirstName]);
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{PinCode}"))
                        {
                           expemaillines = expemaillines.Replace("{PinCode}", data[KeyRepository.PinCode]);
                           expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{PaidtoDate}"))
                        {
                            if (emailType.Contains("Payment"))
                                expemaillines = expemaillines.Replace("{PaidtoDate}", Convert.ToDateTime(paidToDate).ToString("MM/dd/yyyy"));
                            else
                                expemaillines = expemaillines.Replace("{PaidtoDate}", paidToDate);
                            expemailContent.Add(expemaillines);
                        }
                        else if (updateConfirmationEmail)
                        {
                            if (expemaillines.Contains("{UserFieldName}"))
                            {
                                expemaillines = expemaillines.Replace("{UserFieldName}", CSWData.TempVal.Trim());
                                expemailContent.Add(expemaillines);
                            }
                        }
                        else if (expemaillines.Contains("{FullName}"))
                        {
                            expemaillines = expemaillines.Replace("{FullName}", data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName]);
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{ClientID}"))
                        {
                            expemaillines = expemaillines.Replace("{ClientID}", data[KeyRepository.ClientIdOfPolicy]);
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{FullDate}"))
                        {
                            expemaillines = expemaillines.Replace("{FullDate}", string.Format("{0:f}", CSWData.EventTriggerTime));
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{UserName}"))
                        {
                            expemaillines = expemaillines.Replace("{UserName}", Environment.UserName.ToLower());
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{AdditionalNotes}"))
                        {
                            expemaillines = expemaillines.Replace("{AdditionalNotes}", CSWData.TempVal.Trim());
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{EmailID}"))
                        {
                            expemaillines = expemaillines.Replace("{EmailID}",data[KeyRepository.EmailId].Trim());
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{ContractNumber}"))
                        {
                            expemaillines = expemaillines.Replace("{ContractNumber}", data[KeyRepository.PolicyNumber]);
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{UpdateConfirmOption}"))
                        {
                            expemaillines = expemaillines.Replace("{UpdateConfirmOption}", CSWData.TempVal.Trim().ToLower());
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{URL}"))
                        {
                            expemaillines = expemaillines.Replace("{URL}", data[KeyRepository.URL].Trim());
                            expemailContent.Add(expemaillines);
                        }
                        else if (expemaillines.Contains("{Token}"))
                        {
                           //string token = new CSW.Common.Services.Webservices(driver, data).SubmitWSCall("GenerateToken", "100");
                            expemaillines = expemaillines.Replace("{Token}", data[KeyRepository.URL].Replace("Login", "Confirm?token=").Trim());
                            expemailContent.Add(expemaillines);
                        }
                        else
                            expemailContent.Add(expemaillines);
                    }
                }

                SaveExpectedEmailContent(expemailfile, expemailContent);

                //Read actual email content from template
                using (StreamReader sr = new StreamReader(actemailfile))
                {
                    int i = 1;
                    bool startAdd = false;

                    string actemaillines;
                    //       Console.WriteLine("Actual Email Content is::");

                    while ((actemaillines = sr.ReadLine()) != null)
                    {
                        //Start Adding after TO address
                        if(startAdd)
                            actemailContent.Add(actemaillines);

                        //Set the Start Add only after To address encountered
                        if (actemaillines.Contains("CS_Web_Dev_Support@newyorklife.com"))
                            startAdd = true;
                      

                        i++;
                    }
                }

                //Compare actual email with expected email
                if (actemailContent.SequenceEqual(expemailContent))
                {

                    NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received and the expected content", emailType + " email is received and content is as expected", "PASS", "no", "no", actemailfile);
                    //NYLDSelenium.ReportStepResult("Expected Content", emailType + " email expected content", "PASS", "no", "no", expemailfile);
                    //NYLDSelenium.ReportStepResult("Actual Content", emailType + " email actual content", "PASS", "no", "no", actemailfile);

                }
                else
                {
                   
                    //If there is mismatch between actual and expected content, verify from which line the mismatch starts
                    if (expemailContent.Count() != actemailContent.Count())
                    {
                        NYLDSelenium.ReportStepResult("Verify the content of email for: " + emailType, "There is mismatch in no. of lines in expected: " + expemailContent.Count() + " and actual: " + actemailContent.Count() + " email", "FAIL", "no");
                    }
                    else
                    {
                        for (int i = 0; i < expemailContent.Count(); i++)
                        {
                            if (!actemailContent[i].Contains(DateTime.Now.ToString("ddd M/d/yyyy")))
                            {
                                if (expemailContent[i] != actemailContent[i])
                                {
                                    int linetoReview = i + 1;
                                    if (!actemailContent[i].Contains("http"))
                                        NYLDSelenium.ReportStepResult("Verify the content of email for: " + emailType, "There is mismatch in  at line #" + linetoReview + ". Expected: " + expemailContent[i] + " Actual: " + actemailContent[i], "FAIL", "no");
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            else
                NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received", emailType + " email is not received with in the time frame from:  " + CSWData.EventTriggerTime + " To : " + DateTime.Now, "FAIL", "no");

            try
            {
              //  File.Delete(expemailfile);
              //  File.Delete(actemailfile);
            }
            catch { }
            cyberFraudEmail = false;
            updateConfirmationEmail = false;
            paymentEmail = false;
        }


        public void GetEmailContentValues(string Eventtype)
        {
            switch (Eventtype)
            {
                //case "Email Verification":
                //    expSubject = "Email Verification: AARP Life Insurance Program from New York Life";
                //    expEmailTemplate = "EmailVerification.txt";
                //    break;

                case "Registration Success":
                    expSubject = "Success, " + data[KeyRepository.FirstName] + ": Your account has been created.";
                    expEmailTemplate = "RegistrationSuccess.txt";
                    break;

                case "Account Verification":
                    expSubject = data[KeyRepository.FirstName] + ", here's your email verification code.";
                    expEmailTemplate = "AccountVerification.txt";
                    break;

                case "Reset Password":
                    expSubject = "Reset Your Password with Verification Code: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "ResetPassword.txt";
                    break;

                case "PM Reset Password":
                    expSubject = "Reset Your Password: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "PMResetPassword.txt";
                    break;

                case "Password Confirmation":
                    expSubject = "Password Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "PasswordConfirmation.txt";
                    break;

                case "Change Payor Confirmation":
                    expSubject = "Change Payor Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "ChangePayorConfirmation.txt";
                    break;

                case "Contact Information Update Address Confirmation":
                    expSubject = "Contact Information Update Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "ContactInfoUpdateAddressConfirmation.txt";
                    break;

                case "Contact Information Update Phone Confirmation":
                    expSubject = "Contact Information Update Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "ContactInfoUpdatePhoneConfirmation.txt";
                    break;

                case "Edit Insured Confirmation":
                    expSubject = "Edit Insured Details Request: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "EditInsuredConfirmation.txt";
                    break;

                case "Change Beneficiary Confirmation":
                    expSubject = "Change Beneficiary Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "ChangeBeneficiaryConfirmation.txt";
                    break;

                case "Update Confirmation":
                    expSubject = "Update Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "UpdateConfirmation.txt";
                    break;

                case "Payment Enrollment Confirmation":
                    expSubject = "Payment Enrollment Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "PaymentEnrollmentConfirmation.txt";
                    paymentEmail = true;
                    break;

                case "Payment Change Confirmation":
                    expSubject = "Payment Change Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "PaymentChangeConfirmation.txt";
                    paymentEmail = true;
                    break;

                case "Cancel ET":
                    expSubject = "Payment Change Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "CancelET.txt";
                    paymentEmail = true;
                    break;

                case "Cash Value Letter Confirmation":
                    expSubject = "Cash Value Letter Request Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "CashValueLetterRequestConfirmation.txt";
                    break;

                case "Cancel Pending ET":
                    expSubject = "Payment Change Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "CancelPendingET.txt";
                    paymentEmail = true;
                    break;

                case "Payment Frequency Change Confirmation":
                    expSubject = "Payment Frequency Change Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "PaymentFrequencyChangeConfirmation.txt";
                    paymentEmail = true;
                    break;

                case "Cyber Fraud Alert":
                    expSubject = "Cyber Fraud Alert: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "CyberFraudAlert.txt";
                    cyberFraudEmail = true;
                    break;

                case "Deactivated Customer Notification":
                    expSubject = "Deactivated Customer Notification";
                    expEmailTemplate = "DeactivatedCustomerNotification.txt";
                    break;

                case "Rider SubmitAddress Confirmation":
                    expSubject = "Thank you for your application for an AARP Term Rider from New York Life";
                    expEmailTemplate = "RiderSubmitConfirmation.txt";
                    break;

                case "Fax Cash Value Letter Confirmation":
                    expSubject = "Fax Cash Value Letter Request Confirmation: AARP Life Insurance Program from New York Life";
                    expEmailTemplate = "FaxCashValueLetterRequestConfirmation.txt";
                    break;
            }

        }

        public void GetEmailContentUI(string emailType, int tsMinutes = 1, string hardStop = "no")
        {
            //try
            //{
            if (!CSWData.OutlookFlagOff)
            {
                GetEmailContentValues(emailType);
                emailArrive = false;

                CommonFunctions.WindowsTabFocus("NavigateTab", "outlookTabInstance");

                CommonFunctions.SetTSOutlookEmail(emailType, tsMinutes);

                string folderAttOpen = NYLDSelenium.GetAttribute("Folder Attribute", Folders, "data-is-focusable");
                for (int i = 1; i < 3; i++)
                {  
                    Thread.Sleep(60); driver.Navigate().Refresh();
                }

                NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Outlook Email reception and verification for type: " + emailType + "</h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
                //NYLDSelenium.PageLoad("Moving to Outlook on CSW Folder", CSWFolderList);
                int j = 1;
                for (int i=j; i <= 20; i++)
                    {
                        driver.Navigate().Refresh();
                        Thread.Sleep(150);
                        NYLDSelenium.PageLoad("Outlook Inbox", OutlookInbox);
                        if (VerifyOutlook(emailType))
                            break;
                    }

                if (!emailArrive)
                {
                    NYLDSelenium.ReportStepResult("Verify if " + emailType + " email is received", emailType + " email is not received for first name " + data[KeyRepository.FirstName], "FAIL", "yes", hardStop);
                    CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
                }
            }
            //}
            //catch(Exception e)
            //{
            //    NYLDSelenium.ReportStepResult("Get Email Content",e.Message, "FAIL", "yes", hardStop);
            //}
        }

        private bool VerifyOutlook(string emailType)
        {
           
            string emailTitle = "";
            string emailTime = "";
            string titlePrefix = "[CSWDev] ";
            string emailRowTitleXpath;
            IWebElement emailRowTitle = null;

            Thread.Sleep(60000);

            //Get the Email Count

            try
            {
                ReadOnlyCollection<IWebElement> emails = driver.FindElements(By.XPath("//div[@role='option']"));

                //Wait until the title get enalbled
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(d => emails[0].Enabled);

                int emailsCount = emails.Count;


                for (int i = 1; i <= emailsCount; i++)
                {
                    driver.Navigate().Refresh(); Thread.Sleep(50);
                    emailRowTitleXpath = "(//div[@role='option'])[" + i + "]/div/div/div/div/div[2]/div/span";
                    emailRowTitle = NYLDSelenium.GetWE(emailRowTitleXpath);
                 
                    //Get the eMail Title
                    emailTitle = emailRowTitle.Text;

                    if (emailTitle.Contains(expSubject))
                    {
                        //Wait until the title get enalbled
                        WebDriverWait wait2 = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
                        wait2.Until(d => emailRowTitle.Enabled);
                        //Click on the Email Title
                        emailRowTitle.Click();

                        //Set Focus on the email
                        //for (int et = 0; et <= 3; et++)
                        //{
                          //  driver.Navigate().Refresh();
                            Thread.Sleep(20);
                            NYLDSelenium.GetWE("((//div[@role='option'])[" + i + "]/div/div/div)[1]").Click();
                            Thread.Sleep(15);
                            if (NYLDSelenium.ElemExist("Email Time", ReadPanelDateMotest))
                            {
                                emailTime = NYLDSelenium.GetAttribute("Email Time", ReadPanelDateMotest, "text");
                            }
                       // }

                        emailTime = GetDateWDay(emailTime);

                        //Convert eMailTime to DateTime Format
                        dtUI = DateTime.Parse(emailTime, new CultureInfo("en-US"));

                        //Check if eMail is generate on or after the trigger time
                        if (CSWMerge.date <= dtUI)
                        {
                            // emailRowTitleXpath = "(//div[@role='option'])[" + i + "]/div/div/div/div/div[2]/div/span";
                            // emailRowTitle = NYLDSelenium.GetWE(emailRowTitleXpath);

                            //Get the eMail Title
                            //emailTitle = emailRowTitle.Text;

                            //Handle CSWDev Appended Text
                            if (!emailTitle.StartsWith("[CSWDev]"))
                                titlePrefix = "";

                            //Check if expected subject is the email title
                            if (titlePrefix + expSubject == emailTitle)
                            {

                                //Get the Body of the email
                                string emailBodyExtract = EmailBody.Text.Trim();
                                string nameBodyExtract = "";

                                //Logic to extract the name based on the email type
                                if (emailType == "Contact Information Update Address Confirmation" && !emailBodyExtract.Contains("address"))
                                    break;
                                else if (emailType == "Contact Information Update Phone Confirmation" && !emailBodyExtract.Contains("phone number"))
                                    break;
                                else if ((emailType == "Cancel ET" && !emailBodyExtract.Contains("We processed your request to cancel your Automatic Premium Payment enrollment")) || (emailType == "Cancel Pending ET" && !emailBodyExtract.Contains("your Automatic Premium Payment cancelation will begin with the next payment")))
                                    break;
                                else if ((emailType == "Cancel Pending ET" || emailType == "Rider SubmitAddress Confirmation"))
                                    nameBodyExtract = GetBetween(emailBodyExtract, "Dear", ":").Replace("\r", "").Replace("\n", "").Trim();
                                else if (emailType == "Cyber Fraud Alert")
                                    nameBodyExtract = GetBetween(emailBodyExtract, "Name:", "Event").Replace("\r", "").Replace("\n", "").Trim();
                                else if (emailType == "Account Verification")
                                    nameBodyExtract = GetBetween(emailBodyExtract, "CS_Web_Dev_Support@newyorklife.com", ", let").Replace("\r", "").Replace("\n", "").Trim();
                                else if (emailType == "Registration Success")
                                    nameBodyExtract = GetBetween(emailBodyExtract, "Your registration is complete,", "Your").Replace("\r", "").Replace("\n", "").Trim();

                                else
                                    nameBodyExtract = GetBetween(emailBodyExtract, "Dear", ",").Replace("\r", "").Replace("\n", "").Trim();

                                //NYLDSelenium.ReportStepResult("Step 1e email Title is :" + emailTitle, "Test", "PASS");

                                if (nameBodyExtract.Contains(data[KeyRepository.FirstName]) || nameBodyExtract.Contains(data[KeyRepository.FirstName] + " " + data[KeyRepository.LastName]))
                                {
                                    NYLDSelenium.ReportStepResult("Email Received", emailType + " is received and selected", "PASS");

                                    SaveEmailContent(emailType, emailBodyExtract.Replace("•", "").Replace("customer’s", "customers"));
                                    IWebElement element;

                                    switch (emailType)
                                    {
                                        case "Reset Password":

                                            data[KeyRepository.PinCode] = GetBetween(emailBodyExtract, " one-time code on the customer service website:", "You have 10 minutes").Replace("\r", "").Replace("\n", "").Trim();

                                            //data[KeyRepository.PinCode] = NYLDSelenium.GetAttribute("Reset Password PIN Code",ResetPasswordPinCode, "text");
                                            emailArrive = true;
                                            break;

                                        case "Account Verification":

                                            data[KeyRepository.PinCode] = GetBetween(emailBodyExtract, "continue your registration:", "You have 10 minutes").Replace("\r", "").Replace("\n", "").Trim();

                                            //if (NYLDSelenium.ElemExist("PIN Code", EmailVerificationPinCode1, 10))
                                            // data[KeyRepository.PinCode] = EmailVerificationPinCode1.Text;
                                            //else 
                                            //    data[KeyRepository.PinCode] = EmailVerificationPinCode2.Text;

                                            emailArrive = true;
                                            break;
                                        case "PM Reset Password":
                                            NYLDSelenium.Click("Reset Password", RestPasswordLink);
                                            switchNewTab = true;
                                            emailArrive = true;
                                            break;
                                        case "Registration Success":
                                        case "Password Confirmation":
                                        case "Change Payor Confirmation":
                                        case "Contact Information Update Address Confirmation":
                                        case "Contact Information Update Phone Confirmation":
                                        case "Edit Insured Confirmation":
                                        case "Change Beneficiary Confirmation":
                                        case "Update Confirmation":
                                        case "Payment Enrollment Confirmation":
                                        case "Payment Change Confirmation":
                                        case "Cancel ET":
                                        case "Cash Value Letter Confirmation":
                                        case "Payment Frequency Change Confirmation":
                                        case "Cancel Pending ET":
                                        case "Cyber Fraud Alert":
                                        case "Deactivated Customer Notification":
                                        case "Rider SubmitAddress Confirmation":
                                        case "Fax Cash Value Letter Confirmation":
                                            emailArrive = true;
                                            break;
                                    }

                                }

                            }

                            if (emailArrive)
                                break;
                        }
                        else ////Break out of for loop if no email is recieved after the trigger time
                        {
                            NYLDSelenium.ReportStepResult(emailType + " Email didnt Received at Time :" + emailTime, "Test", "PASS");
                            break;
                        }
                    }
                    else emailArrive = false;
                }

                if (emailsCount == 0) emailArrive = false;

                if (emailArrive)
                    VerifyEmail(emailType);

                if (switchNewTab)
                {
                    CommonFunctions.WindowsTabFocus("CloseTab", "cswTabInstance");
                    CommonFunctions.WindowsTabFocus("SaveTab", "cswTabInstance");
                    CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
                }
                else if (emailArrive)
                    CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");


                switchNewTab = false;
            }
            catch
            {
                emailArrive = false;

            }
            return emailArrive;
        }

        private void SaveEmailContent(string emailType, string emailContent)
        {

            //emailContent = DeleteLines(emailContent, 7);

            File.WriteAllText(finalFilesPath + emailType + "_Actual_" + data[KeyRepository.PolicyNumber] + ".txt", emailContent);
        }

        private void SaveExpectedEmailContent(string expemailfile, List<string> expemailContent)
        {
            TextWriter tw = new StreamWriter(expemailfile);

            foreach (String s in expemailContent)
                tw.WriteLine(s);

            tw.Close();
        }

        public void OutlookLogin()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color: \">" + "Outlook Login </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");
            CommonFunctions.WindowsTabFocus("SaveTab", "outlookTabInstance");

            string emailAddress = "motest12@newyorklife.com";            Thread.Sleep(800);
            try
            {
                if (NYLDSelenium.ElemExist("Outlook Sign In", LoginSignIn, "no"))
                {
                    NYLDSelenium.PageLoad("Outlook Sign In", LoginSignIn);
                    NYLDSelenium.SendKeys("Email", LoginEmail, Properties.Settings.Default.OutlookEmailId);
                }
                else
                {
                    NYLDSelenium.SendKeys("Email", LoginEmail, Properties.Settings.Default.OutlookEmailId);
                }
            }
            catch
            {
                NYLDSelenium.SendKeys("Email", LoginEmail, Properties.Settings.Default.OutlookEmailId);

            }
            NYLDSelenium.Click("Next", LoginNext);
            if (NYLDSelenium.ElemExist("Work or school account option", WorkOrSchoolAccount, "no"))
                NYLDSelenium.Click("Work or school account option", WorkOrSchoolAccount);
            Thread.Sleep(2000);
            NYLDSelenium.SendKeys("Password", LoginPwd, Properties.Settings.Default.OutlookEmailPwd);
            NYLDSelenium.Click("Next", LoginNext);            
            
            if (!CSWData.OutlookFlagOff)
            {
                if (!NYLDSelenium.ElemExist("Error Login", NYLDSelenium.GetWE("//p[text() ='Sorry, but we’re having trouble signing you in.']"),"no"))
                {
                    try
                    {
                        NYLDSelenium.PageLoad("Stay signed in", LoginStaySignedIn);
                        NYLDSelenium.Click("Yes", LoginNext);
                       Thread.Sleep(1000);
                        NYLDSelenium.PageLoad("Outlook Inbox", OutlookInbox);
                        CommonFunctions.WindowsTabFocus("OpenNewTab", "cswTabInstance");
                    }
                    catch
                    {
                        if (NYLDSelenium.ElemExist("Stay signed in", LoginStaySignedIn, "no"))
                        {
                            NYLDSelenium.Click("Yes", LoginNext);
                        }
                        Thread.Sleep(1000);
                        NYLDSelenium.PageLoad("Outlook Inbox", OutlookInbox);
                        CommonFunctions.WindowsTabFocus("OpenNewTab", "cswTabInstance");
                    }
                   
                }
                else
                {
                    if (!CSWData.OutlookFlagOff)
                        NYLDSelenium.ReportStepResult("Outlook Open/Login", "Open Login or authentication failed", "Fail");
                    CSWData.OutlookFlagOff = true;
                    CommonFunctions.WindowsTabFocus("OpenNewTab", "cswTabInstance");
                    CommonFunctions.WindowsTabFocus("CloseTab", "outlookTabInstance");
                    CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");

                }
            }
            else
            {
                CSWData.OutlookFlagOff = true;
                CommonFunctions.WindowsTabFocus("OpenNewTab", "cswTabInstance");
                CommonFunctions.WindowsTabFocus("CloseTab", "outlookTabInstance");
                CommonFunctions.WindowsTabFocus("NavigateTab", "cswTabInstance");
            }
        }

        public void OutlookLogout()
        {
            NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Outlook Logout </h3>", "<h3 style=\"color:Blue\">" + "###########" + "</h3>", "INFO", "no");

            if (!CSWData.OutlookFlagOff)
            {
                CommonFunctions.WindowsTabFocus("NavigateTab", "outlookTabInstance");

                //Logout
                NYLDSelenium.Click("Profile Menu", ProfileMenu);
                NYLDSelenium.Click("Logout", LogoutBtn);
                Thread.Sleep(8000);
                CommonFunctions.WindowsTabFocus("CloseTab", "outlookTabInstance");
            }
        }

        private string GetDateWDay(string emailTime)
        {
            return emailTime.Replace("Mon ", "").Replace("Tue ", "").Replace("Wed ", "").Replace("Thu ", "").Replace("Fri ", "").Trim();
        }

        public static string GetBetween(string strSource, string strStart, string strEnd)
        {
            int Start, End;
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                Start = strSource.IndexOf(strStart, 0) + strStart.Length;
                End = strSource.IndexOf(strEnd, Start);
                return strSource.Substring(Start, End - Start);
            }
            else
            {
                return "";
            }
        }

        public static string DeleteLines(string s, int linesToRemove)
        {
            return s.Split(Environment.NewLine.ToCharArray(),
                           linesToRemove + 1
                ).Skip(linesToRemove)
                .FirstOrDefault();
        }


        public string[] GetOneTimeCodeFromEMail()
        {
            string[] oneTimeCode = null;
            OutlookEmailUI OE = new OutlookEmailUI(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            OE.GetEmailContentUI("Account Verification",5,"yes");
            if (OutlookEmailUI.emailArrive)
                oneTimeCode = CF.SplitPinCode();
            else
                NYLDSelenium.ReportStepResult("Account Verification Email with PinCode not received", "Account Verification Email with PinCode was not received", "FAIL", "no", "yes");

            return oneTimeCode;
        }

    }
}
