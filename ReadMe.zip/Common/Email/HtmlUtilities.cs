﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CSW.Common.Email
{
    class HtmlUtilities
    {
        public static string HtmlToPlainText(string html,string emailgroup)
        {
            const string tagWhiteSpace = @"(>|$)(\W|\r)+<";//matches one or more (white space or line breaks) between '>' and '<'
            const string removenewline = @"(>|$)+<";//matches one or more (white space or line breaks) between '>' and '<'
            const string stripFormatting = @"<[^>]*(>|$)";//match any character between '<' and '>', even when end tag is missing
            const string lineBreak = @"<(br|BR)\s{0,1}\/{0,1}>";//matches: <br>,<br/>,<br />,<BR>,<BR/>,<BR />
            var lineBreakRegex = new Regex(lineBreak, RegexOptions.Multiline);
            var stripFormattingRegex = new Regex(stripFormatting, RegexOptions.Multiline);
            var tagWhiteSpaceRegex = new Regex(tagWhiteSpace, RegexOptions.Multiline);
            var removenewlinesRegex = new Regex(removenewline, RegexOptions.Multiline);

            string text = "";
            //Decode html specific characters
            text = System.Net.WebUtility.HtmlDecode(html);
            //Remove tag whitespace/line breaks
            text = tagWhiteSpaceRegex.Replace(text, "><");
            //Strip formatting
            text = stripFormattingRegex.Replace(text, "\n");
            text = text.Replace("\nhere", "here]");
            text = text.Replace("time, \nclick here", "time, click here.");
            text = text.Replace("New York Life at \n(800)", "New York Life at (800)");
            text = text.Replace("Friday\n 8", "Friday 8");
            //Replace <br /> with line breaks
            text = lineBreakRegex.Replace(text, Environment.NewLine);
            if (!emailgroup.Contains("nyld_uploads_dev")&& !emailgroup.Contains("NYLDirect_Claims_General_Test")&& !emailgroup.Contains("NYLDirect_Member_services_General_Test"))
                text = DeleteLines(text, 7);
            return text;
        }


        public static string DeleteLines(string s, int linesToRemove)
        {
            return s.Split(Environment.NewLine.ToCharArray(),
                           linesToRemove + 1
                ).Skip(linesToRemove)
                .FirstOrDefault();
        }
    }
}
