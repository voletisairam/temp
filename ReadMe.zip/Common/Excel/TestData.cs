﻿using CSW.Common.DataBase;
using CSW.Common.Others;
using CSW.Common.Services;
using CSW.Drivers;
using CSW.PageObjects.Home;
using CSW.PageObjects.Login;
using CSW.PageObjects.NewRegistration;
using CSW.PageObjects.Profile;
using Microsoft.Office.Interop.Excel;
using NYLDWebAutomationFramework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;

namespace CSW.Common.Excel
{
    public class TestData
    {
        public Application application;
        public Workbook workBook;
        public Worksheet workSheet;
        public static Dictionary<string, int> colDict;
        public bool processfurther;
        //datasheet
        public static NYLDExcel dataExcel;
        public static WorksheetCollection datatworksheets;
        //existing user account datasheet
        public static NYLDExcel existingUserAccountExcel;
        public static WorksheetCollection existinguseraccountsheets;
        //application sheet
        public static NYLDExcel applicationExcel;
        public static WorksheetCollection applicationsheets;

        /// <summary>
        /// Method to find the test cases in data sheet and retrieve all its associated test data
        /// </summary>
        /// <param name="TestCaseId"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetTestData(string TestId, string file)
        {
            bool testFound = false;
            bool dm = false;
            int x = 2;
            workSheet = OpenDatasheet(file);
            string[] testId = Array.Empty<string>();
            Dictionary<string, string> data;
            string SubFunctionality = "";
            string Functionality = "";

            if (!(TestId.Contains("DM") || TestId.Contains("UserAccounts")))
            {
                // Split the test fixture to get the Test Case ID and Browser
                testId = TestId.Split('_');
                Functionality = testId[0];

                if (testId.Length > 1)
                {
                    SubFunctionality = testId[1];
                    string testCaseID = testId[2];

                    while (!string.IsNullOrEmpty(workSheet.Cells[x, 1].Text()))
                    {
                        if (workSheet.Cells[x, 1].Text() == Functionality.Trim() &&
                            workSheet.Cells[x, 2].Text() == SubFunctionality.Trim() &&
                            workSheet.Cells[x, 3].Text() == testCaseID.Trim())
                        {
                            testFound = true;
                            break;
                        }
                        x++;
                    }
                }

                // Fail a test case if it is not found
                if (!testFound)
                {
                    NYLDSelenium.ReportStepResult("Test not Found", TestId, "Fail", "no", "yes");
                }
            }
            else
            {
                dm = true;
            }

            // Read test data information from scenario sheet
            if (TestId.Contains("Stage"))
            {
                data = ReadTestData(workSheet, x, "Stage", dm);
            }
            else
            {
                data = ReadTestData(workSheet, x, TestId, dm);
            }

            // Add TestID to data dictionary
            data[KeyRepository.TestID] = data[KeyRepository.TestCaseID] = TestId;
            data[KeyRepository.SubFuntionality] = SubFunctionality;
            data[KeyRepository.Funtionality] = Functionality;
            data[KeyRepository.TestCaseDescription] = workSheet.Cells[x, 4].Text() + " - " + "<br>TestCaseID:<br>" + workSheet.Cells[x, 5].Text();
            return data;
        }

        /// <summary>
        /// Method to open datasheet and fetch all required worksheets
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public Worksheet OpenDatasheet(string file, bool readDataSheets = true)
        {          
            int retryCount = 3;
            while (retryCount > 0)
            {
                try
                {
                    // Open data Excel
                    dataExcel = new NYLDExcel(file, editable: false);
                    workBook = dataExcel.workbook;
                    application = dataExcel.application;
                    workSheet = dataExcel.GetWorksheetByName(workBook, "TestSuite");
                    datatworksheets = dataExcel.GetWorksheets(workBook);
                    break; // Exit the loop if successful
                }
                catch (Exception ex)
                {
                    dataExcel.CloseExcel(workBook);
                    // Handle any other exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                    retryCount--;
                    if (retryCount == 0)
                    {
                        Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);
                        throw;
                    }
                    Thread.Sleep(10000); // Wait before retrying
                }
            }
            return workSheet;
        }
        
        /// <summary>
        /// Method to read the test data based on the row number
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="iRow"></param>
        /// <param name="testEnvironment"></param>
        /// <returns></returns>
        public Dictionary<string, string> ReadTestData(Worksheet sheet, int iRow, string EnvSet, bool dm = false)
        {
            Dictionary<string, int> colDict = new Dictionary<string, int>();

            Dictionary<string, string> testdata = new Dictionary<string, string>();

            int range = sheet.UsedRange.Columns.Count;
            colDict = dataExcel.GetColumnIndices(sheet);

            string[] randomAddress = new string[6];
            int row = iRow;

            try
            {
                if (!dm)
                {
                    testdata = dataExcel.ReadTestCaseData(sheet, row);                    
                }
                else
                {
                    testdata.Add(KeyRepository.ContractSource, "DM");
                }

                //Url and Browser info  
                string environmentDetails = "";

                if (EnvSet.Contains("Stage"))
                    environmentDetails = GetEnvionmentDetails(EnvSet.Trim());
                else if (EnvSet.Contains("QA"))
                {
                    if (EnvSet.Contains("QA1")) EnvSet = "QA-1";
                    else if (EnvSet.Contains("QA2")) EnvSet = "QA-2";
                    else if (EnvSet.Contains("QA3")) EnvSet = "QA-3";
                    else if (EnvSet.Contains("QA4")) EnvSet = "QA-4";
                    else if (EnvSet.Contains("QA5")) EnvSet = "QA-5";
                    environmentDetails = GetEnvionmentDetails(EnvSet.Trim());
                }
                else
                    environmentDetails = GetEnvionmentDetails(datatworksheets.GetByName("Test Configuration").Cells[7, 7].Text().Trim());

                string browser = GetBrowserName(datatworksheets.GetByName("Test Configuration").Cells[8, 7].Text().Trim());
                testdata.Add(KeyRepository.Environment, environmentDetails.Split(';')[0].Trim());
                testdata.Add(KeyRepository.URL, environmentDetails.Split(';')[1].Trim());
                testdata.Add(KeyRepository.MIDBServerName, environmentDetails.Split(';')[2].Trim());
                testdata.Add(KeyRepository.WSUrl, environmentDetails.Split(';')[3].Trim());
                testdata.Add(KeyRepository.Browser, browser);
                testdata.Add(KeyRepository.DBValidation, environmentDetails.Split(';')[4].Trim());
                
                //LSP Date
                testdata.Add(KeyRepository.LSPDate, "");

                //Other Application parameters
                testdata.Add(KeyRepository.PolicyNumber, "");
                testdata.Add(KeyRepository.PolicyStatus, "");
                testdata.Add(KeyRepository.ControlNumber, "");
                testdata.Add(KeyRepository.FamilyBillGroupID, "");
                testdata.Add(KeyRepository.ClientIdOfPolicy, "");
                testdata.Add(KeyRepository.UclientIdOfPolicy, "");
                testdata.Add(KeyRepository.UserNameSet, "");
                testdata.Add(KeyRepository.FISPremium, "");
                testdata.Add(KeyRepository.TokenWaitTime, "");
                testdata.Add(KeyRepository.TempValue, "");
                testdata.Add(KeyRepository.SourceCode, "");
                testdata.Add(KeyRepository.PFC, "");
                testdata.Add(KeyRepository.Version, "");
                testdata.Add(KeyRepository.Product, "LR10");
                testdata.Add(KeyRepository.SSN, "");

                if (datatworksheets.GetByName("Test Configuration").Cells[14, 7].Text().Contains("All"))
                    CSWData.PageVerification = true;
                else
                    CSWData.PageVerification = false;

                if (datatworksheets.GetByName("Test Configuration").Cells[12, 7].Text().Contains("All"))
                    CSWData.EmailVerificationflag = true;
                else
                    CSWData.EmailVerificationflag = false;
            }
            catch (Exception e)
            {
                NYLDSelenium.ReportStepResult("Get values from the datasheet", "Failed to get the values. Please check report to automation team. Here is the exception: " + e, "FAIL", "no", "yes");
            }

            //dataExcel.CloseExcel(workBook);
            return testdata;
        }               

        /// <summary>
        /// Method to fetch the correponding Environment URL based on the page information passed
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public string GetEnvionmentDetails(string args)
        {
            string environmentUrl = "";

            // int row = CSWData.Url.UsedRange.Rows.Count;
            Worksheet url = datatworksheets.GetByName("URLs");
            //Get the Url based on the scenario passed in args
            for (int i = 1; i <= url.UsedRange.Rows.Count; i++)
            {
                if (url.Cells[i, 1].Text().Replace(" ", "").Trim() == args.Replace(" ", ""))
                {
                    environmentUrl = url.Cells[i, 1].Text().Trim() + ";" + url.Cells[i, 2].Text().Trim() + ";" + url.Cells[i, 3].Text().Trim() + ";" + url.Cells[i, 4].Text().Trim() + ";" + url.Cells[i, 5].Text().Trim();
                    break;
                }
            }

            return environmentUrl;
        }

        /// <summary>
        /// Method to fetch the correponding Environment URL based on the page information passed
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public string GetBrowserName(string args)
        {
            string browserName = "";

            //Get browser naming convention as used in script
            switch (args.ToLower().Trim())
            {
                case "FireFox":
                    browserName = "ff";
                    break;

                case "IE":
                    browserName = "ie";
                    break;

                default:
                    browserName = "chrome";
                    break;
            }

            return browserName;
        }

        /// <summary>
        /// Method to Fetch Fesh control number from app entry and corresponding policy details from DB
        /// </summary>
        /// <param name="data"></param>   
        /// 

        public void GetContractData(IWebDriver driver, Dictionary<string, string> data, string criteria = "Monthly")
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);

            //This if condtion helps for 1st -new status & 2nd for Pre user accounts -Active status
            string type = data[KeyRepository.UserAccountStatus];

            if (type == "Active")
                type = "Account Created";
            else
                type = "New";
            //Read the curret worksheet
            ReadWorksheet(driver, data, criteria, type);
        }

        public void GetUserDataWorkSheet()
        {
            int retryCount = 3;
            while (retryCount > 0)
            {
                try
                {
                    // Open Application Excel
                    string applicationsFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.NewUserAccountSheet;
                    applicationExcel = new NYLDExcel(applicationsFile, editable: true);
                    workBook = applicationExcel.workbook;
                    application = applicationExcel.application;
                    applicationsheets = applicationExcel.GetWorksheets(workBook);
                    break; // Exit the loop if successful
                }
                catch (Exception ex)
                {
                    applicationExcel.CloseExcel(workBook);
                    // Handle any other exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                    retryCount--;
                    if (retryCount == 0)
                    {
                        Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);
                        throw;
                    }
                    Thread.Sleep(10000); // Wait before retrying
                }
            }
            
        }
       
        /// <summary>
        /// Name: VerifyAccountStatus
        /// Description: This method verifies the account status of the contract
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <returns>void</returns>
        public void CreateNewUserAccounts(IWebDriver driver, Dictionary<string, string> data)
        {
            int existingCount = 0;
            int thersholdCount = 0;
            Dictionary<string, string> configInfo = new Dictionary<string, string>();
            RestServices restcall = new RestServices(data);

            // Get the worksheet for Test Data Configuration
            GetUserDataWorkSheet();
            workSheet = applicationsheets.GetByName("Test Data Configuration");
            // Retrieve threshold counts
            int cswThreshold = int.Parse(workSheet.Cells[4, 9].Text());
            int protectProfileThreshold = int.Parse(workSheet.Cells[5, 9].Text());
            int cswLiteThreshold = int.Parse(workSheet.Cells[6, 9].Text());
            string smsNumber = workSheet.Cells[8, 9].Text();

            data[KeyRepository.ProfilePhone] = smsNumber;
            // Get the worksheet for Applications
            workSheet = applicationsheets.GetByName("Applications");
            // Get the column indices
            colDict = applicationExcel.GetColumnIndices(workSheet);

            // Initialize counts
            int cswCount = 0;
            int protectProfileCount = 0;
            int cswLiteCount = 0;

            // Count occurrences of each account type with "Account Created" status
            int x = 2;
            while (!string.IsNullOrWhiteSpace(workSheet.Cells[x, 1].Text()))
            {
                if (workSheet.Cells[x, colDict["Contract"]].Text() == "Account Created")
                {
                    string accountType = workSheet.Cells[x, colDict["CSWAccountType"]].Text();
                    if (string.IsNullOrWhiteSpace(accountType))
                    {
                        cswCount++;
                    }
                    else if (accountType == "CSWLite")
                    {
                        cswLiteCount++;
                    }
                    else if (accountType == "ProtectYourProfile")
                    {
                        protectProfileCount++;
                    }
                }
                x++;
            }
            // Calculate differences
            int cswDifference = cswThreshold - cswCount;
            int protectProfileDifference = protectProfileThreshold - protectProfileCount;
            int cswLiteDifference = cswLiteThreshold - cswLiteCount;

            // Store differences in configInfo
            configInfo["csw"] = cswDifference.ToString();
            configInfo["protectProfile"] = protectProfileDifference.ToString();
            configInfo["cswLite"] = cswLiteDifference.ToString();

            // Check in between time period to execute this flow 
            DateTime endTime = DateTime.Now.AddMinutes(25);

            data[KeyRepository.AuthToken] = restcall.SubmitRestCall("GenerateOAuthToken");
            data[KeyRepository.NYLApplicationRole] = "Owner";
            foreach (var app in configInfo)
            {                
                if (DateTime.Now >= endTime)
                {
                    break;
                }
                if (app.Key == "cswLite")
                {
                    data[KeyRepository.NYLApplicationRole] = "Lite Owner";
                    existingCount = cswLiteCount;
                    thersholdCount = cswLiteThreshold;
                }
                if (app.Key == "protectProfile")
                {
                    existingCount = protectProfileCount;
                    thersholdCount = protectProfileThreshold;
                }
                if (app.Key == "csw")
                {
                    existingCount = cswCount;
                    thersholdCount = cswThreshold;
                }              
                    CreateUserAccounts(driver, data, thersholdCount, existingCount, app.Key, endTime);
            }
        }
       
        /// <summary>
        /// Name: VerifyAccountStatus
        /// Description: This method verifies the account status of the contract
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <param name="thersholdCount"></param>
        /// <param name="existingCount"></param>
        /// <param name="app"></param>
        /// <returns>void</returns>
        public void CreateUserAccounts(IWebDriver driver, Dictionary<string, string> data, int thersholdCount, int existingCount, string app, DateTime endTime)
        {
            CSWData.EmailVerificationflag = true;
            bool NewControlNumberFound = false, newAccountStatus = false;
            string controlNumberStatus = "";
            LSPDatabase DB = new LSPDatabase(driver, data);
           
            data[KeyRepository.Status] = "Unable to proceed the user accounts creation";

            int j = 0;           
            
            try
            {
                // Ensure the key exists in the dictionary
                if (!data.ContainsKey(KeyRepository.Status))
                {
                    data[KeyRepository.Status] = string.Empty;
                }

                // Get the workbook information with specific worksheet details 
                workSheet = applicationsheets.GetByName("Applications");
                // Get the column names which is having in specific worksheet
                colDict = applicationExcel.GetColumnIndices(workSheet);

                int x = 0;
                if (existingCount < thersholdCount)
                {
                 x = 2;
                    do
                    {
                        if (DateTime.Now >= endTime)
                        {
                            break;
                        }
                        if (existingCount < thersholdCount)
                        {
                                controlNumberStatus = workSheet.Cells[x, colDict["Contract"]].Text();
                            if (controlNumberStatus == "New")
                            {
                                string policynumber = workSheet.Cells[x, colDict["ContractNumber"]].Text().Trim();
                                if (string.IsNullOrEmpty(workSheet.Cells[x, colDict["MCUSR4"]].Text()) && !string.IsNullOrEmpty(policynumber) && (policynumber.Substring(0, 1).Trim() == "A"))
                                {
                                    data[KeyRepository.PolicyNumber] = policynumber;
                                    if (DB.GetPolicyDetails())
                                    {
                                        NewControlNumberFound = true;
                                        DB.QueryPolicyNumber();
                                        DB.GetClientId();
                                        // Verify the contract status if the contracy response returns Avtive, the update the col with Account Created-Used
                                      string accountStatus = VerifyAccountStatus(data);
                                        if (accountStatus == "Active")
                                        {
                                            workSheet.Cells[x, 56] = "Account Created-Used";
                                            applicationExcel.SaveExcel(workBook);
                                            x++;
                                            continue;
                                        }
                                        else if (accountStatus == null) // if null then Register a contract
                                        {
                                            newAccountStatus = CreateAccount(driver, data, j);
                                            if (newAccountStatus)
                                            {
                                                bool addDevice = false;
                                                if (app == "protectProfile") // add Phone number to the registered contract for SMS OTP
                                                    addDevice = AddSMSDevice(data);
                                                workSheet.Cells[x, 56] = "Account Created";
                                                workSheet.Cells[x, 57] = data[KeyRepository.UserName];
                                                workSheet.Cells[x, 58] = data[KeyRepository.Password];
                                                if (addDevice)
                                                    workSheet.Cells[x, 60] = "ProtectYourProfile"; // Update the col [CSWAccountType] 
                                                if (app == "cswLite")
                                                    workSheet.Cells[x, 60] = "CSWLite"; // Update the col [CSWAccountType] 
                                                applicationExcel.SaveExcel(workBook);
                                                Thread.Sleep(2000);
                                                j++;
                                                existingCount++;
                                                NYLDSelenium.ReportStepResult("Till Now " + j + " User Accounts Created", "Till Now User Accounts Created :" + j + " for Policy Number: " + data[KeyRepository.PolicyNumber], "PASS", "always", "no");
                                                data[KeyRepository.Status] = "Contracts are successfully created";
                                            }
                                            else
                                            {
                                                workSheet.Cells[x, 56] = "Account Created-Used";
                                                applicationExcel.SaveExcel(workBook);
                                                NYLDSelenium.ReportStepResult("Unable to create a new account for " + policynumber, "Register user account returns " + newAccountStatus, "Info", "no", "no");                                                
                                            }
                                        }
                                    }
                                    else
                                    {
                                        applicationExcel.SaveExcel(workBook);
                                    }
                                }
                            }
                            x++;
                        }
                    else
                    {
                        break;
                    }

                } while (workSheet.Cells[x, 1].Text() != "");
                    
                }

                if (existingCount < thersholdCount)
                {
                    // Report if the contract is not found
                    if (!NewControlNumberFound)
                    {
                        NYLDSelenium.ReportStepResult("Create UserAccounts-Use a new test contract for this test case.", "All contracts in the data sheet have been used or in cancelled status. Please refurbish the data sheet", "FAIL", "always", "yes");
                        data[KeyRepository.Status] = "All contracts in the data sheet have been used or in cancelled status";
                        GetSettor.failCounter++;
                    }
                }
                else
                {
                    NYLDSelenium.ReportStepResult("Create UserAccounts ", "Expected Contract count: " + thersholdCount + " Actual Contract count :" + existingCount, "PASS", "always", "no");
                    data[KeyRepository.Status] = "Actual Contract count : " + existingCount;
                }
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine("NullReferenceException: " + ex.Message);
                NYLDSelenium.ReportStepResult("Unable to get any data", "Please reachout Automation team", "FAIL", "always", "yes");
                data[KeyRepository.Status] = "Unable to get any data. Please reachout Automation team.";
                GetSettor.failCounter++;
            }
            catch (KeyNotFoundException ex)
            {
                Console.WriteLine("KeyNotFoundException: " + ex.Message);
                NYLDSelenium.ReportStepResult("Unable to get any new contractcheck LSP update", "Please reachout Automation team", "FAIL", "always", "yes");
                data[KeyRepository.Status] = "Unable to get any new contractcheck LSP update. Please reachout Automation team.";
                GetSettor.failCounter++;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message);
                NYLDSelenium.ReportStepResult("An error occurred while creating user accounts", "Please reachout Automation team", "FAIL", "always", "yes");
                data[KeyRepository.Status] = "An error occurred while creating user accounts. Please reachout Automation team.";
                GetSettor.failCounter++;
            }
            finally
            {
                try
                {
                    if (workBook != null)
                    {
                        applicationExcel.SaveExcel(workBook);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception in finally block: " + ex.Message);
                    data[KeyRepository.Status] = "Please reachout Automation team.";
                }
            }
        }
        
        /// <summary>
        /// Name: VerifyAccountStatus
        /// Description: Method to verify the account status
        /// </summary>
        /// <param name="data"></param>
        /// <returns>string</returns>
        public string VerifyAccountStatus(Dictionary<string, string> data)
        {
            RestServices restCall = new RestServices(data);
            string accountStatus = restCall.SubmitOAuth2RestCall("SearchUser", "status");

            return accountStatus;
        }

        /// <summary>
        /// Name: CreateAccount
        /// Description: Method to create a new account
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <returns>bool</returns>
        public bool CreateAccount(IWebDriver driver, Dictionary<string, string> data, int count)
        {
            LoginPage loginPage = new LoginPage(driver, data);
            ThankYouPage thankYouPage = new ThankYouPage(driver, data);
            RestServices restCall = new RestServices(data);
            bool status = false;

            string newAccountStatus = restCall.SubmitOAuth2RestCall("RegisterUser", "status");
            if (newAccountStatus == "Active")
            {
                status = loginPage.CreateAccountLogin(count);
                
                if(status)
                    status = thankYouPage.VerifyRegistrationThankYouPage();

                return status;
            }

            return status;
        }

        /// <summary>
        /// Name: AddSMSDevice
        /// Description: Method to add SMS device
        /// </summary>
        /// <param name="data"></param>
        /// <returns>bool</returns>
        public bool AddSMSDevice(Dictionary<string, string> data)
        {
            RestServices restCall = new RestServices(data);
            restCall.SubmitOAuth2RestCall("SearchUser", "nylid");
            string result = restCall.SubmitOAuth2RestCall("RegisterSMS", "pairingId");
            if (result != null)
            {
                restCall.SubmitOAuth2RestCall("RegisterSMSOTP", "message");
                string value = restCall.SubmitOAuth2RestCall("DeviceInfo", "phoneNumber");
                if (value == data[KeyRepository.ProfilePhone].Substring(1))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Name: GetExistingUserAccountsSheetData    
        /// Description:  Method to get the Existing User Accounts details
        /// </summary>
        /// <param name="data"></param>
        /// <param name="action"></param>
        public void GetExistingUserAccountsSheetData(Dictionary<string, string> data, string action = "")
        {
            int startCounter = GetSettor.failCounter;
            Dictionary<string, int> colDict = new Dictionary<string, int>();
            string type;
            string file = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataPath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet;                       
            Worksheet testdataWorksheet = null;
            Workbook existingAccountWorkbook = null;            
            Random random = new Random();
            bool expecteduseraccountfound = false;

            int loop = 0;
            do
            {
                loop++;
                Console.WriteLine("loop count: " + loop);
                
                //Open workbook 
                int retryCount = 3;
                while (retryCount > 0)
                {
                    try
                    {
                        // Open Existing User Account Excel
                        existingUserAccountExcel = new NYLDExcel(file, editable: true);
                        existingAccountWorkbook = existingUserAccountExcel.workbook;
                        application = existingUserAccountExcel.application;
                        testdataWorksheet = existingUserAccountExcel.GetWorksheetByName(existingAccountWorkbook, "TestData");
                        existinguseraccountsheets = existingUserAccountExcel.GetWorksheets(existingAccountWorkbook);
                        break; // Exit the loop if successful
                    }
                    catch (Exception ex)
                    {
                        existingUserAccountExcel.CloseExcel(existingAccountWorkbook);
                        // Handle any other exceptions
                        Console.WriteLine("An error occurred: " + ex.Message);
                        retryCount--;
                        if (retryCount == 0)
                        {
                            Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);
                            throw;
                        }
                        Thread.Sleep(10000); // Wait before retrying
                    }
                }
                try
                {

                    //Get the row number tobe uppated
                    int x = 2; string exisitngcontractuse = "NO";

                    //Reset the Row
                    if (action == "Release")
                    {
                        data.TryGetValue(KeyRepository.ResettheRow, out string ResettheRow);
                        if (!string.IsNullOrEmpty(ResettheRow))
                            x = Convert.ToInt32(data[KeyRepository.ResettheRow]);
                        else
                            x = random.Next(2, 5);

                        type = testdataWorksheet.Cells[x, 1].Text();
                    }
                    //lock the row until testcase complete
                    if (action != "Release")
                    {
                        do
                        {
                            type = testdataWorksheet.Cells[x, 1].Text();
                            string uname = testdataWorksheet.Cells[x, 3].Text();
                            exisitngcontractuse = testdataWorksheet.Cells[x, 5].Text();
                            if (exisitngcontractuse == "NO" && type == data[KeyRepository.ContractType] && uname != "")
                                expecteduseraccountfound = true;


                            if (action == "" && expecteduseraccountfound == true)
                            {
                                data[KeyRepository.PolicyNumber] = testdataWorksheet.Cells[x, 2].Text();
                                data[KeyRepository.UserName] = testdataWorksheet.Cells[x, 3].Text();
                                data[KeyRepository.Password] = testdataWorksheet.Cells[x, 4].Text();
                                testdataWorksheet.Cells[x, 6] = Environment.MachineName;
                                testdataWorksheet.Cells[x, 7] = DateTime.Now;
                                testdataWorksheet.Cells[x, 5] = "YES";
                                data[KeyRepository.ResettheRow] = x.ToString();
                                break;
                            }
                            x++;
                        } while (testdataWorksheet.Cells[x, 1].Text() != "");
                    }
                    else if (action == "Release")
                    {
                        expecteduseraccountfound = true;
                        testdataWorksheet.Cells[x, 6] = Environment.MachineName;
                        testdataWorksheet.Cells[x, 7] = DateTime.Now;
                        testdataWorksheet.Cells[x, 5] = "NO";
                    }

                    //Write the control number, save and close workbook
                    data[KeyRepository.ResettheRow] = x.ToString();
                    existingUserAccountExcel.SaveExcel(existingAccountWorkbook);
                    existingAccountWorkbook.Close();
                }
                catch
                {
                    //Nothing to do
                }
                if (expecteduseraccountfound == false)
                {
                    int waittime = random.Next(50000, 60000);
                    Thread.Sleep(waittime);
                }

            } while (!expecteduseraccountfound && loop < 10);

            if (expecteduseraccountfound==false)
            {
                NYLDSelenium.ReportStepResult("The test case failed because the existing account " + data[KeyRepository.ContractType] + " is currently in use by another test case. Despite waiting for the specified wait time, the account did not become available.", "Fail", "no", "yes");
            }

        }            

        //Release
        public void ReleaseUserAccounts(IWebDriver driver, Dictionary<string, string> data)
        {
            //Due to smoke test adding same- testcase name with out space
            string testcasename = data[KeyRepository.TestID].ToString().Trim();
            if (testcasename.Contains("Owner Address") || testcasename.Contains("Edit Insured") || testcasename.Contains("Change Payor") || testcasename.Contains("Owner Phone") || testcasename.Contains("SecureDoc") ||
               testcasename.Contains("OwnerAddress")|| testcasename.Contains("EditInsured") || testcasename.Contains("ChangePayor") || testcasename.Contains("OwnerPhone"))
            {
                string applicationsFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.NewUserAccountSheet;
             
                CommonFunctions CF = new CommonFunctions(data);
                Dictionary<string, int> colDict = new Dictionary<string, int>();

                string testFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.TestFileAppData;
                string ContractNumber = "";
                int x = 2;

                try
                {
                    GetUserDataWorkSheet();
                    workSheet = applicationsheets.GetByName("Applications");
                    //Get the column names which is having in specfic worksheet
                    colDict = applicationExcel.GetColumnIndices(workSheet);

                    //Reset the row 
                    x = Convert.ToInt32(data[KeyRepository.ResettheRow]);

                    //Get the row number tobe uppated

                    ContractNumber = workSheet.Cells[x, colDict["ContractNumber"]].Text();
                    if (ContractNumber.Trim() == data[KeyRepository.PolicyNumber].Trim().ToString())
                    {
                        workSheet.Cells[x, 56] = "Account Created";

                    }

                    //Write the control number, save and close workbook
                    applicationExcel.SaveExcel(workBook);
                    workBook.Close();
                }
                catch
                {
                    //  NYLDSelenium.ReportStepResult("Release the contract number fail-Testing", "Rerun the test case", "INFO", "always","always","no");
                    // Console.WriteLine("Release the contract number fail :"+ ContractNumber);
                }
            }
        }

        /// <summary>
        /// Method helps to get the Existing User acccounts sheet -username / passwords
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <param name="action"></param>
        public void VerifyExistingUserAccountsSheetCreds(IWebDriver driver, Dictionary<string, string> data, string action = "")
        {
            HomeDriver home = new HomeDriver(driver, data);
            string type;
            Worksheet testdataWorksheet = null;
            Workbook existingAccountWorkbook = null;
            string file = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataPath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet;
            string testFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.ExistingdataSheet;
            int i = 0;

            //Open workbook  
            int retryCount = 3;
            while (retryCount > 0)
            {
                try
                {
                    // Open Existing User Account Excel
                    existingUserAccountExcel = new NYLDExcel(file, editable: true);
                    existingAccountWorkbook = existingUserAccountExcel.workbook;
                    application = existingUserAccountExcel.application;
                    testdataWorksheet = existingUserAccountExcel.GetWorksheetByName(existingAccountWorkbook, "TestData");
                    existinguseraccountsheets = existingUserAccountExcel.GetWorksheets(existingAccountWorkbook);
                    break; // Exit the loop if successful
                }
                catch (Exception ex)
                {
                    existingUserAccountExcel.CloseExcel(existingAccountWorkbook);
                    // Handle any other exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                    retryCount--;
                    if (retryCount == 0)
                    {
                        Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);
                        throw;
                    }
                    Thread.Sleep(10000); // Wait before retrying
                }
            }
            LoginPage loginCSW = new LoginPage(driver, data);
            ResetPasswordPage resetPassword = new ResetPasswordPage(driver, data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            HomePage homePage = new HomePage(driver, data);

            //Get the row number to be updated
            int x = 2;
            do
            {
                type = testdataWorksheet.Cells[x, 1].Text();
                data[KeyRepository.ContractType] = "AUTTest";
                if (!string.IsNullOrEmpty(type) && !type.Contains("X") && !type.Contains("OneTimePaymentContract"))
                {
                    data[KeyRepository.PolicyNumber] = testdataWorksheet.Cells[x, 2].Text();
                    data[KeyRepository.PolicyNumber] = data[KeyRepository.PolicyNumber].Trim();
                    data[KeyRepository.UserName] = testdataWorksheet.Cells[x, 3].Text();
                    data[KeyRepository.Password] = testdataWorksheet.Cells[x, 4].Text();
                    if (data[KeyRepository.UserName] != "Nocontractexists")
                    {
                        Console.WriteLine("UsernameTest:" + data[KeyRepository.UserName]);
                        bool? status = loginCSW.VerifyLoginCreds();
                        if (status == null)
                        {
                            NYLDSelenium.ReportStepResult("Verify if user able to login successfully", "User failed to login -Please check and report to automation team.", "Fail", "always", "yes");
                            data[KeyRepository.Status] = "User failed to login - Please check and report to automation team.";
                        }
                        //Verify if user able to login or not and return a boolean value
                        else if (status == false)
                        {
                            bool? result = false;
                            try
                            {
                                driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                                // Reset the password
                                // Query policy number is provided in ExistingUserAccountsSheet Spreadsheet
                                DB.QueryPolicyDetails();
                                home.ForgotPassword("No,default");
                                // Update the latest password to sheet
                                testdataWorksheet.Cells[x, 4] = data[KeyRepository.Password];

                                Thread.Sleep(200); // Consider replacing with a more efficient wait mechanism if possible

                                // Revalidate the login credentials
                                result = loginCSW.VerifyLoginCreds();

                                Thread.Sleep(3000); // Consider replacing with a more efficient wait mechanism if possible
                            }
                            catch (Exception ex)
                            {
                                NYLDSelenium.ReportStepResult("An error occurred while resetting the password", "Please reach out to the automation team. Exception: " + ex.Message, "FAIL", "always", "yes");
                                data[KeyRepository.Status] = "An error occurred while resetting the password for " + data[KeyRepository.UserName] + ". Please reach out to the automation team.";
                                GetSettor.failCounter++;
                            }
                            Thread.Sleep(3000);
                            if (result == true)
                            { testdataWorksheet.Cells[x, 8] = "Working"; testdataWorksheet.Cells[x, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green); }
                            else
                            { testdataWorksheet.Cells[x, 8] = "Not Working"; testdataWorksheet.Cells[x, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow); i++; }
                        }
                        else// update the row based on the boolean
                        {
                            testdataWorksheet.Cells[x, 8] = "Working"; testdataWorksheet.Cells[x, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                        }

                        //to set the time for saving the color in excel sheet 
                        //checking if any one credential fail we can fail the execution
                        if (i == 0)
                            data[KeyRepository.Status] = "All the Login credentials are valid";
                        else
                            data[KeyRepository.Status] = "All the Login credentials are not valid";
                    }
                }

                existingUserAccountExcel.SaveExcel(existingAccountWorkbook);
                x++;
            } while (testdataWorksheet.Cells[x, 1].Text() != "");
            //Write the control number, save and close workbook
            existingUserAccountExcel.SaveExcel(existingAccountWorkbook);
            existingAccountWorkbook.Close();
        }

        /// <summary>
        /// Method helps to make the one time payment
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        public void MakePayment(IWebDriver driver, Dictionary<string, string> data)
        {
            try
            {
                string applicationsFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.NewUserAccountSheet;
                LSPDatabase DB = new LSPDatabase(driver, data);
                RestServices webService = new RestServices(data);
                Dictionary<string, int> colDict = new Dictionary<string, int>();
                RestServices webServices = new RestServices(data);

                GetUserDataWorkSheet();
                workSheet = applicationsheets.GetByName("Applications");
                //Get the column names which is having in specfic worksheet
                colDict = applicationExcel.GetColumnIndices(workSheet);

                //Check in between time period to execute this flow 
                DateTime date1 = new DateTime();
                date1 = DateTime.Now.AddMinutes(0);

                DateTime date2 = new DateTime();
                date2 = DateTime.Now.AddMinutes(24);

                // comparing date1 and date2
                int value = DateTime.Compare(date1, date2);

                int x = 2;
                do
                {   date1 = DateTime.Now.AddMinutes(0);
                    value = DateTime.Compare(date1, date2);
                    if (value != 0 && value < 0)
                    {

                        string policynumber = workSheet.Cells[x, colDict["ContractNumber"]].Text();
                        string accountnotused = workSheet.Cells[x, colDict["Contract"]].Text();
                        data[KeyRepository.PolicyNumber] = policynumber.Trim();

                        if (accountnotused!= "Account Created-Used" && string.IsNullOrEmpty(workSheet.Cells[x, colDict["OneTimepayment"]].Text()) && !string.IsNullOrEmpty(policynumber) && (policynumber.Substring(0, 1).Trim() == "A"))
                        {
                            if (DB.GetPolicyDetails() == true)
                            {
                                if (DB.PendingPayment() == false)
                                {
                                    DB.QueryPolicyDetails();
                                    data[KeyRepository.PolicyNumber] = policynumber.Trim();
                                    workSheet.Cells[x, colDict["OneTimepayment"]] = webService.Makeonetimepayment(driver, data);
                                }
                            }
                        }

                        applicationExcel.SaveExcel(workBook);
                        x++;
                    }
                    else
                        break;
                } while (workSheet.Cells[x, 1].Text() != "");

                //Finally close the sheet
                workBook.Close();
                data[KeyRepository.Status] = "One time payment for new contracts completed ";
            }
            catch
            {
                NYLDSelenium.ReportStepResult("One time payment for New Contracts is not complete  :", "One time payment for new contracts is not complete ", "INFO", "always", "no");
                data[KeyRepository.Status] = "One time payment for new contracts is not complete ";
            }
        }

        /// <summary>
        /// Method helps to make the Paperless OptIn
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        public void PaperlessOptIn(IWebDriver driver, Dictionary<string, string> data)
        {
            try
            {
                string applicationsFile = Properties.Settings.Default.RootDirectory + Properties.Settings.Default.NewUserAccountSheet;
                Worksheet workSheet = null;
                LSPDatabase DB = new LSPDatabase(driver, data);
                PaperlessSettingsPage paperless = new PaperlessSettingsPage(driver, data);
                Dictionary<string, int> colDict = new Dictionary<string, int>();
                HomePage home = new HomePage(driver, data);
               
                GetUserDataWorkSheet();
                workSheet = applicationsheets.GetByName("Applications");
                //Get the column names which is having in specfic worksheet
                colDict = applicationExcel.GetColumnIndices(workSheet);

                int x = 2;
                do
                {
                    if (!driver.Url.ToLower().Contains("login"))
                    {
                        driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                        Thread.Sleep(100);
                    }
                    string policynumber = workSheet.Cells[x, colDict["ContractNumber"]].Text();
                    data[KeyRepository.PolicyNumber] = policynumber.Trim();

                    string username = workSheet.Cells[x, colDict["MCUSR4"]].Text();
                    if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(policynumber) && policynumber.Substring(0, 1).Trim() == "A" && string.IsNullOrEmpty(workSheet.Cells[x, 61].Text()))
                    {
                        if (DB.GetPolicyDetails() == true)
                        { workSheet.Cells[x, 61] = "Paperless-OptIn";
                            try
                            {
                                data[KeyRepository.PolicyNumber] = policynumber.Trim();
                                data[KeyRepository.UserName] = workSheet.Cells[x, 57].Text();
                                data[KeyRepository.Password] = workSheet.Cells[x, 58].Text();
                                paperless.PaperlessSettingOptIn();
                                if (driver.Url.Contains("Thank-You"))

                                    //Need to wait until OptIn action completes
                                    Thread.Sleep(1000);
                                home.NavigateToPage(KeyRepository.LogoutPage);
                            }
                            catch
                            {

                            }
                        }
                    }

                    applicationExcel.SaveExcel(workBook);
                    x++;
                } while (workSheet.Cells[x, 1].Text() != "");

                //Finally close the sheet
                workBook.Close();
                data[KeyRepository.Status] = "Paperless OptIn completed successfully for " + data[KeyRepository.PolicyNumber];
            }
            catch
            {
                NYLDSelenium.ReportStepResult("Paperless OptIn   :", "Paperless OptIn not complete ", "INFO", "always", "no");
                data[KeyRepository.Status] = "Paperless OptIn not complete for " + data[KeyRepository.PolicyNumber];
            }
        }

        /// <summary>
        /// This Method helps to read the current work sheet
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <param name="criteria"></param>
        /// <param name="testcaseuserstatus"></param>
        public void ReadWorksheet(IWebDriver driver, Dictionary<string, string> data, string criteria = "Monthly", string testcaseuserstatus = "New")
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions CF = new CommonFunctions(data);
            RestServices restCall = new RestServices(data);
            bool NewControlNumberFound = false;
            string controlNumberStatus = "";
            string paymentMode = "";
            int x = 2;
            if (data[KeyRepository.PreTestDataSet].Equals("Frequency:Quarterly"))
                criteria = "Quarterly";
            if (data[KeyRepository.PreTestDataSet].Equals("Payment:MQPayFreqElig"))
                criteria = "Quarterly";

            data[KeyRepository.AuthToken] = restCall.SubmitRestCall("GenerateOAuthToken");
            GetUserDataWorkSheet();
            workSheet = applicationsheets.GetByName("Applications");
            //Get the column names which is having in specfic worksheet
            colDict = applicationExcel.GetColumnIndices(workSheet);
            do
            {
                controlNumberStatus = workSheet.Cells[x, colDict["Contract"]].Text();
                paymentMode = workSheet.Cells[x, colDict["PaymentMode"]].Text();
                bool paymodeSatisfied = false;

                if (controlNumberStatus == testcaseuserstatus)
                    Console.WriteLine("Test");
                if (criteria == "Quarterly" && paymentMode == "Quarterly")
                    paymodeSatisfied = true;
                else if (criteria == "Monthly" && paymentMode == "Monthly")
                    paymodeSatisfied = true;
                else if (!data[KeyRepository.PreTestDataSet].Contains("Payment"))
                    paymodeSatisfied = true;

                if (controlNumberStatus == testcaseuserstatus && paymodeSatisfied)
                {
                    string policynumber = workSheet.Cells[x, colDict["ContractNumber"]].Text().Trim();
                    if (!string.IsNullOrEmpty(policynumber) && (policynumber.Substring(0, 1).Trim() == "A" || policynumber.Substring(0, 1).Trim() == "B") && !policynumber.Contains("Face"))
                    {
                        //driver.Navigate().GoToUrl(data[KeyRepository.URL]);
                        string email = workSheet.Cells[x, colDict["Email"]].Text();

                        data[KeyRepository.EmailId] = workSheet.Cells[x, 39].Text();
                        data[KeyRepository.PolicyNumber] = policynumber;

                        //For New contract verifying the contract status is already register /cyberfraud impacted to skip the contracts
                        if (testcaseuserstatus == "New")
                        {
                            if (ValidContract(driver, data) == false)
                            {
                                x++;
                                continue;
                            }
                        }
                        else
                        {
                            //Verify the Policy details is present in LSPdatabase
                            DB.QueryPolicyNumber();
                            CF.GetContractCardcolor();
                            if (data[KeyRepository.PolicyStatus] != "Inforce")
                            {
                                x++;
                                continue;
                            }
                        }
                        if (data[KeyRepository.PreTestDataSet].Contains("NoExistingEFT") && !string.IsNullOrEmpty(workSheet.Cells[x, colDict["OneTimepayment"]].Text().ToString()))
                        {
                            x++;
                            continue;
                        }
                        if (data[KeyRepository.ContractType] == "NoExistingEmail" && !string.IsNullOrEmpty(email))
                        {
                            x++;
                            continue;
                        }
                        if (data[KeyRepository.ContractType] == "EmailAlreadyInUse" && !string.Equals(email, "test@email.com"))
                        {
                            x++;
                            continue;
                        }
                        if (data[KeyRepository.ContractType] == "ValidFuneralHomeStates" && ((string.Equals(data[KeyRepository.State], "MI")) || (string.Equals(data[KeyRepository.State], "MN")) || (string.Equals(data[KeyRepository.State], "NY")) || (string.Equals(data[KeyRepository.State], "OK")) || (string.Equals(data[KeyRepository.State], "IN"))))
                        {
                            x++;
                            continue;
                        }
                        //Data for ProtectYourProfile and CSWLite manily for Active account
                        if (data["ContractType"] != "continueflow")
                        {
                            if (!string.IsNullOrEmpty(workSheet.Cells[x, colDict["CSWAccountType"]].Text()))
                            {
                                if (data["ContractType"] == "ProtectYourProfile")
                                {
                                    if (workSheet.Cells[x, colDict["CSWAccountType"]].Text() != "ProtectYourProfile")
                                    {
                                        x++;
                                        continue;
                                    }
                                }
                                else if (data["ContractType"] == "CSWLite")
                                {
                                    if (workSheet.Cells[x, colDict["CSWAccountType"]].Text() != "CSWLite")
                                    {
                                        x++;
                                        continue;
                                    }
                                }
                            }
                            else
                            {
                                x++;
                                continue;
                            }
                        }
                        //User status is active
                        if (testcaseuserstatus != "New")
                        {
                            data[KeyRepository.UserName] = workSheet.Cells[x, 57].Text();
                            data[KeyRepository.Password] = workSheet.Cells[x, 58].Text();
                            NewControlNumberFound = true;

                            //Verify the below conditions not satisfied then continue the loop / else stop the loop and continue the business flow test
                            if (string.IsNullOrEmpty(data[KeyRepository.UserName]))
                            {
                                NewControlNumberFound = false;
                                x++;
                                continue;
                            }
                        }

                        workSheet.Cells[x, 56] = "Account Created-Used";
                        NewControlNumberFound = true;
                        if (data[KeyRepository.PolicyStatus] != "Cancelled")
                            break;
                    }
                    else
                    {
                        workSheet.Cells[x, 56] = "Account Created-Used";
                    }
                }

                x++;
            } while (workSheet.Cells[x, 1].Text() != "");

            //Save work book with udpated information
            data[KeyRepository.ResettheRow] = x.ToString();
            applicationExcel.SaveExcel(workBook);
            workBook.Close();

            //Report if the contract is not found
            if (!NewControlNumberFound)
            {
                NYLDSelenium.ReportStepResult("Use a new test contract for this test case.", "All contracts in the data sheet have been used or in cancelled status. Please refurbish the data sheet", "FAIL", "no", "yes");               
            }

            if (testcaseuserstatus != "New")
            {
                //Verify the Policy details is present in LSPdatabase
                DB.QueryPolicyNumber();
                CF.GetContractCardcolor();
                DB.QueryQuarterlyPaymntElig();
            }
        }

        public bool ValidContract(IWebDriver driver, Dictionary<string, string> data, [Optional] string arg)
        {
            CommonFunctions CF = new CommonFunctions(data);
            LSPDatabase DB = new LSPDatabase(driver, data);
            RestServices restCall = new RestServices(data);
            bool RecordFound = false; bool isDigitNSymbolPresent = false;
            string accountStatus = "";
            //Local
            DB.QueryPolicyNumber();
            DB.GetDataBaseValues("queryPolicyDetailsEffectiveDate");
            //If the contract is not paid to date then skip the contract
            data.TryGetValue(KeyRepository.PaidToDate, out string PaidToDate);
            if (!string.IsNullOrEmpty(PaidToDate))
            {
                CF.GetContractCardcolor();
                bool isCancelled = data[KeyRepository.PolicyStatus] == "Cancelled";
                bool isInvalidPolicyNumber = data[KeyRepository.PolicyNumber] == null || !data[KeyRepository.PolicyNumber].StartsWith("A");

                if (isInvalidPolicyNumber)
                { RecordFound = false; }
                else
                {
                    //verify if the special characters present then skip the contract
                    isDigitNSymbolPresent = Regex.IsMatch(data[KeyRepository.LastName].Trim(), @"^[a-zA-Z]+$");

                    if (isDigitNSymbolPresent == true)
                    {
                        DB.GetDataBaseValues("queryEmail");
                        DB.GetClientId();
                        if (data[KeyRepository.ClientId] == null)
                        {
                            RecordFound = false;
                        }
                        else
                        {
                            accountStatus = VerifyAccountStatus(data);
                            if (accountStatus == "Active")
                            {
                                RecordFound = false;
                            }
                            else
                                RecordFound = true;
                        }   
                    }
                }
            }
            else
                RecordFound = false;

            Console.WriteLine("Valid Contract " + RecordFound);
            return RecordFound;
        }

        /// <summary>
        /// Method to get mapped values from datasheet
        /// </summary>
        /// <param name="mappingname"></param>
        /// <param name="value"></param>
        /// <param name="mapdirection"></param>
        /// <returns></returns>
        public string GetMappedValue(string mappingname, string value, string mapdirection = "forward")
        {
            string type;
            string actval;
            string mappedval = "";

            int x = 1;
            Worksheet Mapping = datatworksheets.GetByName("Mapping");
            do
            {
                type = Mapping.Cells[x, 1].Text();

                if (type == mappingname)
                {
                    if (mapdirection == "forward")
                    {
                        actval = Mapping.Cells[x, 2].Text();
                        if (value == actval)
                        {
                            mappedval = Mapping.Cells[x, 3].Text();
                            break;
                        }
                    }
                    else
                    {
                        actval = Mapping.Cells[x, 3].Text();
                        if (value == actval)
                        {
                            mappedval = Mapping.Cells[x, 2].Text();
                            break;
                        }
                    }
                }

                x++;
            } while (Mapping.Cells[x, 1].Text() != "");

            return mappedval;
        }

        /// <summary>
        /// Method to find if the contracts of Static data are active
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public int GetStatusOfTestContracts(IWebDriver driver, Dictionary<string, string> data)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions commonFunctions = new CommonFunctions(data);
            RestServices webServices = new RestServices(data);
            int mismatchcount = 0;
            Worksheet allContractsWorksheet = null;
            Workbook existingAccountWorkbook = null;
            string filePath = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataPath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet;
           //Open Excel
            int retryCount = 3;
            while (retryCount > 0)
            {
                try
                {
                    // Open Existing User Account Excel
                    existingUserAccountExcel = new NYLDExcel(filePath, editable: true);
                    existingAccountWorkbook = existingUserAccountExcel.workbook;
                    application = existingUserAccountExcel.application;
                    allContractsWorksheet = existingUserAccountExcel.GetWorksheetByName(existingAccountWorkbook, "CSW_AllContracts");
                    existinguseraccountsheets = existingUserAccountExcel.GetWorksheets(existingAccountWorkbook);
                    break; // Exit the loop if successful
                }
                catch (Exception ex)
                {
                    existingUserAccountExcel.CloseExcel(existingAccountWorkbook);
                    // Handle any other exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                    retryCount--;
                    if (retryCount == 0)
                    {
                        Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);
                        throw;
                    }
                    Thread.Sleep(10000); // Wait before retrying
                }
            }
            int x = 2;

            do
            {
                string status = allContractsWorksheet.Cells[x, 3].Text();
                string expectedstatus = allContractsWorksheet.Cells[x, 4].Text();

                data[KeyRepository.PolicyNumber] = allContractsWorksheet.Cells[x, 3].Text();
                data[KeyRepository.PolicyNumber] = data[KeyRepository.PolicyNumber].Trim();


                DB.QueryPolicyDetails();
                commonFunctions.GetContractCardcolor();
                string actualstatus = data[KeyRepository.PolicyStatus].Substring(0,1).ToUpper();

                if (expectedstatus != actualstatus)
                {
                    mismatchcount = mismatchcount + 1;
                    if (expectedstatus == "I")
                    {
                        allContractsWorksheet.Cells[x,11] = webServices.Makeonetimepayment(driver, data);
                        allContractsWorksheet.Cells[x, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);  
                    }
                    else
                        allContractsWorksheet.Cells[x, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                }
                else
                    allContractsWorksheet.Cells[x, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);

                //PaidToDate
                allContractsWorksheet.Cells[x, 8] = data[KeyRepository.PolicyStatus];
                allContractsWorksheet.Cells[x, 9] = data[KeyRepository.LSPDate];
                allContractsWorksheet.Cells[x, 10] = data[KeyRepository.PaidToDate];

                Thread.Sleep(100);
                existingUserAccountExcel.SaveExcel(existingAccountWorkbook);
                x++;     // go to next row in sheet //

            } while (allContractsWorksheet.Cells[x, 1].Text() != "");

            existingUserAccountExcel.SaveExcel(existingAccountWorkbook);
            existingAccountWorkbook.Close();

            return mismatchcount;
        }

        /// <summary>
        /// Method to find if the Valid Emails which are In Use
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public bool GetValidEmail(IWebDriver driver, Dictionary<string, string> data)
        {
            LSPDatabase DB = new LSPDatabase(driver, data);
            CommonFunctions commonFunctions = new CommonFunctions(data);
            bool EmailAvailable = false;
            string InUse = "";
            ForgotPage forgot = new ForgotPage(driver, data);
            LSPDatabase db = new LSPDatabase(driver, data);
            Worksheet loginWorkSheet = null;
            Workbook existingAccountWorkBook = null;
            string filePath = CSW.Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataPath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet;           
            int retryCount = 3;
            while (retryCount > 0)
            {
                try
                {
                    // Open Existing User Account Excel
                    existingUserAccountExcel = new NYLDExcel(filePath, editable: true);
                    existingAccountWorkBook = existingUserAccountExcel.workbook;
                    application = existingUserAccountExcel.application;
                    loginWorkSheet = existingUserAccountExcel.GetWorksheetByName(existingAccountWorkBook, "LoginEmail");
                    existinguseraccountsheets = existingUserAccountExcel.GetWorksheets(existingAccountWorkBook);
                    colDict = existingUserAccountExcel.GetColumnIndices(loginWorkSheet);
                    break; // Exit the loop if successful
                }
                catch (Exception ex)
                {
                    existingUserAccountExcel.CloseExcel(existingAccountWorkBook);
                    // Handle any other exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                    retryCount--;
                    if (retryCount == 0)
                    {
                        Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);
                        throw;
                    }
                    Thread.Sleep(10000); // Wait before retrying
                }
            }

            int x = 2;string defaultemailid;

            do
            {
                InUse = loginWorkSheet.Cells[x, colDict["In_Use"]].Text();
                if (InUse == "NO")
                {
                    loginWorkSheet.Cells[x, colDict["In_Use"]] = "YES";
                    defaultemailid = loginWorkSheet.Cells[x, colDict["Emailid"]].Text();
                    data[KeyRepository.EmailId] = loginWorkSheet.Cells[x, colDict["Emailid"]].Text();
                    data[KeyRepository.EmailLastname] = loginWorkSheet.Cells[x, colDict["Lastname"]].Text();


                    data[KeyRepository.EmailIdSet] = data[KeyRepository.EmailId];
                    string policynumber = data[KeyRepository.PolicyNumber];

                    //For registration we are using the valid email id availability and if it is available then we are using the same email id for registration
                    //else we are reset the details and then continue the process
                    if (data[KeyRepository.SubFuntionality].Contains("Registration"))
                    {
                        ForgotPage forgotPage = new ForgotPage(driver, data);
                        if (GetValidEmailId(driver, data)==false)
                            forgotPage.DeleteEmailIdInExistingUserAccount(data[KeyRepository.EmailId]);
                    }
                    //set the right values back due to reset the email id
                    data[KeyRepository.ReResettheRow] = x.ToString();
                    data[KeyRepository.EmailId] = defaultemailid;
                    data[KeyRepository.EmailIdSet] = data[KeyRepository.EmailId];
                    data[KeyRepository.PolicyNumber] = policynumber;
                    DB.QueryPolicyDetails();
                    processfurther = true;
                    data[KeyRepository.PostpreProcess] = "Yes";
                    break;
                }
                else
                {
                    Thread.Sleep(9000);
                    x++;
                    continue;// go to next row in sheet //
                }
                   
            } while (loginWorkSheet.Cells[x, 1].Text() != "");

                data[KeyRepository.ReResettheRow] = x.ToString();

            existingUserAccountExcel.SaveExcel(existingAccountWorkBook);
            existingAccountWorkBook.Close();

            if (processfurther == true)
            {
                NYLDSelenium.ReportStepResult("<h3 style=\"color:Purple\">" + "Prerequisite - GetValid Email" + "</h3>", "Using this valid Email Id: " + data[KeyRepository.EmailIdSet] + " for this testcase", "Info", "always", "no");
                //After selecting the availability email and then continue the process 
                if (data[KeyRepository.SubFuntionality].Contains("Reset"))
                {
                    if (forgot.UpdateAccountInfoEMail(data[KeyRepository.PolicyNumber], "Email"))
                    {
                        EmailAvailable = true;
                    }
                }
                if (data[KeyRepository.SubFuntionality].Contains("Registration"))
                    EmailAvailable = true;
            }
            return EmailAvailable;          
        }

        /// <summary>
        /// Method to find if the Valid Emails which are In Use
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public bool GetValidEmailId(IWebDriver driver, Dictionary<string, string> data)
        {           
            bool EmailAvailable = false;
            LSPDatabase db = new LSPDatabase(driver, data);

            data.TryGetValue(KeyRepository.EmailIdSet, out string EmailIdSet);
            if (!string.IsNullOrEmpty(EmailIdSet))
            {
                data[KeyRepository.EmailId] = data[KeyRepository.EmailIdSet];

                db.GetDataBaseValues("queryEmailcontract");
                if (db.queryResultList.Count == 0)
                {
                    EmailAvailable = true;
                }
            }
            else
            {//for smoke test 
                data[KeyRepository.EmailId] = ("AUT" + data[KeyRepository.FirstName] + DateTime.Now.Second + DateTime.Now.Minute + "@automation.com").Trim();
                EmailAvailable = true;
            }
            return EmailAvailable;        
        }

        /// <summary>
        /// Method helps to get the Existing User acccounts sheet -username / passwords and update email id in account information page
        /// </summary>
        /// <param name="driver"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public string UpdateValidEmailId(IWebDriver driver, Dictionary<string, string> data)
        {
            int x = 2;
            string InUse = "";
            string filePath = Properties.Settings.Default.RootDirectory + CSW.Properties.Settings.Default.TestDataPath + CSW.Properties.Settings.Default.ExistingUserAccountsSheet;

            LSPDatabase DB = new LSPDatabase(driver, data);
            ForgotPage forgot = new ForgotPage(driver, data);
            UserRegistrationDriver userRegistration = new UserRegistrationDriver(driver, data);
            CommonFunctions commonFunctions = new CommonFunctions(data);
            Worksheet loginworksheet = null;
            Workbook existingAccountWorkbook = null;
            //Open Existing user account sheet 
            int retryCount = 3;
            while (retryCount > 0)
            {
                try
                {
                    // Open Existing User Account Excel
                    existingUserAccountExcel = new NYLDExcel(filePath, editable: true);
                    existingAccountWorkbook = existingUserAccountExcel.workbook;
                    application = existingUserAccountExcel.application;
                    loginworksheet = existingUserAccountExcel.GetWorksheetByName(existingAccountWorkbook, "LoginEmail");
                    existinguseraccountsheets = existingUserAccountExcel.GetWorksheets(existingAccountWorkbook);
                    colDict = existingUserAccountExcel.GetColumnIndices(loginworksheet);
                    break; // Exit the loop if successful
                }
                catch (Exception ex)
                {
                    existingUserAccountExcel.CloseExcel(existingAccountWorkbook);
                    // Handle any other exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                    retryCount--;
                    if (retryCount == 0)
                    {
                        Console.WriteLine("Failed to open Excel after multiple attempts. Exception: " + ex.Message);                        
                        throw;
                    }
                    Thread.Sleep(10000); // Wait before retrying
                }
            }
            Random random = new Random();
            data.TryGetValue(KeyRepository.ReResettheRow, out string ReResettheRow);
            if (!string.IsNullOrEmpty(ReResettheRow))
                x = Convert.ToInt32(data[KeyRepository.ReResettheRow]);
            else
                x = random.Next(2, 7);
            bool update = false;

            if (!string.IsNullOrEmpty(ReResettheRow))
            {
                data.TryGetValue(KeyRepository.UserName, out string UserName);
                if (!string.IsNullOrEmpty(UserName))
                {
                    data.TryGetValue(KeyRepository.PostpreProcess, out string PostpreProcess);
                    data.TryGetValue(KeyRepository.Regerror, out string Regerror);
                    if (!string.IsNullOrEmpty(PostpreProcess) && PostpreProcess == "Yes")
                    {
                        //If in middle of registration process fail then it could not process into post prerequisite
                        if (data[KeyRepository.SubFuntionality].Contains("Registration") && !string.IsNullOrEmpty(Regerror) && (driver.Url.Contains("Invalid?Reason") || Regerror == "2" || Regerror == "3"))
                            update = false;
                        else if (data[KeyRepository.SubFuntionality].Contains("Reset"))
                            update = true;
                        else
                            update = true;

                        if (update == true)
                        {
                            NYLDSelenium.ReportStepResult("<h3 style=\"color:Purple\">" + "Post PreRequisite" + "</h3>", "Reset the  Email Id: " + data[KeyRepository.EmailIdSet] + " for reusable", "Info", "always", "no");
                            try
                            {
                                userRegistration.SetValue("NewEmail");
                                forgot.UpdateAccountInfoEMail(data[KeyRepository.PolicyNumber], "Email");
                            }
                            catch { data[KeyRepository.Status] = "Unable to update the Email ID for " + data[KeyRepository.PolicyNumber]; }
                        }
                    }
                    loginworksheet.Cells[x, colDict["Userid"]] = data[KeyRepository.UserName];
                    loginworksheet.Cells[x, colDict["Password"]] = data[KeyRepository.Password];
                }
            }
            loginworksheet.Cells[x, colDict["In_Use"]] = "NO";

            existingUserAccountExcel.SaveExcel(existingAccountWorkbook);
            existingAccountWorkbook.Close();
            data[KeyRepository.Status] = "Email ID updated successfully for " + data[KeyRepository.PolicyNumber];
            return InUse; 
        }

        /// <summary>
        /// Method to fetch the required options for Datamine
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public string GetDataMineOptionsContent(string args)
        {
            string content = "";
            string type = "";
            int x = 1;     
            Worksheet DataMine = datatworksheets.GetByName("DataMine");
            do
            {
                type = DataMine.Cells[x, 1].Text().Trim();

                if (type == args.Trim())
                {
                    content = DataMine.Cells[x, 2].Text().Trim() + "," + DataMine.Cells[x, 3].Text().Trim() + "," + DataMine.Cells[x, 4].Text().Trim() + "," + DataMine.Cells[x, 5].Text().Trim() + "," + DataMine.Cells[x, 6].Text().Trim();
                    break;
                }
                x++;
            } while (DataMine.Cells[x, 1].Text() != "");

            return content;
        }

        /// <summary>
        /// Method to fetch the required content from datasheet
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public string GetContent(string args)
        {
            string content = "";
            string type = "";
            int x = 1;
            Worksheet Content = datatworksheets.GetByName("Content");
            do
            {
                type = Content.Cells[x, 2].Text().Trim();

                if (type == args.Trim())
                {
                    content = Content.Cells[x, 4].Text().Trim();
                    break;
                }
                x++;
            } while (Content.Cells[x, 3].Text() != "");
            return content;         
        }

        /// <summary>
        /// Method to fetch the required content from datasheet
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public string GetInputData(string name)
        {
            string value = "";
            string type = "";
            int x = 1;
            Worksheet InputData = datatworksheets.GetByName("InputData");

            do
            {
                type = InputData.Cells[x, 1].Text().Trim();

                if (type == name.Trim())
                {
                    value = InputData.Cells[x, 2].Text().Trim();
                    break;
                }
                x++;
            } while (InputData.Cells[x, 1].Text() != "");

            return value;

        }

        /// <summary>
        /// Emthod to fetcht data from datsheet to validate a field
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetFieldValidationData(string args, string Page)
        {
            Dictionary<string, string> fieldValidationData = new Dictionary<string, string>();
            Dictionary<string, int> colDict = new Dictionary<string, int>();            
            Worksheet FieldValidation = datatworksheets.GetByName("FieldValidation");
            colDict = dataExcel.GetColumnIndices(FieldValidation);
            int i = 2;
            do
            {
                string pagename = FieldValidation.Cells[i, colDict[KeyRepository.PageName]].Text().Trim();
                if (Page != "Bene" && string.IsNullOrEmpty(pagename) && string.Equals(args.Trim(), FieldValidation.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    fieldValidationData.Add(KeyRepository.FieldName, FieldValidation.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.FieldType, FieldValidation.Cells[i, colDict[KeyRepository.FieldType]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.BlankMessage, FieldValidation.Cells[i, colDict[KeyRepository.BlankMessage]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.InvalidMessage, FieldValidation.Cells[i, colDict[KeyRepository.InvalidMessage]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.ValidInput, FieldValidation.Cells[i, colDict[KeyRepository.ValidInput]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.InvalidInput, FieldValidation.Cells[i, colDict[KeyRepository.InvalidInput]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.MaximumLength, FieldValidation.Cells[i, colDict[KeyRepository.MaximumLength]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.ErrorTrigger, FieldValidation.Cells[i, colDict[KeyRepository.ErrorTrigger]].Text().Trim());
                    break;
                }
                if (!string.IsNullOrEmpty(pagename) && Page.Trim().Contains(pagename) && string.Equals(args.Trim(), FieldValidation.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    fieldValidationData.Add(KeyRepository.FieldName, FieldValidation.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.FieldType, FieldValidation.Cells[i, colDict[KeyRepository.FieldType]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.BlankMessage, FieldValidation.Cells[i, colDict[KeyRepository.BlankMessage]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.InvalidMessage, FieldValidation.Cells[i, colDict[KeyRepository.InvalidMessage]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.ValidInput, FieldValidation.Cells[i, colDict[KeyRepository.ValidInput]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.InvalidInput, FieldValidation.Cells[i, colDict[KeyRepository.InvalidInput]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.MaximumLength, FieldValidation.Cells[i, colDict[KeyRepository.MaximumLength]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.ErrorTrigger, FieldValidation.Cells[i, colDict[KeyRepository.ErrorTrigger]].Text().Trim());
                    break;
                }
                i++;

            } while (FieldValidation.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim() != "");

            return fieldValidationData;
        }

        public Dictionary<string, string> GetFieldAttributeData(string Page, string fieldname)
        {
            Dictionary<string, string> fieldValidationData = new Dictionary<string, string>();
            Dictionary<string, int> colDict = new Dictionary<string, int>();
            Worksheet FieldAttributes = datatworksheets.GetByName("FieldAttributes");
            colDict = dataExcel.GetColumnIndices(FieldAttributes);
            int i = 2;
            //NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Get Field Attribute Data for :" +Page + "and field name"+ fieldname+"</h3>", "############", "Info", "always", "no");
            do
            {
                string pagename = FieldAttributes.Cells[i, colDict[KeyRepository.PageName]].Text().Trim();
                string Fieldname = FieldAttributes.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim();
                if (!string.IsNullOrEmpty(pagename) && Page == pagename && fieldname.Trim()==Fieldname)
                {
                    NYLDSelenium.ReportStepResult("<h3 style=\"color:Blue\">" + "Get Field Attribute Data for :" + Page + " and field name " + fieldname + "</h3>", "############", "Info", "always", "no");
                    fieldValidationData.Add(KeyRepository.FieldName, FieldAttributes.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.FieldType, FieldAttributes.Cells[i, colDict[KeyRepository.FieldType]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.Regrex, FieldAttributes.Cells[i, colDict[KeyRepository.Regrex]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.BlankMessage, FieldAttributes.Cells[i, colDict[KeyRepository.BlankMessage]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.InvalidMessage, FieldAttributes.Cells[i, colDict[KeyRepository.InvalidMessage]].Text().Trim());
                    fieldValidationData.Add(KeyRepository.MaximumLength, FieldAttributes.Cells[i, colDict[KeyRepository.MaximumLength]].Text().Trim());
                    break;
                }
                i++;
            } while (FieldAttributes.Cells[i, colDict[KeyRepository.FieldName]].Text().Trim() != "");

            return fieldValidationData;
        }

        public Worksheet GetFieldAttributeSheet()
        {
            return datatworksheets.GetByName("FieldAttributes"); 
        }

        public Worksheet GetMappingSheet()
        {
            return datatworksheets.GetByName("FieldMapping");
        }

        public void VerifyfieldAttributes(string page)
        {
            Worksheet fieldAttributes = GetFieldAttributeSheet();
            Worksheet mapping = GetMappingSheet();
            NYLDDigital.PerformFormfieldValidations(page, fieldAttributes, mapping);         

        }

        public bool GetRiderPdfInfo(IWebDriver driver, Dictionary<string, string> data)
        {
            int row = 2;
            bool Templatefound = false;
            Worksheet PDFContent = datatworksheets.GetByName("PDFContent");
            do
            {
                string ch2 = PDFContent.Cells[row, 2].Text();
                if (ch2.Contains(data[KeyRepository.State]))
                {
                    Templatefound = true;
                    data[KeyRepository.TemplateType] = PDFContent.Cells[row, 5].Text();
                    data[KeyRepository.TemplateFormId] = PDFContent.Cells[row, 4].Text();
                    data[KeyRepository.Read_SignDisclaimer] = PDFContent.Cells[row, 6].Text();
                    data[KeyRepository.CAResidents] = PDFContent.Cells[row, 7].Text();
                    break;
                }

                row = row + 1;

            } while (PDFContent.Cells[row, 2].Text() != "");

            return Templatefound;
        }

        public string GetPDFContent(int row, int col)
        {
            Worksheet PDFContent = datatworksheets.GetByName("PDFContent");
            return PDFContent.Cells[row, col].Text();
        }
        public string PDFConfigSheet(int row, int col)
        {
            Worksheet PDFConfigSheet = datatworksheets.GetByName("PDFConfigSheet");
            return PDFConfigSheet.Cells[row, col].Text();
        }
        public string Makeonetimepayment(IWebDriver driver, Dictionary<string, string> data)
        {
            string status = "";
            RestServices webServices = new RestServices(data);
            try
            {
                double daysPastEFD = (Convert.ToDateTime(data[KeyRepository.LSPDate]) - Convert.ToDateTime(data[KeyRepository.PaidToDate])).TotalDays;
                if (daysPastEFD > 0)
                {
                    return status = webServices.SubmitRestCall("AddOneTimePayment");
                }
            }
            catch
            {
                GetSettor.failCounter++;
            }
            return status;
        }

        public List<string> GetAddresses(string state = "Any")
        {
            Worksheet AddressSheet = datatworksheets.GetByName("Addresses");
            return NYLDGeneric.GetAddress(AddressSheet, state);
        }

        public void ReleaseExcelObjects()
        {
            if (workSheet != null)
            {
                Marshal.ReleaseComObject(workSheet);
                workSheet = null;
            }
            if (workBook != null)
            {
                workBook.Close(false);
                Marshal.ReleaseComObject(workBook);
                workBook = null;
            }
            if (application != null)
            {
                application.Quit();
                Marshal.ReleaseComObject(application);
                application = null;
            }
        }       
    }
}
